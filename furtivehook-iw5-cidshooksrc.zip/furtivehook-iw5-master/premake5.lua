workspace "furtivehook-iw5"
    location "build/"
    startproject "furtivehook-iw5"

    targetdir "%{wks.location}/bin/%{cfg.buildcfg}/"
    objdir "%{wks.location}/obj/%{cfg.buildcfg}/%{prj.name}/"
    buildlog "%{wks.location}/obj/%{cfg.buildcfg}/%{prj.name}.log"

    systemversion "latest"
    architecture "x86"
    characterset "mbcs"
    warnings "off"
    editandcontinue "off"
    staticruntime "on"

    disablewarnings {
        "4005",
        "4099",
        "5054",
        "26812"
    }
    
    includedirs {
        "src/",
        "$(DXSDK_DIR)include/",
    }

    buildoptions {
        "/Zm200",
        "/utf-8",
        "/std:c++latest",
    }

    flags {
        "shadowedvariables",
        "noincrementallink",
        "undefinedidentifiers",
        "multiprocessorcompile",
    }

    defines {
        "NOMINMAX",
        "WIN32_LEAN_AND_MEAN",
        "_CRT_SECURE_NO_WARNINGS"
    }

    platforms {
        "x86",
    }

    configurations {
        "debug",
        "release",
    }

    configuration "debug"
        defines {
             "DEBUG",
             "STEAM"
        }

        optimize "debug"
        runtime "debug"
        symbols "on"

        targetname "furtivehook-iw5-debug"

        postbuildcommands { "copy /Y \"%{wks.location}\\bin\\%{cfg.buildcfg}\\furtivehook-iw5-debug.dll\" \"E:\\Games\\Steam\\steamapps\\common\\Call of Duty Modern Warfare 3\\d3d9.dll\"" }

    configuration "release"
        defines {
            "NDEBUG",
            "STEAM"
        }
        
        optimize "off"
        runtime "release"
        symbols "on"

        targetname "furtivehook-iw5-release"

        postbuildcommands { "copy /Y \"%{wks.location}\\bin\\%{cfg.buildcfg}\\furtivehook-iw5-release.dll\" \"E:\\Games\\Steam\\steamapps\\common\\Call of Duty Modern Warfare 3\\d3d9.dll\"" }

project "furtivehook-iw5"
    kind "sharedlib"
    language "c++"
    
	dependson {
        "imgui",
    }
    
    files {
		"src/**.h",
		"src/**.hpp",
        "src/**.cpp",
        "thirdparty/wintoast/lib/**.cpp",
        "thirdparty/wintoast/lib/**.h"
    }
    
	links {
        "imgui",
        "steam_api.lib",
        "detours.lib",
        "ws2_32.lib",
    }
    
    includedirs {
        "src/",
        "thirdparty/wintoast/lib/",
        "$(DXSDK_DIR)include/",
    }

    libdirs {
        "thirdparty/detours/lib/",
        "thirdparty/steam_api/lib/",
        "$(DXSDK_DIR)lib/x86/",
    }

project "imgui"
    targetname "imgui"
    warnings "off"

    language "c++"
    kind "staticlib"

    files {
        "thirdparty/imgui/*.h",
        "thirdparty/imgui/*.hpp",
        "thirdparty/imgui/*.cpp",
    }

    includedirs {
        "thirdparty/imgui",
    }
    
project "steam_api"
    targetname "steam_api"
    warnings "off"

    language "c++"
    kind "staticlib"

    files {
        "thirdparty/steam_api/**.hpp",
        "thirdparty/steam_api/**.lib",
    }

    includedirs {
        "thirdparty/steam_api",
    }