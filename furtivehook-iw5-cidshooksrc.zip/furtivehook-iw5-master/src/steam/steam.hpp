#pragma once
#include "dependencies/std_include.hpp"

namespace steam
{
	bool get_p2p_session_state(const std::uint64_t steam_id);
	std::string get_friend_persona_name(const std::uint64_t steam_id, const std::string & name);
	const char * __cdecl steam_get_persona_name();
	int __stdcall on_begin_auth_session_reply(ValidateAuthTicketResponse_t * response);
	bool read_p2p_packet(uint64_t networking, void* buffer, uint32_t size, uint32_t* packet_size, CSteamID* xuid, int channel);
	void initialize();
	
	extern std::string persona_name;
	extern ISteamNetworking* networking;
}