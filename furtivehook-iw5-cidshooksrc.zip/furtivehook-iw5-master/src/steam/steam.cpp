#include "dependencies/std_include.hpp"

namespace steam
{
	auto steam_get_persona_name_original = reinterpret_cast<decltype(&steam_get_persona_name)>(0x00637300);
	ISteamNetworking* networking = nullptr; 
	std::string persona_name = "";

	bool get_p2p_session_state(const std::uint64_t steam_id)
	{
		P2PSessionState_t state{};
		const auto result = networking->GetP2PSessionState(steam_id, &state);

		if (result)
		{
			if (!state.m_bUsingRelay && state.m_nRemoteIP)
			{
				const auto inaddr = htonl(state.m_nRemoteIP); 
				
				char buffer[0x1000] = { 0 };
				inet_ntop(AF_INET, &inaddr, buffer, sizeof(buffer));
				
				PRINT_LOG("Session state info: (%llu) %s", steam_id, buffer);
			}
		}

		return result;
	}

	std::string get_friend_persona_name(const std::uint64_t steam_id, const std::string& name)
	{
		if (steam_id)
		{
			char steam_name[32] = {};
			game::Friends_Gamertag(0, steam_id, steam_name, sizeof steam_name);

			if (steam_name != nullptr
				&& *steam_name
				&& steam_name != "[unknown]"s
				&& steam_name != name)
			{
				return steam_name;
			}
		}

		return {};
	}

	const char* __cdecl steam_get_persona_name()
	{
		if (!persona_name.empty())
		{
			return persona_name.data();
		}

		return steam_get_persona_name_original();
	}

	auto on_begin_auth_session_reply_original = reinterpret_cast<decltype(&on_begin_auth_session_reply)>(0x006378F0);
	int __stdcall on_begin_auth_session_reply(ValidateAuthTicketResponse_t* response)
	{
		const auto user = response->m_SteamID;
		const auto owner = response->m_OwnerSteamID;

		if (user != owner)
		{
			PRINT_LOG("User (%llu) is using a shared account (%llu)", user, owner);
		}
		
		return on_begin_auth_session_reply_original(response);
	}
	
	auto read_p2p_packet_original = reinterpret_cast<decltype(&read_p2p_packet)>(0);

	bool read_p2p_packet(uint64_t networking, void* buffer, uint32_t size, uint32_t* packet_size, CSteamID* xuid, int channel)
	{
		PRINT_LOG("%x (%llu) %u %u", buffer, xuid->ConvertToUint64(), size, packet_size);
		return read_p2p_packet_original(networking, buffer, size, packet_size, xuid, channel);
	}
	
	void initialize()
	{
		utils::nt::library steam{ "steam_api.dll" }; 
		
		if (networking = steam.invoke<ISteamNetworking*>("SteamNetworking"))
		{
			//read_p2p_packet_original = utils::hook::vtable(networking, 2, &read_p2p_packet);
		}
		
		utils::hook::detour(&steam_get_persona_name_original, &steam_get_persona_name);
		utils::hook::detour(&on_begin_auth_session_reply_original, &on_begin_auth_session_reply);
	}
}
