#pragma once
#include "dependencies/std_include.hpp"

namespace utils::io
{
	void write_minidump(const LPEXCEPTION_POINTERS ex, const std::string & filename, const std::string & error = {});
	bool write_file(const std::string & file, const std::string & data, const bool append = false);
	bool create_directory(const std::string & directory);
	auto file_exists(const std::string & file);
	std::ifstream read_log(const std::string & name);
}