#pragma once

namespace utils
{
	class toast
	{
	public:
		static toast show(const std::string& title, const std::string& text = {});
		static toast show(const std::string& title, const std::string& text, const std::string& image);
		static void hide();

	private:
		toast(const std::int64_t id);
	};
}