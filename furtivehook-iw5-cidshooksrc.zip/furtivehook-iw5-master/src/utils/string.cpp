#include "dependencies/std_include.hpp"
#include "string.hpp"

namespace utils::string
{
	std::string adr_to_string(const game::XNADDR* address)
	{
		static auto adr = ""s;
		adr = utils::string::va("%u.%u.%u.%u:%u", address->ip[0], address->ip[1], address->ip[2], address->ip[3], address->port);

		return adr;
	}

	std::string adr_to_string(const game::netadr_t* address, const bool update_adr)
	{
		if (update_adr)
			game::dwUpdateNetadr(address);
		
		static auto adr = ""s;
		adr = utils::string::va("%u.%u.%u.%u:%u", address->ip[0], address->ip[1], address->ip[2], address->ip[3], address->port);

		return adr;
	}
	
	std::string format(const va_list ap, const char* message)
	{
		static thread_local char buffer[0x1000];

		const auto count = vsnprintf_s(buffer, sizeof(buffer), _TRUNCATE, message, ap);

		if (count < 0) return {};
		return { buffer, static_cast<size_t>(count) };
	}
	
	const char* va(const char* fmt, ...)
	{
		static thread_local va_provider<8, 4096> provider;

		va_list ap;
		va_start(ap, fmt);

		const auto* result = provider.get(fmt, ap);

		va_end(ap);
		return result;
	}

	std::string join(const std::vector<std::string>& args, const std::size_t index)
	{
		auto result = ""s;

		for (auto i = index; i < args.size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(args[i]);
		}

		return result;
	}

	std::vector<std::string> split(const std::string& text, const char delimiter)
	{
		std::stringstream ss(text);
		std::string item;
		std::vector<std::string> elems;

		while (std::getline(ss, item, delimiter))
		{
			elems.emplace_back(item);
		}

		return elems;
	}

	std::string replace_all(std::string str, const std::string& search, const std::string& replace)
	{
		if (search.empty())
		{
			return str;
		}
		
		std::string::size_type match;

		while ((match = str.find(search)) != std::string::npos)
		{
			str.replace(match, search.length(), replace);
		}

		return str;
	}

	bool begins_with(const std::string& text, const std::string& substring)
	{
		return text.find(substring) == 0;
	}

	bool contains(const std::string &sentence, const std::string &word)
	{
		return sentence.find(word) != std::string::npos;
	}

	std::string string_to_hex(const std::string& data)
	{
		static auto result = ""s;
		result = va("%X", data);

		return result;
	}

	std::string dump_hex(const std::string& data, const std::string& separator)
	{
		auto result = ""s;

		for (size_t i = 0; i < data.size(); ++i)
		{
			if (i > 0)
			{
				result.append(separator);
			}

			result.append(va("%02X", data[i] & 0xFF));
		}

		return result;
	}

	std::string reverse_words(std::string_view s)
	{
		std::string result;
		result.reserve(s.size());

		while (!s.empty())
		{
			const auto i = s.rfind(' ');
			result.append(s.begin() + i + 1, s.end());

			if (i == std::string_view::npos) break;

			s = s.substr(0, i);
		}

		return result;
	}

#pragma warning(push)
#pragma warning(disable: 4100)
	std::string convert(const std::wstring& wstr)
	{
		std::string result;
		result.reserve(wstr.size());

		for (const auto& chr : wstr)
		{
			result.push_back(static_cast<char>(chr));
		}

		return result;
	}

	std::wstring convert(const std::string& str)
	{
		std::wstring result;
		result.reserve(str.size());

		for (const auto& chr : str)
		{
			result.push_back(static_cast<wchar_t>(chr));
		}

		return result;
	}
#pragma warning(pop)

	std::string ltrim(const std::string& s)
	{
		return std::regex_replace(s, std::regex("^\\s+"), std::string(""));
	}

	std::string rtrim(const std::string& s)
	{
		return std::regex_replace(s, std::regex("\\s+$"), std::string(""));
	}

	std::string trim(const std::string& s)
	{
		return ltrim(rtrim(s));
	}

	std::string to_lower(std::string text)
	{
		std::transform(text.begin(), text.end(), text.begin(), [](const char input)
		{
			return static_cast<char>(std::tolower(input));
		});

		return text;
	}
}