#include "dependencies/std_include.hpp"
#include "io.hpp"

namespace utils::io
{
	void write_minidump(const LPEXCEPTION_POINTERS ex, const std::string& filename, const std::string& error)
	{
		const auto data = exception::minidump::create_minidump(ex);
		write_file(filename, data);

		if (!error.empty())
		{
			PRINT_LOG("%s", error.data());
		}
	}
	
	bool write_file(const std::string& file, const std::string& data, const bool append)
	{
		const auto pos = file.find_last_of("/\\");
		if (pos != std::string::npos)
		{
			create_directory(file.substr(0, pos));
		}

		std::ofstream stream(file, std::ios::binary | std::ofstream::out | (append ? std::ofstream::app : 0));

		if (stream.is_open())
		{
			stream.write(data.data(), data.size());
			stream.close();

			return true;
		}

		return false;
	}
	
	bool create_directory(const std::string& directory)
	{
		return std::filesystem::create_directories(directory);
	}

	auto file_exists(const std::string& file)
	{
		return std::ifstream(file).good();
	}

	std::ifstream read_log(const std::string& name)
	{
		char path[MAX_PATH] = { 0 };
		GetModuleFileNameA(nullptr, path, sizeof path);
		PathRemoveFileSpecA(path);

		std::strcat(path, "\\");
		std::strcat(path, name.data());

		if (file_exists(path))
		{
			std::ifstream file(path, std::ios_base::in);

			return file;
		}
	}
}