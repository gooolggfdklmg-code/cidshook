#include "dependencies/std_include.hpp"
#include "toast.hpp"
#include "../thirdparty/wintoast/lib/wintoastlib.h"

namespace utils
{
	std::vector<std::int64_t> ids;
	
	namespace
	{
		bool initialize()
		{
			static bool initialized = false;
			static bool success = false;
			if (initialized)
			{
				return success;
			}

			initialized = true;
			auto* instance = WinToastLib::WinToast::instance();
			if (!instance)
			{
				success = false;
				return success;
			}

			instance->setAppName(L"furtivehook");
			instance->setAppUserModelId(
				WinToastLib::WinToast::configureAUMI(L"furtivehook", L"iw5mp"));

			WinToastLib::WinToast::WinToastError error;
			success = instance->initialize(&error);

			return success;
		}

		class toast_handler : public WinToastLib::IWinToastHandler
		{
		public:
			void toastActivated() const override
			{
			}

			void toastActivated(const int /*actionIndex*/) const override
			{
			}

			void toastFailed() const override
			{
			}

			void toastDismissed(WinToastDismissalReason /*state*/) const override
			{
			}
		};
	}

	toast::toast(const std::int64_t id)
	{
		ids.emplace_back(id);
	}

	void toast::hide()
	{
		for (const auto& id : ids)
		{
			WinToastLib::WinToast::instance()->hideToast(id);
		}
	}

	toast toast::show(const std::string& title, const std::string& text)
	{
		if (!initialize())
		{
			return toast{ -1 };
		}

		WinToastLib::WinToastTemplate toast_template(WinToastLib::WinToastTemplate::Text02);
		toast_template.setTextField(string::convert(title), WinToastLib::WinToastTemplate::FirstLine);
		toast_template.setTextField(string::convert(text), WinToastLib::WinToastTemplate::SecondLine);
		toast_template.setDuration(WinToastLib::WinToastTemplate::System);

		return toast{ WinToastLib::WinToast::instance()->showToast(toast_template, new toast_handler()) };
	}

	toast toast::show(const std::string& title, const std::string& text, const std::string& image)
	{
		if (!initialize())
		{
			return { -1 };
		}

		WinToastLib::WinToastTemplate toast_template(WinToastLib::WinToastTemplate::ImageAndText02);
		toast_template.setTextField(string::convert(title), WinToastLib::WinToastTemplate::FirstLine);
		toast_template.setTextField(string::convert(text), WinToastLib::WinToastTemplate::SecondLine);
		toast_template.setDuration(WinToastLib::WinToastTemplate::Short);
		toast_template.setImagePath(string::convert(image));

		return { WinToastLib::WinToast::instance()->showToast(toast_template, new toast_handler()) };
	}
}