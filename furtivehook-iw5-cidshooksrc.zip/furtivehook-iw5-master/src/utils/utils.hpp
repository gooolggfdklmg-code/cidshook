#pragma once
#include "dependencies/std_include.hpp"

#define CONSOLE_LOG "console_log.hpp"
#define PRINT_MESSAGE(format, ...) game::CG_GameMessage(0, format)
#define PRINT_BOLD_MESSAGE(format, ...) game::CG_BoldGameMessage(0, format)

#define PRINT_LOG_DETAILED(format, ...)																							\
{																																\
    std::printf(utils::string::va("[%s] %s\n", __FUNCTION__, format), __VA_ARGS__);												\
    logger::print_log(utils::string::va("[%s] %s", __FUNCTION__, format), __VA_ARGS__);											\
}

#define PRINT_LOG(format, ...)																									\
{																																\
	std::printf(utils::string::va("%s\n", format), __VA_ARGS__);																\
    logger::print_log(format, __VA_ARGS__);																						\
}

namespace utils
{
	void close_console();
	std::uint32_t floating_point_to_hex(const float value);
	void open_console();
	std::string generate_log_filename(const std::string & dir, const std::string& ext = "log");

	template <typename T>
	static auto atoi(const std::string& str)
	{
		return static_cast<T>(std::atoi(str.data()));
	}

	static auto atoi(const std::string& str)
	{
		return static_cast<std::uint32_t>(std::atoi(str.data()));
	}

	static auto atoll(const std::string& str)
	{
		return static_cast<std::uint64_t>(std::atoll(str.data()));
	}
}
