#pragma once

namespace offsets
{
	constexpr static auto cg_t = 0x00900FA0;
	constexpr static auto g_partyJoinInfo = 0x001333D80;
	constexpr static auto g_p2pAuthManager = 0x06C0CCB0;
	constexpr static auto gclient_t = 0x01C2D440;
	constexpr static auto clientActive_t = 0x001062790;
	constexpr static auto weaponCompleteDefs = 0x008DFD88;
	constexpr static auto end_address = 0x007E0000;

	constexpr static auto Dvar_FindVar = 0x005BDCC0;
	
	constexpr static auto GScr_AllocString = 0x00517400;
	constexpr static auto Com_GetClientDObj = 0x00556A30;
	constexpr static auto CG_DObjGetWorldTagPos = 0x0044D9D0;

	constexpr static auto damage_table = 0x0008E0148;
	constexpr static auto BG_AdvanceTrace = 0x0042FFC0;
	constexpr static auto BG_GetDamage = 0x00432800;
	constexpr static auto BG_GetMinDamage = 0x004328C0;
	constexpr static auto BG_GetPlayerDamageRange = 0x00432BF0;
	constexpr static auto Trace_GetEntityHitId = 0x0053ED10;
	
	constexpr static auto CG_GetPlayerViewOrigin = 0x0047C220;
	constexpr static auto server_id = 0x01065AF8;

	constexpr static auto vectoangles = 0x005B2EE0;
	constexpr static auto prestige = 0x01CE6EAF;
	constexpr static auto g_localSteamClient = 0x05CF0500;
	constexpr static auto g_partyData = 0x01336668;
	constexpr static auto g_lobbyData = 0x0132ECA0;

	constexpr auto match_data = 0x02116D80;
}