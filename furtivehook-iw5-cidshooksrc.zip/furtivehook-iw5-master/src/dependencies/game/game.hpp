#pragma once
#include "structs.hpp"
#include "offsets.hpp"
#include "core/command/command.hpp"

namespace game
{
	enum class shader
	{
		white,
		lagometer,
		num_shaders,
	};
	
	enum class bone_tag
	{
		helmet,
		head_end,
		head,
		neck,
		shoulder_left,
		shoulder_right,
		clavicle_left,
		clavicle_right,
		spineupper,
		spine,
		spinelower,
		hip_left,
		hip_right,
		knee_left,
		knee_right,
		wrist_left,
		wrist_right,
		wrist_twist_left,
		wrist_twist_right,
		elbow_left,
		elbow_right,
		elbow_buldge_left,
		elbow_buldge_right,
		ankle_left,
		ankle_right,
		ball_left,
		ball_right,
		mainroot,
		num_tags,
	};

	const static auto SV_GetClientPersistentDataBuffer = reinterpret_cast<StructuredDataBuffer*(*)(ClientNum_t)>(0x005703A0);
	const static auto SV_GetClientPersistentDataModifiedFlags = reinterpret_cast<uint8_t*(*)(ClientNum_t)>(0x005703B0);
	const static auto StringTable_GetAsset = reinterpret_cast<StringTable*(*)(const char*, const StringTable**)>(0x005B87D0);
	const static auto StringTable_GetColumnValueForRow = reinterpret_cast<const char*(*)(const StringTable*, const int, const int)>(0x005B86A0);
	const static auto StringTable_LookupRowNumForValue = reinterpret_cast<int(*)(const StringTable*, const int, const char*)>(0x005B8610);
	const static auto StringTable_Lookup = reinterpret_cast<const char*(*)(const StringTable*, const int, const char*, const int)>(0x005B86E0);
	const static auto LiveStorage_SetPlayerCardItemFieldByName = reinterpret_cast<const char*(*)(LocalClientNum_t, const char*, const char*, const char*, int, bool)>(0x0054A420);
	const static auto Live_SyncOnlineDataFlags = reinterpret_cast<int(*)(LocalClientNum_t)>(0x0064EAA0);
	const static auto Xenon_GetXNAddr = reinterpret_cast<game::XNADDR(*)(void*)>(0x005CAA80);
	const static auto Sys_IsDatabaseThread = reinterpret_cast<bool(*)()>(0x0055FB50);
	const static auto MSG_ReadStringLine = reinterpret_cast<char*(*)(msg_t *msg, char *string, unsigned int maxChars)>(0x005591A0);
	const static auto Scr_IsValidGameType = reinterpret_cast<bool(*)(const char*)>(0x00527AD0);
	const static auto Steam_SendIntroducerMSG = reinterpret_cast<bool(*)(uint64_t)>(0x0063AB60);
	const static auto Steam_SendP2PPacket = reinterpret_cast<bool(*)(uint64_t, const void*, unsigned int, int, int)>(0x0063AB30);
	const static auto Party_GetPlaylistEntry = reinterpret_cast<int(*)(PartyData_s *)>(0x004A2F60);
	const static auto CL_Netchan_Transmit = reinterpret_cast<bool(*)(void*, void*, size_t)>(0x004953A0); 
	const static auto G_GetClientState = reinterpret_cast<int(*)(int)>(0x0050BF40);
	const static auto dwCommonAddrToNetadr = reinterpret_cast<bool(*)(netadr_t* netadr, const void* commonAddrBuf, const void* secID)>(0x006152B0);
	const static auto dwRegisterSecIDAndKey = reinterpret_cast<bool(*)(const game::bdSecurityID* id, const game::bdSecurityKey* key)>(0x00613F00);
	const static auto CL_DeathMessageIconDimension = reinterpret_cast<int(*)(float)>(0x00487BC0);
	const static auto BG_GetSpreadForWeapon = reinterpret_cast<void(*)(game::playerState_s const*, Weapon, float*, float*)>(0x00438950);
	const static auto BG_srand = reinterpret_cast<std::uint32_t*(*)(std::uint32_t* serverTime)>(0x004237A0);
	const static auto BG_random = reinterpret_cast<float(*)(std::uint32_t* serverTime)>(0x00421ED0);
	const static auto PartyAtomicHost_SendMemberJoin = reinterpret_cast<void(*)(PartyJoinInfo*)>(0x004B0690);
	const static auto BG_ADSSpread = reinterpret_cast<float(*)(Weapon, bool)>(0x00434580); 
	const static auto G_SoundAliasIndex = reinterpret_cast<int(*)(const char*)>(0x0052DE80);
	const static auto ClientUserinfoChanged = reinterpret_cast<void(*)(int)>(0x004FADB0);
	const static auto CL_GetCurrentCmdNumber = reinterpret_cast<int(*)()>(0x00484420);
	const static auto CL_GetUserCmd = reinterpret_cast<bool(*)(int, int, usercmd_s*)>(0x004843D0);
	const static auto Party_IsHosting = reinterpret_cast<bool(*)(game::PartyData_s*, size_t)>(0x004A5100);
	const static auto Friends_Gamertag = reinterpret_cast<char*(*)(LocalClientNum_t, std::uint64_t, char*, int)>(0x006491B0);
	const static auto UI_GetMapDisplayName = reinterpret_cast<const char*(*)(const char*)>(0x00590640);
	const static auto SV_GetAssignedTeam_Internal = reinterpret_cast<int(*)(size_t)>(0x005777F0);
	const static auto Party_GetAssignedTeam = reinterpret_cast<int(*)(game::PartyData_s*, std::uint64_t)>(0x004A2EC0);
	const static auto PartyAtomic_AcceptInviteMP = reinterpret_cast<void(*)(int, const void*, bool)>(0x004B1050);
	const static auto& map_handler = reinterpret_cast<MapnameRichPresenceInfo*>(0x00814738);
	const static auto& user_groups_handler = reinterpret_cast<handler_t*>(0x00823860);
	const static auto& p2p_auth_manager_handler = reinterpret_cast<handler_t*>(0x0083FE60);
	const static auto& party_migrate_handler = reinterpret_cast<handler_t*>(0x007F6268);
	const static auto& party_host_handler = reinterpret_cast<handler_t*>(0x007F9C88);
	const static auto ScrPlace_GetActivePlacement = reinterpret_cast<void*(*)()>(0x004B7610);
	const static auto RegisterShader = reinterpret_cast<std::uint32_t(*)(char* name)>(0x00674780); 
	const static auto SV_GetGuid = reinterpret_cast<const char*(*)(size_t client_num)>(0x00573990);
	const static auto SV_ExecuteClientCommand = reinterpret_cast<void(*)(game::client_t* client, const char *s, bool clientOK, bool fromOldServer)>(0x00571880); 
	const static auto BG_IsThirdPersonMode = reinterpret_cast<bool(*)(game::cg_t* cg)>(0x0041BDB0);
	const static auto I_strncpyz = reinterpret_cast<void(*)(char*, const char*, size_t)>(0x005C2940);
	const static auto SV_DropClient = reinterpret_cast<void(*)(game::client_t* client, const char* s, bool tell_them)>(0x00570980);
	const static auto Scr_Notify = reinterpret_cast<void(*)(game::gentity_s* entity, std::uint16_t value, size_t params)>(0x0052B190);
	const static auto SL_GetString = reinterpret_cast<int(*)(const char* s, size_t user)>(0x005649E0);
	const static auto& max_clients = *reinterpret_cast<size_t*>(0x4B5CF8C); 
	const static auto BG_NetDataChecksum = reinterpret_cast<int(*)()>(0x0041BB20);
	const static auto Steam_ShowSteamUserOverlay = reinterpret_cast<void(*)(std::uint64_t xuid)>(0x00638E90);
	const static auto LiveStorage_GetPersistentDataDefVersion = reinterpret_cast<int(*)()>(0x00548D60);
	const static auto LiveStorage_GetPersistentDataDefFormatChecksum = reinterpret_cast<int(*)()>(0x00548D80);
	const static auto SV_Cmd_TokenizeString = reinterpret_cast<void(*)(const char* string)>(0x00545D40);
	const static auto SV_DirectConnect = reinterpret_cast<void(*)(game::netadr_t adr)>(0x00572750);
	const static auto SV_Cmd_EndTokenizedString = reinterpret_cast<void(*)()>(0x00545D70);
	const static auto SV_ClientEnterWorld = reinterpret_cast<void(*)(game::client_t* client, game::usercmd_s* usercmd)>(0x00571100); 
	const static auto window = *reinterpret_cast<HWND*>(0x005AA3930);
	const static auto device = reinterpret_cast<IDirect3DDevice9**>(0x005FC0C28);
	const static auto& server_id = *reinterpret_cast<std::uint8_t*>(offsets::server_id);
	const static auto& g_partyData = reinterpret_cast<game::PartyData_s*>(0x01336668);
	const static auto& g_lobbyData = reinterpret_cast<game::PartyData_s*>(0x0132ECA0);
	const static auto& g_serverSession = reinterpret_cast<game::PartyData_s*>(0x05C6B5F0);
	const static auto AngleVectors = reinterpret_cast<void(*)(const Vec3 * angles, Vec3 * forward, Vec3 * right, Vec3 * up)>(0x005B6360);
	const static auto BG_GetViewmodelWeaponIndex = reinterpret_cast<int(*)(const game::playerState_s*)>(0x0042FB10);
	const static auto BG_WeaponIsDualWield = reinterpret_cast<bool(*)(int a1)>(0x00438420);
	const static auto CL_IsLocalClientInGame = reinterpret_cast<bool(*)()>(0x0048EE50);
	const static auto MSG_ReadData = reinterpret_cast<char*(*)(game::msg_t* msg, void* data, size_t len)>(0x005592A0);
	const static auto MSG_ReadByte = reinterpret_cast<std::uint8_t(*)(game::msg_t* msg)>(0x00558F70);
	const static auto MSG_ReadBits = reinterpret_cast<std::uint32_t(*)(game::msg_t* msg, int bits)>(0x00558E90);
	const static auto MSG_ReadInt64 = reinterpret_cast<std::uint64_t(*)(game::msg_t* msg)>(0x00559030);
	const static auto MSG_ReadLong = reinterpret_cast<std::uint32_t(*)(game::msg_t* msg)>(0x00558FF0);
	const static auto Com_Quit_f = reinterpret_cast<void(*)()>(0x005556B0);
	const static auto Cbuf_AddText = reinterpret_cast<std::uint32_t(*)(LocalClientNum_t localClientNumber, const char* text)>(0x00545680);
	const static auto Cmd_ExecuteSingleCommand = reinterpret_cast<std::uint32_t(*)(LocalClientNum_t localClientNumber, int, const char* text)>(0x005462B0);
	const static auto CG_GameMessage = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, const char* message)>(0x00456DC0);
	const static auto CG_BoldGameMessage = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, const char* message)>(0x00456DF0);
	const static auto Dvar_FindVar = reinterpret_cast<dvar_t*(*)(const char* dvarName)>(offsets::Dvar_FindVar);
	const static auto Com_Error = reinterpret_cast<void(*)(errorParm_t errorType, const char* text)>(0x00555450);
	const static auto Sys_GetValue = reinterpret_cast<int(*)(int valueIndex)>(0x0055FBC0);
	const static auto Sys_Milliseconds = reinterpret_cast<std::uint32_t(*)()>(0x005CE740);
	const static auto IN_Activate = reinterpret_cast<void(*)(bool open)>(0x005C92A0);
	const static auto GScr_AllocString = reinterpret_cast<std::uint32_t(*)(const char* s)>(offsets::GScr_AllocString);
	const static auto Com_GetClientDObj = reinterpret_cast<char*(*)(int handle)>(offsets::Com_GetClientDObj);
	const static auto CG_DObjGetWorldTagPos = reinterpret_cast<std::uint32_t(*)(const game::centity_t * entity, void* obj, std::uint32_t tagName, Vec3* pos)>(offsets::CG_DObjGetWorldTagPos);
	const static auto BG_AdvanceTrace = reinterpret_cast<bool(*)(game::BulletFireParams* bp, game::BulletTraceResults* br, float distance)>(offsets::BG_AdvanceTrace);
	const static auto BG_WeaponBulletFire_ShouldPenetrate = reinterpret_cast<bool(*)(unsigned int* perks, Weapon weapon, bool alternate)>(0x00431250);
	const static auto BG_GetSurfacePenetrationDepth = reinterpret_cast<float(*)(Weapon weapon, bool alt, int surfaceType)>(0x0042F4D0);
	const static auto CG_ClientHasPerk = reinterpret_cast<bool(*)(std::uint32_t* perk, std::uint32_t b)>(0x0040FEE0);
	const static auto BG_GetDamage = reinterpret_cast<int(*)(Weapon weapon, Weapon alt)>(offsets::BG_GetDamage);
	const static auto BG_GetMinDamage = reinterpret_cast<int(*)(Weapon weapon, Weapon alt)>(offsets::BG_GetMinDamage);
	const static auto G_GetWeaponHitLocationMultiplier = reinterpret_cast<float(*)(std::uint16_t, Weapon, bool)>(0x005036B0);
	const static auto BG_GetPlayerDamageRange = reinterpret_cast<int(*)(std::uint32_t* perks, Weapon weapon, bool alt, float* min_damage_range, float* max_damage_range)>(offsets::BG_GetPlayerDamageRange);
	const static auto Trace_GetEntityHitId = reinterpret_cast<std::uint16_t(*)(const game::trace_t* results)>(offsets::Trace_GetEntityHitId);
	const static auto BG_GetAltWeapon = reinterpret_cast<Weapon(*)(Weapon weapon)>(0x004383D0);
	const static auto damage_table = reinterpret_cast<float*>(offsets::damage_table);
	const static auto CG_GetPlayerViewOrigin = reinterpret_cast<bool(*)(LocalClientNum_t localClientNum, playerState_s * ps, Vec3* outvec)>(offsets::CG_GetPlayerViewOrigin);
	const static auto vectoangles = reinterpret_cast<void(*)(const Vec3* vec, Vec3* angles)>(offsets::vectoangles);
	const static auto MSG_Init = reinterpret_cast<void(*)(game::msg_t * buf, char* data, int length)>(0x00558830);
	const static auto MSG_WriteData = reinterpret_cast<void(*)(game::msg_t *buf, const void *data, size_t length)>(0x00558C00);
	const static auto MSG_WriteString = reinterpret_cast<void(*)(game::msg_t * sb, const char* s)>(0x00558CF0);
	const static auto MSG_WriteInt64 = reinterpret_cast<void(*)(game::msg_t * msg, uint64_t c)>(0x00558CA0);
	const static auto MSG_WriteShort = reinterpret_cast<void(*)(game::msg_t * msg, int c)>(0x00558C40);
	const static auto MSG_WriteByte = reinterpret_cast<void(*)(game::msg_t * msg, int c)>(0x00558BD0);
	const static auto MSG_WriteBool = reinterpret_cast<void(*)(game::msg_t * msg, int c)>(0x00558A20);
	const static auto MSG_WriteLong = reinterpret_cast<void(*)(game::msg_t *msg, int c)>(0x00558C70);
	const static auto MSG_WriteBits = reinterpret_cast<void(*)(game::msg_t *msg, int value, int bits)>(0x00558A70);
	const static auto MSG_ReadShort = reinterpret_cast<std::uint16_t(*)(game::msg_t *msg)>(0x00558FB0);
	const static auto MSG_ReadString = reinterpret_cast<char*(*)(msg_t *msg, char *string, unsigned int maxChars)>(0x00559090);
	const static auto Info_ValueForKey = reinterpret_cast<char*(*)(const char *s, const char *key)>(0x005C2DB0);
	const static auto NET_OutOfBandData = reinterpret_cast<bool(*)(game::netsrc_t sock, game::netadr_t adr, const char* format, int len)>(0x0055C8F0);
	const static auto NET_OutOfBandPrint = reinterpret_cast<bool(*)(game::netsrc_t sock, game::netadr_t adr, const char* format)>(0x0055C830);
	const static auto RMsg_AddPrint = reinterpret_cast<bool(*)(game::netadr_t const* adr, const char* data)>(0x005C4550);
	const static auto RMsg_SendMessages = reinterpret_cast<void(*)()>(0x005C3EF0);
	const static auto RMSG_AddMessage = reinterpret_cast<bool(*)(game::netadr_t const* adr, game::msg_t* msg)>(0x005C4530);
	const static auto SV_SendServerCommandMsg = reinterpret_cast<bool(*)(game::client_t* client, std::uint32_t type, game::msg_t *msg)>(0x00575E80);
	const static auto SV_GameSendServerCommand = reinterpret_cast<void(*)(ClientNum_t clientNum, std::uint32_t type, const char *text)>(0x00573220);
	const static auto CL_CanWeConnectToClient = reinterpret_cast<int(*)(void *sessionData, ClientNum_t ourClientNum, ClientNum_t theirClientNum)>(0x004986D0);
	const static auto Live_GetXuid = reinterpret_cast<std::uint64_t(*)(ControllerIndex_t controllerIndex)>(0x005C93C0);
	const static auto CL_SendPeerData = reinterpret_cast<bool(*)(void * session, int localClientNum, game::netsrc_t sock, int clientNum, game::msg_t * msg, int dataType)>(0x00499CD0);
	const static auto Party_FindMember = reinterpret_cast<int(*)(game::PartyData_s * party, game::netadr_t playerAddr)>(0x004A2E80);
	const static auto dwUpdateNetadr = reinterpret_cast<bool(*)(const netadr_t* netadr)>(0x00614810);
	const static auto dwNetadrToCommonAddr = reinterpret_cast<bool(*)(netadr_t netadr, void* commonAddrBuf, const unsigned int size, void* secID)>(0x00614400);
	const static auto Session_GetPlayerAddr = reinterpret_cast<void(*)(netadr_t* netadr, void* sess, int client)>(0x006117A0);
	const static auto NET_StringToAdr = reinterpret_cast<bool(*)(const char* s, netadr_t* a)>(0x0055CA40);
	const static auto NET_CompareAdr = reinterpret_cast<bool(*)(netadr_t a, netadr_t b)>(0x0055C190);
	const static auto NET_CompareBaseAdr = reinterpret_cast<bool(*)(netadr_t a, netadr_t b)>(0x0055C110);
	const static auto& sv_cmd_argc = reinterpret_cast<std::uint32_t*>(0x1CAA9DC);
	const static auto& sv_cmd_id = reinterpret_cast<std::uint32_t*>(0x1CAA998);
	const static auto& cmd_argc = reinterpret_cast<std::uint32_t*>(0x1C97914);
	const static auto& cmd_id = reinterpret_cast<std::uint32_t*>(0x1C978D0);
	const static auto NET_SendPacket = reinterpret_cast<bool(*)(int sock, size_t size, const void* data, netadr_t adr)>(0x0055C790);
	const static auto Cmd_Argv = reinterpret_cast<char*(*)(int index)>(0x00467600);
	const static auto SV_Cmd_Argv = reinterpret_cast<char*(*)(int index)>(0x005455D0);
	const static auto& bg_lastParsedWeaponIndex = *reinterpret_cast<std::uint32_t*>(0x08E0338);
	const static auto UI_OpenMenu = reinterpret_cast<int(*)(int a, const char* b)>(0x0058FB40);
	const static auto Menu_IsMenuOpenAndVisible = reinterpret_cast<int(*)(int, const char*)>(0x0058FAF0);
	const static auto CL_GetClientName = reinterpret_cast<char*(*)(LocalClientNum_t, int, char*, int)>(0x004981C0);
	const static auto CL_DrawStretchPic = reinterpret_cast<void(*)(void *scrPlace, float x, float y, float w, float h, int horzAlign, int vertAlign, float s1, float t1, float s2, float t2, const ImVec4* color, int material)>(0x00484BF0);
	const static auto UI_DrawHandlePic = reinterpret_cast<void(*)(void* scrPlace, float x, float y, float w, float h, int horz, int vert, const ImVec4* color, int material)>(0x0057ED70);
	const static auto Steam_GetSteamLobbyID = reinterpret_cast<std::uint64_t(*)()>(0x00637430);
	const static auto Steam_JoinLobby = reinterpret_cast<bool(*)(std::uint64_t xuid, bool b)>(0x0063A7B0);
	const static auto Live_StartAcceptingInvitation = reinterpret_cast<int(*)(std::uint64_t, bool b, bool c)>(0x005C9DF0);
	const static auto Live_StartConfirmAcceptInvitation = reinterpret_cast<bool(*)()>(0x0064F290);
	const static auto Party_FillInOurMemberInfo = reinterpret_cast<void(*)(PartyData_s*, int, void*)>(0x004A3500);
	const static auto Party_WriteMemberInfo = reinterpret_cast<void(*)(game::msg_t*, void*)>(0x004A5260);
	const static auto Party_ReadMemberInfo = reinterpret_cast<void(*)(game::msg_t*, void*)>(0x004A53E0);
	const static auto Sys_ChecksumCopy = reinterpret_cast<std::uint16_t(*)(char*, char*, int)>(0x005CD2C0);
	const static auto PartyAtomic_ReadJoinIdentifier = reinterpret_cast<void(*)(game::msg_t*, void*, void*)>(0x004AF840);
	const static auto bdSecurity_ID = reinterpret_cast<void(__fastcall*)(bdSecurityID*)>(0x006EECB0);
	const static auto ClampChar = reinterpret_cast<char(*)(int)>(0x005B26D0);
	const static auto GetHandshakeTicket = reinterpret_cast<bool(__thiscall*)(void*, void*)>(0x006BEBB0);
	const static auto CreateHandshakeTicket = reinterpret_cast<bool(__thiscall*)(void*, bool)>(0x006BF4F0);
	const static auto Scr_GetSelf = reinterpret_cast<std::uint32_t(*)(std::uint32_t)>(0x00565F60);
	const static auto SL_ConvertToString = reinterpret_cast<const char*(*)(std::uint32_t)>(0x00564270);
	const static auto Scr_AddString = reinterpret_cast<void(*)(const char*)>(0x0056AC00);
	const static auto Scr_AddInt = reinterpret_cast<void(*)(int)>(0x0056AA20);
	const static auto Scr_ClearOutParams = reinterpret_cast<void(*)()>(0x00569010);
	const static auto GScr_MakeDvarServerInfo = reinterpret_cast<void(*)()>(0x005256E0);
	const static auto GScr_SetPlayerData = reinterpret_cast<void(*)(size_t)>(0x00522920);
	const static auto GScr_SetDvar = reinterpret_cast<void(*)()>(0x00517AB0);
	const static auto Dvar_SetFromStringByNameFromSource = reinterpret_cast<dvar_t*(*)(const char*, const char*, int)>(0x005BF6D0);
	const static auto SV_Loaded = reinterpret_cast<bool(*)()>(0x005741E0);
	const static auto XNKIDToString = reinterpret_cast<void(*)(void *, char*, size_t)>(0x0055CC70);
	const static auto PLAYER_NAME = reinterpret_cast<char*>(0x05A966C4);
	const static auto BG_WeaponBulletFire_ShouldSpread = reinterpret_cast<bool(*)(std::uint32_t*, Weapon, bool)>(0x00438F00);
	const static auto Session_AreWeHost = reinterpret_cast<bool(*)(void* sess)>(0x00632B80);
	const static auto Dvar_AddFlags = reinterpret_cast<void(*)(dvar_t *dvar, int flags)>(0x005BF760);
	const static auto G_GetWeaponForName = reinterpret_cast<std::uint32_t(*)(const char*)>(0x00531070);
	const static auto BG_AddClipAmmo = reinterpret_cast<int(*)(game::playerState_s*, int clip, int hand_index, int count)>(0x0042E8F0);
	const static auto BG_ClipForWeapon = reinterpret_cast<int(*)(Weapon, bool)>(0x0042E560);
	const static auto Dvar_SetStringByName = reinterpret_cast<void(*)(const char*, const char*)>(0x005BF660);
	const static auto Cbuf_AddCall = reinterpret_cast<void(*)(LocalClientNum_t, void(*)(LocalClientNum_t))>(0x00545720);
	const static auto UI_Map = reinterpret_cast<void(*)(LocalClientNum_t)>(0x0058D020);
	const static auto BG_AmmoForWeapon = reinterpret_cast<std::uint32_t(*)(Weapon, bool)>(0x0042E440);
	const static auto BG_PlayerHasRoomForAmmo = reinterpret_cast<bool(*)(const playerState_s*, Weapon, bool)>(0x004199C0);
	const static auto CG_IsPlayerReloading = reinterpret_cast<bool(*)()>(0x00479E20);
	const static auto XUIDToString = reinterpret_cast<void(*)(const std::uint64_t*, char*) > (0x0055CC20);
	const static auto IsServerRunning = reinterpret_cast<bool(*)()>(0x0064E640);
	const static auto Com_BlockChecksumKey32 = reinterpret_cast<std::uint32_t(*)(const void *, unsigned int, unsigned int)>(0x00610180);
	const static auto Dvar_IsValidCodInfoDvar = reinterpret_cast<bool(*)(const char *)>(0x005BC700);
	const static auto& g_statsBackup = reinterpret_cast<void*>(0x00B0DB00);
	const static auto DB_GetMaterialIndex = reinterpret_cast<int(*)(void*)>(0x004CB8E0);
	const static auto Material_Register = reinterpret_cast<Material*(*)(const char*)>(0x00674760);
	const static auto Steam_GetInviteHostInfo = reinterpret_cast<XSESSION_INFO*(*)()>(0x00637420);
	const static auto CL_GetConfigString = reinterpret_cast<const char*(*)(int)>(0x004849D0);
	const static auto DB_EnumXAssets_Internal = reinterpret_cast<void(*)(XAssetType type, void(*)(void*, void*), const void* inData, bool includeOverride)>(0x004CA240);
	const static auto DB_GetXAssetName = reinterpret_cast<const char*(*)(const XAsset*)>(0x004B7C10);
	const static auto LiveStorage_MaySetPersistentData = reinterpret_cast<bool(*)()>(0x00548630);
	const static auto LiveStorage_GetPersistentDataBuffer = reinterpret_cast<StructuredDataBuffer*(*)(LocalClientNum_t)>(0x00549020);
	const static auto LiveStorage_StatsWriteNeeded = reinterpret_cast<void(*)(LocalClientNum_t)>(0x00549060);
	const static auto StructuredDataDef_GetAsset = reinterpret_cast<void*(*)(const char*, int)>(0x005B9D10);
	const static auto StructuredData_InitializeLookup = reinterpret_cast<void(*)(void*, void*)>(0x005B88A0);
	const static auto StructuredData_NavigateByStrings = reinterpret_cast<bool(*)(void*, char const* const*, int, int*)>(0x005B9D80);
	const static auto LiveStorage_SetLookedUpDataFromString = reinterpret_cast<int(*)(StructuredDataLookup *, StructuredDataBuffer*, uint8_t*, char const*)>(0x00548470);
	const static auto& g_p2pAuthManager = reinterpret_cast<void*>(offsets::g_p2pAuthManager);
	const static auto& com_errorMessage = reinterpret_cast<const char*>(0x01CEFB08);
	const static auto& errorCode = *reinterpret_cast<int*>(0x01CEFB00);
	const static auto& com_errorEnteredCount = *reinterpret_cast<int*>(0x01CF0B70);
	const static auto& g_ourXnaddr = reinterpret_cast<XNADDR*>(0x05ADBF98);
	const static auto& persistentData = reinterpret_cast<StructuredDataBuffer*>(0x01CE43A0);
	static auto& g_minPing = *reinterpret_cast<int*>(0x05CC6AC8);
	static auto& g_inLobby = *reinterpret_cast<bool*>(0x05CF04E9);
	static auto& g_IWLobbyJoinInProgress = *reinterpret_cast<bool*>(0x005CF04EB);
	static auto& inviteState = *reinterpret_cast<std::uint32_t*>(0x05AA2D58);
	const static auto& match_data = reinterpret_cast<void*>(offsets::match_data);
	
	extern std::array<std::uint32_t, static_cast<std::size_t>(shader::num_shaders)> shaders;
	extern std::array<scr_string_t, static_cast<std::size_t>(bone_tag::num_tags)> bone_tags;
	extern std::unordered_map<std::string, bool> handlers;
	extern game::PartyData_s* party;
	extern dvar_t* cl_maxpackets;
	extern dvar_t* perk_bullet_penetration_multiplier;
	extern dvar_t* validate_drop_on_fail;
	
	void initialize();
	bool AimTarget_GetTagPos(const game::centity_t * cent, const scr_string_t& tag_name, Vec3 * end);
	bool is_valid_target(const size_t client_num);
	int CL_GetLocalClientConnectionState();
	int CL_GetLocalClientMigrationState();
	void adjust_user_cmd_moves(game::usercmd_s * cmd, const float angle, const float old_angle, const float old_forward_move, const float old_right_move);
	int Party_FindMemberByXUID(const std::uint64_t player);
	int get_held_weapon_slot(game::playerState_s * ps, std::uint32_t weapon);
	bool user_is_registered(game::PartyData_s * party, size_t client);
	bool CG_WorldPosToScreenPos(const Vec3 * world_pos, Vec2 * out_pos);
	bool NET_CompareXNAddr(const XNADDR *a1, const XNADDR *a2);
	bool is_enemy(size_t client_num);
	bool has_alt_weapon(Weapon weapon);
	int find_target_from_addr(PartyData_s * party, const netadr_t & from);
	void send_server_command_crashes(const int index = -1);
	void on_every_frame();
	void CG_AddLagometerFrameInfo(game::lagometer_t & lagometer);
	void CG_AddLagometerSnapshotInfo(game::lagometer_t & lagometer, const game::snapshot_s * snap);
	bool is_packet_from_host(const netadr_t & from);
	bool send_exploit_caught_messages(const std::string & command, const netadr_t & target);
	bool send_unhandled_message(const std::string & command, const netadr_t & target);
	std::string get_oob_command(const game::netadr_t& target);
	bool is_hosting();
	void cycling_prestige();
	void make_dvar_server_info(const std::string& dvar, const std::string& value);
	float get_weapon_damage_range(const Weapon & weapon, const playerState_s * ps);
	float BG_GetLocationDamageMultipliers(const Weapon & weapon, const std::uint16_t hit_location);
	int Bullet_GetDamage(const game::BulletTraceResults & br, const game::BulletFireParams & bp, const game::centity_t * cent, const Weapon & weapon, const Weapon & alt);
	void set_map(const std::string & map);
	void CG_BulletEndpos(std::uint32_t * randSeed, const float spread, Vec3 * dir, Vec3 * forwardDir, Vec3 * rightDir, Vec3 * upDir, const float maxRange);
	std::uint64_t StringToInt64(const std::string & string);
	std::string CL_AddMessageIcon(const std::string & name, const Vec2 & dimensions = { 1.5f, 1.5f }, const bool flip_icon = false);
	int I_stricmp(const std::string & a, const std::string & b);
	std::vector<std::uint32_t> party_ids();
	std::string get_client_name(const game::PartyMember* pm, const size_t index);
	void game_message(const std::string & msg);
	void bold_game_message(const std::string & msg);
	void send_server_command(const int client_num, const std::string & command);
	void enum_assets(const XAssetType type, const std::function<void(void*)>& callback, const bool includeOverride);
	game::Material * get_material(const char * material_ptr, const int length);
	int Playlist_GetCurrentId();
	bool is_valid_cod_info_dvar(const std::string & dvar_name);
	bool is_preparing_migration(const size_t index, const char * game_end_time);
	bool is_valid_new_server_map_info(msg_t & msg);
	bool is_valid_map_name(const std::string& map);
	bool is_valid_relay_packet(const command::params_ & args, const netadr_t & target, msg_t & msg);
	bool LiveStorage_DataSetInternalString(const int index, char const * const * args, const std::string & value, StructuredDataBuffer * persistent_data, uint8_t * modified_flags);
	const StringTable * get_string_table(const std::string & asset);

	inline IWSteamClient* iw_steam_client()
	{
		return reinterpret_cast<IWSteamClient*>(*reinterpret_cast<uintptr_t*>(offsets::g_localSteamClient));
	}
	
	inline void* netchan()
	{
		return reinterpret_cast<void*>(0x00B83950);
	}

	inline client_t* svs_client(const std::size_t index)
	{
		return reinterpret_cast<client_t*>(0x004B5CF90) + (index * 0x78698);
	}

	inline gentity_s* gentity(const std::size_t index)
	{
		return reinterpret_cast<gentity_s*>(0x001A66E28) + (index * 0x274);
	}

	inline gclient_t* gclient(const std::size_t index)
	{
		return *reinterpret_cast<gclient_t**>(0x001A66E28 + index * 0x274 + 0x158);
	}

	inline cg_t* cg() {
		return reinterpret_cast<cg_t*>(offsets::cg_t);
	}

	inline PartyJoinInfo* g_partyJoinInfo()
	{
		return reinterpret_cast<PartyJoinInfo*>(offsets::g_partyJoinInfo);
	}

	inline clientActive_t* cl() {
		return reinterpret_cast<clientActive_t*>(offsets::clientActive_t);
	}

	inline weaponCompleteDefs* bg_weaponCompleteDefs(Weapon weapon)
	{
		return reinterpret_cast<weaponCompleteDefs**>(offsets::weaponCompleteDefs)[weapon & 0xFF];
	}

	inline Vec3 get_point(const std::vector<Vec3>& point, const bone_tag t)
	{
		if (t >= bone_tag::num_tags)
			return {};

		return point[static_cast<std::size_t>(t)];
	}

	inline auto get_tag(const bone_tag t)
	{
		if (t >= bone_tag::num_tags)
			return static_cast<scr_string_t>(0u);
		
		return game::bone_tags[static_cast<std::size_t>(t)];
	}

	inline auto get_shader(const shader t)
	{
		if (t >= shader::num_shaders)
			return static_cast<uint32_t>(0u);

		return game::shaders[static_cast<std::size_t>(t)];
	}
}