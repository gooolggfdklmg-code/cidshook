#pragma once
#include "dependencies/std_include.hpp"

#define DOT_PRODUCT(a,b)	((a)[0]*(b)[0]+(a)[1]*(b)[1]+(a)[2]*(b)[2])
#define ANGLE2SHORT(a) ((int)((a)*(65536/360.0f))&65535)
#define SHORT2ANGLE(a) ((float)((a)*(360.0f/65536)))
#define M_PI 3.14159265358979323846
#define M_PI_DOUBLE ((float)M_PI*2.0f)
#define DEG2RAD(a) ((a)*((float)M_PI/180.0f))
#define RAD2DEG(a) ((a)*(180.0f/(float)M_PI))
#define ANGLE_COMPARE_180(a) (((a)<90.0f&&(a)>-90.0f)||((a)>270.0f||(a)<-270.0f))
#define GET_SIGN(a) ((a) ? ((*(int*)&(a) >> 31) | 1) : 0)
#define VECTOR_COPY(a,b) ((b)[0]=(a)[0],(b)[1]=(a)[1],(b)[2]=(a)[2])

template <class T>
class vec2 {
public:
	T x, y;

	vec2() :x(0), y(0) {}
	vec2(T x, T y) : x(x), y(y) {}
	vec2(const vec2& v) : x(v.x), y(v.y) {}

	vec2& operator=(const vec2& v) {
		x = v.x;
		y = v.y;
		return *this;
	}

	vec2 operator+(vec2& v) {
		return vec2(x + v.x, y + v.y);
	}
	vec2 operator-(vec2& v) {
		return vec2(x - v.x, y - v.y);
	}

	vec2& operator+=(vec2& v) {
		x += v.x;
		y += v.y;
		return *this;
	}
	vec2& operator-=(vec2& v) {
		x -= v.x;
		y -= v.y;
		return *this;
	}

	vec2 operator+(double s) {
		return vec2(x + s, y + s);
	}
	vec2 operator-(double s) {
		return vec2(x - s, y - s);
	}
	vec2 operator*(double s) {
		return vec2(x * s, y * s);
	}
	vec2 operator/(double s) {
		return vec2(x / s, y / s);
	}


	vec2& operator+=(double s) {
		x += s;
		y += s;
		return *this;
	}
	vec2& operator-=(double s) {
		x -= s;
		y -= s;
		return *this;
	}
	vec2& operator*=(double s) {
		x *= s;
		y *= s;
		return *this;
	}
	vec2& operator/=(double s) {
		x /= s;
		y /= s;
		return *this;
	}

	void set(T x, T y) {
		this->x = x;
		this->y = y;
	}

	void rotate(const double deg) {
		const double theta = deg / 180.0 * M_PI;
		double c = cos(theta);
		double s = sin(theta);
		double tx = x * c - y * s;
		double ty = x * s + y * c;
		x = tx;
		y = ty;
	}

	vec2& normalize() {
		if (length() == 0) return *this;
		*this *= (1.0 / length());
		return *this;
	}

	float dist(vec2 v) const {
		vec2 d(v.x - x, v.y - y);
		return d.length();
	}

	float length() const {
		return std::sqrt(x * x + y * y);
	}

	void truncate(const double length) {
		const double angle = atan2f(y, x);
		x = length * cos(angle);
		y = length * sin(angle);
	}

	vec2 ortho() const {
		return vec2(y, -x);
	}

	static float dot(vec2 v1, vec2 v2) {
		return v1.x * v2.x + v1.y * v2.y;
	}

	static float cross(vec2 v1, vec2 v2) {
		return (v1.x * v2.y) - (v1.y * v2.x);
	}
};

class Vec3
{
public:
	float x, y, z;

	inline Vec3(void) { x = 0.0f; y = 0.0f; z = 0.0f; }
	inline Vec3(float X, float Y, float Z) { x = X; y = Y; z = Z; }
	inline Vec3(double X, double Y, double Z) { x = (float)X; y = (float)Y; z = (float)Z; }
	inline Vec3(int X, int Y, int Z) { x = (float)X; y = (float)Y; z = (float)Z; }
	inline Vec3(const Vec3& v) { x = v.x; y = v.y; z = v.z; }
	inline Vec3(float rgfl[3]) { x = rgfl[0]; y = rgfl[1]; z = rgfl[2]; }

	inline Vec3 operator-(void) const { return Vec3(-x, -y, -z); }
	inline int operator==(const Vec3& v) const { return x == v.x && y == v.y && z == v.z; }
	inline int operator!=(const Vec3& v) const { return !(*this == v); }
	inline Vec3 operator+(const Vec3& v) const { return Vec3(x + v.x, y + v.y, z + v.z); }
	inline Vec3 operator-(const Vec3& v) const { return Vec3(x - v.x, y - v.y, z - v.z); }
	inline Vec3 operator*(float fl) const { return Vec3(x * fl, y * fl, z * fl); }
	inline float operator*(const Vec3& other) const { return x * other.x + y * other.y + z * other.z; }
	inline Vec3 operator/(float fl) const { return Vec3(x / fl, y / fl, z / fl); }
	void operator += (const Vec3& add) { x += add.x; y += add.y; z += add.z; }
	void operator -= (const Vec3& sub) { x -= sub.x; y -= sub.y; z -= sub.z; }
	void operator *= (const float mul) { x *= mul; y *= mul; z *= mul; }
	void operator /= (const float mul) { x /= mul; y /= mul; z /= mul; }
	operator float* () { return &x; }
	operator const float* () const { return &x; }

	float length() const {
		return std::sqrtf(x * x + y * y + z * z);
	}

	float dot() const {
		return (x * x + y * y + z * z);
	}

	Vec3 cross_product(const Vec3& other) {
		return { y * other.z - z * other.y, z * other.x - x * other.z, x * other.y - y * other.x };
	}

	Vec3& normalized() {
		if (length() == 0) return *this;
		*this *= (1.0 / length());
		return *this;
	}

	Vec3 clear() {
		return { x = 0.0f, y = 0.0f, z = 0.0f };
	}

	float distance(Vec3 v) const {
		Vec3 d(x - v.x, y - v.y, z - v.z);
		return d.length();
	}
};

using LocalClientNum_t = std::uint32_t;
using scr_string_t = std::uint16_t;
using Weapon = std::uint32_t;
using ControllerIndex_t = std::uint32_t;
using ClientNum_t = std::uint32_t;
using Vec2 = vec2<float>;

namespace game
{
	struct lagometer_t
	{
		int frameSamples[128];
		int frameCount;
		int snapshotFlags[128];
		int snapshotSamples[128];
		int pad[128][5];
		int snapshotCount;
	};

	enum entityType_t
	{
		ET_GENERAL = 0x0,
		ET_PLAYER = 0x1,
		ET_PLAYER_CORPSE = 0x2,
		ET_ITEM = 0x3,
		ET_MISSILE = 0x4,
		ET_INVISIBLE = 0x5,
		ET_SCRIPTMOVER = 0x6,
		ET_SOUND_BLEND = 0x7,
		ET_FX = 0x8,
		ET_LOOP_FX = 0x9,
		ET_PRIMARY_LIGHT = 0xA,
		ET_TURRET = 0xB,
		ET_HELICOPTER = 0xC,
		ET_PLANE = 0xD,
		ET_VEHICLE = 0xE,
		ET_VEHICLE_COLLMAP = 0xF,
		ET_VEHICLE_CORPSE = 0x10,
		ET_VEHICLE_SPAWNER = 0x11
	};

	
	enum svscmd_type
	{
		SV_CMD_CAN_IGNORE = 0x0,
		SV_CMD_RELIABLE = 0x1,
	}; 

	enum stat_index
	{
		prestige = 3240,
		experience = 0xa98,
		score = 0xcb0,
		wins = 0xd0c,
		losses = 0xd10,
		ties = 0xd14,
		win_streak = 0xd18,
		kills = 0xcd8,
		deaths = 0xce0,
		ratio = 0xd08,
		headshots = 0xcec,
		accuracy = 0xd30,
		assists = 0xce8,
		kill_streak = 0xcdc,
		time_played1 = 0xcf8,
		time_played2 = 0xcfc,
		add_classes = 0x2b0f,
		tokens = 0x2b07,
		double_xp = 0x2b5d,
		double_weapon_xp = 0x2b65,
		class_name_1 = 0x1058,
		class_name_2 = 0x10ba,
		class_name_3 = 0x111c,
		class_name_4 = 0x117e,
		class_name_5 = 0x11e0,
		class_name_6 = 0x1242,
		class_name_7 = 0x12a4,
		class_name_8 = 0x1306,
		class_name_9 = 0x1368,
		class_name_10 = 0x13ca,
		class_name_11 = 0x142c,
		class_name_12 = 0x148e,
		class_name_13 = 0x14f0,
		class_name_14 = 0x1552,
		class_name_15 = 0x15b4,
		pm_class_name_1 = 0x1616,
		pm_class_name_2 = 0x1678,
		pm_class_name_3 = 0x16da,
		pm_class_name_4 = 0x173c,
		pm_class_name_5 = 0x179e,

		unlock_all_0 = 0x17db,
		unlock_all_1 = 0x8e0,
		unlock_all_2 = 0x28cc,
		unlock_all_3 = 0x181e,
	};
	
	enum errorParm_t
	{
		ERR_FATAL = 0x0,
		ERR_DROP = 0x1,
		ERR_FROM_STARTUP = 0x2,
		ERR_SERVERDISCONNECT = 0x3,
		ERR_DISCONNECT = 0x4,
		ERR_SCRIPT = 0x5,
		ERR_SCRIPT_DROP = 0x6,
		ERR_LOCALIZATION = 0x7,
	}; 
	
	enum team_t
	{
		TEAM_FREE,
		TEAM_AXIS,
		TEAM_ALLIES,
		TEAM_SPECTATOR,
		TEAM_NUM_TEAMS
	};

	enum PenetrateType
	{
		PENETRATE_TYPE_NONE = 0,
		PENETRATE_TYPE_SMALL = 1,
		PENETRATE_TYPE_MEDIUM = 2,
		PENETRATE_TYPE_LARGE = 3,
		PENETRATE_TYPE_MAX
	};

	struct msg_t
	{
		int overflowed;
		int readOnly;
		char* data;
		char* splitData;
		int maxsize;
		int cursize;
		int splitSize;
		int readcount;
		int bit;
		int lastEntityRef;
		int targetLocalNetID;
		int useZlib;
	};

	union DvarValue
	{
		bool enabled;
		int integer;
		unsigned int unsignedInt;
		char* string;
		float value;
		float vector[4];
		float color[4];
	}; 
	
	struct dvar_t
	{
		char pad[0x4];
		unsigned int flags;
		char pad2[0x4];
		DvarValue current;
	}; 
	
	enum netadrtype_t
	{
		NA_BOT = 0x0,
		NA_BAD = 0x1,
		NA_LOOPBACK = 0x2,
		NA_BROADCAST = 0x3,
		NA_IP = 0x4,
	};

	enum netsrc_t
	{
		NS_NULL = 0xFFFFFFFF,
		NS_CLIENT1 = 0x0,
		NS_CLIENT2 = 0x1,
		NS_CLIENT3 = 0x2,
		NS_CLIENT4 = 0x3,
		NS_SERVER = 0x4,
		NS_MAXCLIENTS = 0x4,
		NS_PACKET = 0x5,
	};

	struct netadr_t
	{
		netadrtype_t type;
		
		union
		{
			std::uint8_t ip[4];
			std::uint32_t inaddr;
		};
		
		std::uint16_t port;
		char pad[0xA];
		std::uint32_t adr_handle;
	};

#pragma pack(push, 1)
	struct bdSecurityID
	{
		std::uint64_t id;
	}; 
#pragma pack(pop)
	
#pragma pack(push, 1)
	struct PartyJoinChallenge
	{
		std::uint32_t challenge;
		char pad[0x2];
	};
#pragma pack(pop)

#pragma pack(push, 1)
	struct XNADDR
	{
		char pad[0x12];
		union
		{
			std::uint8_t ip[4];
			std::uint32_t inaddr;
		};
		
		std::uint16_t port;
		char pad2[0x1];
	};
#pragma pack(pop)

	struct bdSecurityKey
	{
		char ab[16];
	};
	
	struct XSESSION_INFO
	{
		bdSecurityID sessionID;
		XNADDR hostAddress;
		bdSecurityKey keyExhangeKey;
	};
	
	struct SubpartyInfo
	{
	public:
	private:
		char pad[0x58];
	};

	class PartyHostDetails
	{
	public:
		netadr_t adr;
	private:
		char pad[0x18];
	public:
		XSESSION_INFO sessionInfo;
	private:
		char pad2[0x3];
	public:
		int lastPacketTime;
		int lastPacketSentTime;
		int numPrivateSlots;
		int numPublicSlots;
		int hostNum;
	private:
		char pad3[0x4];
	};

	struct PartyMember
	{
		std::uint8_t status;
		char pad[0x2B];
		char gamertag[16];
		char pad2[0x8C];
		XNADDR xnaddr;
		char pad3[0x27];
		std::uint64_t player;
		char pad4[0x30];
	}; 
	
	class PartyData_s
	{
	public:
	private:
		char pad[0x188];
	public:
		PartyMember partyMembers[18];
		SubpartyInfo subparties[18];
		int subpartycount;
		PartyHostDetails currentHost;
	private:
		char pad2[0x28];
	public:
		int partyID;
	private:
		char pad3[0x14];
	public:
		int lastPartyStateTime;
	private:
		char pad4[0xC];
	public:
		std::uint64_t lobbySteamID;
	private:
		char pad5[0x8];
	public:
		int inParty;
		int party_system_active;
	private:
		char pad6[0x2C];
	public:
		int hostTimeouts;
		int lobbyFlags;

		bool in_party() const
		{
			return party_system_active == 1 && inParty;
		}

		bool is_running() const
		{
			return party_system_active == 1;
		}

		auto& public_slots()
		{
			return *reinterpret_cast<int*>((reinterpret_cast<int>(session()) + 0x48));
		}

		auto& private_slots()
		{
			return *reinterpret_cast<std::uint32_t*>((reinterpret_cast<int>(session()) + 0x4C));
		}

		auto& lobby_flags() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this) + 0x1F58);
		}

		bool is_active_party()
		{
			return reinterpret_cast<bool(__cdecl*)()>(0x004A55A0)();
		}

		void* session()
		{
			return reinterpret_cast<void*(__cdecl*)()>(0x005C9390)();
		}
	};
	
	struct weaponCompleteDefs
	{
		char pad0[0x2C];
		int weaponType;
		int weaponClass;
		PenetrateType penetrateType;
		int impactType;
		int inventoryType;
		int fireType;
		char pad1[0x18];
		int fireDelay;
		char pad2[0x194];
		int hudIcon;
		char pad3[0x18];
		int maxAmmo;
		char pad4[68];
		int fireTime;
		char pad5[0x190];
		float speedMultiplier;
		char pad6[0x30];
		Vec3 spread[3];
		char pad7[0x88];
		int clipAmmo;
		char pad8[0xC4];
		int weaponID;
		char pad9[0x1CD];
		bool rifleBullet;

		auto& ads_spread() const
		{
			return *reinterpret_cast<float*>(reinterpret_cast<uintptr_t>(this + 0x640));
		}
	};

	struct __declspec(align(8)) handler_t
	{
		char* string;
	};
	
	struct BulletFireParams
	{
		int weaponEntIndex;
		int ignoreEntIndex;
		float damageMultiplier;
		int methodOfDeath;
		char pad[0x04];
		Vec3 origStart;
		Vec3 start;
		Vec3 end;
		Vec3 dir;
	};

	struct trace_t
	{
		float fraction;
		Vec3 normal;
		char pad0[0x18];
		bool allsolid;
		bool startsolid;
		char pad1[0x2];
	};

	struct BulletTraceResults
	{
		trace_t trace;
		char pad0[0x4];
		Vec3 hitPos;
		char pad1[0x4];
		int depthSurfaceType;
		char pad2[0x4];
	}; 
	
	struct trajectory_t
	{
		int trType;
		int trTime; 
		int trDuration;
		Vec3 trBase;
		Vec3 trDelta;
	};

	struct LerpEntityState
	{
		int eFlags;
		trajectory_t pos;
		trajectory_t apos;
		char pad[0x10];
		std::uint8_t stowedweaponID;
		char pad2[0xB];
	}; 

	struct entityState_s
	{
		int	number;
		int	eType;
		LerpEntityState lerp;
		char pad[0x58];
		std::uint8_t weaponID;
		char pad2[0x37];
	};
	
	struct usercmd_s
	{
		int serverTime;
		int buttons;
		int angles[3];
		char pad0[0x8];
		char forwardmove;
		char rightmove;
		char upmove;
		char pad1[0xD];
	};

	class playerState_s
	{
	private:
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) const {
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		auto origin() const {
			return get<Vec3>(0x1C);
		}

		auto velocity() const {
			return get<Vec3>(0x28);
		}

		auto delta_angles() const {
			return get<Vec3>(0x60);
		}

		auto& command_time() const {
			return get<std::uint32_t>(0);
		}

		auto& number() const {
			return get<std::uint32_t>(0x150);
		}

		auto& weapon() const {
			return get<std::uint32_t>(0x370);
		}

		auto& held_weapons(std::uint32_t slot) 
		{
			return get<std::uint32_t>(4 * slot + 0x274);
		}

		auto& other_flags() {
			return get<std::uint32_t>(0x10);
		}

		auto& pm_type() const {
			return get<std::uint32_t>(0x4);
		}

		auto& pm_flags() const {
			return get<std::uint32_t>(0xC);
		}

		auto rendering_third_person() const {
			return get<bool>(0x6B200);
		}

		auto weapon_pos_frac() const {
			return get<float>(0x378);
		}

		auto& e_flags() const {
			return get<std::uint32_t>(0xB0);
		}

		auto& rank() const {
			return get<std::uint32_t>(0x3424);
		}

		auto& prestige() const {
			return get<std::uint32_t>(0x3428);
		}

		auto& title() const {
			return get<std::uint32_t>(0x3440);
		}

		auto& emblem() const {
			return get<std::uint32_t>(0x343C);
		}
	}; 

	struct snapshot_s
	{
		playerState_s ps;

		auto server_time() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this + 0x3314));
		}

		auto ping() const
		{
			return *(((int*)this) + 0xCC4);
		}

		auto snap_flags() const
		{
			return *(((int*)this) + 0xCC3);
		}
	};
	
	class clientActive_t
	{
	private:
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) {
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		auto& view_angles()
		{
			return get<Vec3>(0x34F4);
		}

		auto& ping()
		{
			return get<std::uint32_t>(0);
		}

		auto ps() {
			return reinterpret_cast<playerState_s*>(get_base() + 0x8);
		}

		char pad0[0x3500];
		usercmd_s cmds[128];
		int currentCmdNum;

		usercmd_s* get_user_cmd(int i)
		{
			return &cmds[i & 0x7F];
		}
	}; 
	
	class clientInfo_t
	{
	private:
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

	public:
		char pad0[0x34];
		std::uint32_t perks[2];
		BYTE pad2[0x18];
		char bodyType[0x40];
		char teamType[0x40];
		char riotType[0x40];
		BYTE pad3[0x140];
		char riotStatus[0x40];
		
		template<typename T> T& get(std::uintptr_t offset) 
		{
			return *reinterpret_cast<T*>(get_base() + offset);
		}
		
		auto name() {
			return get<std::string>(0xC).data();
		}

		auto a() {
			return get<std::string>(0x50).data();
		}

		auto valid() {
			return get<std::uint32_t>(0);
		}

		auto team() {
			return get<std::uint32_t>(0x20);
		}

		auto& player_angles() {
			return get<Vec3>(0x408);
		}
	}; 
	
	class centity_t
	{
	private:
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) const {
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		bool is_alive() {
			return get<std::uint8_t>(0x1D0) & 1;
		}

		auto valid() {
			return get<std::uint16_t>(0x2);
		}

		auto origin() {
			return get<Vec3>(0x14);
		}

		auto& angles() const {
			return get<Vec3>(0x20);
		}

		auto& prev_state() const { 
			return get<LerpEntityState>(0x68);
		}

		auto& next_state() const {
			return get<entityState_s>(0xD0);
		}
	};
	
	class cg_t
	{
	private:
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) const {
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		auto ps() const {
			return reinterpret_cast<playerState_s*>(get_base());
		}

		auto number() const {
			return ps()->number();
		}

		auto& flags() const {
			return get<std::uint32_t>(0x2BC);
		}

		auto latest_snapshot_time() const {
			return get<std::uint32_t>(0x3360);
		}

		auto frame_interpolation() const {
			return get<float>(0x6B1E4);
		}

		auto frame_time() const {
			return get<std::uint32_t>(0x6B1E8);
		}

		auto time() const {
			return get<std::uint32_t>(0x6B1EC);
		}

		auto& refdef_view_angles() const {
			return get<Vec3>(0x6FD3C);
		}

		auto gun_angles() const {
			return get<Vec3>(0x6FD78);
		}

		auto& v_dmg_pitch() const {
			return get<float>(0x190);
		}

		auto& v_dmg_yaw() const {
			return get<float>(0x18C);
		}

		auto in_killcam() const {
			return get<bool>(0x77254);
		}

		auto aim_spread_scale() const {
			return get<float>(0x104928);
		}

		auto snap() const {
			return reinterpret_cast<snapshot_s*>(*reinterpret_cast<std::uintptr_t*>(get_base() + 0x3364));
		}

		auto next_snap() const {
			return reinterpret_cast<snapshot_s*>(*reinterpret_cast<std::uintptr_t*>(get_base() + 0x3368));
		}

		auto client(std::size_t index) const {
			return reinterpret_cast<clientInfo_t*>(get_base() + (0xFD6D8 + (0x564 * index)));
		}

		auto centity(std::size_t index) const {
			return reinterpret_cast<centity_t*>(get_base() + (0x109620 + (0x1F8 * index)));
		}
	};

	struct IWSteamClient
	{
		auto persona_name() const
		{
			return reinterpret_cast<char*>(reinterpret_cast<uintptr_t>(this + 0x156));
		}

		auto& steam_id() const
		{
			return *reinterpret_cast<std::uint64_t*>(reinterpret_cast<uintptr_t>(this + 0x14E));
		}

		auto& security_id() const
		{
			return *reinterpret_cast<std::uint64_t*>(reinterpret_cast<uintptr_t>(this + 0x607CFD5));
		}
	};

	struct PartyJoinInfo
	{
		auto& party_join_failed() const
		{
			return *reinterpret_cast<char**>(reinterpret_cast<uintptr_t>(this + 0x26C8));
		}
	};

	enum clientState_t
	{
		CS_FREE = 0,
		CS_ZOMBIE = 1,
		CS_UNKNOWN = 2,
		CS_CONNECTED = 3,
		CS_PRIMED = 4,
		CS_ACTIVE = 5
	}; 
	
	struct client_t
	{
		auto& xuid() const
		{
			return *reinterpret_cast<std::uint64_t*>(reinterpret_cast<uintptr_t>(this + 0x452C8));
		}
		
		auto& message_acknowledge() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this + 0x20E7C));
		}

		auto& server_id() const
		{
			return *reinterpret_cast<std::uint8_t*>(reinterpret_cast<uintptr_t>(this + 0x41CB8));
		}

		auto& reliable_sequence() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this + 0x20E70));
		}
		
		auto& reliable_acknowledge() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this + 0x20E74));
		}
		
		auto& session_state() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this + 0x3338));
		}

		auto& bot_flag() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this + 0x452B8));
		}

		auto& stat_flag() const
		{
			return *reinterpret_cast<std::uint32_t*>(reinterpret_cast<uintptr_t>(this + 0x452BE));
		}

		auto& port() const
		{
			return *reinterpret_cast<std::uint16_t*>(reinterpret_cast<uintptr_t>(this + 0x30));
		}

		auto& state() const
		{
			return *reinterpret_cast<clientState_t*>(reinterpret_cast<uintptr_t>(this));
		}

		auto remote_address() const
		{
			return *reinterpret_cast<game::netadr_t*>(reinterpret_cast<uintptr_t>(this + 0x28));
		}

		auto& send_match_data() const
		{
			return *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(this) + 0x452D0);
		}

		auto& send_player_data() const
		{
			return *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(this) + 0x452BD);
		}
	}; 
	
	struct MaterialTechniqueSet
	{
		const char *name;
	}; 
	
	struct Material
	{
		char pad[0x54];
		MaterialTechniqueSet *techniqueSet;
	};

	struct gclient_t
	{
		playerState_s ps;

		auto& m_flags() const
		{
			return *reinterpret_cast<std::size_t*>(reinterpret_cast<uintptr_t>(this + 0x35CC));
		}

		auto& team() const
		{
			return *reinterpret_cast<std::size_t*>(reinterpret_cast<uintptr_t>(this + 0x33D0));
		}

		auto name() const
		{
			return reinterpret_cast<std::string*>(reinterpret_cast<uintptr_t>(this + 0x3410))->data();
		}
	};
	
	struct gentity_s
	{
		int entity_num() const
		{
			return *reinterpret_cast<std::size_t*>(reinterpret_cast<uintptr_t>(this));
		}
	};


	struct InstantMessage
	{
		std::uint16_t deez;
		
		auto type() const
		{
			return *reinterpret_cast<std::uint16_t*>(reinterpret_cast<uintptr_t>(this + 0x2));
		}

		auto addr() const
		{
			return reinterpret_cast<game::netadr_t*>(reinterpret_cast<uintptr_t>(this + 0xC));
		}

		auto session() const
		{
			return reinterpret_cast<game::XSESSION_INFO*>(reinterpret_cast<uintptr_t>(this + 0x8));
		}
	};

	enum weapClass_t
	{
		WEAPCLASS_RIFLE = 0,
		WEAPCLASS_SNIPER = 1,
		WEAPCLASS_MG = 2,
		WEAPCLASS_SMG = 3,
		WEAPCLASS_SPREAD = 4,
		WEAPCLASS_PISTOL = 5,
		WEAPCLASS_GRENADE = 6,
		WEAPCLASS_ROCKETLAUNCHER = 7,
		WEAPCLASS_TURRET = 8,
		WEAPCLASS_THROWINGKNIFE = 9,
		WEAPCLASS_NON_PLAYER = 10,
		WEAPCLASS_ITEM = 11,
		WEAPCLASS_MAX
	};

	enum XAssetType
	{
		ASSET_TYPE_PHYSPRESET = 0x0,
		ASSET_TYPE_PHYSCOLLMAP = 0x1,
		ASSET_TYPE_XANIMPARTS = 0x2,
		ASSET_TYPE_XMODEL_SURFS = 0x3,
		ASSET_TYPE_XMODEL = 0x4,
		ASSET_TYPE_MATERIAL = 0x5,
		ASSET_TYPE_PIXELSHADER = 0x6,
		ASSET_TYPE_VERTEXSHADER = 0x7,
		ASSET_TYPE_VERTEXDECL = 0x8,
		ASSET_TYPE_TECHNIQUE_SET = 0x9,
		ASSET_TYPE_IMAGE = 0xA,
		ASSET_TYPE_SOUND = 0xB,
		ASSET_TYPE_SOUND_CURVE = 0xC,
		ASSET_TYPE_LOADED_SOUND = 0xD,
		ASSET_TYPE_CLIPMAP_SP = 0xE,
		ASSET_TYPE_CLIPMAP_MP = 0xF,
		ASSET_TYPE_COMWORLD = 0x10,
		ASSET_TYPE_GAMEWORLD_SP = 0x11,
		ASSET_TYPE_GAMEWORLD_MP = 0x12,
		ASSET_TYPE_MAP_ENTS = 0x13,
		ASSET_TYPE_FXWORLD = 0x14,
		ASSET_TYPE_GFXWORLD = 0x15,
		ASSET_TYPE_LIGHT_DEF = 0x16,
		ASSET_TYPE_UI_MAP = 0x17,
		ASSET_TYPE_FONT = 0x18,
		ASSET_TYPE_MENULIST = 0x19,
		ASSET_TYPE_MENU = 0x1A,
		ASSET_TYPE_LOCALIZE_ENTRY = 0x1B,
		ASSET_TYPE_WEAPON = 0x1C,
		ASSET_TYPE_SNDDRIVER_GLOBALS = 0x1D,
		ASSET_TYPE_FX = 0x1E,
		ASSET_TYPE_IMPACT_FX = 0x1F,
		ASSET_TYPE_AITYPE = 0x20,
		ASSET_TYPE_MPTYPE = 0x21,
		ASSET_TYPE_CHARACTER = 0x22,
		ASSET_TYPE_XMODELALIAS = 0x23,
		ASSET_TYPE_RAWFILE = 0x24,
		ASSET_TYPE_STRINGTABLE = 0x25,
		ASSET_TYPE_LEADERBOARD = 0x26,
		ASSET_TYPE_STRUCTURED_DATA_DEF = 0x27,
		ASSET_TYPE_TRACER = 0x28,
		ASSET_TYPE_VEHICLE = 0x29,
		ASSET_TYPE_ADDON_MAP_ENTS = 0x2A,
		ASSET_TYPE_COUNT = 0x2B,
		ASSET_TYPE_STRING = 0x2B,
		ASSET_TYPE_ASSETLIST = 0x2C,
		ASSET_TYPE_INVALID = -1,
	};

	struct XAsset
	{
		XAssetType type;
		void* header;
	};
	
	struct MapnameRichPresenceInfo
	{
		char* mapname;
	};

	enum connstate_t
	{
		CA_DISCONNECTED = 0x0,
		CA_CINEMATIC = 0x1,
		CA_LOGO = 0x2,
		CA_CONNECTING = 0x3,
		CA_CHALLENGING = 0x4,
		CA_CONNECTED = 0x5,
		CA_SENDINGSTATS = 0x6,
		CA_LOADING = 0x7,
		CA_PRIMED = 0x8,
		CA_ACTIVE = 0x9,
	};

	struct StructuredDataBuffer
	{
		char *data;
		unsigned int size;
	};

	struct StructuredDataLookup
	{
		char pad[0x18];
	};

	struct StringTableCell
	{
		const char *string;
		int hash;
	};

	struct StringTable
	{
		const char *name;
		int columnCount;
		int rowCount;
		StringTableCell *values;
	};

}