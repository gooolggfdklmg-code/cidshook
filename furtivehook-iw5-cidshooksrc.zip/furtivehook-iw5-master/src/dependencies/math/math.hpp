#pragma once
#include "dependencies/std_include.hpp"

namespace math
{
	float calculate_fov(const Vec3 & start, const Vec3 & end);
	void normalize_angles(Vec3* angles);
	int clamp_value(int value, int min, int max);
	float angle_delta(const float angle, const float angle2);
	float angle_normalize_180(const float angle);
	void rotate_point(const Vec3& point, const Vec3& center, const float yaw, Vec3& out);
}
