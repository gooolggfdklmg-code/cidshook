#include "dependencies/std_include.hpp"
#include "math.hpp"

namespace math
{
	void normalize_angles(Vec3* angles)
	{
		while (angles->x > 180.0f) {
			angles->x -= 360.0f;
		}

		while (angles->x < -180.0f) {
			angles->x += 360.0f;
		}

		while (angles->y > 180.0f) {
			angles->y -= 360.0f;
		}

		while (angles->y < -180.0f) {
			angles->y += 360.0f;
		}
	}

	int clamp_value(int value, int min, int max)
	{
		if (value > max) {
			return max;
		}
		
		if (value < min) {
			return min;
		}
		
		return value;
	}

	float angle_normalize_180(const float angle) 
	{
		const auto scaledAngle = angle * 0.0027777778f;
		return (scaledAngle - std::floorf(scaledAngle + std::numeric_limits<float>::round_error())) * 360.0f;
	}
	
	float angle_delta(const float angle, const float angle2) {
		return angle_normalize_180(angle - angle2);
	}
	
	void make_vector(const Vec3& angles, Vec3& out) 
	{
		float pitch = DEG2RAD(angles[0]), 
			yaw = DEG2RAD(angles[1]);

		out[0] = -std::cosf(pitch) * -std::cosf(yaw);
		out[1] = std::sinf(yaw) * std::cosf(pitch);
		out[2] = -std::sinf(pitch);
	}

	float calculate_fov(const Vec3& start, const Vec3& end)
	{
		Vec3 angle, aim_angles;
		game::vectoangles(&(end - start), &angle);

		make_vector(game::cg()->refdef_view_angles(), aim_angles);
		make_vector(angle, angle);

		float result = RAD2DEG(std::acosf(DOT_PRODUCT(aim_angles, angle)
			/ std::powf(aim_angles.length(), 2.0f)));

		if (isnan(result))
			result = 0.0f;

		return result;
	}

	void rotate_point(const Vec3& point, const Vec3& center, const float yaw, Vec3& out)
	{
		Vec2 cos_sin{
			cosf(((-yaw + 180.0f) / 360.0f - 0.25f) * M_PI_DOUBLE),
			sinf(((-yaw + 180.0f) / 360.0f - 0.25f) * M_PI_DOUBLE)
		}, delta{};

		delta.x = point.x - center.x;
		delta.y = point.y - center.y;

		out.x = center.x + cos_sin.y * delta.x - cos_sin.x * delta.y;
		out.y = center.y + cos_sin.x * delta.x + cos_sin.y * delta.y;
		out.z = point.z;
	}
}