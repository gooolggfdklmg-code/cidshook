#pragma once

#include <ws2tcpip.h>
#include <windows.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <vector>
#include <memory>
#include <intrin.h>
#include <algorithm>
#include <WinInet.h>
#include <time.h>
#include <dxgi.h>
#include <random>
#include <numeric>
#include <future>
#include <mutex>
#include <regex>
#include <cmath>
#include <fstream>
#include <iterator>
#include <algorithm>
#include <array>
#include <codecvt>
#include <psapi.h>
#include <Shlwapi.h>
#include <dbghelp.h>
#include <filesystem>
#include <shellapi.h>
#include <cctype>
#include <d3d9.h>
#include <csetjmp>
#include <map>
#include <sstream>
#include <mmsystem.h>
#pragma comment(lib, "dbghelp.lib")
#pragma comment(lib, "shlwapi.lib")

using namespace std::chrono_literals;
using namespace std::literals;

#include "dependencies/hooks/detours.hpp"

#include "../thirdparty/imgui/imgui.h"
#include "../thirdparty/imgui/imgui_internal.h"
#include "../thirdparty/imgui/imgui_impl_dx9.h"
#include "../thirdparty/imgui/imgui_impl_win32.h"

#include "../thirdparty/steam_api/isteammatchmaking.hpp"
#include "../thirdparty/steam_api/isteamuser.hpp"
#include "../thirdparty/steam_api/isteamnetworking.hpp"

#include "game/game.hpp"
#include "math/math.hpp"

#include "utils/utils.hpp"
#include "utils/io.hpp"
#include "utils/toast.hpp"
#include "utils/hook.hpp"
#include "utils/memory.hpp"
#include "utils/string.hpp"
#include "utils/nt.hpp"
#include "utils/concurrent_list.hpp"
#include "utils/exception/minidump.hpp"

#include "core/autowall/autowall.hpp"
#include "core/entity_prediction/entity_prediction.hpp"
#include "core/aimbot/aimbot.hpp"
#include "core/nospread/nospread.hpp"
#include "core/events/events.hpp"
#include "core/command/command.hpp"
#include "core/network/network.hpp"
#include "core/misc/misc.hpp"
#include "core/input/input.hpp"
#include "core/rendering/dx.hpp"
#include "core/rendering/rendering.hpp"
#include "core/security/security.hpp"
#include "core/esp/esp.hpp"
#include "core/menu/menu.hpp"
#include "core/exception/exception.hpp"
#include "core/exploit/rop/rop.hpp"
#include "core/exploit/rce/rce.hpp"
#include "core/exploit/exploit.hpp"
#include "core/exploit/host/rce.hpp"
#include "core/bots/bots.hpp"
#include "core/scheduler/scheduler.hpp"
#include "core/stats/stats.hpp"
#include "core/antiaim/antiaim.hpp"
#include "core/esp/chams/chams.hpp"
#include "core/lagometer/lagometer.hpp"
#include "core/command/command.hpp"
#include "core/server_command/server_command.hpp"
#include "core/host/host.hpp"
#include "core/session/session.hpp"
#include "core/logger/logger.hpp"
#include "core/loader/loader.hpp"
#include "core/security/iat/iat.hpp"

#include "steam/steam.hpp"