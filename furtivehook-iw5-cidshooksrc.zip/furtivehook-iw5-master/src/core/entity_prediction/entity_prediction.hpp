#pragma once
#include "dependencies/std_include.hpp"

namespace entity_prediction
{
	void cg_interpolate_entity_position(game::centity_t * cent);
	extern bool predict_entity_movement;
}