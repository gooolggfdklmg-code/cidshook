#include "dependencies/std_include.hpp"
#include "entity_prediction.hpp"

namespace entity_prediction
{
	bool predict_entity_movement = true;
	
	float BG_EvaluateTrajectory(const game::trajectory_t* tr, std::uint32_t time, Vec3& result, float scale)
	{
		static constexpr auto address = 0x00419E80;
		auto actual_result = 0.0f;

		__asm
		{
			fld scale;

			push result;
			push time;
			push tr;
			call address;
			add esp, 12;

			fstp actual_result;
		}

		return actual_result;
	}

	Vec3 get_entity_velocity(const game::centity_t* cent)
	{
		Vec3 old_position, new_position; 
		
		auto result = BG_EvaluateTrajectory(&cent->prev_state().pos, game::cg()->snap()->server_time(), old_position, game::cg()->frame_interpolation());
		BG_EvaluateTrajectory(&cent->next_state().lerp.pos, game::cg()->next_snap()->server_time(), new_position, result);

		auto velocity = (new_position - old_position);
		velocity[0] = static_cast<float>(GET_SIGN(velocity[0]));
		velocity[1] = static_cast<float>(GET_SIGN(velocity[1]));
		velocity[2] = static_cast<float>(GET_SIGN(velocity[2]));

		return velocity;
	}

	Vec3 get_entity_interpolated_angles(const game::centity_t* cent)
	{
		Vec3 old_angles, new_angles, angles; 
		
		auto result = BG_EvaluateTrajectory(&cent->prev_state().apos, game::cg()->snap()->server_time(), old_angles, game::cg()->frame_interpolation());
		BG_EvaluateTrajectory(&cent->next_state().lerp.apos, game::cg()->next_snap()->server_time(), new_angles, result);

		angles[0] = math::angle_delta(new_angles[0], old_angles[0]);
		angles[1] = math::angle_delta(new_angles[1], old_angles[1]);
		angles[2] = math::angle_delta(new_angles[2], old_angles[2]);

		angles[0] = static_cast<float>(GET_SIGN(angles[0]));
		angles[1] = static_cast<float>(GET_SIGN(angles[1]));
		angles[2] = static_cast<float>(GET_SIGN(angles[2]));

		return angles;
	}

	void cg_interpolate_entity_position(game::centity_t* cent)
	{
		const auto velocity = get_entity_velocity(cent);
		cent->origin() += (velocity * (game::cg()->frame_time() / 1000.0f));
		cent->origin() += (velocity * (game::cg()->snap()->ping() / 1000.0f));
		
		const auto angles = get_entity_interpolated_angles(cent); 
		cent->angles() += (angles * (game::cg()->frame_time() / 1000.0f));
		cent->angles() += (angles * (game::cg()->snap()->ping() / 1000.0f));
	}
}