#pragma once
#include "dependencies/std_include.hpp"

namespace misc
{ 
	extern float fov_value;
	extern bool no_recoil, no_flinch, third_person, never_host, cycling_prestige;
	extern int brush_model_trace_finish;
	
	void __stdcall exit_process(std::uint32_t exit_code);
	void com_clean_name(const char * in, char * out, size_t length);
	void __cdecl com_error(game::errorParm_t errorType, const char * error);
	void initialize();
	void __cdecl cg_calc_entity_lerp_positions(LocalClientNum_t localClientNum, game::centity_t * cent);
	bool __cdecl live_can_host_server(size_t num_players);
	bool __cdecl party_migrate_can_we_host_lobby(game::PartyData_s * party, int b, bool c);
	void sys_get_value();
}
