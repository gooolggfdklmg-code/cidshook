#include "dependencies/std_include.hpp"
#include "misc.hpp"

namespace misc
{
	auto live_can_host_server_original = reinterpret_cast<decltype(&live_can_host_server)>(0x005CB960);
	auto party_migrate_can_we_host_lobby_original = reinterpret_cast<decltype(&party_migrate_can_we_host_lobby)>(0x004B19F0);
	auto sys_get_value_original = reinterpret_cast<decltype(&sys_get_value)>(0x0055FBD9);
	auto cg_calc_entity_lerp_positions_original = reinterpret_cast<decltype(&cg_calc_entity_lerp_positions)>(0x0044DB10);
	auto exit_hook_original = reinterpret_cast<decltype(&exit_process)>(ExitProcess);
	auto com_clean_name_original = reinterpret_cast<decltype(&com_clean_name)>(0x005C3A50);
	auto com_error_original = reinterpret_cast<decltype(&com_error)>(0x00555450);

	std::uint64_t original_steam_id;
	float fov_value = 65.0f;
	bool no_recoil = true, no_flinch = true, third_person = false, never_host = true, cycling_prestige = false;
	int brush_model_trace_finish = 0;
	Vec3 client_angles_backup = {};
	Vec3 cent_angles_backup = {};

	void __cdecl bg_weapon_fire_recoil(const game::playerState_s* ps, Vec2 recoilSpeed, std::uint32_t* holdrand, int unk1)
	{
		if (!no_recoil)
		{
			return reinterpret_cast<decltype(&bg_weapon_fire_recoil)>(0x00438680)(ps, recoilSpeed, holdrand, unk1);
		}
	}

	void __cdecl cg_calc_entity_lerp_positions(LocalClientNum_t localClientNum, game::centity_t* cent)
	{
		cg_calc_entity_lerp_positions_original(localClientNum, cent);

		if (cent->is_alive())
		{
			const auto angles = &game::cg()->client(cent->next_state().number)->player_angles();
			client_angles_backup = *angles;

			if (antiaim::enabled && game::cg()->ps()->rendering_third_person() && cent->next_state().number == game::cg()->number())
			{
				game::cg()->client(cent->next_state().number)->player_angles() = antiaim::cur_angles + game::cg()->ps()->delta_angles();
				cent->angles().y = antiaim::cur_angles.y + game::cg()->ps()->delta_angles().y;
			}

			if (cent->next_state().eType == game::ET_PLAYER)
			{
				if (entity_prediction::predict_entity_movement)
					entity_prediction::cg_interpolate_entity_position(cent);
			}
		}
	}

	bool __cdecl live_can_host_server(size_t num_players)
	{
		return !never_host;
	}

	bool __cdecl party_migrate_can_we_host_lobby(game::PartyData_s* party, int b, bool c)
	{
		return !never_host;
	}

	__declspec(naked) void sys_get_value()
	{
		__asm
		{
			test eax, eax;
			jz fix;

			jmp sys_get_value_original;

		fix:
			mov eax, brush_model_trace_finish;
			retn;
		}
	}

	void __stdcall exit_process(std::uint32_t exit_code)
	{
		scheduler::destroy_thread();
		exit_hook_original(exit_code);
	}

	void __cdecl com_clean_name(const char* in, char* out, size_t length)
	{
		strncpy_s(out, length, in, _TRUNCATE);
	}

	void __cdecl com_error(game::errorParm_t errorType, const char* error)
	{
		if (game::com_errorEnteredCount >= 1)
		{
			PRINT_LOG("[double com_error] First Error: %s Second Error: %s", game::com_errorMessage, error);
		}

		logger::print_log("[%i] %s @ 0x%08X", errorType, error, _ReturnAddress());

		if (errorType == game::ERR_FATAL)
			return com_error_original(game::ERR_DROP, error);

		return com_error_original(errorType, error);
	}
	
	void initialize()
	{
		utils::hook::detour(&cg_calc_entity_lerp_positions_original, &cg_calc_entity_lerp_positions);
		utils::hook::detour(&live_can_host_server_original, &live_can_host_server);
		utils::hook::detour(&party_migrate_can_we_host_lobby_original, &party_migrate_can_we_host_lobby);
		utils::hook::detour(&sys_get_value_original, &sys_get_value);
		utils::hook::detour(&exit_hook_original, &exit_process);
		utils::hook::detour(&com_clean_name_original, &com_clean_name);
		utils::hook::detour(&com_error_original, &com_error);

		utils::hook::call(0x004826D9, &bg_weapon_fire_recoil);
		
		utils::hook::return_value(0x0064EED0, false); // Live_GetSkill
		utils::hook::retn(0x005CCAC0); // Sys_CheckCrashOrRerun
		
		utils::hook::set<std::uint8_t>(0x00552675 + 0x1, 0x0); // LiveStorage_StatsReadComplete
		utils::hook::set<std::uint8_t>(0x004A6682, 0xEB); // Party_IsMemberInfoVisible
		utils::hook::set<std::uint8_t>(0x005563A6, 0xEB); // Com_StartHunkUsers
		
		input::on_key(VK_F2, [] { game::Cbuf_AddText(0, "disconnect"); });
		input::on_key(VK_F3, [] { game::Com_Quit_f(); });
		input::on_key(VK_F4, [] { third_person = !third_person; });

		scheduler::once(game::initialize, scheduler::pipeline::main);
		scheduler::loop(game::cycling_prestige, scheduler::pipeline::main, 500ms);
		
		scheduler::loop([]()
		{
			if (game::g_lobbyData->in_party() || (game::party = game::g_partyData, !game::g_partyData->in_party()))
				game::party = game::g_lobbyData;

			for (size_t client_num = 0; client_num < 18; ++client_num)
			{
				if (!game::is_valid_target(client_num))
				{
					aimbot::priority_target[client_num] = false;
					aimbot::ignore_target[client_num] = false;
				}
			}

			if (lagometer::draw_lagometer)
			{
				game::CG_AddLagometerFrameInfo(lagometer::lagometer);
			}

			stats::set_skills(0); 
			game::Dvar_FindVar("ping_default_min")->current.integer = 250;
		}, scheduler::pipeline::main);

		scheduler::loop(game::on_every_frame, scheduler::pipeline::renderer); 
		
		scheduler::loop([]()
		{
			brush_model_trace_finish = game::Sys_GetValue(3);

			const static auto cg_thirdperson = game::Dvar_FindVar("cg_thirdPerson");
			const static auto fov = game::Dvar_FindVar("cg_fov");
			cg_thirdperson->current.enabled = third_person && !game::cg()->in_killcam();
			fov->current.value = fov_value;

			if (const auto client_num = game::cg()->number(); game::cg()->centity(client_num)->is_alive())
			{
				if (antiaim::enabled && game::cg()->ps()->rendering_third_person())
				{
					game::cg()->centity(client_num)->angles().y = cent_angles_backup.y;
					game::cg()->client(client_num)->player_angles() = client_angles_backup;
				}
			}

			if (no_flinch)
			{
				game::cg()->v_dmg_pitch() = 0;
				game::cg()->v_dmg_yaw() = 0;
			}

		}, scheduler::pipeline::renderer);
	}
}