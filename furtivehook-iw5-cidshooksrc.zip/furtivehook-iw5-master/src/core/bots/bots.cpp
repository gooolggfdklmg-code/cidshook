#include "dependencies/std_include.hpp"
#include "bots.hpp"

namespace bots
{
	game::client_t* bot_client = nullptr;
	
	namespace patches
	{
		auto sv_add_server_command_original = reinterpret_cast<decltype(&sv_add_server_command)>(0x00575BC1);
		auto sv_add_server_command_msg_original = reinterpret_cast<decltype(&sv_add_server_command_msg)>(0x00575D1D);
		auto sv_check_timeouts_original = reinterpret_cast<decltype(&sv_check_timeouts)>(0x00576DCC);
		auto iw_steam_server_run_frame_original = reinterpret_cast<decltype(&iw_steam_server_run_frame)>(0x006374B7); 
		
		bool callback_is_bot(size_t index)
		{
			return is_bot(index);
		}

		bool callback_is_bot_adr(game::client_t* client)
		{
			return client->remote_address().type == game::NA_BOT;
		}

		__declspec(naked) void sv_add_server_command()
		{
			__asm
			{
				pushad;

				push ebx;
				call callback_is_bot_adr;
				add esp, 4;

				test al, al;
				jnz fix;

				popad;

				jmp sv_add_server_command_original;

			fix:
				popad;

				push 0x00575C2D;
				retn;
			}
		}

		__declspec(naked) void sv_add_server_command_msg()
		{
			__asm
			{
				pushad;

				push ebx;
				call callback_is_bot_adr;
				add esp, 4;

				test al, al;
				jnz fix;

				popad;

				jmp sv_add_server_command_msg_original;

			fix:
				popad;

				push 0x00575DDA;
				retn;
			}
		}

		__declspec(naked) void sv_check_timeouts()
		{
			__asm
			{
				pushad;

				push ebp;
				call callback_is_bot;
				add esp, 4;

				test al, al;
				jnz fix;

				popad;

				jmp sv_check_timeouts_original;

			fix:
				popad;

				push 0x00576E76;
				retn;
			}
		}

		__declspec(naked) void iw_steam_server_run_frame()
		{
			__asm
			{
				pushad;

				push edi;
				call callback_is_bot;
				add esp, 4;

				test al, al;
				jnz fix;

				popad;

				jmp iw_steam_server_run_frame_original;

			fix:
				popad;

				push 0x0063753D;
				retn;
			}
		}

		const char* client_connect(ClientNum_t clientNum, std::uint16_t scriptPersId)
		{
			if (is_bot(clientNum))
			{
				game::svs_client(clientNum)->state() = game::CS_FREE;
				return "EXE_PLAYERKICKED";
			}

			return reinterpret_cast<decltype(&client_connect)>(0x004FAFB0)(clientNum, scriptPersId);
		}
	}
	
	void SV_SendClientGameState(game::client_t* client)
	{
		static constexpr auto address = 0x00570FC0;
		
		__asm
		{
			mov eax, address;
			
			push esi;
			mov esi, client;
			call eax;
			pop esi;
		}
	}
	
	game::gentity_s* add_test_client()
	{
		auto bot_num = 0u;

		for (; bot_num < game::max_clients; ++bot_num)
		{
			if (game::svs_client(bot_num)->state() == game::CS_FREE)
			{
				break;
			}
		}

		if (bot_num == game::max_clients)
		{
			PRINT_MESSAGE("Can't add bot, server is full.");
		}
		else
		{
			char connect[1024] = { 0 };
			sprintf_s(connect, "connect bot%d \"\\cg_predictItems\\1\\cl_anonymous\\0\\color\\4\\head\\default\\model\\multi\\snaps\\20\\rate\\5000\\name\\furtive[%d]\\protocol\\%d\\checksum\\%d\\statver\\%d %u\\qport\\%u\"",
				bot_num,
				bot_num,
				20604,
				game::BG_NetDataChecksum(),
				game::LiveStorage_GetPersistentDataDefVersion(),
				game::LiveStorage_GetPersistentDataDefFormatChecksum(),
				bot_num);

			game::netadr_t adr = {};
			adr.port = bot_num;
			
			game::SV_Cmd_TokenizeString(connect);
			game::SV_DirectConnect(adr);
			game::SV_Cmd_EndTokenizedString();

			for (bot_client = game::svs_client(bot_num); bot_num < game::max_clients; ++bot_num)
			{
				if (bot_client->state())
				{
					if (game::NET_CompareBaseAdr(bot_client->remote_address(), adr))
					{
						break;
					}
				}
			}

			if (bot_num < game::max_clients)
			{
				SV_SendClientGameState(bot_client);

				game::usercmd_s usercmd = {};
				game::SV_ClientEnterWorld(bot_client, &usercmd);

				return game::gentity(bot_num);
			}
		}

		return nullptr;
	}

	bool is_bot(size_t client_num)
	{
		return std::strstr(game::SV_GetGuid(client_num), "bot");
	}

	void bot_team_join(const size_t entity_num)
	{
		scheduler::once([entity_num]()
		{
			game::SV_ExecuteClientCommand(
				game::svs_client(entity_num),
				("mr " + std::to_string(game::server_id) + " 2 autoassign").data(),
				true, false);

			scheduler::once([entity_num]()
			{
				game::SV_ExecuteClientCommand(
					game::svs_client(entity_num),
					("mr " + std::to_string(game::server_id) + " 9 class1").data(),
					true, false);
				
			}, scheduler::pipeline::renderer, 1s);
			
		}, scheduler::pipeline::renderer, 1s);
	}

	void bot_team(const size_t entity_num)
	{
		if (is_bot(game::gentity(entity_num)->entity_num()))
		{
			if (game::cg()->client(entity_num)->team() == game::TEAM_SPECTATOR)
			{
				bot_team_join(entity_num);
			}

			scheduler::once([entity_num]()
			{
				bot_team(entity_num);
			}, scheduler::pipeline::renderer, 3s);
		}
	}

	void spawn_bot(const size_t entity_num)
	{
		scheduler::once([entity_num]()
		{
			bot_team(entity_num);
		}, scheduler::pipeline::renderer, 1s);
	}
	
	void add_bot()
	{
		const auto gentity = add_test_client();

		if (gentity)
		{
			spawn_bot(gentity->entity_num());
		}
	}

	void initialize()
	{
		utils::hook::detour(&patches::sv_add_server_command_original, &patches::sv_add_server_command);
		utils::hook::detour(&patches::sv_add_server_command_msg_original, &patches::sv_add_server_command_msg);
		utils::hook::detour(&patches::sv_check_timeouts_original, &patches::sv_check_timeouts);
		utils::hook::detour(&patches::iw_steam_server_run_frame_original, &patches::iw_steam_server_run_frame);
		
		utils::hook::call(0x005754A3, &patches::client_connect);
	}
}