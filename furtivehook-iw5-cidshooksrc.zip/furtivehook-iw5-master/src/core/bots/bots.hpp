#pragma once
#include "dependencies/std_include.hpp"

namespace bots
{
	bool is_bot(size_t client_num);
	void add_bot();
	void initialize();

	namespace patches
	{
		void sv_check_timeouts();
		void sv_add_server_command_msg();
		void sv_add_server_command();
		void iw_steam_server_run_frame();
	}
}