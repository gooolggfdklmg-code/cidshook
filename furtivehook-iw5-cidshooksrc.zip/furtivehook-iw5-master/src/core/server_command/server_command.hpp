#pragma once

namespace server_command
{
	void on_server_command(std::uint8_t command, const std::function<bool(command::params_&)>& callback);
	void cg_execute_new_server_commands();
	void initialize();
	extern bool log_sv_commands;
}
