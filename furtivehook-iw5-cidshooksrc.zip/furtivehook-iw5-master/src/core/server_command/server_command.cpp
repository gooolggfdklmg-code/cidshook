#include "dependencies/std_include.hpp"
#include "server_command.hpp"

namespace server_command
{
	auto cg_execute_new_server_commands_original = reinterpret_cast<decltype(&cg_execute_new_server_commands)>(0x0046B2BE);
	std::unordered_map<std::uint8_t, std::function<bool(command::params_&)>> callbacks;
	bool log_sv_commands = false;
	
	void on_server_command(std::uint8_t command, const std::function<bool(command::params_&)>& callback)
	{
		if (callbacks.find(command) == callbacks.end())
		{
			callbacks[command] = callback;
		}
	}
	
	bool can_handle_server_command(std::uint8_t command)
	{
		return callbacks.find(command) != callbacks.end() && callbacks[command];
	}
	
	void log_server_commands(const std::string& command)
	{
		if (log_sv_commands)
		{
			PRINT_LOG("Received SV Command: %s", command.data());
			return;
		}

		logger::print_sv_log("Received SV Command: %s", command.data());
	}
	
	bool handle_server_command()
	{
		command::params_ params = {};

		if (params.size() >= 1)
		{
			auto cmd_string = params[0][0];

			log_server_commands(params.join(0));

			if (can_handle_server_command(cmd_string))
			{
				return callbacks[cmd_string](params);
			}
		}

		return false;
	}
	
	bool callback_cg_execute_new_server_commands()
	{
		if (handle_server_command())
		{
			return true;
		}

		return false;
	}

	__declspec(naked) void cg_execute_new_server_commands()
	{
		__asm
		{
			pushad;
			call callback_cg_execute_new_server_commands;
			test al, al;
			jnz fix;
			popad;
			
			jmp cg_execute_new_server_commands_original;

		fix:
			popad;
			
			push 0x00046B374;
			retn;
		}
	}
	
	void initialize()
	{
		utils::hook::detour(&cg_execute_new_server_commands_original, &cg_execute_new_server_commands);
	}
}