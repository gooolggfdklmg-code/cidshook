#pragma once
#include "dependencies/std_include.hpp"

namespace logger
{
	void print_log(const char* msg, ...);
	void print_sv_log(const char * msg, ...);
}