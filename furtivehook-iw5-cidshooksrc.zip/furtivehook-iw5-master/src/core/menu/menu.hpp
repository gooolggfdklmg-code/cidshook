#pragma once
#include "dependencies/std_include.hpp"

namespace menu
{
	constexpr static auto window_title = "furtive hook";
	constexpr static auto color_flags = ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip;
	constexpr static auto window_flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize;
	const Vec2 color_position = { 430.5f, 455.0f };
	extern bool initialized;
	extern ImFont* glacial_indifference_bold_base_85;
	extern ImFont* glacial_indifference_base_85;
	extern std::unordered_map<std::string, std::string> map_names;
	
	void initialize(IDirect3DDevice9 * device);
	std::pair<std::string, std::string> get_rce_commands(const float width);
	void draw();
	bool is_open();
	void set_style();
}
