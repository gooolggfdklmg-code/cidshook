#pragma once
#include "dependencies/std_include.hpp"

namespace esp::chams
{
	void r_draw_indexed_primitive(void * state, const void * args);
	void __cdecl r_add_dobj_to_scene(const void * dobj, const void * cpose, std::uint32_t entity_num, std::uint32_t fx_flags, float * lightingOrigin, float materialTime);
	void initialize();

	extern bool chams;
}