#include "dependencies/std_include.hpp"
#include "core/esp/chams/chams.hpp"
//#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib") 

namespace esp::chams
{
	auto r_draw_indexed_primitive_original = reinterpret_cast<decltype(&r_draw_indexed_primitive)>(0x006889B0);
	auto r_add_dobj_to_scene_original = reinterpret_cast<decltype(&r_add_dobj_to_scene)>(0x006809F0);
	LPDIRECT3DTEXTURE9 yellow_texture, green_texture;
	bool chams = false;
	
	void __cdecl r_add_dobj_to_scene(const void* dobj, const void* cpose, std::uint32_t entity_num, std::uint32_t fx_flags, float* lightingOrigin, float materialTime)
	{
		r_add_dobj_to_scene_original(dobj, cpose, entity_num, fx_flags, lightingOrigin, materialTime);
	}
	
	void r_draw_indexed_primitive(void* state, const void* args)
	{
		auto player_texture_names = { "" };
		
		if (const auto client_num = game::cg()->number(); game::cg()->client(client_num)->team() == game::TEAM_ALLIES)
		{
			player_texture_names = 
			{
				"henchmen",
				"russian",
				"militia",
				"sniper",
				"ghillie",
				"sleeve",
				"viewmodel",
			};
		}
		else if(game::cg()->client(client_num)->team() == game::TEAM_AXIS)
		{
			player_texture_names =
			{
				"delta",
				"sas",
				"gign",
				"africa",
				"pmc",
				"ghillie",
				"sleeve",
				"viewmodel",
			};
		}
		else if (game::cg()->client(client_num)->team() == game::TEAM_FREE)
		{
			player_texture_names =
			{ 
				"delta",
				"sas",
				"gign",
				"africa",
				"pmc",
				"ghillie",
				"sleeve",
				"viewmodel",
				"henchmen",
				"russian",
				"militia",
				"sniper",
			};
		}
		
		const auto material_name = **(reinterpret_cast<const char***>(state) + 0x0A); 
		auto chams = false;
		
		for (const auto& player_texture_name : player_texture_names)
		{
			if (std::strstr(material_name, player_texture_name))
			{
				chams = true & chams::chams;
				break;
			}
		}
		
		if (chams) 
		{
			(*game::device)->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
			(*game::device)->SetTexture(0, green_texture);
		}

		r_draw_indexed_primitive_original(state, args);

		if (chams) 
		{
			(*game::device)->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
			(*game::device)->SetTexture(0, yellow_texture);
			
			r_draw_indexed_primitive_original(state, args);
		}
	}
	
	void initialize()
	{
		const static std::uint8_t yellow[] =
		{
			0x42, 0x4D, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
			0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
			0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x12, 0x0B, 0x00, 0x00, 0x12, 0x0B, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0xFF, 0xFF, 0x00, 0x00, 0x00
		};

		const static std::uint8_t green[] =
		{
			0x42, 0x4D, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00,
			0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
			0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0x12, 0x0B, 0x00, 0x00, 0x12, 0x0B, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x20, 0xA0, 0x00, 0x00, 0xFF, 0xFF
		}; 
		
		if (static auto initialized = false; !initialized)
		{
			initialized = true;

			//D3DXCreateTextureFromFileInMemory(*game::device, &yellow, std::size(yellow), &yellow_texture);
			//D3DXCreateTextureFromFileInMemory(*game::device, &green, std::size(green), &green_texture);
		}

		//utils::hook::call(0x006A1CAB, r_draw_indexed_primitive);
	}
}