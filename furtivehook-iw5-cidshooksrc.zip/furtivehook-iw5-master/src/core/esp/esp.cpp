#include "dependencies/std_include.hpp"
#include "esp.hpp"
#include <d3d9.h>

namespace esp
{
	esp_info_t esp_info[18];
	float bone_thickness = 2.0f;
	std::uint32_t point_scale = 3;
	bool enabled = false, name_tag = true, box = true, bone_esp = true, aimbot_positions = false, enemies_only = true;
	ImVec4 enemy_visible_color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f), enemy_color = ImVec4(0.0f, 0.5f, 1.0f, 1.0f), friendly_color = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
	std::vector<game::bone_tag> esp_bones
	{
		game::bone_tag::helmet,
		game::bone_tag::head_end,
		game::bone_tag::head,
		game::bone_tag::neck,
		game::bone_tag::shoulder_left,
		game::bone_tag::shoulder_right,
		game::bone_tag::clavicle_left,
		game::bone_tag::clavicle_right,
		game::bone_tag::spineupper,
		game::bone_tag::spine,
		game::bone_tag::spinelower,
		game::bone_tag::hip_left,
		game::bone_tag::hip_right,
		game::bone_tag::knee_left,
		game::bone_tag::knee_right,
		game::bone_tag::wrist_left,
		game::bone_tag::wrist_right,
		game::bone_tag::wrist_twist_left,
		game::bone_tag::wrist_twist_right,
		game::bone_tag::elbow_left,
		game::bone_tag::elbow_right,
		game::bone_tag::elbow_buldge_left,
		game::bone_tag::elbow_buldge_right,
		game::bone_tag::ankle_left,
		game::bone_tag::ankle_right,
		game::bone_tag::ball_left,
		game::bone_tag::ball_right,
		game::bone_tag::mainroot,
	};

	void draw_string(const std::string& text, const ImVec2& position, const ImVec4& color, const bool shadow, const float font_size)
	{
		if (shadow)
		{
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x - 1.0f, position.y - 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x, position.y - 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x + 1.0f, position.y - 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x + 1.0f, position.y }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x + 1.0f, position.y + 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x, position.y + 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x - 1.0f, position.y + 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
			ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, { position.x - 1.0f, position.y }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }), text.data());
		}

		ImGui::GetWindowDrawList()->AddText(menu::glacial_indifference_base_85, font_size, position, ImGui::GetColorU32(color), text.data());
	}

	void draw_string(size_t index, float height, const bool shadow, const float font_size = 15.0f)
	{
		char player_name_with_clan[42] = { 0 };
		game::CL_GetClientName(0, index, player_name_with_clan, sizeof player_name_with_clan);

		const auto size = menu::glacial_indifference_base_85->CalcTextSizeA(font_size, FLT_MAX, 0.0f, player_name_with_clan);

		draw_string(player_name_with_clan,
			{ esp_info[index].screen.x - size.x / 2.0f, esp_info[index].screen.y - height / 2.0f - size.y },
			{ 1.0f, 1.0f, 1.0f, 1.0f },
			shadow,
			font_size);
	}

	void draw_box(const float x, const float y, const float w, const float h, const bool border, const ImVec4& color)
	{
		if (border)
			ImGui::GetWindowDrawList()->AddRect({ x, y }, { x + w, y + h }, ImGui::GetColorU32(color));
		else
			ImGui::GetWindowDrawList()->AddRectFilled({ x, y }, { x + w, y + h }, ImGui::GetColorU32(color));
	}
	
	void draw_line(const float x, const float y, const float w, const float h, const ImVec4& color)
	{
		ImGui::GetWindowDrawList()->AddLine({ x, y }, { w, h }, ImGui::GetColorU32(color), bone_thickness);
	}
	
	void draw_corners(float x, float y, float w, float h, const Vec2& length, const ImVec4& color, bool shadow)
	{
		if (shadow)
		{
			ImGui::GetWindowDrawList()->AddRectFilled({ x - 1.0f, y - 1.0f }, { x + length.x + 2.0f, y + 2.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
			ImGui::GetWindowDrawList()->AddRectFilled({ x - 1.0f, y - 1.0f }, { x + 2.0f, y + length.y + 2.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
			ImGui::GetWindowDrawList()->AddRectFilled({ x + w - length.x - 1.0f, y - 1.0f }, { x + w + 1.0f, y + 2.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
			ImGui::GetWindowDrawList()->AddRectFilled({ x + w - 2.0f, y - 1.0f }, { x + w + 1.0f, y + length.y + 2.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
			ImGui::GetWindowDrawList()->AddRectFilled({ x - 1.0f, y + h - 2.0f }, { x + length.x + 2.0f, y + h + 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
			ImGui::GetWindowDrawList()->AddRectFilled({ x - 1.0f, y + h - length.y - 1.0f }, { x + 2.0f, y + h + 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
			ImGui::GetWindowDrawList()->AddRectFilled({ x + w - length.x - 1.0f, y + h - 2.0f }, { x + w + 1.0f, y + h + 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
			ImGui::GetWindowDrawList()->AddRectFilled({ x + w - 2.0f, y + h - length.y - 1.0f }, { x + w + 1.0f, y + h + 1.0f }, ImGui::GetColorU32({ 0.0f, 0.0f, 0.0f, 1.0f }));
		}

		ImGui::GetWindowDrawList()->AddRectFilled({ x, y }, { x + length.x + 1.0f, y + 1.0f }, ImGui::GetColorU32(color));
		ImGui::GetWindowDrawList()->AddRectFilled({ x, y }, { x + 1.0f, y + length.y + 1.0f }, ImGui::GetColorU32(color));
		ImGui::GetWindowDrawList()->AddRectFilled({ x + w - length.x, y }, { x + w, y + 1.0f }, ImGui::GetColorU32(color));
		ImGui::GetWindowDrawList()->AddRectFilled({ x + w - 1.0f, y }, { x + w, y + length.y + 1.0f }, ImGui::GetColorU32(color));
		ImGui::GetWindowDrawList()->AddRectFilled({ x, y + h - 1.0f }, { x + length.x + 1.0f, y + h }, ImGui::GetColorU32(color));
		ImGui::GetWindowDrawList()->AddRectFilled({ x, y + h - length.y }, { x + 1.0f, y + h }, ImGui::GetColorU32(color));
		ImGui::GetWindowDrawList()->AddRectFilled({ x + w - length.x, y + h - 1.0f }, { x + w, y + h }, ImGui::GetColorU32(color));
		ImGui::GetWindowDrawList()->AddRectFilled({ x + w - 1.0f, y + h - length.y }, { x + w, y + h }, ImGui::GetColorU32(color));
	}

	void draw_bones(const ImVec2 bones2d[static_cast<size_t>(game::bone_tag::num_tags)], const std::vector<Vec2> points, const ImVec4& color, const bool priority)
	{
		if (bone_esp)
		{
			draw_line(bones2d[static_cast<size_t>(game::bone_tag::helmet)][0], bones2d[static_cast<size_t>(game::bone_tag::helmet)][1],
				bones2d[static_cast<size_t>(game::bone_tag::head)][0], bones2d[static_cast<size_t>(game::bone_tag::head)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::head)][0], bones2d[static_cast<size_t>(game::bone_tag::head)][1],
				bones2d[static_cast<size_t>(game::bone_tag::neck)][0], bones2d[static_cast<size_t>(game::bone_tag::neck)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::neck)][0], bones2d[static_cast<size_t>(game::bone_tag::neck)][1],
				bones2d[static_cast<size_t>(game::bone_tag::shoulder_left)][0], bones2d[static_cast<size_t>(game::bone_tag::shoulder_left)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::neck)][0], bones2d[static_cast<size_t>(game::bone_tag::neck)][1],
				bones2d[static_cast<size_t>(game::bone_tag::shoulder_right)][0], bones2d[static_cast<size_t>(game::bone_tag::shoulder_right)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::shoulder_left)][0], bones2d[static_cast<size_t>(game::bone_tag::shoulder_left)][1],
				bones2d[static_cast<size_t>(game::bone_tag::elbow_left)][0], bones2d[static_cast<size_t>(game::bone_tag::elbow_left)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::shoulder_right)][0], bones2d[static_cast<size_t>(game::bone_tag::shoulder_right)][1],
				bones2d[static_cast<size_t>(game::bone_tag::elbow_right)][0], bones2d[static_cast<size_t>(game::bone_tag::elbow_right)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::shoulder_right)][0], bones2d[static_cast<size_t>(game::bone_tag::shoulder_right)][1],
				bones2d[static_cast<size_t>(game::bone_tag::elbow_right)][0], bones2d[static_cast<size_t>(game::bone_tag::elbow_right)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::elbow_left)][0], bones2d[static_cast<size_t>(game::bone_tag::elbow_left)][1],
				bones2d[static_cast<size_t>(game::bone_tag::wrist_left)][0], bones2d[static_cast<size_t>(game::bone_tag::wrist_left)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::elbow_right)][0], bones2d[static_cast<size_t>(game::bone_tag::elbow_right)][1],
				bones2d[static_cast<size_t>(game::bone_tag::wrist_right)][0], bones2d[static_cast<size_t>(game::bone_tag::wrist_right)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::neck)][0], bones2d[static_cast<size_t>(game::bone_tag::neck)][1],
				bones2d[static_cast<size_t>(game::bone_tag::spinelower)][0], bones2d[static_cast<size_t>(game::bone_tag::spinelower)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::spinelower)][0], bones2d[static_cast<size_t>(game::bone_tag::spinelower)][1],
				bones2d[static_cast<size_t>(game::bone_tag::knee_left)][0], bones2d[static_cast<size_t>(game::bone_tag::knee_left)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::spinelower)][0], bones2d[static_cast<size_t>(game::bone_tag::spinelower)][1],
				bones2d[static_cast<size_t>(game::bone_tag::knee_right)][0], bones2d[static_cast<size_t>(game::bone_tag::knee_right)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::knee_left)][0], bones2d[static_cast<size_t>(game::bone_tag::knee_left)][1],
				bones2d[static_cast<size_t>(game::bone_tag::ankle_left)][0], bones2d[static_cast<size_t>(game::bone_tag::ankle_left)][1],
				color);

			draw_line(bones2d[static_cast<size_t>(game::bone_tag::knee_right)][0], bones2d[static_cast<size_t>(game::bone_tag::knee_right)][1],
				bones2d[static_cast<size_t>(game::bone_tag::ankle_right)][0], bones2d[static_cast<size_t>(game::bone_tag::ankle_right)][1],
				color);
		}

		if (aimbot_positions)
		{
			for (const auto bone : esp_bones)
			{
				ImGui::GetWindowDrawList()->AddRectFilled({ bones2d[size_t(bone)][0], bones2d[size_t(bone)][1] }, { bones2d[size_t(bone)][0] + bone_thickness, bones2d[size_t(bone)][1] + bone_thickness }, ImGui::GetColorU32(color));

				if (priority)
					ImGui::GetWindowDrawList()->AddRectFilled({ points[size_t(bone)].x, points[size_t(bone)].y }, { points[size_t(bone)].x + bone_thickness, points[size_t(bone)].y + bone_thickness }, ImGui::GetColorU32(color));
			}
		}
	}
	
	bool is_valid_target(game::centity_t* cent)
	{
		if (!cent->is_alive() || !cent->valid())
			return false;

		if (cent->next_state().number == game::cg()->number())
			return false;

		return true;
	}
	
	void visuals()
	{
		for (size_t i = 0; i < 18; i++)
		{
			esp_info[i].valid = false;

			if (const auto cent = game::cg()->centity(i); is_valid_target(cent))
			{
				Vec3 min_temp = { std::numeric_limits<float>::max(), std::numeric_limits<float>::max(), std::numeric_limits<float>::max() },
					max_temp = { std::numeric_limits<float>::lowest(), std::numeric_limits<float>::lowest(), std::numeric_limits<float>::lowest() };

				for (size_t bone = 0; bone < game::bone_tags.size(); ++bone)
				{
					if (const auto dobj = game::Com_GetClientDObj(cent->next_state().number); dobj)
						game::CG_DObjGetWorldTagPos(cent, dobj, game::get_tag(esp_bones[bone]), &esp_info[i].bone_pos[bone]);

					game::CG_WorldPosToScreenPos(&esp_info[i].bone_pos[bone], &esp_info[i].temp);

					for (size_t j = 0; j < 3; ++j)
					{
						if (esp_info[i].bone_pos[bone][j] < min_temp[j])
							min_temp[j] = esp_info[i].bone_pos[bone][j];

						if (esp_info[i].bone_pos[bone][j] > max_temp[j])
							max_temp[j] = esp_info[i].bone_pos[bone][j];
					}

					esp_info[i].bone_2d[bone].x = esp_info[i].temp.x;
					esp_info[i].bone_2d[bone].y = esp_info[i].temp.y;
				}

				if (aimbot::priority_target[i])
				{
					esp_info[i].points_2d.clear();

					Vec2 point_2d{};

					if (!aimbot::enabled)
					{
						aimbot::target[i].points.clear();
					}
					
					for (const auto& points : aimbot::target[i].points)
					{
						game::CG_WorldPosToScreenPos(&points, &point_2d);
						esp_info[i].points_2d.emplace_back(point_2d);
					}
				}

				esp_info[i].center_pos = (min_temp + max_temp) / 2.0f;
				esp_info[i].valid = true;

				auto feet = cent->origin(); feet.z += 55.0f;
				esp_info[i].w2s = game::CG_WorldPosToScreenPos(&cent->origin(), &esp_info[i].bottom) && game::CG_WorldPosToScreenPos(&feet, &esp_info[i].top) && game::CG_WorldPosToScreenPos(&esp_info[i].center_pos, &esp_info[i].screen);
			}
		}
	}
	
	void run()
	{
		if (!enabled || !game::CL_IsLocalClientInGame())
			return;

		for (size_t i = 0; i < 18; i++)
		{
			if (const auto cent = game::cg()->centity(i); esp_info[i].w2s && esp_info[i].valid)
			{
				float width, height, scale;
				scale = esp_info[i].bottom.y - esp_info[i].top.y;

				if (cent->next_state().lerp.eFlags & 0x08) 
				{
					width = scale / 1.5f;
					height = scale / 2.0f;
				}
				else if (cent->next_state().lerp.eFlags & 0x04) 
				{
					width = scale / 2.0f;
					height = scale / 2.0f;
				}
				else 
				{
					width = scale / 2.0f;
					height = scale / 1.5f;
				}

				width *= 1.75f;
				height *= 1.75f;

				if (!aimbot::enabled && aimbot::target[i].vulnerable)
					aimbot::target[i].vulnerable = false; 
				
				auto bone_color = aimbot::ignore_target[i] ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : aimbot::priority_target[i] ? ImVec4(1.0f, 0.0f, 0.0f, 1.0f) : (aimbot::target[i].vulnerable ? enemy_visible_color : enemy_color);
				auto esp_color = aimbot::ignore_target[i] ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : aimbot::priority_target[i] ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : (aimbot::target[i].vulnerable ? enemy_visible_color : enemy_color);

				if (enemies_only && !game::is_enemy(i))
					continue; 
				
				if (!game::is_enemy(i)) {
					esp_color = friendly_color;
					bone_color = friendly_color;
				}

				if (aimbot::priority_target[i] && aimbot::target[i].vulnerable)
					bone_color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);

				if (name_tag)
					draw_string(i, height, true);

				if (box)
					draw_corners(esp_info[i].screen.x - width / 2.0f, esp_info[i].screen.y - height / 2.0f, width, height, { width / 3.0f, height / 3.0f }, { esp_color.x, esp_color.y, esp_color.z, 1.0f }, true);

				draw_bones(esp_info[i].bone_2d, esp_info[i].points_2d, { bone_color.x, bone_color.y, bone_color.z, 1.0f }, aimbot::priority_target[i] & !aimbot::ignore_target[i]);
			}
		}
	}
	
	void draw()
	{
		ImGui::PushStyleColor(ImGuiCol_WindowBg, {});
		ImGui::PushStyleColor(ImGuiCol_Border, {});

		ImGui::SetNextWindowPos({});
		ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);

		if (!ImGui::Begin(window_title, nullptr, window_flags))
		{
			ImGui::End();
			return;
		}

		ImGui::GetWindowDrawList()->PushClipRectFullScreen();

		run();

		ImGui::PopStyleColor(2);
	}
}