#pragma once
#include "dependencies/std_include.hpp"

namespace esp
{
	struct esp_info_t
	{
		bool valid, w2s;
		std::vector<Vec2> points_2d;
		Vec3 bone_pos[static_cast<std::uint32_t>(game::bone_tag::num_tags)], center_pos;
		ImVec2 bone_2d[static_cast<std::uint32_t>(game::bone_tag::num_tags)];
		Vec2 temp, bottom, top, screen;
	};

	constexpr static auto window_title = "visuals"; 
	constexpr static auto window_flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoInputs;
	
	extern float bone_thickness;
	extern bool enabled, name_tag, box, bone_esp, aimbot_positions, enemies_only;
	extern ImVec4 enemy_visible_color, enemy_color, friendly_color;

	void visuals();
	void draw();
}
