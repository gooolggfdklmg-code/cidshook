#pragma once
#include "dependencies/std_include.hpp"

namespace scheduler
{
	enum class pipeline
	{
		async,
		renderer,
		main,
		server,
	};

	static const bool cond_continue = false;
	static const bool cond_end = true;
	
	void __cdecl draw_active(LocalClientNum_t localClientNum, void * viewParmsDraw);
	void __cdecl com_frame();
	void __cdecl g_glass_update();
	void execute(const pipeline type);
	void schedule(const std::function<bool()>& callback, pipeline type = pipeline::async, std::chrono::milliseconds delay = 0ms);
	void loop(const std::function<void()>& callback, pipeline type = pipeline::async, std::chrono::milliseconds delay = 0ms);
	void once(const std::function<void()>& callback, pipeline type = pipeline::async, std::chrono::milliseconds delay = 0ms);
	void async();
	void destroy_thread();
	void initialize();
}