#include "dependencies/std_include.hpp"
#include "scheduler.hpp"

namespace scheduler
{
	struct task
	{
		pipeline type;
		std::function<bool()> handler;
		std::chrono::milliseconds interval;
		std::chrono::high_resolution_clock::time_point last_call{};
	};

	auto draw_active_original = reinterpret_cast<decltype(&draw_active)>(0x00448990);
	auto com_frame_original = reinterpret_cast<decltype(&com_frame)>(0x00556470); 
	auto g_glass_update_original = reinterpret_cast<decltype(&g_glass_update)>(0x00505BB0);
	volatile bool kill = false;
	std::thread thread;
	utils::concurrent_list<task> callbacks;

	void __cdecl draw_active(LocalClientNum_t localClientNum, void *viewParmsDraw)
	{
		execute(pipeline::renderer); 
		draw_active_original(localClientNum, viewParmsDraw);
	}

	void __cdecl com_frame()
	{
		execute(pipeline::main); 
		com_frame_original();
	}

	void __cdecl g_glass_update()
	{
		g_glass_update_original();
		execute(pipeline::server);
	}

	void execute(const pipeline type)
	{
		for (auto callback : callbacks)
		{
			if (callback->type != type)
			{
				continue;
			}

			const auto now = std::chrono::high_resolution_clock::now();
			const auto diff = now - callback->last_call;

			if (diff < callback->interval)
			{
				continue;
			}

			callback->last_call = now;

			const auto res = callback->handler();
			if (res == cond_end)
			{
				callbacks.remove(callback);
			}
		}
	}

	void schedule(const std::function<bool()>& callback, const pipeline type, const std::chrono::milliseconds delay)
	{
		task task;
		task.type = type;
		task.handler = callback;
		task.interval = delay;
		task.last_call = std::chrono::high_resolution_clock::now();

		callbacks.add(task);
	}

	void loop(const std::function<void()>& callback, const pipeline type, const std::chrono::milliseconds delay)
	{
		schedule([callback]()
		{
			callback();
			return cond_continue;
		}, type, delay);
	}

	void once(const std::function<void()>& callback, const pipeline type, const std::chrono::milliseconds delay)
	{
		schedule([callback]()
		{
			callback();
			return cond_end;
		}, type, delay);
	}

	void async()
	{
		thread = std::thread([]()
		{
			while (!kill)
			{
				execute(pipeline::async);
				std::this_thread::sleep_for(10ms);
			}
		});
	}

	void destroy_thread()
	{
		kill = true;
		if (thread.joinable())
		{
			thread.join();
		}

		utils::toast::hide();
	}
	
	void initialize()
	{
		utils::hook::detour(&com_frame_original, &com_frame);
		utils::hook::detour(&draw_active_original, &draw_active);
		utils::hook::detour(&g_glass_update_original, &g_glass_update);
	}
}