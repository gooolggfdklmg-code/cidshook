#include "dependencies/std_include.hpp"
#include "host.hpp"

namespace host
{
	bool force_host, unlimited_ammo, anti_leave;
	float jump_height = 39.0f;
	std::uint32_t movement_speed = 190, gravity = 800;

	void set_unlimited_ammo(size_t index)
	{
		for (auto slot = 0u; slot < 15u; ++slot)
		{
			const auto clip_for_weapon = game::BG_ClipForWeapon(game::gclient(index)->ps.held_weapons(slot), false);
			game::BG_AddClipAmmo(&game::gclient(index)->ps, clip_for_weapon, 0, 1024);
		}
	}
	
	void on_force_host()
	{
		if (const static auto private_match = game::Dvar_FindVar("xblive_privatematch"); force_host && !private_match->current.enabled)
		{
			const static auto gametype = game::Dvar_FindVar("ui_gametype"); 
			const static auto team_based = game::Dvar_FindVar("party_teambased");
			const static auto min_players = game::Dvar_FindVar("party_minplayers");
			const static auto team_diffrence = game::Dvar_FindVar("party_maxTeamDiff");
			const static auto connect_timeout = game::Dvar_FindVar("pt_connectTimeout");
			const static auto game_start_timer_length = game::Dvar_FindVar("pt_gameStartTimerLength");
			const static auto pregame_start_timer_length = game::Dvar_FindVar("pt_pregameStartTimerLength");
			team_based->current.enabled = gametype->current.string != "dm"s;
			min_players->current.integer = 1;
			team_diffrence->current.integer = 18;
			connect_timeout->current.integer = 1;
			game_start_timer_length->current.integer = 0;
			pregame_start_timer_length->current.integer = 0;
		}
	}

	void initialize()
	{
		scheduler::loop(on_force_host, scheduler::pipeline::main, 1500ms);
		scheduler::loop(stats::set_stats_integrity_dvars, scheduler::pipeline::server);

		scheduler::loop([]()
		{
			static auto allow_leave = false;
				
			if (anti_leave) 
			{
				allow_leave = true; 
				
				game::send_server_command(-1, "q g_scriptMainMenu aaaa");
			}
			else if(allow_leave)
			{
				allow_leave = false; 
				
				game::send_server_command(-1, "q g_scriptMainMenu class");
			}
		}, scheduler::pipeline::renderer, 2500ms); 
		
		scheduler::loop([]()
		{
			for (size_t i = 0; i < game::max_clients; ++i)
			{
				if (game::is_valid_target(i))
				{
					if (unlimited_ammo)
						set_unlimited_ammo(i);
				}
			}
			
			if (const auto client_num = game::cg()->number(); game::cg()->centity(client_num)->is_alive())
			{
				if(game::gclient(game::cg()->number())->m_flags() & 4)
					game::gclient(game::cg()->number())->m_flags() = 0;
			}

		}, scheduler::pipeline::server);
	}
}