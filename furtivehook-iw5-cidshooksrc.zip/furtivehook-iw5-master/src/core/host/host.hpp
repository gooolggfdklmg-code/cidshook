#pragma once
#include "dependencies/std_include.hpp"

namespace host
{
	void on_force_host();
	void initialize();

	extern bool force_host, unlimited_ammo, anti_leave;
	extern float jump_height; 
	extern std::uint32_t movement_speed, gravity;
}