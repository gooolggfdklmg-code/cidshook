#pragma once
#include "dependencies/std_include.hpp"

namespace network
{
	using callback = std::function<bool(const command::params_&, const game::netadr_t&, game::msg_t&)>; 
	
	void on_command(const std::string & command, const callback & callback);
	void cl_dispatch_connectionless_packet();
	void initialize();

	extern bool log_packets;
}