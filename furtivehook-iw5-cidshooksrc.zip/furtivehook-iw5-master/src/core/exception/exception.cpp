#include "dependencies/std_include.hpp"
#include "exception.hpp"

namespace exception
{
	bool is_harmless_error(const std::uint32_t code)
	{
		return code == STATUS_INTEGER_OVERFLOW
			|| code == STATUS_FLOAT_OVERFLOW
			|| code == STATUS_SINGLE_STEP;
	}
	
	LONG __stdcall exception_filter(const LPEXCEPTION_POINTERS ex)
	{
		const auto addr = ex->ExceptionRecord->ExceptionAddress;
		const auto code = ex->ExceptionRecord->ExceptionCode;

		if (is_harmless_error(code))
		{
			return EXCEPTION_CONTINUE_EXECUTION;
		}

		auto error = "Termination due to a stack overflow."s;
		if (code != EXCEPTION_STACK_OVERFLOW)
		{
			error = utils::string::va("Exception (0x%08X) at 0x%08X", code, ex->ExceptionRecord->ExceptionAddress);
		}
		
		const auto filename = utils::generate_log_filename("furtivehook\\logs\\minidumps\\", "dmp");
		utils::io::write_minidump(ex, filename, error);
		game::Com_Error(game::ERR_DROP, error.data());

		return EXCEPTION_CONTINUE_SEARCH;
	}

	LPTOP_LEVEL_EXCEPTION_FILTER __stdcall set_unhandled_exception_filter(LPTOP_LEVEL_EXCEPTION_FILTER)
	{
		return &exception_filter;
	}
	
	void initialize()
	{
		SetUnhandledExceptionFilter(exception_filter);
		utils::hook::jump(&SetUnhandledExceptionFilter, &set_unhandled_exception_filter);
	}
}