#pragma once
#include "dependencies/std_include.hpp"

namespace session
{
	void session_list();
	void initialize();
}