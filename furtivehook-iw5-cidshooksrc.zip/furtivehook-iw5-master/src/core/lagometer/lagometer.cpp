#include "dependencies/std_include.hpp"
#include "core/lagometer/lagometer.hpp"

namespace lagometer
{
	auto cl_get_snapshot_original = reinterpret_cast<decltype(&cl_get_snapshot)>(0x00484450);
	auto cg_draw_2d_original = reinterpret_cast<decltype(&cg_draw_2d)>(0x00448770);
	game::lagometer_t lagometer = {};
	bool draw_lagometer = false;
	
	void cg_draw_lagometer()
	{
		if (const auto active_placement = game::ScrPlace_GetActivePlacement(); active_placement && draw_lagometer)
		{
			game::UI_DrawHandlePic(active_placement, -55.0f, -140.0f, 48.0f, 48.0f, 3, 3, nullptr, game::get_shader(game::shader::lagometer));

			const auto range = 16.0f;
			const auto rangea = 24.0f;

			for (auto ay = 0u; ay < 48u; ++ay)
			{
				const auto i = (lagometer.frameCount - 1 - ay) & (LAG_SAMPLES - 1);
				auto v = lagometer.frameSamples[i] * (range / MAX_LAGOMETER_RANGE);

				if (v > 0)
				{
					game::CL_DrawStretchPic(active_placement, -8.0f - ay, -124.0f - std::fminf(v, range), 1.0f, std::fminf(v, range), 3, 3, 0.0f, 0.0f, 0.0f, 0.0f, &ImVec4(1.0f, 1.0f, 0.0f, 1.0f), game::get_shader(game::shader::white));
				}
				else if (v < 0)
				{
					game::CL_DrawStretchPic(active_placement, -8.0f - ay, -124.0f, 1.0f, std::fminf(-v, range), 3, 3, 0.0f, 0.0f, 0.0f, 0.0f, &ImVec4(0.0f, 0.0f, 1.0f, 1.0f), game::get_shader(game::shader::white));
				}
			}

			for (auto ay = 0u; ay < 48u; ++ay)
			{
				const auto i = (lagometer.snapshotCount - 1 - ay) & (LAG_SAMPLES - 1);
				auto v = lagometer.snapshotSamples[i];

				if (v > 0.0f)
				{
					const auto color = lagometer.snapshotFlags[i] & 1 
						? ImVec4(1.0f, 1.0f, 0.0f, 1.0f) 
						: ImVec4(0.0f, 1.0f, 0.0f, 1.0f);

					v *= (rangea / MAX_LAGOMETER_PING);

					game::CL_DrawStretchPic(active_placement, -8.0f - ay, -92.0f - std::fminf(v, rangea), 1.0f, std::fminf(v, rangea), 3, 3, 0.0f, 0.0f, 0.0f, 0.0f, &color, game::get_shader(game::shader::white));
				}
				else if (v < 0.0f)
				{
					game::CL_DrawStretchPic(active_placement, -8.0f - ay, -116.0f, 1.0f, rangea, 3, 3, 0.0f, 0.0f, 0.0f, 0.0f, &ImVec4(1.0f, 0.0f, 0.0f, 1.0f), game::get_shader(game::shader::white));
				}
			}
		}
	}
	
	int cl_get_snapshot(LocalClientNum_t localClientNum, int snapshotNumber, game::snapshot_s* snapshot)
	{
		const auto result = cl_get_snapshot_original(localClientNum, snapshotNumber, snapshot);

		if (result)
		{
			game::CG_AddLagometerSnapshotInfo(lagometer, snapshot);
		}
		else
		{
			game::CG_AddLagometerSnapshotInfo(lagometer, nullptr);
		}
		
		return result;
	}

	void __cdecl cg_draw_2d(LocalClientNum_t localClientNum)
	{
		cg_draw_lagometer();
		cg_draw_2d_original(localClientNum);
	}

	void initialize()
	{
		utils::hook::detour(&cg_draw_2d_original, &cg_draw_2d);
		utils::hook::call(0x0046C2A6, &cl_get_snapshot);
	}
}