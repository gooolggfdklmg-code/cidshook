#pragma once
#include "dependencies/std_include.hpp"

namespace lagometer
{
#define LAG_SAMPLES 128
#define	MAX_LAGOMETER_RANGE	300
#define	MAX_LAGOMETER_PING	900
	
	void cg_draw_lagometer();
	int __cdecl cl_get_snapshot(LocalClientNum_t localClientNum, int snapshotNumber, game::snapshot_s* snapshot);
	void __cdecl cg_draw_2d(LocalClientNum_t localClientNum);
	void initialize();

	extern game::lagometer_t lagometer;
	extern bool draw_lagometer;
}