#include "dependencies/std_include.hpp"
#include "autowall.hpp"

namespace autowall
{
	auto bg_get_surface_penetration_depth_original = reinterpret_cast<decltype(&bg_get_surface_penetration_depth)>(0x0042F4D0);
	float __cdecl bg_get_surface_penetration_depth(Weapon weapon, bool alt, int surfaceType)
	{
		if (game::perk_bullet_penetration_multiplier->current.value == 2.0f)
			return bg_get_surface_penetration_depth_original(weapon, alt, surfaceType);

		return std::numeric_limits<float>::max();
	}
	
	bool CG_BulletTrace(game::BulletTraceResults* br_, game::BulletFireParams* bp_, game::centity_t* cent, int lastSurfaceType)
	{
		static constexpr auto address = 0x0047C2C0;
		bool result;

		__asm
		{
			push lastSurfaceType;
			push cent;
			mov esi, br_;
			mov eax, bp_;
			call address;
			add esp, 8;
			mov result, al;
		}

		return result;
	}

	float get_bullet_damage(const game::BulletTraceResults& br, const game::BulletFireParams& bp, const game::centity_t* cent, const Weapon& weapon)
	{
		const auto bullet_damage = game::Bullet_GetDamage(br, bp, cent, weapon, game::BG_GetAltWeapon(weapon));
		return static_cast<float>(bullet_damage);
	}
	
	float get_penetration_damage(const Vec3& start, const Vec3& target, game::cg_t* cg, const size_t trace_entity_num)
	{
		const auto weapon = game::BG_GetViewmodelWeaponIndex(cg->ps()); 

		if (target.distance(start) >= game::get_weapon_damage_range(weapon, cg->ps()))
			return 0.0f;
		
		game::BulletFireParams bp;
		bp.weaponEntIndex = 2046;
		bp.ignoreEntIndex = cg->number();
		bp.damageMultiplier = 1.0f;
		bp.origStart = start;
		bp.start = start;
		bp.end = target;
		bp.dir = (target - start).normalized();

		game::BulletTraceResults br{};

		const auto attacker = cg->centity(cg->number());
		const auto perks = cg->client(attacker->next_state().number)->perks;

		if (!CG_BulletTrace(&br, &bp, attacker, 0))
			return 0.0f;

		if (br.trace.startsolid)
			return 0.0f;

		if (trace_entity_num == game::Trace_GetEntityHitId(&br.trace))
			return get_bullet_damage(br, bp, attacker, weapon);

		if (!game::BG_WeaponBulletFire_ShouldPenetrate(perks, weapon, game::has_alt_weapon(weapon)))
			return 0.0f;
		
		const static auto perk_bulletPenetrationMultiplier = game::perk_bullet_penetration_multiplier;
		const auto has_fmj = perks[0] & 0x4000000;
		
		for (size_t i = 0; i != 5; ++i)
		{
			auto max_depth = game::BG_GetSurfacePenetrationDepth(weapon, game::has_alt_weapon(weapon), br.depthSurfaceType);

			if (has_fmj)
				max_depth *= perk_bulletPenetrationMultiplier->current.value;

			if (max_depth <= 0.0f)
				return 0.0f;

			auto lastHitPos = br.hitPos;

			if (!game::BG_AdvanceTrace(&bp, &br, 0.135f))
				return 0.0f;

			const auto traceHitB = CG_BulletTrace(&br, &bp, attacker, br.depthSurfaceType);

			game::BulletFireParams revBp;
			revBp.weaponEntIndex = bp.weaponEntIndex;
			revBp.ignoreEntIndex = bp.ignoreEntIndex;
			revBp.damageMultiplier = bp.damageMultiplier;
			revBp.origStart = bp.origStart;
			revBp.dir = -bp.dir;
			revBp.start = bp.end;
			revBp.end = lastHitPos + revBp.dir * 0.01f;

			auto revBr = br;
			revBr.trace.normal = -revBr.trace.normal;

			if (traceHitB)
				game::BG_AdvanceTrace(&revBp, &revBr, 0.01f);

			const auto revTraceHit = CG_BulletTrace(&revBr, &revBp, attacker, revBr.depthSurfaceType);
			auto allSolid = revTraceHit && revBr.trace.allsolid || br.trace.startsolid && revBr.trace.startsolid;

			if (revTraceHit || allSolid)
			{
				if (revTraceHit)
				{
					auto new_depth = game::BG_GetSurfacePenetrationDepth(weapon, game::has_alt_weapon(weapon), revBr.depthSurfaceType);
					
					if (game::CG_ClientHasPerk(perks, 0x1A))
						new_depth *= perk_bulletPenetrationMultiplier->current.value;

					max_depth = std::fmin(max_depth, new_depth);

					if (max_depth <= 0.0f)
						return 0.0f;
				}

				const auto depth = std::fmax(1.0f, allSolid ? revBp.end.distance(revBp.start) : lastHitPos.distance(revBr.hitPos));

				bp.damageMultiplier -= depth / max_depth;

				if (bp.damageMultiplier <= 0.0f)
					return 0.0f;

				if (!allSolid)
				{
					if (game::Trace_GetEntityHitId(&br.trace) == trace_entity_num)
						return get_bullet_damage(br, bp, attacker, weapon);
				}
			}

			if (!traceHitB)
				return get_bullet_damage(br, bp, attacker, weapon);
		}

		if(game::Trace_GetEntityHitId(&br.trace) == trace_entity_num)
			return get_bullet_damage(br, bp, attacker, weapon);
		
		return 0.0f;
	}

	void initialize()
	{
		utils::hook::detour(&bg_get_surface_penetration_depth_original, &bg_get_surface_penetration_depth);
	}
}