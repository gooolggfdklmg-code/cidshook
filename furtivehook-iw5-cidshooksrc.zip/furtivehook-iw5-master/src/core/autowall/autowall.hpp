#pragma once
#include "dependencies/std_include.hpp"

namespace autowall
{
	float __cdecl bg_get_surface_penetration_depth(Weapon weapon, bool alt, int surfaceType);
	float get_penetration_damage(const Vec3& start, const Vec3& target, game::cg_t* cg, const std::size_t trace_entity_num);
	void initialize();
}