#pragma once
#include "dependencies/std_include.hpp"

namespace nospread
{
	extern bool enabled, bullet_fix;

	void cg_simulate_bullet_fire_internal();
	float get_aim_spread_amount(const Weapon weapon, const bool use_aim_offset = false);
	Vec3 get_spread_angles(std::uint32_t rand_seed, const Weapon weapon, const bool akimbo);
	Vec3 get_compensation_angles(std::uint32_t rand_seed, const Weapon weapon, const bool akimbo);
	void initialize();
}