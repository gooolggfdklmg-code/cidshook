#include "dependencies/std_include.hpp"
#include "nospread.hpp"

namespace nospread
{
	auto cg_simulate_bullet_fire_internal_original = reinterpret_cast<decltype(&cg_simulate_bullet_fire_internal)>(0x00481FF8);
	bool enabled = true, bullet_fix = true;

	void callback_cg_simulate_bullet_fire_internal(game::BulletFireParams* bp)
	{
		if (const auto client_num = game::cg()->number(); bp->ignoreEntIndex == client_num)
		{
			auto angles = game::cg()->refdef_view_angles();

			if (aimbot::aim_target && aimbot::silent)
			{
				angles += aimbot::aim_angles;
			}

			Vec3 view_axis[3];
			game::AngleVectors(&angles, &view_axis[0], &view_axis[1], &view_axis[2]);

			const auto weapon = game::BG_GetViewmodelWeaponIndex(game::cg()->ps());
			const auto weapon_damage_range = game::get_weapon_damage_range(weapon, game::cg()->ps());
			const auto aim_spread_amount = get_aim_spread_amount(weapon, true);
			auto spread_angles = get_compensation_angles(game::cg()->ps()->command_time(),
				weapon, false);

			const auto aim_offset = std::tanf(DEG2RAD(aim_spread_amount)) * weapon_damage_range;
			spread_angles *= aim_offset;

			bp->end = bp->start + (view_axis[0] * weapon_damage_range) + (view_axis[1] * spread_angles[1]) + (view_axis[2] * spread_angles[0]);
			bp->dir = (bp->end - bp->start).normalized();
		}
	}

	__declspec(naked) void cg_simulate_bullet_fire_internal()
	{
		__asm
		{
			pushad;
			push eax;
			call callback_cg_simulate_bullet_fire_internal;
			add esp, 4;
			popad;

			jmp cg_simulate_bullet_fire_internal_original;
		}
	}

	float get_aim_spread_amount(const Weapon weapon, const bool use_aim_offset)
	{
		if (use_aim_offset && enabled)
			return 0.0f;

		float min_spread, max_spread;
		game::BG_GetSpreadForWeapon(game::cg()->ps(), weapon, &min_spread, &max_spread);

		const auto weapon_pos_frac = game::cg()->ps()->weapon_pos_frac();
		const auto aim_spread_scale = game::cg()->aim_spread_scale() / 255.0f;
		const auto aim_spread_amount = (max_spread - min_spread) * aim_spread_scale + min_spread;
		
		if (weapon_pos_frac == 0.0f)
		{
			return aim_spread_amount;
		}

		const auto ads_spread = game::BG_ADSSpread(weapon, false);
		auto spread = aim_spread_amount * (1.0f - weapon_pos_frac);
		spread += ((max_spread - ads_spread) * aim_spread_scale + ads_spread) * weapon_pos_frac;

		return spread;
	}
	
	Vec3 get_spread_angles(std::uint32_t rand_seed, const Weapon weapon, const bool akimbo)
	{
		if (akimbo)
			rand_seed += 10; 
		
		auto seed = game::BG_srand(&rand_seed);

		Vec3 view_axis[3];
		game::AngleVectors(&game::cg()->gun_angles(), &view_axis[0], &view_axis[1], &view_axis[2]);

		const auto weapon_damage_range = game::get_weapon_damage_range(weapon, game::cg()->ps());
		const auto aim_spread_amount = get_aim_spread_amount(weapon);

		Vec3 angles;
		game::CG_BulletEndpos(&rand_seed, aim_spread_amount, &angles, &view_axis[0], &view_axis[1], &view_axis[2], weapon_damage_range);
		game::vectoangles(&angles, &angles);
		
		angles[0] = math::angle_delta(game::cg()->gun_angles()[0], angles[0]);
		angles[1] = math::angle_delta(game::cg()->gun_angles()[1], angles[1]);
		angles[2] = math::angle_delta(game::cg()->gun_angles()[2], angles[2]);

		return angles;
	}

	Vec3 get_compensation_angles(std::uint32_t rand_seed, const Weapon weapon, const bool akimbo)
	{
		if (akimbo)
			rand_seed += 10;
		
		game::BG_srand(&rand_seed);
		const auto aim_spread_amount = enabled
			? get_aim_spread_amount(weapon)
			: 1.0f;

		auto theta = game::BG_random(&rand_seed) * 360.0f;
		const auto r = game::BG_random(&rand_seed);
		theta = DEG2RAD(theta);
		
		return
		{
			std::sinf(theta) * r * aim_spread_amount,
			std::cosf(theta) * r * aim_spread_amount,
			0.0f,
		};
	}

	void initialize()
	{
		utils::hook::detour(&cg_simulate_bullet_fire_internal_original, &cg_simulate_bullet_fire_internal);
	}
}