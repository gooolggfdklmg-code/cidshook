#include "dependencies/std_include.hpp"
#include "aimbot.hpp"

namespace aimbot
{
	bool enabled = false, silent = true, auto_fire = true, priority_bonescan = true, priority_riot = true, asynchronous = true;
	std::uint32_t leg_multipoint_radius = 3;
	Vec3 aim_angles, view_origin;
	bone_target_t* bone_target = nullptr;
	aim_target_t* aim_target = nullptr;
	target_t target[18];
	std::vector<std::uint8_t> ignore_target(18, 0);
	std::vector<std::uint8_t> priority_target(18, 0);
	std::vector<aim_target_t> aim_targets;
	std::vector<bone_target_t> bone_targets;
	std::vector<std::future<float>> penetration_damage;
	std::vector<game::bone_tag> aim_bones
	{
		game::bone_tag::helmet,
		game::bone_tag::head_end,
		game::bone_tag::head,
		game::bone_tag::neck,
		game::bone_tag::shoulder_left,
		game::bone_tag::shoulder_right,
		game::bone_tag::clavicle_left,
		game::bone_tag::clavicle_right,
		game::bone_tag::spineupper,
		game::bone_tag::spine,
		game::bone_tag::spinelower,
		game::bone_tag::hip_left,
		game::bone_tag::hip_right,
		game::bone_tag::knee_left,
		game::bone_tag::knee_right,
		game::bone_tag::wrist_left,
		game::bone_tag::wrist_right,
		game::bone_tag::wrist_twist_left,
		game::bone_tag::wrist_twist_right,
		game::bone_tag::elbow_left,
		game::bone_tag::elbow_right,
		game::bone_tag::elbow_buldge_left,
		game::bone_tag::elbow_buldge_right,
		game::bone_tag::ankle_left,
		game::bone_tag::ankle_right,
		game::bone_tag::ball_left,
		game::bone_tag::ball_right,
		game::bone_tag::mainroot,
	};

	std::vector<Vec3> calculate_inner_points(const Vec3& a, const Vec3& b, const std::uint32_t c)
	{
		std::vector<Vec3> inner_points;
		inner_points.clear();

		for (size_t i = 0; i <= c; ++i)
		{
			const auto point = b + ((a - b) / static_cast<float>(c) * static_cast<float>(i));

			inner_points.emplace_back(point);
		}

		return inner_points;
	}

	std::vector<Vec3> calculate_outer_points(const game::centity_t* cent, const std::vector<Vec3> a, const float b)
	{
		std::vector<Vec3> outer_points;
		outer_points.clear();

		for (const auto& point : a)
		{
			auto front = point + Vec3(b, 0.0f, 0.0f);
			auto back = point + Vec3(-b, 0.0f, 0.0f);

			auto left = point + Vec3(0.0f, b, 0.0f);
			auto right = point + Vec3(0.0f, -b, 0.0f);

			math::rotate_point(front, point, cent->angles().y, front);
			math::rotate_point(back, point, cent->angles().y, back);

			math::rotate_point(left, point, cent->angles().y, left);
			math::rotate_point(right, point, cent->angles().y, right);

			outer_points.emplace_back(front);
			outer_points.emplace_back(back);

			outer_points.emplace_back(left);
			outer_points.emplace_back(right);
		}

		return outer_points;
	}

	std::vector<Vec3> calculate_points(const game::centity_t* cent, const Vec3 bone[static_cast<std::uint32_t>(game::bone_tag::num_tags)], const std::uint32_t divisor, const float radius)
	{
		std::vector<Vec3> points;
		points.clear();

		const auto upper_left_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::hip_left)], bone[static_cast<std::uint32_t>(game::bone_tag::knee_left)], divisor);
		const auto upper_right_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::hip_right)], bone[static_cast<std::uint32_t>(game::bone_tag::knee_right)], divisor);

		const auto lower_left_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::knee_left)], bone[static_cast<std::uint32_t>(game::bone_tag::ankle_left)], divisor);
		const auto lower_right_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::knee_right)], bone[static_cast<std::uint32_t>(game::bone_tag::ankle_right)], divisor);

		const auto left_foot_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::ankle_left)], bone[static_cast<std::uint32_t>(game::bone_tag::ball_left)], divisor);
		const auto right_foot_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::ankle_right)], bone[static_cast<std::uint32_t>(game::bone_tag::ball_right)], divisor);

		const auto upper_left_leg_outer = calculate_outer_points(cent, upper_left_leg_inner, radius);
		const auto upper_right_leg_outer = calculate_outer_points(cent, upper_right_leg_inner, radius);

		const auto lower_left_leg_outer = calculate_outer_points(cent, lower_left_leg_inner, radius);
		const auto lower_right_leg_outer = calculate_outer_points(cent, lower_right_leg_inner, radius);

		const auto left_foot_outer = calculate_outer_points(cent, left_foot_inner, radius);
		const auto right_foot_outer = calculate_outer_points(cent, right_foot_inner, radius);

		points.insert(points.end(), upper_left_leg_inner.begin(), upper_left_leg_inner.end());
		points.insert(points.end(), upper_right_leg_inner.begin(), upper_right_leg_inner.end());

		points.insert(points.end(), lower_left_leg_inner.begin(), lower_left_leg_inner.end());
		points.insert(points.end(), lower_right_leg_inner.begin(), lower_right_leg_inner.end());

		points.insert(points.end(), left_foot_inner.begin(), left_foot_inner.end());
		points.insert(points.end(), right_foot_inner.begin(), right_foot_inner.end());

		points.insert(points.end(), upper_left_leg_outer.begin(), upper_left_leg_outer.end());
		points.insert(points.end(), upper_right_leg_outer.begin(), upper_right_leg_outer.end());

		points.insert(points.end(), lower_left_leg_outer.begin(), lower_left_leg_outer.end());
		points.insert(points.end(), lower_right_leg_outer.begin(), lower_right_leg_outer.end());

		points.insert(points.end(), left_foot_outer.begin(), left_foot_outer.end());
		points.insert(points.end(), right_foot_outer.begin(), right_foot_outer.end());

		return points;
	}
	
	struct hit_point_t
	{
		float damage;
		Vec3 location;

		hit_point_t() = delete;
		hit_point_t(const float _damage, const Vec3 _location) : damage(_damage), location(_location) {}

		bool operator<(const hit_point_t& other) const
		{
			return other.damage < damage;
		}
	}; 
	
	hit_point_t* hit_point = nullptr;
	std::vector<hit_point_t> hit_points;
	
	bool should_target_lower_points(game::centity_t* cent, const Vec3& start, const std::vector<Vec3> points, Vec3* pos, float* damage)
	{
		hit_points.clear();
		hit_point = nullptr;

		std::vector<hit_point_t>point_s;
		point_s.emplace_back(hit_point_t{ 0.0f, game::get_point(points, game::bone_tag::ankle_left) });
		point_s.emplace_back(hit_point_t{ 0.0f, game::get_point(points, game::bone_tag::ankle_right) });
		point_s.emplace_back(hit_point_t{ 0.0f, game::get_point(points, game::bone_tag::ball_left) });
		point_s.emplace_back(hit_point_t{ 0.0f, game::get_point(points, game::bone_tag::ball_right) });

		if (!(cent->next_state().lerp.eFlags & 4) && !(cent->next_state().lerp.eFlags & 8))
		{
			point_s.emplace_back(hit_point_t{ 0.0f, game::get_point(points, game::bone_tag::knee_left) });
			point_s.emplace_back(hit_point_t{ 0.0f, game::get_point(points, game::bone_tag::knee_right) });
		}

		for (auto& point : point_s)
		{
			if (is_bone_hittable(cent, start, points, nullptr, &point.damage))
			{
				hit_points.emplace_back(point.damage, point.location);
			}
		}

		if (!hit_points.empty())
		{
			hit_point = &*std::max_element(hit_points.begin(), hit_points.end());

			*damage = hit_point->damage;
			*pos = hit_point->location;

			return true;
		}
		
		return false;
	}
	
	bool is_bone_hittable(game::centity_t* cent, const Vec3& start, const std::vector<Vec3> points, Vec3* pos, float* damage, const size_t bone_index)
	{
		if (bone_index < static_cast<size_t>(game::bone_tag::num_tags))
		{
			if (asynchronous)
			{
				return std::async(&autowall::get_penetration_damage, start, points[bone_index], game::cg(), cent->next_state().number).get() > 0.0f;
			}

			return autowall::get_penetration_damage(start, points[bone_index], game::cg(), cent->next_state().number) > 0.0f;
		}
		
		penetration_damage.clear();
		bone_targets.clear();
		bone_target = nullptr;
		
		if (asynchronous)
		{
			for (size_t bone = 0; bone < points.size(); ++bone)
			{
				penetration_damage.emplace_back(std::async(&autowall::get_penetration_damage, start, points[bone], game::cg(), cent->next_state().number));
			}
			
			for (size_t bone = 0; bone < points.size(); ++bone)
			{
				if (const auto damage = penetration_damage[bone].get(); damage > 0.0f)
				{
					bone_targets.emplace_back(damage, points[bone]);
				}
			}
		}
		else
		{
			for (size_t bone = 0; bone < points.size(); ++bone)
			{
				if (const auto damage = autowall::get_penetration_damage(start, points[bone], game::cg(), cent->next_state().number); damage > 0.0f)
				{
					bone_targets.emplace_back(damage, points[bone]);
				}
			}
		}

		if (!bone_targets.empty())
		{
			bone_target = &*std::max_element(bone_targets.begin(), bone_targets.end());

			if(damage) *damage = bone_target->damage;
			if(pos) *pos = bone_target->location;

			return true;
		}

		return false;
	}

	Vec3 get_best_target_position(const aim_target_t* aim_target)
	{
		const auto priority_target = std::find_if(aim_targets.begin(), aim_targets.end(), [&](const aim_target_t& target) { return target.priority; });

		if (priority_target != aim_targets.end())
		{
			return target[priority_target->index].aim_pos;
		}
		else
		{
			return target[aim_target->index].aim_pos;
		}
	}

	Vec3 get_riot_shield_delta(game::centity_t* cent, game::playerState_s* ps)
	{
		Vec3 angles = {};
		const auto direction = (cent->origin() - ps->origin()).normalized();

		game::vectoangles(&direction, &angles);
		math::normalize_angles(&angles);

		return angles - cent->angles();
	}

	bool is_bad_entity(game::centity_t* cent, const Vec3& delta)
	{
		return cent->next_state().lerp.stowedweaponID == 0 && ANGLE_COMPARE_180(delta.y)
			|| (cent->next_state().weaponID == 3 || cent->next_state().weaponID == 4)
			&& !ANGLE_COMPARE_180(delta.y);
	}

	bool can_aimbot(const game::playerState_s* ps)
	{
		return ps->pm_type() & 2 || game::CG_IsPlayerReloading();
	}
	
	bool is_valid_target(game::centity_t* cent)
	{
		if (!cent->is_alive() || cent->next_state().lerp.eFlags & 0x800000)
			return false;

		if (cent->next_state().number == game::cg()->number() || !game::is_enemy(cent->next_state().number))
			return false;

		return true;
	}
	
	void run(game::playerState_s* ps)
	{
		aim_targets.clear();
		aim_target = nullptr;

		if (!enabled)
			return;

		game::CG_GetPlayerViewOrigin(0, ps, &view_origin);

		for (size_t i = 0; i < 18; ++i)
		{
			if (const auto cent = game::cg()->centity(i); is_valid_target(cent))
			{
				target[i].point_scan.clear();

				const auto priority_client = priority_target[i];

				for (size_t bone = 0; bone < game::bone_tags.size(); ++bone)
					game::AimTarget_GetTagPos(cent, game::get_tag(aim_bones[bone]), &target[i].aim_point[static_cast<std::size_t>(bone)]);

				const auto delta = get_riot_shield_delta(cent, ps); 
				
				if (priority_bonescan && priority_client || !priority_bonescan || is_bad_entity(cent, delta))
				{
					for (size_t bone = 0; bone < game::bone_tags.size(); ++bone)
					{
						target[i].point_scan.emplace_back(target[i].aim_point[static_cast<std::size_t>(bone)]);
					}
				}
				else
				{
					target[i].point_scan.emplace_back(target[i].aim_point[static_cast<std::uint32_t>(game::bone_tag::head)]);
				}

				if (priority_client)
				{
					target[i].points.clear();
					target[i].points = calculate_points(cent, target[i].aim_point, leg_multipoint_radius, 2.0f);

					for (const auto& points : target[i].points)
					{
						target[i].point_scan.emplace_back(points);
					}
				}

				if (is_bad_entity(cent, delta))
				{
					target[i].vulnerable = should_target_lower_points(cent, view_origin, target[i].point_scan, &target[i].aim_pos, &target[i].damage);
				}
				else
				{
					target[i].vulnerable = is_bone_hittable(cent, view_origin, target[i].point_scan, &target[i].aim_pos, &target[i].damage);
				}
				
				if (target[i].vulnerable && !ignore_target[i])
				{
					aim_targets.emplace_back(priority_client, i, target[i].damage, std::floorf(cent->origin().distance(ps->origin())));
				}
			}
		}

		if (!aim_targets.empty() && !can_aimbot(ps))
		{
			aim_target = &*std::max_element(aim_targets.begin(), aim_targets.end());
			game::vectoangles(&(get_best_target_position(aim_target) - view_origin), &aim_angles);

			aim_angles[0] = math::angle_delta(aim_angles[0], game::cg()->refdef_view_angles()[0]);
			aim_angles[1] = math::angle_delta(aim_angles[1], game::cg()->refdef_view_angles()[1]);
			aim_angles[2] = math::angle_delta(aim_angles[2], game::cg()->refdef_view_angles()[2]);

			if (!silent)
				game::cl()->view_angles() += aim_angles;
		}
	}
}