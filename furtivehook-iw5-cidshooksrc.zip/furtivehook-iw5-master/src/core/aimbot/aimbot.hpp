#pragma once
#include "dependencies/std_include.hpp"

namespace aimbot
{
	struct target_t
	{
		Vec3 aim_point[static_cast<std::uint32_t>(game::bone_tag::num_tags)], aim_pos;
		std::vector<Vec3> point_scan, points;
		bool vulnerable, feet;
		float damage;
	};

	struct bone_target_t
	{
		float damage;
		Vec3 location;

		bone_target_t() = delete;
		bone_target_t(const float _damage, const Vec3 _location) : damage(_damage), location(_location) {}

		bool operator<(const bone_target_t& other) const
		{
			return other.damage > damage;
		}
	};

	struct aim_target_t
	{
		bool priority;
		std::uint32_t index;
		float damage;
		float distance;

		aim_target_t() = delete;
		aim_target_t(const bool _priority, const std::uint32_t _index, const float _damage, const float _distance) : priority(_priority), index(_index), damage(_damage), distance(_distance) {}

		bool operator<(const aim_target_t& other) const
		{
			return other.damage > damage || (other.damage == damage && other.distance < distance) || (other.damage == damage && other.distance == distance);
		}
	};

	extern bool enabled, silent, auto_fire, priority_bonescan, priority_riot, asynchronous;
	extern std::uint32_t leg_multipoint_radius;
	extern Vec3 aim_angles, view_origin;
	extern aim_target_t* aim_target;
	extern target_t target[18];
	extern std::vector<std::uint8_t> priority_target;
	extern std::vector<std::uint8_t> ignore_target;

	void run(game::playerState_s * ps);
	bool is_bone_hittable(game::centity_t * cent, const Vec3 & start, const std::vector<Vec3> points, Vec3 * pos, float * damage, const size_t bone_index = static_cast<size_t>(game::bone_tag::num_tags));
}