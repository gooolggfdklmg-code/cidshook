#include "dependencies/std_include.hpp"
#include "stats.hpp"

namespace stats
{
	bool is_ready()
	{
		if (game::LiveStorage_MaySetPersistentData() && game::Live_SyncOnlineDataFlags(0) == 0)
			return true;

		return false;
	}

	std::vector<const char*> parse_args_to_lookup_strings(const std::vector<std::string>& args, const bool set_data)
	{
		std::vector<const char*> lookup_strings_vector{};
		size_t amount_lookup_strings{ args.size() };

		if (set_data)
		{
			--amount_lookup_strings;
		}

		for (size_t i = 0; i < amount_lookup_strings; ++i)
		{
			lookup_strings_vector.push_back(args[i].data());
		}

		return lookup_strings_vector;
	}
	
	void set_player_data(const int client_num, const std::vector<std::string>& args)
	{
		if (args.size() < 2)
			return;

		if (client_num < 0 || client_num >= 18)
			return;

		if (!game::Dvar_FindVar("sv_running")->current.enabled)
			return;

		const auto& client = game::svs_client(client_num);
		if (client->state() < game::CS_CONNECTED)
			return;

		const auto persistent_data_buffer{ game::SV_GetClientPersistentDataBuffer(client_num) };
		const auto persistent_data_flags{ game::SV_GetClientPersistentDataModifiedFlags(client_num) };
		const auto lookup_strings_vector{ parse_args_to_lookup_strings(args, true) };
		const auto index{ args.size() - 1 };

		if (!game::LiveStorage_DataSetInternalString(index, &lookup_strings_vector[0], args[index], persistent_data_buffer, persistent_data_flags))
			return;

		client->send_player_data() = true;
	}
	
	void set_player_data(const std::vector<std::string>& args)
	{
		if (args.size() < 2)
			return;

		if (!is_ready())
			return;

		const auto persistent_data_buffer{ game::LiveStorage_GetPersistentDataBuffer(0) };
		const auto lookup_strings_vector{ parse_args_to_lookup_strings(args, true) };
		const auto index{ args.size() - 1 };
		const auto value{ args[index] };

		if (!game::LiveStorage_DataSetInternalString(index, &lookup_strings_vector[0], value, persistent_data_buffer, nullptr))
			return;

		game::LiveStorage_StatsWriteNeeded(0);
	}

	const static auto LiveStorage_DataGetInternalInt = reinterpret_cast<int(*)(char const* const*, int, game::StructuredDataBuffer* const)>(0x00548B70);
	int get_player_data(const std::vector<std::string>& args)
	{
		if (args.size() < 1)
			return 0;

		const auto* persistent_data_buffer{ game::LiveStorage_GetPersistentDataBuffer(0) };
		const auto lookup_strings_vector{ parse_args_to_lookup_strings(args, false) };
		const auto index{ args.size() };

		return LiveStorage_DataGetInternalInt(&lookup_strings_vector[0], index, reinterpret_cast<game::StructuredDataBuffer*>(&persistent_data_buffer));
	}

	void set_skills(const int skill)
	{
		if (!is_ready())
			return;

		const auto skills = get_player_data("skills", "war");
		if (skills == skill)
			return;

		set_player_data("skills", "war", std::to_string(skill));
		PRINT_LOG("Setting skill value [%i] to [%i]", skills, skill);
	}
	
	void set_prestige(const int prestige)
	{
		if (!is_ready())
			return;

		if (prestige < 0 || prestige > 11)
			return;

		set_player_data("prestige", std::to_string(prestige));
	}

	int get_max_experience()
	{
		const game::StringTable* rank_table{ nullptr };
		game::StringTable_GetAsset("mp/rankTable.csv", &rank_table);

		const auto current_rank = game::StringTable_Lookup(rank_table, 0, "maxrank", 1);
		const auto max_rank = game::StringTable_Lookup(rank_table, 0, current_rank, 7);
		return std::atoi(max_rank);
	}

	void unlock_all()
	{
		if (!is_ready())
			return;

		const auto challenges_table = game::get_string_table("mp/allChallengesTable.csv");
		for (size_t i = 0; i < challenges_table->rowCount; ++i)
		{
			auto max_state{ 0 };
			auto max_progress{ 0 };

			for (size_t j = 0; j < 10; ++j)
			{
				const auto progress{ std::atoi(game::StringTable_GetColumnValueForRow(challenges_table, i, 6 + j * 2)) };
				if (!progress) break;

				max_state = j + 2;
				max_progress = progress;
			}

			const auto challenge{ game::StringTable_GetColumnValueForRow(challenges_table, i, 0) };
			set_player_data("challengeState", challenge, std::to_string(max_state));
			set_player_data("challengeProgress", challenge, std::to_string(max_progress));
		}

		const auto camos_table = game::get_string_table("mp/camoTable.csv");
		for (size_t i = 0; i < camos_table->rowCount; ++i)
		{
			const auto camo{ std::atoi(game::StringTable_GetColumnValueForRow(camos_table, i, 0)) };
			if (camo > 4) break;

			set_player_data("unlockedCamo", std::to_string(camo), "1");
		}

		const auto unlock_table = game::get_string_table("mp/unlocktable.csv");
		for (size_t i = 0; i < unlock_table->rowCount; ++i)
		{
			const auto value{ game::StringTable_GetColumnValueForRow(unlock_table, i, 0) };
			const auto type{ game::StringTable_GetColumnValueForRow(unlock_table, i, 1) };

			if (type == "weapon"s)
			{
				constexpr auto max_weapon_xp = std::numeric_limits<int>::max();
				set_player_data("weaponXP", value, std::to_string(max_weapon_xp));
			}
			else if (type == "title"s)
			{
				game::LiveStorage_SetPlayerCardItemFieldByName(0, "titleUnlocked", "mp/cardTitleTable.csv", value, 0, true);
			}
			else if (type == "icon"s)
			{
				game::LiveStorage_SetPlayerCardItemFieldByName(0, "iconUnlocked", "mp/cardIconTable.csv", value, 0, true);
			}
		}
		
		const auto max_experience = get_max_experience();
		set_player_data("experience", std::to_string(max_experience));
		set_player_data("skills", "war", "0");

		for (size_t i = 0; i < 15; ++i)
		{
			set_player_data("customClasses", std::to_string(i), "name", "^2furtivehook");

			if(i < 5)
				set_player_data("privateMatchCustomClasses", std::to_string(i), "name", "^2furtivehook");
		}

		command::execute("uploadStats", true);
		command::execute("updateGamerProfile", true);
	}

	void set_stats_integrity_dvars()
	{
		game::make_dvar_server_info("pdc", "0");
		game::make_dvar_server_info("matchdata_active", "1");
		game::make_dvar_server_info("validate_apply_clamps", "0");
		game::make_dvar_server_info("validate_apply_revert", "0");
		game::make_dvar_server_info("validate_apply_revert_full", "0");
		game::make_dvar_server_info("validate_drop_on_fail", "0");
	}
}