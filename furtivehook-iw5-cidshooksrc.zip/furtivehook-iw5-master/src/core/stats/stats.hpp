#pragma once
#include "dependencies/std_include.hpp"

namespace stats
{
	void set_player_data(const int client_num, const std::vector<std::string>& args);
	void set_player_data(const std::vector<std::string>& args);
	int get_player_data(const std::vector<std::string>& args);
	void set_skills(const int skill);
	void set_prestige(const int prestige);
	void unlock_all();
	void set_stats_integrity_dvars();

	template<typename... Args>
	void set_player_data(const Args... args)
	{
		std::vector<std::string> data{};
		(data.push_back(args), ...);

		set_player_data(data);
	}

	template<typename... Args>
	void set_player_data(const int client_num, const Args... args)
	{
		std::vector<std::string> data{};
		(data.push_back(args), ...);

		set_player_data(client_num, data);
	}

	template<typename... Args>
	int get_player_data(const Args... args)
	{
		std::vector<std::string> data{};
		(data.push_back(args), ...);

		return get_player_data(data);
	}
}