#pragma once
#include "dependencies/std_include.hpp"

namespace events
{
	void __cdecl cg_predict_playerstate(LocalClientNum_t localClientNum);
	void __cdecl live_handle_instant_message(LocalClientNum_t local_num, std::uint64_t sender_id, const char * sender_name, game::InstantMessage * message);
	void party_atomic_host_send_join_failed_response();
	void initialize();
}