#include "dependencies/std_include.hpp"
#include "events.hpp"

namespace events
{
	auto cg_predict_playerstate_original = reinterpret_cast<decltype(&cg_predict_playerstate)>(0x00464D80);
	auto live_handle_instant_message_original = reinterpret_cast<decltype(&live_handle_instant_message)>(0x005CB510);
	auto party_atomic_host_send_join_failed_response_original = reinterpret_cast<decltype(&party_atomic_host_send_join_failed_response)>(0x004A9E9D);

	void __cdecl cg_predict_playerstate(LocalClientNum_t localClientNum)
	{
		auto cmd_cur = game::cl()->get_user_cmd(game::cl()->currentCmdNum);
		auto cmd_old = game::cl()->get_user_cmd(game::cl()->currentCmdNum - 1);
		auto cmd_new = game::cl()->get_user_cmd(++game::cl()->currentCmdNum);

		*cmd_new = *cmd_cur;
		cmd_cur->serverTime -= 1;
		cmd_old->serverTime += 1;

		static std::uint32_t backup_angles[3];
		VECTOR_COPY(backup_angles, cmd_old->angles);
		VECTOR_COPY(cmd_cur->angles, backup_angles);

		static std::uint32_t backup_angles2[3];
		VECTOR_COPY(backup_angles2, cmd_cur->angles);
		VECTOR_COPY(cmd_new->angles, backup_angles2);

		static bool gun_switch = false; gun_switch = !gun_switch;
		const auto is_akimbo_gun = game::BG_WeaponIsDualWield(game::cg()->ps()->weapon());
		const auto is_auto_fire = aimbot::aim_target && aimbot::auto_fire;
		std::uint32_t button_flag = 0;

		if ((is_auto_fire && (gun_switch || !is_akimbo_gun)) || (cmd_cur->buttons & 1))
			button_flag |= 1;
		if (is_akimbo_gun && ((is_auto_fire && !gun_switch) || (cmd_cur->buttons & 0x80800)))
			button_flag |= 0x80800;

		cmd_old->buttons |= button_flag;

		if (game::bg_weaponCompleteDefs(game::cl()->ps()->weapon())->fireTime == 0)
		{
			cmd_new->buttons &= ~1;
			cmd_cur->buttons &= ~1;
		}

		if (button_flag)
		{
			const auto old_angle = SHORT2ANGLE(cmd_old->angles[1]);

			if (aimbot::aim_target)
			{
				cmd_old->angles[0] += ANGLE2SHORT(aimbot::aim_angles[0]);
				cmd_old->angles[1] += ANGLE2SHORT(aimbot::aim_angles[1]);
				cmd_old->angles[2] += ANGLE2SHORT(aimbot::aim_angles[2]);
			}

			const auto spread_angles = nospread::get_spread_angles(cmd_old->serverTime,
				game::BG_GetViewmodelWeaponIndex(game::cg()->ps()),
				(button_flag & 1) && is_akimbo_gun);

			cmd_old->angles[0] += ANGLE2SHORT(spread_angles[0]);
			cmd_old->angles[1] += ANGLE2SHORT(spread_angles[1]);
			cmd_old->angles[2] += ANGLE2SHORT(spread_angles[2]);

			if (aimbot::aim_target && aimbot::silent)
			{
				game::adjust_user_cmd_moves(cmd_old, SHORT2ANGLE(cmd_old->angles[1]), old_angle, cmd_old->forwardmove, cmd_old->rightmove);
			}
		}

		cg_predict_playerstate_original(localClientNum);

		antiaim::anti_aim(game::cg()->ps(), game::cl()->get_user_cmd(game::cl()->currentCmdNum));
	}

	void __cdecl live_handle_instant_message(LocalClientNum_t local_num, std::uint64_t sender_id, const char* sender_name, game::InstantMessage* message)
	{
		if (message->type() == 2)
		{
			PRINT_LOG("Received join request from '%s' (%llu): %s", sender_name, sender_id, utils::string::adr_to_string(&message->session()->hostAddress).data());
		}
		else if (message->type() == 1)
		{
			PRINT_LOG("Received join reply from '%s' (%llu): %s", sender_name, sender_id, utils::string::adr_to_string(&message->session()->hostAddress).data());
		}

		live_handle_instant_message_original(local_num, sender_id, sender_name, message);
	}
	
	void callback_party_atomic_host_send_join_failed_response(std::uint32_t response)
	{
		PRINT_LOG("Sending join failed response [%u]", response);
	}

	__declspec(naked) void party_atomic_host_send_join_failed_response()
	{
		__asm
		{
			pushad;
			push ecx;
			call callback_party_atomic_host_send_join_failed_response;
			add esp, 4;
			popad;

			jmp party_atomic_host_send_join_failed_response_original;
		}
	}

	void initialize()
	{
		utils::hook::detour(&live_handle_instant_message_original, &live_handle_instant_message); 
		utils::hook::detour(&party_atomic_host_send_join_failed_response_original, &party_atomic_host_send_join_failed_response);
		
		utils::hook::call(0x00477B8D, &cg_predict_playerstate);

		utils::hook::nop(0x005CB524, 2);
	}
}