#include "dependencies/std_include.hpp"
#include "dx.hpp"

namespace rendering::dx
{
	HWND window; 
	
	void on_every_frame()
	{
		if (menu::initialized)
		{
			ImGui::GetIO().MouseDrawCursor = menu::is_open();

			ImGui_ImplDX9_NewFrame();
			ImGui_ImplWin32_NewFrame();
			ImGui::NewFrame();

			esp::draw();
			menu::draw();

			ImGui::Render();
			ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
		}
	}
	
	void on_frame(IDirect3DDevice9* device)
	{
		if (window = *reinterpret_cast<HWND*>(0x05AA3930); window)
		{
			input::initialize(window);

			ImGui::CreateContext();
			menu::set_style();
			ImGui_ImplWin32_Init(window);
			ImGui_ImplDX9_Init(device);
		}
	}
}