#include "dependencies/std_include.hpp"
#include "rendering.hpp"

namespace rendering
{
	auto end_scene_original = reinterpret_cast<decltype(&end_scene)>(0);
	auto reset_original = reinterpret_cast<decltype(&reset)>(0);

	HRESULT __stdcall reset(IDirect3DDevice9* thisptr, D3DPRESENT_PARAMETERS *pPresentationParameters)
	{
		if (!menu::initialized)
			return reset_original(thisptr, pPresentationParameters);
		
		ImGui_ImplDX9_InvalidateDeviceObjects();
		const auto original = reset_original(thisptr, pPresentationParameters);
		ImGui_ImplDX9_CreateDeviceObjects();

		return original;
	}
	
	HRESULT __stdcall end_scene(IDirect3DDevice9* thisptr)
	{
		menu::initialize(thisptr);
		dx::on_every_frame();
		
		return end_scene_original(thisptr);
	}
	
	void initialize()
	{
		end_scene_original = reinterpret_cast<decltype(end_scene_original)>((**reinterpret_cast<void****>(game::device))[42]);
		reset_original = reinterpret_cast<decltype(reset_original)>((**reinterpret_cast<void****>(game::device))[16]);
		
		utils::hook::detour(&end_scene_original, &end_scene);
		utils::hook::detour(&reset_original, &reset);
	}
}