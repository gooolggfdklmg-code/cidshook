#pragma once

namespace command
{
	class params_sv_ final
	{
	public:
		const char* get(const size_t index) const;
		size_t size() const;
		std::string join(const size_t index) const;

		const char* operator[](const size_t index) const
		{
			return this->get(index);
		}

	}extern params_sv; 
	
	class params_ final
	{
	public:
		const char* get(const size_t index) const;
		size_t size() const;
		std::string join(const size_t index) const;

		const char* operator[](const size_t index) const
		{
			return this->get(index);
		}

	}extern params; 
	
	void on_sv(std::string command, const std::function<bool(size_t, const params_sv_&)>& callback);
	void client_command(size_t client_num);
	void sv_update_user_info(int client);
	void execute(std::string command, const bool sync = false);
	void initialize();
}
