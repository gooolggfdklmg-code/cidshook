#include "dependencies/std_include.hpp"
#include "command.hpp"

namespace command
{
	auto client_command_original = reinterpret_cast<decltype(&client_command)>(0x00502CB0);
	auto sv_update_user_info_original = reinterpret_cast<decltype(&sv_update_user_info)>(0x00571800);
	std::unordered_map<std::string, std::function<bool(const size_t, params_sv_&)>> handlers_sv;
	
	params_ params;
	params_sv_ params_sv;
	
	const char* params_::get(const size_t index) const
	{
		return game::Cmd_Argv(index);
	}

	size_t params_::size() const
	{
		return game::cmd_argc[*game::cmd_id];
	}

	std::string params_::join(const size_t index) const
	{
		auto result = ""s;

		for (auto i = index; i < this->size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(this->get(i));
		}

		return result;
	}

	const char* params_sv_::get(const size_t index) const
	{
		return game::SV_Cmd_Argv(index);
	}

	size_t params_sv_::size() const
	{
		return game::sv_cmd_argc[*game::sv_cmd_id];
	}

	std::string params_sv_::join(const size_t index) const
	{
		auto result = ""s;

		for (auto i = index; i < this->size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(this->get(i));
		}

		return result;
	}

	void on_sv(std::string command, const std::function<bool(size_t, const params_sv_&)>& callback)
	{
		if (handlers_sv.find(command) == handlers_sv.end())
		{
			handlers_sv[utils::string::to_lower(command)] = callback;
		}
	}
	
	bool can_handle_sv(std::unordered_map<std::string, std::function<bool(const size_t, params_sv_&)>> callbacks, std::string command)
	{
		return callbacks.find(command) != callbacks.end() && callbacks[command];
	}

	bool handle_sv(params_sv_& params, const size_t client_num)
	{
		for (size_t i = 0; i < params.size(); ++i)
		{
			const auto command = utils::string::to_lower(params[i]);

			if (can_handle_sv(handlers_sv, command))
			{
				return handlers_sv[command](client_num, params);
			}
		}

		return false;
	}

	void client_command(size_t client_num)
	{
		params_sv_ params = {}; 
		
		if (handle_sv(params, client_num))
		{
			return;
		}
		
		return client_command_original(client_num);
	}

	void sv_update_user_info(int client)
	{
		const auto client_num = ((client - 0x004B5CF90) / 0x78698);

		if (client_num != game::party->currentHost.hostNum)
		{
			game::SV_GameSendServerCommand(-1, game::SV_CMD_RELIABLE,
				utils::string::va("g \"[furtivehook] '%s' tried changing his userinfo!\"",
					game::cg()->client(client_num)->name()));

			return;
		}

		sv_update_user_info_original(client);
	}

	void execute(std::string command, const bool sync)
	{
		command += "\n";

		if (sync)
		{
			game::Cmd_ExecuteSingleCommand(0, 0, command.data());
		}
		else
		{
			game::Cbuf_AddText(0, command.data());
		}
	}

	void initialize()
	{
		utils::hook::detour(&client_command_original, &client_command);
		//utils::hook::detour(&sv_update_user_info_original, &sv_update_user_info);
	}
}