#include "dependencies/std_include.hpp"
#include "security.hpp"

namespace security
{
	auto cl_console_print_original = reinterpret_cast<decltype(&cl_console_print)>(0x0048795B);
	auto sv_set_stats_original = reinterpret_cast<decltype(&sv_set_stats)>(0x00469BAA);
	auto net_defer_packet_to_client_original = reinterpret_cast<decltype(&net_defer_packet_to_client)>(0x0055C670);
	auto ui_replace_directive_original = reinterpret_cast<decltype(&ui_replace_directive)>(0x005A7695);
	auto sv_packet_event_original = reinterpret_cast<decltype(&sv_packet_event)>(0x00576953);
	auto rb_draw_stretch_pic_rotate_original = reinterpret_cast<decltype(&rb_draw_stretch_pic_rotate)>(0x00694CF0);
	auto msg_read_bits_original = reinterpret_cast<decltype(&msg_read_bits)>(0x00558E90);
	auto msg_read_bit_original = reinterpret_cast<decltype(&msg_read_bit)>(0x004514A0);
	auto cl_get_config_string_original = reinterpret_cast<decltype(&cl_get_config_string)>(0x004849D0);
	auto cg_map_restart_original = reinterpret_cast<decltype(&cg_map_restart)>(0x0046A790);
	auto seh_localize_text_message_original = reinterpret_cast<decltype(&seh_localize_text_message)>(0x0057E32F);
	auto field_char_event_original = reinterpret_cast<decltype(&field_char_event)>(0x0048C990);
	bool can_disconnect = false, is_migrating = false;

	int __cdecl msg_read_bit(game::msg_t* msg)
	{
		if (msg->overflowed)
		{
			PRINT_LOG("[0x%08X] Overflow in MSG_ReadBit", _ReturnAddress());
			return 0;
		}

		return msg_read_bit_original(msg);
	}

	int __cdecl msg_read_bits(game::msg_t* msg, int bits)
	{
		if (msg->overflowed)
		{
			PRINT_LOG("[0x%08X] Overflow in MSG_ReadBits", _ReturnAddress());
			return 0;
		}
		
		if (msg->bit & 7)
		{
			const auto v9 = msg->bit >> 3;
			const auto count = v9 - msg->cursize;

			if (count >= 0 && !msg->splitData)
			{
				PRINT_LOG("[0x%08X] !msg->splitData in MSG_ReadBits", _ReturnAddress());
				return 0;
			}
		}

		return msg_read_bits_original(msg, bits);
	}

	const char* __cdecl cl_get_config_string(int configStringIndex)
	{
		if (constexpr auto max_index = 3882u; static_cast<std::uint32_t>(configStringIndex) < max_index)
		{
			return cl_get_config_string_original(configStringIndex);
		}

		PRINT_LOG("(configStringIndex) > (MAX_CONFIGSTRINGS) [%u] [0x%08X]", configStringIndex, _ReturnAddress());
		return "";
	}

	void __cdecl cg_map_restart(LocalClientNum_t localClientNum, int savepersist)
	{
		const auto is_server_restarting = *reinterpret_cast<bool*>(0x00B7F87C);
		if (is_server_restarting)
		{
			return cg_map_restart_original(localClientNum, savepersist);
		}

		PRINT_LOG_DETAILED("Exploit attempt caught!");
	}
	
	void __cdecl net_defer_packet_to_client(game::netadr_t* from, game::msg_t* msg)
	{
		if (msg->cursize >= 0 && msg->cursize <= 1272)
		{
			return net_defer_packet_to_client_original(from, msg);
		}

		game::send_exploit_caught_messages("msg->cursize > 1272", *from);
	}

	void callback_sv_set_stats()
	{
		if (game::IsServerRunning())
		{
			PRINT_BOLD_MESSAGE("Your stats were modified ..");
			return;
		}

		std::memcpy(game::LiveStorage_GetPersistentDataBuffer(0), game::g_statsBackup, 0x2FFC);
		PRINT_BOLD_MESSAGE("Stat change attempt caught from host ..");
	}
	
	__declspec(naked) void sv_set_stats()
	{
		__asm
		{
			pushad;
			call callback_sv_set_stats; 
			popad;

			push 0x00469BE7;
			retn;
		}
	}

	void __cdecl dvar_set_from_string_by_name(const char* dvar, const char* value)
	{
		const auto dvar_lwr = utils::string::to_lower(dvar); 
		if (game::is_valid_cod_info_dvar(dvar_lwr))
		{
			logger::print_sv_log("Setting dvar '%s' to: '%s' from cod-info.", dvar, value);

			game::perk_bullet_penetration_multiplier->current.value = 2.0f;
			host::anti_leave = false;

			return reinterpret_cast<decltype(&dvar_set_from_string_by_name)>(0x005BF740)(dvar, value);
		}

		PRINT_LOG("Not setting dvar '%s' to: '%s' from cod-info.", dvar, value); 
	}

	bool __cdecl load_script_menu(LocalClientNum_t localClientNum, const char *pszMenu, int imageTrack)
	{
		const auto menu_lwr = utils::string::to_lower(pszMenu);
		if (!utils::string::begins_with(menu_lwr, "uiscript"))
		{
			logger::print_sv_log("Loading script menu file '%s'", pszMenu);
			return reinterpret_cast<decltype(&load_script_menu)>(0x0058C070)(localClientNum, pszMenu, imageTrack);
		}

		PRINT_LOG("Not loading script menu file '%s'", pszMenu);
		return true;
	}

	void __cdecl callback_ui_replace_directive(char *string, size_t length)
	{
		if (std::strlen(string) >= length)
		{
			PRINT_LOG_DETAILED("Exploit attempt caught! [%u] [%u]", std::strlen(string), length);
			utils::hook::write_string(string, "Exploit attempt caught!");
		}
	}

	__declspec(naked) void ui_replace_directive()
	{
		__asm
		{
			pushad;
			push eax;
			push ebx;
			call callback_ui_replace_directive;
			add esp, 8;
			popad;

			jmp ui_replace_directive_original;
		}
	}

	void __cdecl callback_sv_packet_event(game::client_t* client)
	{
		PRINT_LOG("Invalid reliableAcknowledge message from (%llu) %s",
			client->xuid(),
			utils::string::adr_to_string(&client->remote_address()).data());
	}

	__declspec(naked) void sv_packet_event()
	{
		__asm
		{
			test eax, eax; // client->reliableAcknowledge
			jge fix;

			pushad;
			push edi;
			call callback_sv_packet_event;
			pop edi;
			popad;

			push 0x00576967;
			retn;

		fix:
			jmp sv_packet_event_original;
		}
	}
	
	bool __cdecl callback_rb_draw_stretch_pic_rotate(const char* string)
	{
		const auto material = game::get_material(string + 4, string[3]); 
		if (material && material->techniqueSet && material->techniqueSet->name == "2d"s)
		{
			return false;
		}

		PRINT_LOG_DETAILED("Invalid material pointer caught!");
		return true;
	}

	__declspec(naked) void rb_draw_stretch_pic_rotate()
	{
		__asm
		{
			pushad;
			push ecx;
			call callback_rb_draw_stretch_pic_rotate;
			test al, al;
			pop ecx;
			popad;

			jz fix;

			retn;

		fix:
			jmp rb_draw_stretch_pic_rotate_original;
		}
	}

	auto party_atomic_host_handle_member_join_original = reinterpret_cast<decltype(&party_atomic_host_handle_member_join)>(0x004AEA87); 
	__declspec(naked) void party_atomic_host_handle_member_join()
	{
		__asm
		{
			test eax, eax;
			jz fix;

			mov esi, [esp + 0x34C];
			push 0x004AEAF7;
			retn;
		fix:
			jmp party_atomic_host_handle_member_join_original;
		}
	}

	void callback_cl_console_print(char* string)
	{
		PRINT_LOG_DETAILED("Invalid material pointer caught! [%s] [%u]", string, string[3]);
		utils::hook::write_string(string, "Invalid material pointer caught!");
	}
	
	__declspec(naked) void cl_console_print()
	{
		__asm
		{
			cmp byte ptr[ebp + 3], 127;
			jbe fix;

			pushad;
			push ebp;
			call callback_cl_console_print;
			pop ebp;
			popad;

			push 0x004879E8;
			retn;
		fix:
			jmp cl_console_print_original; 
		}
	}

	bool __cdecl callback_seh_localize_text_message(size_t token_length)
	{
		if (token_length >= 0x400)
		{
			PRINT_BOLD_MESSAGE("Exploit attempt caught!");
			PRINT_LOG_DETAILED("Exploit attempt caught! [%u]", token_length);
			return true;
		}

		return false;
	}
	
	__declspec(naked) void seh_localize_text_message()
	{
		__asm
		{
			pushad;
			lea eax, [edi + esi];
			push eax;
			call callback_seh_localize_text_message;
			test al, al;
			pop eax;
			popad;

			jz fix;

			pop edi;
			pop esi;
			pop ebp;
			pop ebx;
			add esp, 0x820;
			mov eax, [esp + 4];
			retn;
		fix:
			jmp seh_localize_text_message_original;
		}
	}

	void __declspec(naked) field_char_event()
	{
		__asm
		{
			cmp dword ptr[esp + 12], 0x0048CBC3;
			jz fix;
			jmp field_char_event_original;

		fix:
			push 0x0048C9B5;
			retn;
		}
	}
	
	void initialize()
	{
		security::iat::initialize();
		
		utils::hook::detour(&sv_set_stats_original, &sv_set_stats);
		utils::hook::detour(&rb_draw_stretch_pic_rotate_original, &rb_draw_stretch_pic_rotate);
		utils::hook::detour(&net_defer_packet_to_client_original, &net_defer_packet_to_client);
		utils::hook::detour(&ui_replace_directive_original, &ui_replace_directive);
		utils::hook::detour(&sv_packet_event_original, &sv_packet_event);
		utils::hook::detour(&cl_console_print_original, &cl_console_print);
		utils::hook::detour(&cl_get_config_string_original, &cl_get_config_string);
		utils::hook::detour(&msg_read_bits_original, &msg_read_bits);
		utils::hook::detour(&msg_read_bit_original, &msg_read_bit);
		utils::hook::detour(&cg_map_restart_original, &cg_map_restart);
		utils::hook::detour(&seh_localize_text_message_original, &seh_localize_text_message);
		utils::hook::detour(&field_char_event_original, &field_char_event);
		//utils::hook::detour(&party_atomic_host_handle_member_join_original, &party_atomic_host_handle_member_join);

		utils::hook::call(0x004687E9, &load_script_menu);
		utils::hook::call(0x00467EB0, &dvar_set_from_string_by_name);

		utils::hook::retn(0x00577E70); // SVC_RemoteCommand
		utils::hook::retn(0x00576000); // SVC_Info

		command::on_sv("endround", [](const auto client_num, const auto& params)
		{
			if (client_num != game::party->currentHost.hostNum)
			{
				game::SV_GameSendServerCommand(-1, game::SV_CMD_RELIABLE,
					utils::string::va("g \"[furtivehook] '%s' tried ending the game!\"",
						game::cg()->client(client_num)->name()));

				return true;
			}

			return false;
		});

		for (const auto& handler : game::handlers)
		{
			network::on_command(handler.first.data(), [=](const auto& params, const auto& target, auto& msg)
			{
				if (handler.second && game::is_packet_from_host(target))
				{
					return false;
				}

				return game::send_unhandled_message(params.join(0), target);
			});
		}

		network::on_command("go", [](const auto& args, const auto& target, const auto&)
		{
			const auto playlist_entry = utils::atoi(args[2]);
			const auto map_name = args[4];
			const auto game_type = args[5];

			if (game::is_packet_from_host(target)
				&& playlist_entry < 256
				&& game::is_valid_map_name(map_name))
			{
				return false;
			}

			return game::send_unhandled_message(args.join(0), target);
		}); 
		
		network::on_command("loadingnewmap", [](const auto& args, const auto& target, auto& msg)
		{
			if (game::is_packet_from_host(target)
				&& target.type != game::NA_LOOPBACK
				&& game::is_valid_new_server_map_info(msg))
			{
				return false;
			}

			return game::send_unhandled_message(args.join(0), target);
		}); 
		
		network::on_command("requeststats", [](const auto& args, const auto& target, const auto&)
		{
			if (game::CL_GetLocalClientConnectionState() == game::CA_CONNECTED
				&& game::is_packet_from_host(target))
			{
				return false;
			}

			const auto command = utils::string::va("%s [%u]", args.join(0).data(), game::CL_GetLocalClientConnectionState());
			return game::send_unhandled_message(command, target);
		});

		network::on_command("mstart", [](const auto& args, const auto& target, const auto&)
		{
			if (is_migrating && game::is_packet_from_host(target))
			{
				is_migrating = false;

				return false;
			}

			return game::send_unhandled_message(args.join(0), target);
		}); 
		
		network::on_command("disconnect", [](const auto& args, const auto& target, const auto&)
		{
			if (args[1] == "hostquit"s || args[1] == "roundsdone"s)
			{
				can_disconnect = true;
			}

			return false;
		}); 

		network::on_command("roundsdone", [](const auto& args, const auto& target, const auto&)
		{
			if (can_disconnect)
			{
				can_disconnect = false;

				return false;
			}

			return game::send_unhandled_message(args.join(0), target);
		});
		
		network::on_command("hostquit", [](const auto& args, const auto& target, const auto&)
		{
			if (can_disconnect)
			{
				can_disconnect = false;

				return false;
			}

			return game::send_unhandled_message(args.join(0), target);
		});

		network::on_command("error", [](const auto& args, const auto& target, const auto&)
		{
			if (game::CL_GetLocalClientConnectionState() < game::CA_SENDINGSTATS)
			{
				return false;
			}

			return game::send_unhandled_message(args.join(0), target);
		});
		
		network::on_command("pa_memberjoin", [](const auto& params, const auto& target, auto& msg)
		{	
			game::bdSecurityID id{};
			game::MSG_ReadData(&msg, &id, sizeof id);
			game::PartyJoinChallenge challenge{};
			game::MSG_ReadData(&msg, &challenge, sizeof challenge);
			game::MSG_ReadInt64(&msg);
			game::XNADDR addr{}; 
			game::MSG_ReadData(&msg, &addr, sizeof addr);
			game::MSG_ReadBits(&msg, 2);
			game::MSG_ReadByte(&msg);

			char party_member_info[128] = { 0 };
			game::Party_ReadMemberInfo(&msg, &party_member_info);

			const auto size = game::MSG_ReadShort(&msg); 
			if (size > 0x200)
			{
				return game::send_exploit_caught_messages(params.join(0), target);
			}

			return false;
		}); 
		
		network::on_command("relay", [](const auto& args, const auto& target, auto& msg)
		{
			if (const auto client_num = utils::atoi(args[2]); client_num < 18)
			{
				return game::is_valid_relay_packet(args, target, msg);
			}

			return game::send_exploit_caught_messages(args.join(0), target);
		}); 

		server_command::on_server_command('H', [](const auto& params)
		{
			for (auto i = 1u; i <= 2u; ++i)
			{
				const auto client_num = utils::atoi(params[i]);

				if (client_num >= 18)
				{
					PRINT_BOLD_MESSAGE("Exploit attempt caught!");
					PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], client_num);
					return true;
				}
			}

			return false;
		}); 

		server_command::on_server_command('W', [](const auto& params)
		{
			const auto volume_mod = utils::atoi(params[1]);

			if (volume_mod >= 3514)
			{
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");
				PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], volume_mod);
				return true;
			}

			return false;
		});
		
		server_command::on_server_command('Y', [](const auto& params)
		{
			const auto client_num = utils::atoi(params[1]);

			if (client_num > 18)
			{
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");
				PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], client_num);
				return true;
			}

			return false;
		});

		server_command::on_server_command('a', [](const auto& params)
		{
			const auto weapon_index = utils::atoi(params[1]);
			const auto held_weapon = get_held_weapon_slot(game::cg()->ps(), weapon_index);

			if (held_weapon < 0 || !weapon_index)
			{
				PRINT_LOG("Exploit attempt caught! [%s] [%u] [%u]", params[0], weapon_index, game::bg_lastParsedWeaponIndex);
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");

				return true;
			}

			return false;
		});

		server_command::on_server_command('b', [](const auto& params)
		{
			const auto client_num = utils::atoi(params[5]);

			if (client_num >= 18)
			{
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");
				PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], client_num);
				return true;
			}

			return false;
		});

		server_command::on_server_command('d', [](const auto& args)
		{
			const auto config_string_index = utils::atoi(args[1]);
			const auto config_string = args[2];

			if (config_string_index < 3882)
			{
				if (game::is_preparing_migration(config_string_index, config_string))
				{
					is_migrating = true;
				}
				
				if (config_string_index == 3)
				{
					const auto is_server_restarting = *reinterpret_cast<bool*>(0x00B7F87C);
					if (is_server_restarting)
					{
						return false;
					}

					const auto server_id = game::server_id; 
					if (utils::atoi<std::uint8_t>(config_string) == (static_cast<std::uint8_t>(server_id & 0xF0) + ((static_cast<std::uint8_t>(server_id) + 1) & 0xF)))
					{
						return false;
					}

					PRINT_LOG("Checkerboard screen attempt attempt caught! [%s %u]", args[0], config_string_index);
					return true;
				}

				return false;
			}

			PRINT_LOG("(configStringIndex) > (MAX_CONFIGSTRINGS) [%u]", config_string_index);
			return true;
		});

		server_command::on_server_command('l', [](const auto& params)
		{
			const auto volume = std::atof(params[1]);
			const auto fade = utils::atoi(params[2]);

			if (std::abs(volume) > 1.0f || fade > 1000)
			{
				PRINT_LOG("Exploit attempt caught! [%s] [%f] [%u]", params[0], std::abs(volume), fade);
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");
				return true;
			}

			return false;
		});

		server_command::on_server_command('m', [](const auto& params)
		{
			const auto value = utils::atoi(params[1]);

			if (value >= 2098)
			{
				PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], value);
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");

				return true;
			}

			return false;
		});

		server_command::on_server_command('q', [](const auto& params)
		{
			const auto dvar_lwr = utils::string::to_lower(params[1]);
			const auto value_lwr = utils::string::to_lower(params[2]);

			if (!game::I_stricmp(dvar_lwr, "g_scriptMainMenu"))
			{
				if (game::I_stricmp(value_lwr, "team_marinesopfor")
					&& game::I_stricmp(value_lwr, "class_marines")
					&& game::I_stricmp(value_lwr, "class_opfor")
					&& game::I_stricmp(value_lwr, "class"))
				{
					PRINT_MESSAGE("Anti-leave attempt caught!");
					return true;
				}
			}

			return false;
		});

		server_command::on_server_command('r', [](const auto& params)
		{
			if (game::cg()->next_snap()->ps.command_time())
			{
				PRINT_LOG("Server attempted to disconnect you with reason '%s' ..", params[1]); 
				return true;
			}

			return false;
		}); 
		
		server_command::on_server_command('s', [](const auto& params)
		{
			const auto menu_index = utils::atoi(params[1]);
			if (menu_index < 0x20)
			{
				const auto menu_name = game::CL_GetConfigString(menu_index + 3052);
				if (utils::string::begins_with(menu_name, "quick"))
				{
					PRINT_MESSAGE("Anti-leave attempt caught!");
					return true;
				}
			}

			return false;
		});

		server_command::on_server_command('w', [](const auto& params)
		{
			const auto weapon_index = utils::atoi(params[1]);
			const auto held_weapon = get_held_weapon_slot(game::cg()->ps(), weapon_index);

			if (held_weapon < 0 || !weapon_index)
			{
				PRINT_LOG("Exploit attempt caught! [%s] [%u] [%u]", params[0], weapon_index, game::bg_lastParsedWeaponIndex);
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");

				return true;
			}

			return false;
		});

		server_command::on_server_command('x', [](const auto& params)
		{
			const auto value = utils::atoi(params[1]);

			if (value >= 2098)
			{
				PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], value);
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");

				return true;
			}

			return false;
		});

		server_command::on_server_command('y', [](const auto& params)
		{
			const auto value = utils::atoi(params[1]);

			if (value >= 4)
			{
				PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], value);
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");

				return true;
			}

			return false;
		}); 
		
		server_command::on_server_command('z', [](const auto& params)
		{
			const auto value = utils::atoi(params[1]);

			if (value >= 4)
			{
				PRINT_LOG("Exploit attempt caught! [%s] [%u]", params[0], value);
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");

				return true;
			}

			return false;
		});
	}
}