#include "iat.hpp"

namespace security::iat
{
	HANDLE __stdcall heap_create(const DWORD options, const SIZE_T initial_size, const SIZE_T maximum_size)
	{
		PRINT_LOG_DETAILED("Called at (0x%08X) ..", _ReturnAddress());
		utils::nt::terminate();
	}

	FARPROC __stdcall get_proc_address(const HMODULE module, const LPCSTR proc_name)
	{
		if (proc_name != "VirtualProtect"s)
		{
			return GetProcAddress(module, proc_name);
		}

		PRINT_LOG_DETAILED("Called at (0x%08X) ..", _ReturnAddress());
		utils::nt::terminate();
	}

	void* __stdcall virtual_alloc(const LPVOID address, const SIZE_T size, const DWORD allocation_type, const DWORD protect)
	{
		if (protect != PAGE_EXECUTE_READWRITE)
		{
			return VirtualAlloc(address, size, allocation_type, protect);
		}

		PRINT_LOG_DETAILED("Called at (0x%08X) ..", _ReturnAddress());
		utils::nt::terminate();
	}

	void initialize()
	{
		return;
		
		loader::on_import("KERNEL32.dll", [](const auto& function) -> void*
		{	
			if (function == "GetProcAddress")
			{
				return get_proc_address;
			}
				
			if (function == "HeapCreate")
			{
				return heap_create;
			}
				
			if (function == "VirtualAlloc")
			{
				return virtual_alloc;
			}

			return nullptr;
		});

		loader::load_library("iw5mp.exe");
	}
}