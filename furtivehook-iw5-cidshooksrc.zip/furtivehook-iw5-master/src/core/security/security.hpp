#pragma once
#include "dependencies/std_include.hpp"

namespace security
{
	int __cdecl msg_read_bit(game::msg_t * msg);
	int __cdecl msg_read_bits(game::msg_t * msg, int c);
	const char * __cdecl cl_get_config_string(int configStringIndex);
	void net_defer_packet_to_client(game::netadr_t * from, game::msg_t * msg);
	void __cdecl cg_map_restart(LocalClientNum_t localClientNum, int savepersist);
	void sv_set_stats();
	void ui_replace_directive();
	void sv_packet_event();
	void rb_draw_stretch_pic_rotate();
	void party_atomic_host_handle_member_join();
	void cl_console_print();
	void seh_localize_text_message();
	void field_char_event();
	void initialize();
}