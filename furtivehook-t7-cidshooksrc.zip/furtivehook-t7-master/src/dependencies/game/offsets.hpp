#pragma once

namespace offsets
{
	
}