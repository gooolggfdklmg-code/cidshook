#include "dependencies/std_include.hpp"

namespace steam
{
	ISteamFriends* steam_friends = nullptr;
	ISteamUser* steam_user = nullptr;
	auto steam_friends_original = reinterpret_cast<decltype(&SteamFriends)>(0);
	auto steam_user_original = reinterpret_cast<decltype(&SteamUser)>(0);
	auto get_steam_id_original = reinterpret_cast<decltype(&get_steam_id)>(0); 
	auto get_persona_name_original = reinterpret_cast<decltype(&get_persona_name)>(0);
	auto csteam_id_is_valid_original = reinterpret_cast<decltype(&csteam_id_is_valid)>(0x00531AC0);

	const char* __fastcall get_persona_name(void* ecx, void* edx)
	{
		if (!misc::custom_name.empty())
			return misc::custom_name.data();

		return game::CL_ControllerIndex_GetUsername(0);
	}

	std::uint64_t __cdecl live_steam_get_user_steam_id_as_xuid()
	{
		return 11111111111111111;
	}

	CSteamID* __fastcall get_steam_id(void* ecx, void* edx, int a3)
	{
		auto result = get_steam_id_original(ecx, edx, a3);
		result->SetFromUint64(11111111111111111);

		return result;
	}

	bool __cdecl csteam_id_is_valid(CSteamID* _this) {
		return true;
	}
	
	void initialize()
	{
		steam_friends = reinterpret_cast<decltype(steam_friends_original)>(GetProcAddress(GetModuleHandleA("steam_api.dll"), "SteamFriends"))();
		steam_user = reinterpret_cast<decltype(steam_user_original)>(GetProcAddress(GetModuleHandleA("steam_api.dll"), "SteamUser"))();
		
		get_persona_name_original = reinterpret_cast<decltype(get_persona_name_original)>(utils::hook::vtable(steam_friends, &get_persona_name, 0));
		//get_steam_id_original = reinterpret_cast<decltype(get_steam_id_original)>(utils::hook::vtable(steam_user, &get_steam_id, 2));
		
		//utils::hook::detour(&csteam_id_is_valid_original, csteam_id_is_valid);
		//utils::hook::call(0x00924621, &live_steam_get_user_steam_id_as_xuid);
		
		utils::hook::nop(0x004FEA4F, 5); // LiveSteam_FilterPersonaName
	}
}
