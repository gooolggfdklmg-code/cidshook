#pragma once
#include "dependencies/std_include.hpp"

namespace steam
{
	const char* __fastcall get_persona_name(void* ecx, void* edx);
	CSteamID * __fastcall get_steam_id(void * ecx, void * edx, int a3);
	bool __cdecl csteam_id_is_valid(CSteamID * _this);
	void initialize();

	extern ISteamFriends* steam_friends;
}