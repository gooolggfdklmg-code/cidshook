#include "dependencies/std_include.hpp"
#include "utils.hpp"

namespace utils
{
	FILE* file_out;

	std::string generate_minidump_filename()
	{
		const auto timestamp = utils::get_timestamp();

		char filepath[MAX_PATH] = { 0 };
		utils::io::create_directory("minidumps");
		const auto filename = utils::string::va("furtivehook-%s.dmp", timestamp.data());

		PathCombineA(filepath, "minidumps\\", filename);
		
		return filepath;
	}
	
	std::string get_timestamp()
	{
		tm ltime{};
		char timestamp[MAX_PATH] = { 0 };
		const auto time = _time64(nullptr);

		_localtime64_s(&ltime, &time);
		strftime(timestamp, sizeof timestamp - 1, "%Y-%m-%d-%H-%M-%S", &ltime);

		return timestamp;
	}
	
	std::string get_exe_filename()
	{
		char exe_file_name[MAX_PATH] = { 0 };

		GetModuleFileNameA(nullptr, exe_file_name, sizeof exe_file_name);
		PathStripPathA(exe_file_name);
		PathRemoveExtensionA(exe_file_name);

		return exe_file_name;
	}
	
	void open_console()
	{
		AllocConsole();
		AttachConsole(GetCurrentProcessId());
		freopen_s(&file_out, "CONOUT$", "w", stdout);

		SetConsoleTitleA("furtivehook");
	}

	void close_console()
	{
		fclose(file_out);
		FreeConsole();
	}

	std::uintptr_t find_overlay_present(std::uintptr_t module)
	{
		std::uint8_t pattern[] = { 0x8B, 0x45, 0x0C, 0x53, 0x50, 0xFF, 0x75, 0x08, 0xFF, 0x15 };
		std::uintptr_t first_match = 0;

		module += 0x70000;
		for (std::uintptr_t position = module; position <= (module + 0x90000); ++position)
		{
			first_match = 0;
			
			while (*reinterpret_cast<std::uint8_t*>(position) == pattern[first_match])
			{
				++first_match; ++position;

				if (first_match == sizeof pattern - 1)
				{
					return (position - first_match) + std::uint32_t(10u);
				}
			}
		}

		return 0;
	}

	std::uintptr_t find_overlay_present()
	{
		const auto module = GetModuleHandleA("gameoverlayrenderer.dll");
		return find_overlay_present(reinterpret_cast<std::uintptr_t>(module));
	}

	std::uintptr_t find_direct_address(const std::uintptr_t address, std::vector<std::uintptr_t> offsets)
	{
		auto pointer = *reinterpret_cast<std::uintptr_t*>(address);

		if (!pointer)
			return 0u;

		for (auto offset : offsets)
		{
			if (offset == offsets.back())
			{
				pointer = static_cast<std::uintptr_t>(pointer + offset);

				if (!pointer)
					return 0u;

				return pointer;
			}

			else
			{
				pointer = *reinterpret_cast<std::uintptr_t*>(pointer + offset);

				if (!pointer)
					return 0u;
			}
		}

		return pointer;
	}

	void print_stack_details(const std::uintptr_t* esp, const std::uintptr_t* ebp)
	{
		if (esp)
		{
			PRINT_LOG("ESP: [0x%p]", esp);
			for (size_t i = 0; i < 256; ++i)
			{
				const auto ptr = esp + i;
				PRINT_LOG("[%i]: 0x%p 0x%08X", i, ptr, *ptr);
			}
		}

		if (ebp)
		{
			PRINT_LOG("EBP: [0x%p]", ebp);
			for (size_t i = 0; i < 256; ++i)
			{
				const auto ptr = ebp + i;
				PRINT_LOG("[%i]: 0x%p 0x%08X", i, ptr, *ptr);
			}
		}
	}
}