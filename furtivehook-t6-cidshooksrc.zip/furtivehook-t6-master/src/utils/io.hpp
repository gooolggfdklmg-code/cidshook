#pragma once
#include "dependencies/std_include.hpp"

namespace utils::io
{
	bool write_file(const std::string & file, const std::string & data, const bool append = false);
	void write_minidump(const LPEXCEPTION_POINTERS ex, const std::string & filename, const std::string & error = {});
	bool create_directory(const std::string & directory);
	bool file_exists(const std::string & file);
	std::string get_json_path(const std::string& name);
	std::string get_log_path(const std::string & name);
	std::ifstream read_json_file(const std::string & name);
}