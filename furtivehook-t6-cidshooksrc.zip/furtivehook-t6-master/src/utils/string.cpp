#include "dependencies/std_include.hpp"
#include "string.hpp"

namespace utils::string
{
	std::string xuid_string(const game::platformNetAdr& a, const std::uint64_t xuid)
	{
		if (a.netAddr.type == game::NA_BOT)
		{
			return "bot";
		}

		return std::to_string(xuid);
	}

	std::string adr_to_string(game::XSESSION_INFO const* session)
	{
		return utils::string::va("%u.%u.%u.%u:%u", session->hostAddress.ip[0], session->hostAddress.ip[1], session->hostAddress.ip[2], session->hostAddress.ip[3], session->hostAddress.port);
	}

	std::string adr_to_string(const game::platformNetAdr& address, const std::uint16_t port)
	{
		const auto type = address.netAddr.type;

		if (type == game::NA_BOT)
		{
			return "bot";
		}

		if (type == game::NA_LOOPBACK || type == game::NA_IP)
		{
			std::array<std::uint8_t, 4u> out{};
			std::copy(&address.liveaddr.xnaddr.ip[0], &address.liveaddr.xnaddr.ip[4], out.begin());

			if (port)
			{
				return utils::string::va("%u.%u.%u.%u:%u", out[0], out[1], out[2], out[3], port);
			}
			else if (!port && address.netAddr.port)
			{
				return utils::string::va("%u.%u.%u.%u:%u", out[0], out[1], out[2], out[3], address.netAddr.port);
			}

			return utils::string::va("%u.%u.%u.%u", out[0], out[1], out[2], out[3]);
		}

		return "bad";
	}
	
	const char* va(const char* fmt, ...)
	{
		static thread_local va_provider<8, 256> provider;

		va_list ap;
		va_start(ap, fmt);

		const auto* result = provider.get(fmt, ap);

		va_end(ap);
		return result;
	}

	std::string dump_hex(const std::string& data, const std::string& separator)
	{
		auto result = ""s;

		for (size_t i = 0; i < data.size(); ++i)
		{
			if (i > 0)
			{
				result.append(separator);
			}

			result.append(va("%02X", data[i] & 0xFF));
		}

		return result;
	}

	std::string join(const std::vector<std::string>& args, const std::size_t index)
	{
		auto result = ""s;

		for (auto i = index; i < args.size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(args[i]);
		}

		return result;
	}

	std::vector<std::string> split(const std::string& text, const char delimiter)
	{
		std::stringstream ss(text);
		std::string item;
		std::vector<std::string> elems;

		while (std::getline(ss, item, delimiter))
		{
			elems.emplace_back(item);
		}

		return elems;
	}

	std::string reverse_words(const std::string& src)
	{
		assert(src.size() % 2 == 0);
		std::string result;
		result.reserve(src.size());

		for (std::size_t i = src.size(); i != 0; i -= 2)
		{
			result.append(src, i - 2, 2);
		}

		return result;
	}

	std::string replace_all(std::string str, const std::string& search, const std::string& replace)
	{
		if (search.empty())
		{
			return str;
		}

		std::string::size_type match;

		while ((match = str.find(search)) != std::string::npos)
		{
			str.replace(match, search.length(), replace);
		}

		return str;
	}

	bool begins_with(const std::string& text, const std::string& substring)
	{
		return text.find(substring) == 0;
	}

	bool contains(const std::string &text, const std::string &substring)
	{
		return text.find(substring) != std::string::npos;
	}

	std::wstring s2ws(const std::string& str)
	{
		using convert_typeX = std::codecvt_utf8<wchar_t>;
		std::wstring_convert<convert_typeX, wchar_t> converterX;

		return converterX.from_bytes(str);
	}

	std::string ws2s(const std::wstring& wstr)
	{
		using convert_typeX = std::codecvt_utf8<wchar_t>;
		std::wstring_convert<convert_typeX, wchar_t> converterX;

		return converterX.to_bytes(wstr);
	}

	std::string ltrim(const std::string& s)
	{
		return std::regex_replace(s, std::regex("^\\s+"), std::string(""));
	}

	std::string rtrim(const std::string& s)
	{
		return std::regex_replace(s, std::regex("\\s+$"), std::string(""));
	}

	std::string trim(const std::string& s)
	{
		return ltrim(rtrim(s));
	}

	std::string to_lower(std::string text)
	{
		std::transform(text.begin(), text.end(), text.begin(), [](const char input)
			{
				return static_cast<char>(std::tolower(input));
			});

		return text;
	}
}