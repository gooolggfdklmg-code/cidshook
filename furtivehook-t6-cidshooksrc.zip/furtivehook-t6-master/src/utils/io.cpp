#include "dependencies/std_include.hpp"
#include "io.hpp"

namespace utils::io
{
	void write_minidump(const LPEXCEPTION_POINTERS ex, const std::string& filename, const std::string& error)
	{
		const auto data = exception::minidump::create_minidump(ex);
		write_file(filename, data);

		if (!error.empty())
		{
			PRINT_LOG(error.data());
		}
	}
	
	bool create_directory(const std::string& directory)
	{
		return std::filesystem::create_directories(directory);
	}
	
	bool write_file(const std::string& file, const std::string& data, const bool append)
	{
		const auto pos = file.find_last_of("/\\");
		if (pos != std::string::npos)
		{
			create_directory(file.substr(0, pos));
		}

		std::ofstream stream(file, std::ios::binary | std::ofstream::out | (append ? std::ofstream::app : 0));

		if (stream.is_open())
		{
			auto line = ""s;
			line.append(data);

			if (append)
				line.append("\n");
			
			stream.write(line.data(), line.size());
			stream.close();

			return true;
		}

		return false;
	}
	
	void write_to_log(const std::string & name, const std::string& buffer)
	{
		char path[MAX_PATH] = { 0 };
		GetModuleFileNameA(nullptr, path, sizeof path);
		PathRemoveFileSpecA(path);

		std::strcat(path, "\\");
		std::strcat(path, name.data());
		
		std::ofstream file(path, std::ios_base::out | std::ios_base::app);

		if (file.is_open())
		{
			auto text_to_log = ""s;
			if (static auto initialized = false; !initialized)
			{
				initialized = true;
				text_to_log += "\n\n";
			}

			text_to_log += (utils::get_timestamp() + ": " + buffer).data();
			text_to_log += "\n";

			file.write(text_to_log.data(), text_to_log.size());
			file.close();
		}
	}

	bool file_exists(const std::string& file)
	{
		return std::ifstream(file).good();
	}

	std::string get_json_path(const std::string& name)
	{
		char path[MAX_PATH] = { 0 };
		GetModuleFileNameA(nullptr, path, sizeof path);
		PathRemoveFileSpecA(path);

		std::strcat(path, "\\");
		std::strcat(path, "json\\");
		std::strcat(path, name.data());

		return path;
	}

	std::string get_log_path(const std::string& name)
	{
		char path[MAX_PATH] = { 0 };
		GetModuleFileNameA(nullptr, path, sizeof path);
		PathRemoveFileSpecA(path);

		std::strcat(path, "\\");
		std::strcat(path, "log\\");
		std::strcat(path, name.data());

		return path;
	}
	
	std::ifstream read_json_file(const std::string& name)
	{
		const auto path = get_json_path(name);
		
		if (file_exists(path))
			return std::ifstream(path);

		return {};
	}
}