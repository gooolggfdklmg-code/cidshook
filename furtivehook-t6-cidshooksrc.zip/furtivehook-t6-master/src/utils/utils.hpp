#pragma once
#include "dependencies/std_include.hpp"

#define FRIENDS_LIST "friends.json"
#define PRINT_BOLD_MESSAGE(format, ...) game::CG_BoldGameMessage(0, format, 0)

#define DEBUG_LOG(format, ...)																									\
{																																\
    std::printf(utils::string::va("[%s] %s\n", __FUNCTION__, format), __VA_ARGS__);												\
    logger::print_log(utils::string::va("[%s] %s", __FUNCTION__, format), __VA_ARGS__);											\
}

#define PRINT_LOG(format, ...)																									\
{																																\
	std::printf(utils::string::va("%s\n", format), __VA_ARGS__);																\
    logger::print_log(format, __VA_ARGS__);																						\
}

namespace utils
{
	void close_console();
	std::string generate_minidump_filename();
	std::string get_timestamp();
	std::string get_exe_filename();
	void open_console();
	std::uintptr_t find_overlay_present();
	std::uintptr_t find_direct_address(const std::uintptr_t address, std::vector<std::uintptr_t> offsets);
	void print_stack_details(const std::uintptr_t * esp, const std::uintptr_t * ebp);

	template <typename T> auto strtol(const std::string& str, const int base = 10)
	{
		return static_cast<T>(std::strtol(str.data(), nullptr, base));
	}

	static auto strtol(const std::string& str, const int base = 10)
	{
		return strtol<int>(str, base);
	}
	
	template <typename T>
	static auto atoi(const std::string& str)
	{
		return static_cast<T>(std::atoi(str.data()));
	}

	static auto atoi(const std::string& str)
	{
		return static_cast<std::uint32_t>(std::atoi(str.data()));
	}

	static auto atoll(const std::string& str)
	{
		return static_cast<std::uint64_t>(std::atoll(str.data()));
	}

	template <typename T>
	std::vector<std::vector<T>> get_batch(const std::vector<T>& v, const size_t num)
	{
		std::vector<std::vector<T>> batches{};
		batches.reserve(v.size() / num);

		for (size_t i = 0; i < v.size(); i += num)
		{
			const auto last{ std::min(v.size(), i + num) };
			batches.emplace_back(v.begin() + i, v.begin() + last);
		}

		return batches;
	}

	template <typename T>
	void for_each_batch(const std::vector<T>& v, const size_t num, const std::function<void(std::vector<T>)>& callback)
	{
		const auto batches{ get_batch(v, num) };

		for (const auto& batch : batches)
		{
			callback(batch);
		}
	}

	template <class F>
	class final_action
	{
	public:
		static_assert(!std::is_reference<F>::value && !std::is_const<F>::value &&
			!std::is_volatile<F>::value,
			"Final_action should store its callable by value");

		explicit final_action(F f) noexcept : f_(std::move(f))
		{
		}

		final_action(final_action&& other) noexcept
			: f_(std::move(other.f_)), invoke_(std::exchange(other.invoke_, false))
		{
		}

		final_action(const final_action&) = delete;
		final_action& operator=(const final_action&) = delete;
		final_action& operator=(final_action&&) = delete;

		~final_action() noexcept
		{
			if (invoke_) f_();
		}

		void cancel()
		{
			invoke_ = false;
		}

	private:
		F f_;
		bool invoke_{ true };
	};

	template <class F>
	final_action<typename std::remove_cv<typename std::remove_reference<F>::type>::type>
		finally(F&& f) noexcept
	{
		return final_action<typename std::remove_cv<typename std::remove_reference<F>::type>::type>(
			std::forward<F>(f));
	}
}

namespace std
{
	template<typename T1, typename T2>
	struct hash<std::pair<T1, T2>>
	{
		size_t operator()(const std::pair<T1, T2>& pair) const
		{
			return std::hash<T1>()(pair.first) ^ std::hash<T2>()(pair.second);
		}
	};
}
