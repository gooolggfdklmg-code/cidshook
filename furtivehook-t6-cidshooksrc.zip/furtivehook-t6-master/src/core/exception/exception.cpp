#include "dependencies/std_include.hpp"
#include "exception.hpp"

namespace exception
{
	bool is_harmless_error(const std::uint32_t code)
	{
		return code == STATUS_INTEGER_OVERFLOW
			|| code == STATUS_FLOAT_OVERFLOW 
			|| code == STATUS_SINGLE_STEP;
	}
	
	LONG __stdcall exception_filter(const LPEXCEPTION_POINTERS ex)
	{
		utils::hook::set<std::uint8_t>(0x03A458F4, 0x1);
		utils::hook::set<std::uint8_t>(0x028A1FB4, 0x0);

		const auto addr = ex->ExceptionRecord->ExceptionAddress; 
		const auto code = ex->ExceptionRecord->ExceptionCode;
		
		if (is_harmless_error(code))
		{
			return EXCEPTION_CONTINUE_EXECUTION;
		}
		
		auto error = "Termination due to a stack overflow."s;
		if (code != EXCEPTION_STACK_OVERFLOW)
		{
			error = utils::string::va("Exception (0x%08X) at 0x%08X", code, addr);
		}
		
		const auto filename = utils::generate_minidump_filename();
		utils::io::write_minidump(ex, filename, error);

		game::open_toast_popup(utils::string::va("Exception (0x%08X)\nAt 0x%08X", code, addr));

		reinterpret_cast<void(*)()>(0x00647760)(); // Cmd_ComErrorCleanup
		const auto buf = reinterpret_cast<int*>(game::Sys_GetValue(2));
		std::longjmp(buf, -1);

		return EXCEPTION_CONTINUE_SEARCH;
	}

	LPTOP_LEVEL_EXCEPTION_FILTER __stdcall set_unhandled_exception_filter(LPTOP_LEVEL_EXCEPTION_FILTER&)
	{
		return &exception_filter;
	}

	LONG CALLBACK pVectoredExceptionHandler(EXCEPTION_POINTERS* pExceptionInfo) {
		if (pExceptionInfo->ContextRecord->Eip == (((int)GetModuleHandleA("KERNELBASE.dll")) + 0x149392)) {
			return EXCEPTION_CONTINUE_EXECUTION;
		}

		if (pExceptionInfo->ExceptionRecord->ExceptionCode == 0x80000004) {
			return EXCEPTION_CONTINUE_SEARCH;
		}

		if (pExceptionInfo->ContextRecord->Eip == 0x9b389b) {
			return EXCEPTION_CONTINUE_SEARCH;
		}

		return EXCEPTION_CONTINUE_SEARCH;
	}

	void initialize()
	{
		//SetUnhandledExceptionFilter(exception_filter);
		//utils::hook::jump(&SetUnhandledExceptionFilter, &set_unhandled_exception_filter);

		//SetUnhandledExceptionFilter(handler);
		AddVectoredExceptionHandler(1, pVectoredExceptionHandler);
	}
}