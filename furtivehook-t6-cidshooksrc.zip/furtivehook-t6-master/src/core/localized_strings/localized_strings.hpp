#pragma once
#include "dependencies/std_include.hpp"

namespace localized_strings
{
	//void override(const std::string& key, const std::string& value);
	const char* __cdecl se_get_string_fast_file(const char* reference);
	void initialize();
}