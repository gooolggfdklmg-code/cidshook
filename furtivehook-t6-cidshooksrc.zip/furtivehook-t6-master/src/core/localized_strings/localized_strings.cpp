#include "dependencies/std_include.hpp"
#include "localized_strings.hpp"
#include <stdexcept>
#include <optional>
#include <d3d11.h>

#define STB_IMAGE_IMPLEMENTATION
#include "../thirdparty/stb/stb_image.h"

namespace localized_strings
{
	auto seh_string_ed_get_string_original = reinterpret_cast<decltype(&se_get_string_fast_file)>(0x008975E0);
	
	using callback = std::function<bool(const std::string&, const std::string&)>;
	using pair = std::pair<std::string, callback>;
	using localized_map = std::unordered_map<std::string, pair>;
	utils::concurrency::container<localized_map> overrides;

	void override(const std::string& name, const std::string& override, const callback& cb = {})
	{
		overrides.access([&](auto& map)
		{
			map[name] = { override, cb };
		});
	}

	const char* __cdecl se_get_string_fast_file(const char* reference)
	{
		return overrides.access<const char*>([&](const localized_map& map)
		{
			const auto entry = map.find(reference);

			if (entry != map.end())
				return entry->second.first.data();

			const auto filter = std::find_if(map.begin(), map.end(), [&](const auto& m) 
			{ 
				const auto pair = m.second;
				if (!pair.second) return false;
				return pair.second(reference, m.first);
			});

			if (filter != map.end())
				return filter->second.first.data();

			return seh_string_ed_get_string_original(reference);
		});
	}

	void initialize()
	{
		utils::hook::detour(&seh_string_ed_get_string_original, &se_get_string_fast_file);

		const auto begins_with = [](const std::string& reference, const std::string& override)
		{
			return utils::string::begins_with(reference, override);
		}; 
		
		//localized_strings::override("MENU_", "Twitter", begins_with);
	}
}