#pragma once
#include "dependencies/std_include.hpp"

namespace session
{
	struct sessions_t
	{
		game::XSESSION_INFO sessinfo;
		std::uint64_t xuid;
		size_t clients;
		bool in_game;
		std::string gametype;
		std::string map_name;
	};

	void session_list();
	void party_prober_store_qos_result();
	void initialize();
	bool can_add_to_session(const game::XSESSION_INFO & sessinfo);

	extern std::vector<sessions_t> sessions;
	extern bool grab_info_of_sessions;
}