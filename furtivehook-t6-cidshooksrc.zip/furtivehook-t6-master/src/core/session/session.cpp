#include "dependencies/std_include.hpp"
#include "session.hpp"

namespace session
{
	struct players_list_t
	{
		std::uint64_t xuid;
		size_t client_num;
		std::string name;
	};
	
	std::vector<players_list_t> players_list;
	std::vector<sessions_t> sessions;
	bool grab_info_of_sessions = false;

	bool can_add_to_session_player_list(const size_t client_num)
	{
		const auto player_list = std::find_if(players_list.begin(), players_list.end(), [&](const auto& list) { return list.client_num == client_num; });
		return player_list == players_list.end();
	}
	
	bool can_add_to_session(const game::XSESSION_INFO& sessinfo)
	{
		for (const auto& session : sessions)
		{
			if (game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &sessinfo.hostAddress))
				return false;
		}

		return true;
	}

	game::netadr_t get_net_adr(const game::XSESSION_INFO& info)
	{
		game::netadr_t netadr{};
		game::Xenon_RegisterRemoteXenon(&info, &netadr);

		return netadr;
	}

	bool is_valid_session(const sessions_t& session)
	{
		//if (!session.clients)
		//	return false;

		return true;
	}
	
	void session_list()
	{
		if (ImGui::BeginTabItem("Sessions"))
		{
			const auto width = ImGui::GetContentRegionAvail().x;
			const auto spacing = ImGui::GetStyle().ItemInnerSpacing.x;

			const auto popup = "Add friend##add_friend_popup"s;

			static ImGuiTextFilter filter;

			ImGui::TextUnformatted("Search session");
			filter.Draw("##search_session", width * 0.85f);
			ImGui::SetNextItemWidth(width * 0.85f);
			
			if (ImGui::MenuItem("Grab info of joined sessions", nullptr, grab_info_of_sessions))
			{
				grab_info_of_sessions = !grab_info_of_sessions;
			}

			if (ImGui::MenuItem("Crash all servers", nullptr, nullptr, !sessions.empty()))
			{
				for (const auto& session : sessions)
				{
					if (game::Xenon_RegisterRemoteXenon(&session.sessinfo, &exploits::target))
					{
						exploits::send_relay_crash_packet(game::party, exploits::local_net_id);
						exploits::send_join_party_crash_packet(game::party, exploits::local_net_id);
						exploits::send_join_party_overflowed_crash_packet(game::party, exploits::local_net_id);
					}
				}
			}

			if (ImGui::MenuItem("Delete sessions", nullptr, nullptr, !sessions.empty()))
			{
				sessions.clear();
			}

			ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 0.0f);
			ImGui::BeginColumns("Sessions", 2, ImGuiColumnsFlags_NoResize);

			ImGui::SetColumnWidth(-1, 28.0f);
			ImGui::TextUnformatted("#");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Session");
			ImGui::NextColumn();

			ImGui::Separator();

			std::vector<std::uint32_t> indices{};

			for (auto i = 0u; i != sessions.size(); ++i)
			{
				indices.emplace_back(i);
			}

			std::sort(indices.begin(), indices.end(), [](const auto& a, const auto& b) { return sessions[a].in_game > sessions[b].in_game; });

			for (const auto& session_num : indices)
			{
				auto& session = sessions[session_num]; 
				const auto ip_string = utils::string::adr_to_string(&session.sessinfo);
				
				if (filter.PassFilter(ip_string.data()))
				{
					ImGui::AlignTextToFramePadding();

					ImGui::TextUnformatted(std::to_string(session_num));

					ImGui::NextColumn();

					ImGui::PushStyleColor(ImGuiCol_Text, session.in_game ? ImColor(0, 255, 127, 250).Value : ImColor(200, 200, 200, 250).Value);

					ImGui::AlignTextToFramePadding();

					const auto selected = ImGui::Selectable((ip_string + "##"s + std::to_string(session_num)).data());

					ImGui::PopStyleColor();

					if (game::NET_CompareXNAddr(&game::party->currentHost.sessionInfo.hostAddress, &session.sessinfo.hostAddress))
					{
						ImGui::SameLine(0, spacing);

						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 0.95f), "[Current]");
					}

					const auto popup = "session_popup##" + std::to_string(session_num);
					static game::netadr_t netadr{};

					if (selected)
					{
						if (!game::Xenon_RegisterRemoteXenon(&session.sessinfo, &netadr))
						{
							PRINT_LOG("Couldn't register remote address for '%s'", ip_string.data());
						}

						players_list.clear();

						exploits::pm = {};
						exploits::target = netadr;

						ImGui::OpenPopup(popup.data());
					}

					if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
					{
						if (ImGui::MenuItem(ip_string.data()))
						{
							ImGui::LogToClipboardUnformatted(ip_string.data());
						}

						if (ImGui::MenuItem(std::to_string(session.xuid).data()))
						{
							ImGui::LogToClipboardUnformatted(std::to_string(session.xuid).data());
						}

						if (session.in_game && !session.map_name.empty() && !session.map_name.empty())
						{
							ImGui::MenuItem(game::UI_GetMapName(session.map_name.data(), false), nullptr, nullptr, false);
							ImGui::MenuItem(game::UI_GetGameTypeDisplayName(session.gametype.data(), nullptr), nullptr, nullptr, false);
						}

						ImGui::Separator();

						if (ImGui::MenuItem("Join session"))
						{
							exploits::target = game::party->currentHost.addr;
							exploits::send_rejoin_packet(game::party, session.sessinfo);
						}

						ImGui::Separator();

						if (ImGui::MenuItem("Crash session"))
						{
							exploits::send_relay_crash_packet(game::party, exploits::local_net_id);
							exploits::send_join_party_crash_packet(game::party, exploits::local_net_id);
							exploits::send_join_party_overflowed_crash_packet(game::party, exploits::local_net_id);
						}

						if (ImGui::BeginMenu(("Send OOB to session##" + std::to_string(session_num)).data(), netadr.ip.inaddr))
						{
							static auto oob_input = ""s;

							ImGui::InputTextA(("##" + std::to_string(session_num)).data(), &oob_input);

							if (ImGui::MenuItem("Send OOB", nullptr, nullptr, !oob_input.empty()))
							{
								game::oob::send(netadr, oob_input);
							}

							ImGui::EndMenu();
						}

						ImGui::Separator();

						if (ImGui::BeginMenu(("List players##" + std::to_string(session.xuid)).data(), session.in_game))
						{
							for (const auto& player_list : players_list)
							{
								if (player_list.xuid == session.xuid)
								{
									const auto client_num = player_list.client_num;
									const auto player_name = player_list.name;

									ImGui::PushStyleColor(ImGuiCol_Text, ImColor(200, 200, 200, 250).Value);

									const auto selected = ImGui::Selectable((player_name + "##"s + std::to_string(client_num)).data());

									ImGui::PopStyleColor();
								}
							}

							ImGui::EndMenu();
						}

						ImGui::EndPopup();
					}

					ImGui::NextColumn();

					if (ImGui::GetColumnIndex() == 0)
					{
						ImGui::Separator();
					}
				}
			}

			ImGui::PopStyleVar();
			ImGui::EndColumns();
			ImGui::EndTabItem();
		}
	}

	auto party_prober_store_qos_result_original = reinterpret_cast<decltype(&party_prober_store_qos_result)>(0x00543BA5); 
	
	bool __cdecl callback_party_prober_store_qos_result(game::PartyInfo* partyInfo, game::qosPayload_t *qosPayload)
	{
		if (session::can_add_to_session(partyInfo->info))
			session::sessions.emplace_back(session::sessions_t{ partyInfo->info, qosPayload->xuid, std::uint32_t(partyInfo->occupiedPublicSlots) });

		if (session::grab_info_of_sessions)
			return true;

		return false;
	}

	__declspec(naked) void party_prober_store_qos_result()
	{
		__asm
		{
			pushad;
			push ecx;
			push esi;
			call callback_party_prober_store_qos_result;
			add esp, 8;
			test al, al;
			popad;

			jz fix;

			push 0x00543B7B;
			retn;

		fix:
			jmp party_prober_store_qos_result_original;
		}
	}
	
	void initialize()
	{
		utils::hook::detour(&party_prober_store_qos_result_original, &party_prober_store_qos_result);
		utils::hook::nop(0x004F80D4, 5);
		utils::hook::set<std::uint8_t>(0x0054D84B, 0xEB);
		
		scheduler::loop([]()
		{
			for (const auto& session : sessions)
			{
				const auto netadr = get_net_adr(session.sessinfo);

				if (netadr.ip.inaddr)
				{
					game::oob::send(netadr, "getstatus");
					
					if (game::party->is_running() && !game::NET_CompareAdr(netadr, game::party->currentHost.addr))
						game::oob::send(netadr, "2localJoin");
				}
			}

		}, scheduler::pipeline::main, 1s);
		
		network::on_command("pseg", [](const auto& params, const auto& target, auto& msg)
		{
			game::platformNetAdr adr = {};
			
			if (game::Party_NetAdrToPlatformNetAdr(target, &adr))
			{
				for (auto& session : sessions)
				{
					if (game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &adr.liveaddr.xnaddr))
					{
						session.in_game = false;
					}
				}
			}

			return false;
		});

		network::on_command("localJoinFailed", [](const auto& params, const auto& target, auto& msg)
		{
			game::platformNetAdr adr = {};
			
			if (game::Party_NetAdrToPlatformNetAdr(target, &adr))
			{
				for (auto& session : sessions)
				{
					if (game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &adr.liveaddr.xnaddr))
					{
						if (params[1] == "nothosting"s || params[1] == "ingame"s)
						{
							session.in_game = true;
						}
					}
				}
			}

			return true;
		});
	
		network::on_command("statusResponse", [](const auto& params, const auto& target, auto& msg)
		{
			char response[1024] = { 0 };
			const auto status_string = game::MSG_ReadStringLine(&msg, response, sizeof response);
			const auto gametype = game::Info_ValueForKey(status_string, "g_gametype");
			const auto map_name = game::Info_ValueForKey(status_string, "mapname");

			game::platformNetAdr adr = {};
			
			if (game::Party_NetAdrToPlatformNetAdr(target, &adr))
			{
				for (auto& session : sessions)
				{
					if (game::NET_CompareXNAddr(&session.sessinfo.hostAddress, &adr.liveaddr.xnaddr))
					{
						session.gametype = gametype; 
						session.map_name = map_name;

						for (auto i = 0u; i != 18; ++i)
						{
							const auto string = game::MSG_ReadStringLine(&msg, response, sizeof response);

							if (*string)
							{
								const auto player_name = utils::string::split(string, ' ')[2];
								const auto player_name_str = utils::string::replace_all(player_name, "\"", "");

								if (can_add_to_session_player_list(i))
									players_list.emplace_back(players_list_t{ session.xuid, i, player_name_str });
							}
						}
					}
				}
			}

			return true;
		});
	}
}
