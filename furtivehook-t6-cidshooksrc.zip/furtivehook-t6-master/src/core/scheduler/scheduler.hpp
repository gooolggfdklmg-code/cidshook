#pragma once
#include "dependencies/std_include.hpp"

namespace scheduler
{
	struct task
	{
		std::function<bool()> handler{};
		std::chrono::milliseconds interval{};
		std::chrono::high_resolution_clock::time_point last_call{};
	};
	
	enum pipeline
	{
		async,
		renderer,
		main,
		count,
	};

	using task_list = std::vector<task>; 
	static const bool cond_continue = false;
	static const bool cond_end = true;
	
	void __cdecl main_frame();
	void __cdecl draw_active(LocalClientNum_t localClientNum, void * viewParmsDraw, void * viewParmsDpvs); 
	
	void schedule(const std::function<bool()>& callback, pipeline type = pipeline::async, std::chrono::milliseconds delay = 0ms);
	void loop(const std::function<void()>& callback, pipeline type = pipeline::async, std::chrono::milliseconds delay = 0ms);
	void once(const std::function<void()>& callback, pipeline type = pipeline::async, std::chrono::milliseconds delay = 0ms);
	void on_game_initialized(const std::function<void()>& callback, const pipeline type = pipeline::async, const std::chrono::milliseconds delay = 0ms);
	void start_thread();
	void destroy_thread(); 
	void initialize();
}