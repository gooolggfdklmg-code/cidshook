﻿#include "dependencies/std_include.hpp"
#include "misc.hpp"

namespace misc
{
	auto cl_ready_to_send_packet_original = reinterpret_cast<decltype(&cl_ready_to_send_packet)>(0x007E6775);
	auto cg_calc_entity_lerp_positions_original = reinterpret_cast<decltype(&cg_calc_entity_lerp_positions)>(0x00469870);
	auto is_client_in_our_party_original = reinterpret_cast<decltype(&is_client_in_our_party)>(0x00456110);
	auto sys_get_value_original = reinterpret_cast<decltype(&sys_get_value)>(0x00635F09);
	auto live_send_invite_original = reinterpret_cast<decltype(&live_send_invite)>(0x005E4910);
	auto exit_process_original = reinterpret_cast<decltype(&exit_process)>(ExitProcess);
	auto sys_error_original = reinterpret_cast<decltype(&sys_error)>(0x00577450);
	auto cg_draw_overhead_names_original = reinterpret_cast<decltype(&cg_draw_overhead_names)>(0x006F5FD0);

	std::string custom_name = game::CL_ControllerIndex_GetUsername(0), clan = game::CL_GetClantag(0);
	bool no_flinch = true, no_recoil = true, cycling_prestige = false, third_person = false, anti_leave = false;
	int trace_thread_value = 0;
	std::uint8_t* ip_buffer;
	float fov = 90.0f;
	Vec3 client_angles_backup = {};
	Vec3 cent_angles_backup = {};

	int get_max_packets()
	{
		const auto fps = static_cast<float>(game::Dvar_FindVar("com_maxFPS")->current.integer);
		const auto max_packets = static_cast<int>(std::roundf(1000.0f / fps));
		return static_cast<int>(fps) > 0 ? max_packets : 10;
	}

	bool callback_cl_ready_to_send_packet(std::uint32_t	type)
	{
		const auto max_packets = get_max_packets();
		utils::hook::set<std::uint8_t>(0x007E67E9 + 0x2, max_packets);

		return type == game::NA_LOOPBACK;
	}

	__declspec(naked) void cl_ready_to_send_packet()
	{
		__asm
		{
			mov eax, [esi + 0x24368];

			pushad;

			push eax;
			call callback_cl_ready_to_send_packet;
			add esp, 4;

			test al, al;
			jnz fix;

			popad;

			jmp cl_ready_to_send_packet_original;

		fix:
			popad;

			push 0x007E67B7;
			retn;
		}
	}

	__declspec(naked) void sys_get_value()
	{
		__asm
		{
			test eax, eax;
			jz fix;

			jmp sys_get_value_original;

		fix:
			mov eax, trace_thread_value;
			retn;
		}
	}

	void __cdecl cg_calc_entity_lerp_positions(LocalClientNum_t localClientNum, game::centity_t* cent)
	{
		cg_calc_entity_lerp_positions_original(localClientNum, cent);

		if (cent->is_alive())
		{
			if (cent->next_state().number == game::cg()->client_num())
			{
				const auto angles = &game::cg()->client(cent->next_state().number)->player_angles();
				client_angles_backup = *angles;

				if (antiaim::enabled && game::cg()->rendering_third_person())
				{
					game::cg()->client(cent->next_state().number)->player_angles() = antiaim::cur_angles + game::cg()->ps()->delta_angles;
					cent->angles().y = antiaim::cur_angles.y + game::cg()->ps()->delta_angles.y;
				}
			}
			else
			{
				if (prediction::enabled && cent->next_state().number <= 17)
				{
					prediction::cg_interpolate_entity_position(cent);
				}
			}
		}
	}

	int __cdecl com_gametype_settings_get_uint(int setting)
	{
		return std::numeric_limits<std::int32_t>::max();
	}

	void __cdecl cg_dobj_get_world_bone_matrix(const game::centity_t* poseEA, void* objEA, int boneIndex, Vec3* tagMat, Vec3* origin)
	{
		reinterpret_cast<decltype(&cg_dobj_get_world_bone_matrix)>(0x0047AC00)(poseEA, objEA, boneIndex, tagMat, origin);
		
		game::CG_GetPlayerViewOrigin(0, game::cg()->ps(), origin);
	}

	void __cdecl bg_weapon_fire_recoil(game::playerState_s *ps, Vec3 *recoilSpeed, Vec3 *kickAVel, int *previousRecoilTime, bool previouslyFiring, float *previousRecoilRatio, unsigned int *holdrand)
	{
		if (!no_recoil)
		{
			return reinterpret_cast<decltype(&bg_weapon_fire_recoil)>(0x00407530)(ps, recoilSpeed, kickAVel, previousRecoilTime, previouslyFiring, previousRecoilRatio, holdrand);
		}
	}

	bool __cdecl is_client_in_our_party(LocalClientNum_t localClientNum, ClientNum_t clientNum)
	{
		if (clientNum >= 0)
		{
			return game::is_friend(clientNum);
		}

		return is_client_in_our_party_original(localClientNum, clientNum);
	}

	bool __cdecl live_send_invite(ControllerIndex_t controllerIndex, std::uint64_t xuid, bool a)
	{
		game::open_toast_popup(utils::string::va("Pulling..\n%llu", xuid));
		exploits::instant_message::pulling::setup_instant_message(xuid);
		
		return true;
	}

	const char *__cdecl cl_controller_index_get_username(ControllerIndex_t controllerIndex)
	{
		if (!custom_name.empty())
		{
			return custom_name.data();
		}

		return reinterpret_cast<decltype(&cl_controller_index_get_username)>(0x0065FDE0)(controllerIndex);
	}

	void __stdcall exit_process(std::uint32_t exit_code)
	{
		scheduler::destroy_thread();
		exit_process_original(exit_code);
	}
	
	[[noreturn]] void __cdecl sys_error(const char *error, ...)
	{
		char buffer[2048];

		va_list ap;
		va_start(ap, error);

		vsnprintf_s(buffer, sizeof buffer, _TRUNCATE, error, ap);

		va_end(ap);

		PRINT_LOG("Sys_Error(%s) called at 0x%08X", error, _ReturnAddress());

		if (!std::strcmp(error, game::com_error_message))
		{
			return;
		}

		sys_error_original(error);
	}

	void __cdecl cg_draw_overhead_names(LocalClientNum_t localClientNum, game::centity_t *cent, float alpha, int mode)
	{
		if (!game::can_draw_overhead_names(cent))
			cg_draw_overhead_names_original(localClientNum, cent, alpha, mode);
	}

	void __cdecl sub_64C8A0(char* a1)
	{
		DEBUG_LOG("%s", a1);
		return reinterpret_cast<decltype(&sub_64C8A0)>(0x0064C8A0)(a1);
	}

	auto sys_quit_and_start_process_original = reinterpret_cast<decltype(&sys_quit_and_start_process)>(0x005C0840);
	void __cdecl sys_quit_and_start_process(const char *exeName)
	{
		DEBUG_LOG("%s @ 0x%08X", exeName, _ReturnAddress());
		return sys_quit_and_start_process_original(exeName);
	}
	
	void initialize()
	{
		utils::hook::detour(&cl_ready_to_send_packet_original, &cl_ready_to_send_packet);
		utils::hook::detour(&cg_calc_entity_lerp_positions_original, &cg_calc_entity_lerp_positions);
		utils::hook::detour(&is_client_in_our_party_original, &is_client_in_our_party);
		utils::hook::detour(&sys_get_value_original, &sys_get_value);
		utils::hook::detour(&live_send_invite_original, &live_send_invite);
		//utils::hook::detour(&sys_error_original, &sys_error);
		utils::hook::detour(&cg_draw_overhead_names_original, &cg_draw_overhead_names);
		utils::hook::detour(&sys_quit_and_start_process_original, &sys_quit_and_start_process); 

		utils::hook::call(0x0097CBC2, &com_gametype_settings_get_uint);
		utils::hook::call(0x007D53BA, &cg_dobj_get_world_bone_matrix);
		utils::hook::call(0x0056ED89, &bg_weapon_fire_recoil);
		utils::hook::call(0x004CF0DF, &cl_controller_index_get_username);
		utils::hook::call(0x006F0CF1, &sub_64C8A0);
		
		utils::hook::set<std::uint8_t>(0x007EB762, 0xEB); // CL_DisconnectPacket
		utils::hook::set<std::uint8_t>(0x004FCB1B + 0x1, 32); // Live_UserGetName
		utils::hook::set<float>(offsets::yaw_speed, 750.0f); // cl_yawspeed
		utils::hook::nop(0x006FE6BF, 2); // Don't check for NA_IP in Party_NetAdrToPlatformNetAdr
		utils::hook::nop(0x008C5EEA, 2); // Don't check for GetPlayerStatus in IsPlayerJoinable
		utils::hook::nop(0x007F81C1, 6); // PartyHost_AutoStart 
		utils::hook::nop(0x007EE551, 7); // Show toast popup always in UI_Refresh
		utils::hook::retn(0x006F0A00); // Fix steam crash at initialization
		
		//localized_strings::override("MENU_INVITE_TO_GAME_CAPS", "PULL PLAYER"); 
		
		input::on_key(VK_F2, [] { game::Cbuf_AddText(0, "closeallbusypopups;disconnect\n"); });
		input::on_key(VK_F3, [] { game::Cbuf_AddText(0, "quit"); });
		input::on_key(VK_F4, [] { third_person = !third_person; });
		input::on_key(VK_F5, [] { exploits::instant_message::pulling::reset_instant_messaage(); });
		input::on_key(VK_F6, [] { custom_name = "^H\x2f\x3f\x10\killiconheadshot"; });

		scheduler::once(game::initialize, scheduler::pipeline::main);
		scheduler::loop(game::cycling_prestige, scheduler::pipeline::main, 500ms);
		scheduler::loop(exploits::on_every_frame, scheduler::pipeline::main);
		
		scheduler::loop([]()
		{
			game::cg()->ps()->third_person = third_person && !game::cg()->in_killcam();
			game::set_fov(fov);

			game::party = nullptr;
			if (game::g_lobbyData->in_party() || (game::party = game::g_partyData, !game::g_partyData->in_party()))
				game::party = game::g_lobbyData;

			exploits::local_net_id = game::CL_GetLocalClientConnectionState() >= game::CA_PRIMED ? game::clc()->netchan.sock : game::NS_CLIENT1;
			ip_buffer = reinterpret_cast<std::uint8_t*>(utils::find_direct_address(0x034389B0, std::vector<std::uint32_t>({ 0xE0, 0x90, 0x38, 0x58, 0x14 })));

			if (static auto initialized = false; !initialized && ip_buffer)
			{
				initialized = true;
				
				std::memcpy(security::original_ip_address, ip_buffer, sizeof std::uint32_t);
			}

			for (auto client_num = 0u; client_num < 18u; ++client_num)
			{
				if (!game::is_valid_target(client_num))
				{
					aimbot::priority_target[client_num] = false;
					aimbot::ignore_target[client_num] = false;
				}
			}
		}, scheduler::pipeline::main);

		scheduler::loop(game::on_every_frame, scheduler::pipeline::renderer);
		scheduler::loop(game::anti_leave, scheduler::pipeline::renderer, 1s);

		scheduler::loop([]()
		{
			trace_thread_value = game::Sys_GetValue(3);
				
			if (const auto client_num = game::cg()->client_num(); game::centity(client_num)->is_alive())
			{
				if (antiaim::enabled && game::cg()->rendering_third_person())
				{
					game::centity(client_num)->angles().y = cent_angles_backup.y;
					game::cg()->client(client_num)->player_angles() = client_angles_backup;
				}
			}

			if (no_flinch)
			{
				game::cg()->v_dmg_pitch() = 0;
				game::cg()->v_dmg_roll() = 0;
			}

			if (game::cg()->match_ui_flags() & 0x1000)
			{
				game::cg()->match_ui_flags() &= ~0x1000;
			}
		
		}, scheduler::pipeline::renderer);

		scheduler::loop(game::spectator_client_handler, scheduler::pipeline::renderer, 1500ms);
	}
}