#pragma once
#include "dependencies/std_include.hpp"

namespace misc
{
	extern std::string custom_name, clan;
	extern float fov;
	extern bool no_flinch, no_recoil, third_person, cycling_prestige, anti_leave;
	extern int trace_thread_value;
	extern std::uint8_t* ip_buffer;

	void cl_ready_to_send_packet();
	void sys_get_value();
	void __cdecl cg_calc_entity_lerp_positions(LocalClientNum_t localClientNum, game::centity_t* cent);
	bool __cdecl is_client_in_our_party(LocalClientNum_t localClientNum, ClientNum_t clientNum);
	bool __cdecl live_send_invite(ControllerIndex_t controllerIndex, std::uint64_t xuid, bool a);
	void __stdcall exit_process(std::uint32_t exit_code);
	[[noreturn]] void __cdecl sys_error(const char * error, ...);
	void __cdecl cg_draw_overhead_names(LocalClientNum_t localClientNum, game::centity_t * cent, float alpha, int mode);
	void __cdecl sys_quit_and_start_process(const char * exeName);
	void initialize();
}
