#pragma once
#include "dependencies/std_include.hpp"

namespace stats
{
	void set_prestige(const std::uint32_t prestige);
	void bg_init_unlockables();
	void __cdecl g_say_stub(void * ent, void * target, int mode, const char * text);
	void initialize();
}
