#include "dependencies/std_include.hpp"
#include "stats.hpp"

namespace stats
{
	std::uint32_t hash_id = 0;

	void set_prestige(const std::uint32_t prestige)
	{
		utils::hook::set(offsets::xp, 0x130F4C);
		utils::hook::set(offsets::prestige, prestige);

		char hash[8];

		*reinterpret_cast<std::uint64_t*>(hash) =
			*reinterpret_cast<std::uintptr_t*>(offsets::xp) ^
			*reinterpret_cast<std::uintptr_t*>(offsets::prestige) ^
			game::Live_GetXuid(0);

		utils::hook::set<std::uint8_t>(0x0024A28FC, 0x18);

		game::hash_memory(game::find_hash("tiger"),
			hash,
			sizeof hash,
			reinterpret_cast<char*>(0x0024A2900),
			reinterpret_cast<std::size_t*>(0x0024A28FC));

		game::register_prng(reinterpret_cast<void*>(0x00CC8030));

		utils::hook::set(0x0024A28F8, 0x32);

		game::sign_hash(reinterpret_cast<const char*>(0x0024A2900),
			*reinterpret_cast<std::uintptr_t*>(0x24A28FC),
			reinterpret_cast<char*>(0x002FB18C0),
			reinterpret_cast<size_t*>(0x24A28F8), nullptr,
			game::find_prng(reinterpret_cast<const char*>(0xC52214)),
			*reinterpret_cast<LPVOID*>(0x00301EB88));

		utils::hook::set(0x002FB18BC, *reinterpret_cast<std::uintptr_t*>(0x0024A28F8));

		game::Cbuf_AddText(0, "uploadstats; updategamerprofile");
	}
	
	void initialize()
	{
		utils::hook::set<std::uint8_t>(0x006D88ED, 0xEB); // LiveStats_ValidateStats
		utils::hook::set<std::uint8_t>(0x006D8881, 0xEB); // LiveStats_ValidateStats
		utils::hook::nop(0x006D877C, 6); // LiveStats_ValidateStats
		
		utils::hook::return_value(0x00693970, true); // Content_DoWeHaveMTX
		utils::hook::return_value(0x0054D180, true); // BG_UnlockablesAllItemsUnlocked
		utils::hook::return_value(0x00480850, false); // BG_UnlockablesItemOptionLocked		
		utils::hook::return_value(0x006096C0, false); // BG_UnlockablesIsItemLockedFromBuffer
		utils::hook::return_value(0x0094ADE0, false); // BG_UnlockablesEmblemOrBackingLockedByChallenge
		utils::hook::return_value(0x00949690, false); // BG_UnlockablesIsItemAttachmentLockedFromBuffer
		utils::hook::return_value(0x00707A60, false); // BG_UnlockablesIsItemLocked
		utils::hook::return_value(0x00683340, false); // BG_UnlockablesIsItemNew
		utils::hook::set<std::uint64_t>(0x006414F0, 0xC3FFFFFFFFB8); // BG_UnlockablesGetPreReqChallengeStatValue
		utils::hook::set<std::uint64_t>(0x00405040, 0xC3FFFFFFFFB8); // BG_UnlockablesItemOptionChallengeStatValue

		hash_id = game::find_hash("tiger");
	}
}