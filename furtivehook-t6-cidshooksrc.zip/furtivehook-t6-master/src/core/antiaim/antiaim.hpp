#pragma once
#include "dependencies/std_include.hpp"

namespace antiaim
{
	struct aa_target_t
	{
		bool priority;
		const game::centity_t* cent;
		float damage;
		float distance;

		aa_target_t() = delete;
		aa_target_t(const bool _priority, const game::centity_t* _cent, const float _damage, const float _distance) : priority(_priority), cent(_cent), damage(_damage), distance(_distance) {}

		bool operator<(const aa_target_t& other) const
		{
			return other.damage > damage || (other.damage == damage && other.distance < distance) || (other.damage == damage && other.distance == distance);
		}
	};

	extern Vec3 cur_angles;
	extern float shield_base_pitch_shift;
	extern bool enabled;
	
	void anti_aim(const game::playerState_s * ps, game::usercmd_s * cur_cmd);
}