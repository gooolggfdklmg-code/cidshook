#include "dependencies/std_include.hpp"
#include "antiaim.hpp"

namespace antiaim
{
	Vec3 cur_angles, aa_angles, view_origin;
	float shield_base_pitch_shift = 40.0f;
	bool enabled = false;
	aa_target_t* aa_target = nullptr;
	std::vector<aa_target_t> aa_targets;

	float get_shield_pitch(const game::playerState_s* ps, const Vec3& target_angle)
	{
		const auto target_pitch = math::angle_normalize_180(target_angle.x + ps->delta_angles.x);

		auto pitch = -shield_base_pitch_shift;
		
		if (target_pitch > 0.0f) 
		{
			pitch -= std::fmin(target_pitch, 85.0f - shield_base_pitch_shift);
		}
		else if (target_pitch < -15.0f) 
		{
			pitch += std::fmin(std::abs(target_pitch), 85.0f + shield_base_pitch_shift);
		}

		return pitch;
	}

	bool can_anti_aim(const game::playerState_s* ps)
	{
		return ps->eFlags & 0x8000 || ps->eFlags & 8
			|| ps->pm_flags & 8 || game::cg()->next_snapshot()->ps.pm_type & 10
			|| ps->otherFlags & 2 || ps->otherFlags & 0x1A;
	}

	bool is_valid_target(game::centity_t* cent)
	{
		if (!cent->is_alive() || !game::is_enemy(cent->next_state().number))
			return false;

		if (cent->next_state().number == game::cg()->client_num())
			return false;

		return true;
	}

	void run(const game::playerState_s* ps, game::usercmd_s* cur_cmd)
	{
		aa_target = nullptr;
		aa_targets.clear();

		if (!enabled || can_anti_aim(ps)
			|| game::BG_UsingVehicleWeapon(ps))
			return;

		game::CG_GetPlayerViewOrigin(0, ps, &view_origin);

		for (size_t i = 0; i < 18; ++i)
		{
			if (const auto cent = game::centity(i); is_valid_target(cent))
			{
				auto damage = aimbot::target[i].damage;
				auto magnitude = std::floorf(cent->origin().distance(ps->origin));
				
				const auto num_of_priorities = std::count(aimbot::priority_target.begin(), aimbot::priority_target.end(), 1); 
				
				if (num_of_priorities > 1)
				{
					damage = 1.0f;
					magnitude = math::calculate_fov(view_origin, cent->origin());
				}

				if (aimbot::priority_target[i] && !aimbot::ignore_target[i])
				{
					aa_targets.emplace_back(aimbot::priority_target[i], cent, damage, magnitude);
				}
			}
		}

		if (!aa_targets.empty())
		{
			/*aa_target = &*std::max_element(aa_targets.begin(), aa_targets.end());
			vectoangles(&(aa_target->cent->origin() - ps->origin), &aa_angles);

			//aa_angles[0] = get_shield_pitch(ps, aa_angles);
			aa_angles[0] = math::angle_normalize_180(-40.0f - aa_angles.x - ps->delta_angles.x);
			aa_angles[1] = math::angle_normalize_180(aa_angles.y - 170.0f - ps->delta_angles.y);

			cur_cmd->angles[0] = ANGLE2SHORT(aa_angles[0]);
			cur_cmd->angles[1] = ANGLE2SHORT(aa_angles[1]);
			cur_cmd->angles[2] = ANGLE2SHORT(aa_angles[2]);*/

			aa_target = &*std::max_element(aa_targets.begin(), aa_targets.end());
			auto dir = aa_target->cent->origin() - ps->origin;

			game::vec3_normalize(&dir);
			game::vectoangles(&dir, &aa_angles);

			math::normalize_angles(&aa_angles);

			aa_angles.x = -40.0f - aa_angles.x;
			aa_angles.y = aa_angles.y - 170.0f;

			aa_angles.x -= ps->delta_angles.x;
			aa_angles.y -= ps->delta_angles.y;

			math::normalize_angles(&aa_angles);

			cur_cmd->angles[0] = ANGLE2SHORT(aa_angles.x);
			cur_cmd->angles[1] = ANGLE2SHORT(aa_angles.y);
		}
	}

	void anti_aim(const game::playerState_s* ps, game::usercmd_s* cur_cmd)
	{
		run(ps, cur_cmd);
		
		cur_angles[0] = SHORT2ANGLE(cur_cmd->angles[0]);
		cur_angles[1] = SHORT2ANGLE(cur_cmd->angles[1]);
		cur_angles[2] = SHORT2ANGLE(cur_cmd->angles[2]);
	}
}