#include "aimbot.hpp"

namespace aimbot
{
	bool enabled = false, silent = true, auto_fire = true, priority_bonescan = true, priority_riot = false, priority_friends = false, asynchronous = true, legit = true;
	std::uint32_t leg_multipoint_radius = 3;
	Vec3 aim_angles, view_origin;
	bone_target_t* bone_target = nullptr;
	aim_target_t* aim_target = nullptr;
	target_t target[18];
	std::vector<std::uint8_t> ignore_target(18, 0);
	std::vector<std::uint8_t> priority_target(18, 0);
	std::vector<aim_target_t> aim_targets;
	std::vector<bone_target_t> bone_targets;
	std::vector<std::future<float>> penetration_damage;
	std::vector<game::bone_tag> aim_bones
	{
		game::bone_tag::helmet,
		game::bone_tag::head_end,
		game::bone_tag::head,
		game::bone_tag::neck,
		game::bone_tag::shoulder_left,
		game::bone_tag::shoulder_right,
		game::bone_tag::clavicle_left,
		game::bone_tag::clavicle_right,
		game::bone_tag::spineupper,
		game::bone_tag::spine,
		game::bone_tag::spinelower,
		game::bone_tag::hip_left,
		game::bone_tag::hip_right,
		game::bone_tag::knee_left,
		game::bone_tag::knee_right,
		game::bone_tag::wrist_left,
		game::bone_tag::wrist_right,
		game::bone_tag::wrist_twist_left,
		game::bone_tag::wrist_twist_right,
		game::bone_tag::elbow_left,
		game::bone_tag::elbow_right,
		game::bone_tag::elbow_buldge_left,
		game::bone_tag::elbow_buldge_right,
		game::bone_tag::ankle_left,
		game::bone_tag::ankle_right,
		game::bone_tag::ball_left,
		game::bone_tag::ball_right,
		game::bone_tag::mainroot,
	};

	bool is_reloading(const game::playerState_s* ps)
	{
		return (static_cast<std::uint32_t>(ps->weaponstate - 0xB) < 0x8)
			|| (static_cast<std::uint32_t>(ps->weaponstateLeft - 0xB) < 0x8);
	}

	std::vector<Vec3> calculate_inner_points(const Vec3& a, const Vec3& b, const std::uint32_t c)
	{
		std::vector<Vec3> inner_points;
		inner_points.clear();

		for (size_t i = 0; i <= c; ++i)
		{
			const auto point = b + ((a - b) / static_cast<float>(c) * static_cast<float>(i));

			inner_points.emplace_back(point);
		}

		return inner_points;
	}

	std::vector<Vec3> calculate_outer_points(const game::centity_t* cent, const std::vector<Vec3> a, const float b)
	{
		std::vector<Vec3> outer_points;
		outer_points.clear();

		for (const auto& point : a)
		{
			auto front = point + Vec3(b, 0.0f, 0.0f);
			auto back = point + Vec3(-b, 0.0f, 0.0f);

			auto left = point + Vec3(0.0f, b, 0.0f);
			auto right = point + Vec3(0.0f, -b, 0.0f);

			math::rotate_point(front, point, cent->angles().y, front);
			math::rotate_point(back, point, cent->angles().y, back);

			math::rotate_point(left, point, cent->angles().y, left);
			math::rotate_point(right, point, cent->angles().y, right);

			outer_points.emplace_back(front);
			outer_points.emplace_back(back);

			outer_points.emplace_back(left);
			outer_points.emplace_back(right);
		}

		return outer_points;
	}

	std::vector<Vec3> calculate_points(const game::centity_t* cent, const Vec3 bone[static_cast<std::uint32_t>(game::bone_tag::num_tags)], const std::uint32_t divisor, const float radius)
	{
		std::vector<Vec3> points;
		points.clear();

		const auto upper_left_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::hip_left)], bone[static_cast<std::uint32_t>(game::bone_tag::knee_left)], divisor);
		const auto upper_right_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::hip_right)], bone[static_cast<std::uint32_t>(game::bone_tag::knee_right)], divisor);

		const auto lower_left_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::knee_left)], bone[static_cast<std::uint32_t>(game::bone_tag::ankle_left)], divisor);
		const auto lower_right_leg_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::knee_right)], bone[static_cast<std::uint32_t>(game::bone_tag::ankle_right)], divisor);

		const auto left_foot_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::ankle_left)], bone[static_cast<std::uint32_t>(game::bone_tag::ball_left)], divisor);
		const auto right_foot_inner = calculate_inner_points(bone[static_cast<std::uint32_t>(game::bone_tag::ankle_right)], bone[static_cast<std::uint32_t>(game::bone_tag::ball_right)], divisor);

		const auto upper_left_leg_outer = calculate_outer_points(cent, upper_left_leg_inner, radius);
		const auto upper_right_leg_outer = calculate_outer_points(cent, upper_right_leg_inner, radius);

		const auto lower_left_leg_outer = calculate_outer_points(cent, lower_left_leg_inner, radius);
		const auto lower_right_leg_outer = calculate_outer_points(cent, lower_right_leg_inner, radius);

		const auto left_foot_outer = calculate_outer_points(cent, left_foot_inner, radius);
		const auto right_foot_outer = calculate_outer_points(cent, right_foot_inner, radius);

		points.insert(points.end(), upper_left_leg_inner.begin(), upper_left_leg_inner.end());
		points.insert(points.end(), upper_right_leg_inner.begin(), upper_right_leg_inner.end());

		points.insert(points.end(), lower_left_leg_inner.begin(), lower_left_leg_inner.end());
		points.insert(points.end(), lower_right_leg_inner.begin(), lower_right_leg_inner.end());

		points.insert(points.end(), left_foot_inner.begin(), left_foot_inner.end());
		points.insert(points.end(), right_foot_inner.begin(), right_foot_inner.end());

		points.insert(points.end(), upper_left_leg_outer.begin(), upper_left_leg_outer.end());
		points.insert(points.end(), upper_right_leg_outer.begin(), upper_right_leg_outer.end());

		points.insert(points.end(), lower_left_leg_outer.begin(), lower_left_leg_outer.end());
		points.insert(points.end(), lower_right_leg_outer.begin(), lower_right_leg_outer.end());

		points.insert(points.end(), left_foot_outer.begin(), left_foot_outer.end());
		points.insert(points.end(), right_foot_outer.begin(), right_foot_outer.end());

		return points;
	}

	bool get_best_bone(const game::centity_t* cent, const Vec3& start, const std::vector<Vec3> points, Vec3* pos, float* damage)
	{
		penetration_damage.clear();
		bone_targets.clear();
		bone_target = nullptr;

		if (asynchronous)
		{
			for (size_t bone = 0; bone < points.size(); ++bone)
			{
				penetration_damage.emplace_back(std::async(&autowall::get_penetration_damage, start, points[bone], game::cg()->ps(), cent->next_state().number));
			}

			for (size_t bone = 0; bone < points.size(); ++bone)
			{
				if (const auto damage = penetration_damage[bone].get(); damage > 0.0f)
				{
					bone_targets.emplace_back(damage, points[bone]);
				}
			}
		}
		else
		{
			for (size_t bone = 0; bone < points.size(); ++bone)
			{
				if (const auto damage = autowall::get_penetration_damage(start, points[bone], game::cg()->ps(), cent->next_state().number); damage > 0.0f)
				{
					bone_targets.emplace_back(damage, points[bone]);
				}
			}
		}

		if (!bone_targets.empty())
		{
			bone_target = &*std::max_element(bone_targets.begin(), bone_targets.end());

			*damage = bone_target->damage;
			*pos = bone_target->location;

			return true;
		}

		return false;
	}

	Vec3 get_best_target_position(const aim_target_t* aim_target)
	{
		const auto priority_target = std::find_if(aim_targets.begin(), aim_targets.end(), [&](const aim_target_t& target) { return target.priority; });

		if (priority_target != aim_targets.end())
		{
			return target[priority_target->cent->next_state().number].aim_pos;
		}
		else
		{
			return target[aim_target->cent->next_state().number].aim_pos;
		}
	}

	bool is_in_center_delta(const game::centity_t* cent, const Vec2& screen_center)
	{
		const auto top_position = game::get_top_position(cent);
		const auto top = game::get_screen_pos(top_position);
		const auto bottom = game::get_screen_pos(cent->origin());
		const auto scale = game::get_scale(cent, bottom.y - top.y);

		if (!scale.empty())
		{
			const auto x = std::abs(top.x - screen_center.x);
			const auto y = std::abs(top.y + (bottom.y - top.y) * 0.5f - screen_center.y);

			return x < (scale.x * 0.5f) && y < (scale.y * 0.5f);
		}

		return false;
	}

	bool is_valid_target(const game::centity_t* cent)
	{
		if (!cent->is_alive() || cent->next_state().lerp.flags & 0x40000)
			return false;

		if (cent->next_state().number == game::cg()->ps()->clientNum || !game::is_enemy(cent->next_state().number))
			return false;

		return true;
	}

	void run(const game::playerState_s* ps)
	{
		aim_targets.clear();
		aim_target = nullptr;

		if (!enabled)
			return;

		game::CG_GetPlayerViewOrigin(0, ps, &view_origin);

		for (size_t i = 0; i < 18; ++i)
		{
			if (const auto cent = game::centity(i); is_valid_target(cent))
			{
				target[i].point_scan.clear();

				const auto priority_client = priority_target[i];

				for (size_t bone = 0; bone < game::bone_tags.size(); ++bone)
				{
					if (const auto dobj = game::Com_GetClientDObj(cent->next_state().number, 0); dobj)
					{
						game::CG_DObjGetWorldTagPos(cent, dobj, game::get_tag(aim_bones[bone]), &target[i].aim_point[bone]);
					}
				}

				if (cent->next_state().lerp.stowedweaponID == riot_shield && priority_riot
					|| (game::is_friend(i) && aimbot::priority_friends))
				{
					priority_target[i] = true;
				}

				if (legit)
				{
					for (size_t bone = static_cast<size_t>(game::bone_tag::shoulder_left); bone <= static_cast<size_t>(game::bone_tag::mainroot); ++bone)
					{
						target[i].point_scan.emplace_back(target[i].aim_point[bone]);
					}
				}
				else if (priority_bonescan && priority_client || !priority_bonescan)
				{
					for (size_t bone = 0; bone < game::bone_tags.size(); ++bone)
					{
						target[i].point_scan.emplace_back(target[i].aim_point[bone]);
					}
				}
				else
				{
					target[i].point_scan.emplace_back(target[i].aim_point[static_cast<size_t>(game::bone_tag::head_end)]);
				}
				
				if (priority_client)
				{
					target[i].points.clear();
					target[i].points = calculate_points(cent, target[i].aim_point, leg_multipoint_radius, 2.0f);

					for (const auto& points : target[i].points)
					{
						target[i].point_scan.emplace_back(points);
					}
				}
				
				target[i].vulnerable = get_best_bone(cent, view_origin, target[i].point_scan, &target[i].aim_pos, &target[i].damage);

				auto damage = target[i].damage;
				auto magnitude = cent->origin().distance(ps->origin);

				if (legit)
				{
					const auto screen_center = game::screen_placement()->realViewportSize * 0.5f;
					const auto is_in_center = is_in_center_delta(cent, screen_center);
					const auto pos = game::get_screen_pos(target[i].aim_pos);

					if(pos.empty() || !is_in_center)
						continue;

					damage = 1.0f;
					magnitude = pos.distance(screen_center);
				}

				if (target[i].vulnerable && !ignore_target[i])
				{
					aim_targets.emplace_back(priority_client, cent, damage, std::floorf(magnitude));
				}
			}
		}

		if (!aim_targets.empty())
		{
			aim_target = &*std::max_element(aim_targets.begin(), aim_targets.end());
			game::vectoangles(&(get_best_target_position(aim_target) - view_origin), &aim_angles);

			aim_angles[0] = math::angle_delta(aim_angles[0], game::cg()->refdef_view_angles()[0]);
			aim_angles[1] = math::angle_delta(aim_angles[1], game::cg()->refdef_view_angles()[1]);
			aim_angles[2] = math::angle_delta(aim_angles[2], game::cg()->refdef_view_angles()[2]);

			if (!silent)
				game::cl()->viewangles += aim_angles;
		}
	}
}