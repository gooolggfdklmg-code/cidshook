#pragma once
#include "dependencies/std_include.hpp"

namespace menu
{
	constexpr static auto window_title = "furtivehook";
	constexpr static auto color_flags = ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip;
	constexpr static auto window_flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize;
	const Vec2 color_position = { 440.5f, 458.0f };
	extern bool initialized;
	extern ImFont* glacial_indifference_bold_base_85;
	extern ImFont* glacial_indifference_base_85;

	void draw();
	bool is_open();
	void set_style();
	void toggle();
}
