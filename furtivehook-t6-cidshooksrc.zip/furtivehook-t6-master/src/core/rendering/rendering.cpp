#include "dependencies/std_include.hpp"
#include "rendering.hpp"
#include <d3d11.h>

namespace rendering
{
	auto present_original = reinterpret_cast<decltype(&present)>(0);

	HRESULT __stdcall present(IDXGISwapChain* thisptr, UINT syncInterval, UINT flags)
	{
		dx::initialize(thisptr);
		dx::on_frame(thisptr);

		return present_original(thisptr, syncInterval, flags);
	}
	
	void initialize()
	{
		const auto chain = *reinterpret_cast<IDXGISwapChain**>(0x03606FA4);

		if (!chain)
			return;

		present_original = utils::hook::vtable(chain, 8, &present);
	}
}