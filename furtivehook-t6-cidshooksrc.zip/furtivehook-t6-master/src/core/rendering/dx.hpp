#pragma once
#include "dependencies/std_include.hpp"

namespace rendering::dx
{
    void on_frame(IDXGISwapChain* chain);
    void initialize(IDXGISwapChain* chain);

    extern bool initialized;
}
