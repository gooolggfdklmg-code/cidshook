#include "dependencies/std_include.hpp"
#include "dx.hpp"
#include <d3d11.h>

namespace rendering::dx
{
	bool initialized{ false };

	namespace
	{
		ID3D11Device* device{ nullptr };
		ID3D11DeviceContext* context{ nullptr };

		bool create(IDXGISwapChain* chain)
		{
			if (!chain)
				return false;

			if (FAILED(chain->GetDevice(__uuidof(device), reinterpret_cast<void**>(&device))))
				return false;

			device->GetImmediateContext(&context);
			return true;
		}
	}

	void on_frame(IDXGISwapChain* chain)
	{
		if (dx::initialized)
		{
			ImGui::GetIO().MouseDrawCursor = menu::is_open();

			ImGui_ImplWin32_NewFrame();
			ImGui_ImplDX11_NewFrame();
			ImGui::NewFrame();

			menu::draw();

			ImGui::Render();
			ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
		}
	}

	void initialize(IDXGISwapChain* chain)
	{
		if (!dx::initialized)
		{
			dx::initialized = true;

			const auto created = dx::create(chain);
			if (!created)
				return;

			DXGI_SWAP_CHAIN_DESC sd{};
			if (FAILED(chain->GetDesc(&sd)))
				return;

			if (const auto hwnd = sd.OutputWindow; hwnd)
			{
				ImGui::CreateContext();
				ImGui_ImplWin32_Init(hwnd);
				ImGui_ImplDX11_Init(device, context);

				ImGui::GetIO().IniFilename = nullptr;

				input::initialize(hwnd);
				menu::set_style();
			}
		}
	}
}