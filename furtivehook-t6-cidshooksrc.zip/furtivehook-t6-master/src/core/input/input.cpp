#include "dependencies/std_include.hpp"
#include "input.hpp"

namespace input
{
	auto cl_key_event_original = reinterpret_cast<decltype(&cl_key_event)>(0x0047D4E0); 
	
	WNDPROC wndproc_;
	std::vector<hotkey_t> registered_keys; 

	void __cdecl cl_key_event(LocalClientNum_t localClientNum, std::uint32_t key, const std::uint32_t down, const std::uint32_t time)
	{
		if (down && menu::is_open())
		{
			return;
		}
		
		return cl_key_event_original(localClientNum, key, down, time);
	}
	
	bool should_ignore_msg(UINT msg)
	{
		switch (msg)
		{
		case WM_KEYDOWN:
		case WM_KEYUP:
		case WM_CHAR:
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_LBUTTONDBLCLK:
		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:
		case WM_RBUTTONDBLCLK:
		case WM_SETCURSOR:
		case WM_MOUSEACTIVATE:
		case WM_MBUTTONDOWN:
		case WM_MBUTTONUP:
		case WM_MBUTTONDBLCLK:
		case WM_MOUSEMOVE:
		case WM_NCHITTEST:
		case WM_MOUSEWHEEL:
		case WM_MOUSEHOVER:
		case WM_ACTIVATEAPP:
			return true;

		default:
			return false;
		}
	}

	bool is_key_down(UINT key, UINT msg, WPARAM wparam)
	{
		return msg == WM_KEYDOWN && wparam == key;
	}

	bool was_key_pressed(UINT key, UINT msg, WPARAM wparam, LPARAM lparam)
	{
		return is_key_down(key, msg, wparam) && !(lparam >> 0x1E);
	}

	long __stdcall wndproc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
	{
		auto should_ignore = menu::is_open() && !ImGui_ImplWin32_WndProcHandler(hwnd, msg, wparam, lparam);

		if (msg == WM_CLOSE)
		{
			utils::close_console();
		}

		for (const auto& hotkey : registered_keys)
		{
			if (is_key_down(hotkey.key, msg, wparam) && hotkey.block)
			{
				should_ignore = true;
			}

			if (was_key_pressed(hotkey.key, msg, wparam, lparam))
			{
				hotkey.func();

				if (hotkey.block)
				{
					should_ignore = true;
				}
			}
		}

		if (should_ignore && should_ignore_msg(msg))
		{
			return true;
		}

		return CallWindowProcA(wndproc_, hwnd, msg, wparam, lparam);
	}

	void on_key(UINT key, void(*cb)(), bool block)
	{
		registered_keys.emplace_back(hotkey_t{ key, cb, block });
	}

	void initialize(HWND hwnd)
	{
		//utils::hook::detour(&cl_key_event_original, &cl_key_event); 
		
		wndproc_ = WNDPROC(SetWindowLongPtr(hwnd, GWLP_WNDPROC, LONG_PTR(wndproc)));

		input::on_key(VK_F1, menu::toggle, true);
	}
}