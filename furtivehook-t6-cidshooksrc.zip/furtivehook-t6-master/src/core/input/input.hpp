#pragma once
#include "dependencies/std_include.hpp"

IMGUI_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

struct hotkey_t
{
	UINT key;
	void(*func)();
	bool block;
};

namespace input
{
	void initialize(HWND hwnd);
	void __cdecl cl_key_event(LocalClientNum_t localClientNum, std::uint32_t key, const std::uint32_t down, const std::uint32_t time);
	void on_key(UINT key, void(*cb)(), bool block = false);
}