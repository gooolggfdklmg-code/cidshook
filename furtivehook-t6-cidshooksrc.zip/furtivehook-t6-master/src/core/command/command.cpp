#include "dependencies/std_include.hpp"
#include "command.hpp"

namespace command
{
	std::unordered_map<std::string, std::function<void(params_&)>> handlers;
	std::unordered_map<std::string, std::function<bool(const size_t, params_sv_&)>> handlers_sv;
	params_ params;
	params_sv_ params_sv;

	void __cdecl sv_execute_client_command(game::client_t *cl, const char *s, bool clientOK, bool fromOldServer)
	{
		params_sv_ params{}; 
		game::ucmd_t* u = nullptr;
		
		game::SV_Cmd_EndTokenizedString();
		game::SV_Cmd_TokenizeString(s);
		
		for (u = game::ucmds; u->name; ++u)
		{
			if (!std::strcmp(params[0], u->name))
			{
				if (!fromOldServer || u->allowFromOldServer)
				{
					if (!handle_sv(params, game::Party_FindMemberByXUID(cl->xuid)))
					{
						u->func(cl);
					}
				}

				break;
			}
		}

		if (clientOK && !u->name && game::SV_Loaded())
		{
			if (const auto client_num = game::Party_FindMemberByXUID(cl->xuid); !handle_sv(params, client_num))
			{
				game::ClientCommand(client_num);
			}
		}
	}
	
	const char* params_::get(const size_t index) const
	{
		return game::Cmd_Argv(index);
	}

	size_t params_::size() const
	{
		return game::Cmd_Argc();
	}

	std::string params_::join(const size_t index) const
	{
		auto result = ""s;

		for (auto i = index; i < this->size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(this->get(i));
		}

		return result;
	}

	const char* params_sv_::get(const size_t index) const
	{
		return game::SV_Cmd_Argv(index);
	}

	size_t params_sv_::size() const
	{
		return game::SV_Cmd_Argc();
	}

	std::string params_sv_::join(const size_t index) const
	{
		auto result = ""s;

		for (auto i = index; i < this->size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(this->get(i));
		}

		return result;
	}

	void on_sv(std::string command, const std::function<bool(size_t, const params_sv_&)>& callback)
	{
		if (handlers_sv.find(command) == handlers_sv.end())
		{
			handlers_sv[utils::string::to_lower(command)] = callback;
		}
	}

	bool can_handle_sv(std::unordered_map<std::string, std::function<bool(const size_t, params_sv_&)>> callbacks, std::string command)
	{
		return callbacks.find(command) != callbacks.end() && callbacks[command];
	}

	bool handle_sv(params_sv_& params, const size_t client_num)
	{
		for (size_t i = 0; i < params.size(); ++i)
		{
			const auto command = utils::string::to_lower(params[i]);

			if (can_handle_sv(handlers_sv, command))
			{
				return client_num >= 0 && handlers_sv[command](client_num, params);
			}
		}

		return false;
	}

	void main_handler()
	{
		params_ params{};
		const auto command = utils::string::to_lower(params[0]);

		if (handlers.find(command) != handlers.end())
		{
			handlers[command](params);
		}
	}

	void add_raw(const char* name, void(*callback)())
	{
		game::Cmd_AddCommandInternal(name, callback, utils::memory::get_allocator()->allocate<game::cmd_function_s>());
	}

	void add(const char* name, std::function<void(const params_&)> callback)
	{
		const auto command = utils::string::to_lower(name);

		if (handlers.find(command) == handlers.end())
		{
			add_raw(name, main_handler);
		}

		handlers[command] = callback;
	}

	void add(const char* name, const std::function<void()>& callback)
	{
		add(name, [callback](const params_&)
		{
			callback();
		});
	}

	void enum_assets(const game::XAssetType type, const std::function<void(game::XAssetHeader)>& callback, const bool includeOverride)
	{
		game::DB_EnumXAssets_Internal(type, static_cast<void(*)(game::XAssetHeader, void*)>([](game::XAssetHeader header, void* data)
		{
			const auto& cb = *static_cast<const std::function<void(game::XAssetHeader)>*>(data);
			cb(header);
		}), &callback, includeOverride);
	}
	
	void initialize()
	{
		utils::hook::call(0x00892B80, &sv_execute_client_command);

		add("list_asset", [](const auto& args)
		{
			if (args.size() > 0)
			{
				const auto type = utils::atoi<game::XAssetType>(args[1]);

				if (type >= game::ASSET_TYPE_PHYSPRESET && type < game::ASSET_TYPE_COUNT)
				{
					PRINT_LOG("Listing assets in [%s] pool", game::g_assetNames[type]);

					enum_assets(type, [&](const auto& header)
					{
						const auto asset = game::XAsset{ type, header };
						const auto asset_name = game::DB_GetXAssetName(&asset);

						PRINT_LOG("%s", asset_name);
					}, true);
				}
			}
		}); 
		
		add("crash", []()
		{
			*reinterpret_cast<int*>(1) = 0;
		});
		
		add("god", [&](const params_& params)
		{
			if (!game::SV_Loaded())
			{
				return;
			}
			
			for (auto i = 0; i < 18; ++i)
			{
				game::gclient(i)->ps.otherFlags ^= 1;
			}

			game::CG_GameMessage(0, utils::string::va("God: %s", game::gclient(0)->ps.otherFlags & 1 ? "^2On" : "^1Off"));
		});

		add("yawspeed", [&](const params_& params)
		{
			if (params.size() < 2)
			{
				return;
			}
			
			utils::hook::set<float>(offsets::yaw_speed, std::strtof(params[1], nullptr));
		});
	}
}