#pragma once

namespace command
{
	class params_ final
	{
	public:
		const char* get(const size_t index) const;
		size_t size() const;
		std::string join(const size_t index) const;
		
		const char* operator[](const size_t index) const
		{
			return this->get(index);
		}

	}extern params;

	class params_sv_ final
	{
	public:
		const char* get(const size_t index) const;
		size_t size() const;
		std::string join(const size_t index) const;

		const char* operator[](const size_t index) const
		{
			return this->get(index);
		}
		
	}extern params_sv;

	bool handle_sv(params_sv_ & params, const size_t client_num);
	void on_sv(std::string command, const std::function<bool(const size_t, const params_sv_&)>& callback);
	
	void initialize();
}
