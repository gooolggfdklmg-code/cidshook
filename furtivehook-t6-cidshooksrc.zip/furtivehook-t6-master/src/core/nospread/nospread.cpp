#include "dependencies/std_include.hpp"
#include "nospread.hpp"

namespace nospread
{
	auto cg_simulate_bullet_fire_internal_original = reinterpret_cast<decltype(&cg_simulate_bullet_fire_internal)>(0x007E3BA0); 
	bool enabled = true, bullet_fix = true;

	void callback_cg_simulate_bullet_fire_internal(game::BulletFireParams* bp, game::centity_t* attacker)
	{
		if (const auto client_num = game::cg()->client_num(); bp->ignoreEntIndex == client_num)
		{
			auto angles = game::cg()->refdef_view_angles();
			
			if (aimbot::aim_target && aimbot::silent)
			{
				angles += aimbot::aim_angles;
			}

			Vec3 view_axis[3];
			game::AngleVectors(&angles, &view_axis[0], &view_axis[1], &view_axis[2]);

			const auto weapon = game::BG_GetViewmodelWeaponIndex(game::cg()->ps());
			const auto weapon_damage_range = game::get_weapon_damage_range(weapon);
			const auto aim_spread_amount = get_aim_spread_amount(weapon, true);
			auto spread_angles = get_compensation_angles(game::cg()->ps()->commandTime,
				weapon); 

			const auto aim_offset = std::tanf(DEG2RAD(aim_spread_amount)) * weapon_damage_range;
			spread_angles *= aim_offset;

			bp->end = bp->start + (view_axis[0] * weapon_damage_range) + (view_axis[1] * spread_angles[1]) + (view_axis[2] * spread_angles[0]);
			bp->dir = (bp->end - bp->start).normalized();
		}
	}

	__declspec(naked) void cg_simulate_bullet_fire_internal()
	{
		static game::BulletFireParams* bp_;
		static game::centity_t* attacker;

		__asm
		{
			push eax;
			mov eax, [esp + 0x8];
			mov bp_, eax;
			mov eax, [esp + 0x10];
			mov attacker, eax;
			pop eax;

			pushad;

			push attacker;
			push bp_;
			call callback_cg_simulate_bullet_fire_internal;
			add esp, 8;

			popad;

			jmp cg_simulate_bullet_fire_internal_original;
		}
	}

	void first_bullet_fix()
	{
		if (!bullet_fix)
			return;

		if (game::cg()->shock_sensitivity() != 0.0)
		{
			game::cg()->zoom_sensitivity() *= game::cg()->shock_sensitivity();
		}

		game::CL_SetFovSensitivityScale(0, game::cg()->zoom_sensitivity());

		Vec3 angles{};

		if (game::BG_WeaponHasPerk(game::BG_GetViewmodelWeaponIndex(game::cg()->ps()), 7)
			&& game::BG_UsingSniperScope(game::cg()->ps()) && game::cg()->ps()->fWeaponPosFrac == 1.0f)
		{
			angles = game::cg()->offset_angles() + game::cg()->kick_angles() * 0.25f;
		}
		else
		{
			angles = game::cg()->offset_angles() + game::cg()->kick_angles();
		}

		game::CL_SetUserCmdAimValues(0, &angles);
		game::CL_SetUserCmdWeapons(0, game::cg()->weapon_select(), game::cg()->equipped_offhand(), game::CG_GetLastWeaponForAlt(game::cg(), game::cg()->ps(), game::cg()->weapon_select()));
		game::CL_SetExtraButtons(0, game::cg()->extraButton_bits);
		
		game::cg()->extraButton_bits[0] = 0;
		game::cg()->extraButton_bits[1] = 0;
		
		game::cg()->refdef()->splitscreen_blur_edges() = 0;
		game::cg()->refdef()->player_teleported() = game::cg()->player_teleported();
	}

	float get_aim_spread_amount(const Weapon& weapon, const bool use_aim_offset)
	{
		if (use_aim_offset && enabled)
			return 0.0f;
		
		float min_spread, max_spread;
		game::BG_GetSpreadForWeapon(game::cg()->ps(), weapon, &min_spread, &max_spread);

		if (game::cg()->ps()->fWeaponPosFrac == 1.0f)
		{
			min_spread = game::BG_GetWeaponDef(weapon)->fAdsSpread;
		}

		const auto aim_spread_scale = game::cg()->aim_spread_scale() / 255.0f;
		return (max_spread - min_spread) * aim_spread_scale + min_spread;
	}

	Vec3 get_compensation_angles(std::uint32_t rand_seed, const Weapon& weapon)
	{
		first_bullet_fix();
	
		game::BG_seedRandWithGameTime(&rand_seed);
		const auto aim_spread_amount = enabled 
			? get_aim_spread_amount(weapon) 
			: 1.0f;
		
		auto theta = game::BG_random(&rand_seed) * 360.0f;
		game::BG_srand(&rand_seed);
		const auto r = game::BG_random(&rand_seed);
		theta = DEG2RAD(theta);

		return 
		{ 
			std::sinf(theta) * r * aim_spread_amount,
			std::cosf(theta) * r * aim_spread_amount,
			0.0f,
		};
	}

	void initialize()
	{
		utils::hook::detour(&cg_simulate_bullet_fire_internal_original, &cg_simulate_bullet_fire_internal);
	}
}

