#include "dependencies/std_include.hpp"
#include "network.hpp"

namespace network
{
	auto cl_dispatch_connectionless_packet_original = reinterpret_cast<decltype(&cl_dispatch_connectionless_packet)>(0x007EBFF4);
	std::unordered_map<std::string, callback> callbacks;
	bool log_packets = false;

	void on_command(const std::string& command, const callback& callback)
	{
		if (callbacks.find(command) == callbacks.end())
		{
			callbacks[utils::string::to_lower(command)] = callback;
		}
	}

	bool can_handle_command(const char* command, const bool sv_command = false)
	{
		return callbacks.find(command) != callbacks.end() && callbacks[command];
	}

	bool handle_command(const std::string& command, const game::PartyData_s* party, const game::netadr_t* from, game::msg_t& msg)
	{
		auto cmd_string = utils::string::to_lower(command);

		for (const auto& party_ids : game::get_party_ids())
		{
			const auto party_id = std::to_string(party_ids);
			const auto pos = cmd_string.find_first_of(party_id);

			if (pos != std::string::npos)
			{
				cmd_string = cmd_string.substr(1);
			}
		}

		if (can_handle_command(cmd_string.data()))
		{
			const command::params_ params = {};

			if (params.size() >= 1)
			{
				return callbacks[cmd_string](params, *from, msg);;
			}
		}

		return false;
	}

	void log_dispatch_connectionless_packet_commands(game::netadr_t* from)
	{
		if (!log_packets)
		{
			logger::print_log("%s", game::get_oob_command(*from).data());
			return;
		}

		PRINT_LOG("%s", game::get_oob_command(*from).data());
	}

	bool callback_cl_dispatch_connectionless_packet(const char* command, game::netadr_t* from, game::msg_t* msg)
	{
		if (handle_command(command, game::party, from, *msg))
		{
			return true;
		}

		log_dispatch_connectionless_packet_commands(from);

		return false;
	}

	__declspec(naked) void cl_dispatch_connectionless_packet()
	{
		static char const* command;
		static game::netadr_t* from;
		static game::msg_t* msg;

		__asm
		{
			mov command, ebp;
			mov msg, edi;

			push eax;
			lea eax, [esp + 0x858 + 0x8];
			mov from, eax;
			pop eax;

			pushad;

			push msg;
			push from;
			push command;
			call callback_cl_dispatch_connectionless_packet;
			add esp, 12;

			test al, al;
			jnz fix;

			popad;

			jmp cl_dispatch_connectionless_packet_original;

		fix:
			popad;
			push 0x007ECBD2;
			retn;
		}
	}

	void initialize()
	{
		utils::hook::detour(&cl_dispatch_connectionless_packet_original, &cl_dispatch_connectionless_packet);
	}
}