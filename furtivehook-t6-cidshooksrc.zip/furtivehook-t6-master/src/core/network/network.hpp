#pragma once
#include "dependencies/std_include.hpp"

namespace network
{
	using callback = std::function<bool(const command::params_&, const game::netadr_t&, game::msg_t&)>;

	void on_command(const std::string& command, const callback& callback);
	bool handle_command(const std::string & command, const game::PartyData_s * party, const game::netadr_t * from, game::msg_t& msg);
	void cl_dispatch_connectionless_packet();
	void initialize();

	extern bool log_packets, log_sv_oob_commands;
}