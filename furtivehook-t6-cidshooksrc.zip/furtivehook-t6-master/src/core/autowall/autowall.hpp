#pragma once
#include "dependencies/std_include.hpp"

namespace autowall
{
	float __cdecl bg_get_surface_penetration_depth(game::PenetrateType penetrateType, int surfaceType);
	float get_penetration_damage(const Vec3& start, const Vec3& target, const game::playerState_s* ps, const int trace_entity_num);
	void initialize();

	extern bool enabled;
}
