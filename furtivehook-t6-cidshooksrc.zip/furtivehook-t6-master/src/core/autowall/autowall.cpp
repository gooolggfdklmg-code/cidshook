#include "autowall.hpp"

namespace autowall
{
	bool enabled = true;
	auto bg_get_surface_penetration_depth_original = reinterpret_cast<decltype(&bg_get_surface_penetration_depth)>(0x00572480);
	
	float __cdecl bg_get_surface_penetration_depth(game::PenetrateType penetrateType, int surfaceType)
	{
		if (game::perk_bullet_penetration_multiplier->current.value == 2.0f || !game::SV_Loaded())
		{
			return bg_get_surface_penetration_depth_original(penetrateType, surfaceType);
		}

		return FLT_MAX;
	}
	
	bool CG_BulletTrace(game::BulletTraceResults* br_, game::BulletFireParams* bp_, game::centity_t* attacker, int lastSurfaceType)
	{
		static constexpr auto address = 0x007E0170;
		auto result = false;
		
		__asm 
		{
			push 0;
			push lastSurfaceType;
			push attacker;
			push bp_;
			push 0;
			mov esi, br_;
			call address;
			add esp, 20;
			mov	result, al;
		}
		
		return result;
	}

	bool can_hit_entity(const game::playerState_s* ps, const Weapon weapon)
	{
		return !aimbot::is_reloading(ps)
			&& game::PM_WeaponAmmoAvailable(ps)
			&& game::BG_GetWeaponDef(weapon)->weapType == game::WEAPTYPE_BULLET;
	}

	bool trace_hit(const game::trace_t& bt, const game::playerState_s* ps)
	{
		if (const auto victim = game::Trace_GetEntityHitId(&bt); victim <= 17)
		{
			return aimbot::ignore_target[victim]
				|| (game::cg()->match_ui_flags() & 0x200
				&& game::cg()->client(victim)->team() == game::cg()->client(ps->clientNum)->team());
		}

		return false;
	}

	bool hit_bad_entity(const game::BulletTraceResults& br, const game::playerState_s* ps)
	{
		return !br.ignoreHitEnt
			&& (br.trace.partgroup == 20
				|| game::CG_EntityIsDeployedRiotshield(game::centity(game::Trace_GetEntityHitId(&br.trace)))
				|| trace_hit(br.trace, ps));
	}

	float get_bullet_damage(const Weapon weapon, const game::BulletTraceResults& br, const game::BulletFireParams& bt)
	{
		const auto multiplier = game::G_GetWeaponHitLocationMultiplier(br.trace.partgroup, weapon);
		const auto range_damage = static_cast<float>(game::BG_GetWeaponDamageForRange(weapon, &bt.origStart, &br.hitPos));
		return std::fmax(multiplier * range_damage, 1.0f) * bt.damageMultiplier;
	}

	float autowall::get_penetration_damage(const Vec3& start, const Vec3& target, const game::playerState_s* ps, const int trace_entity_num)
	{
		const auto weapon = game::BG_GetViewmodelWeaponIndex(ps);

		if (!can_hit_entity(ps, weapon))
			return 0.0f;

		if (target.distance(start) >= game::get_weapon_damage_range(weapon))
			return 0.0f;

		game::BulletFireParams bp;
		bp.weaponEntIndex = 1022;
		bp.ignoreEntIndex = ps->clientNum;
		bp.damageMultiplier = 1.0f;
		bp.origStart = start;
		bp.start = start;
		bp.end = target;
		bp.dir = (target - start).normalized();

		game::BulletTraceResults br{};

		const auto attacker = game::centity(ps->clientNum);

		if (!CG_BulletTrace(&br, &bp, attacker, 0))
			return 0.0f;

		if (br.trace.startsolid)
			return 0.0f;

		if (hit_bad_entity(br, ps))
			return 0.0f;

		if (trace_entity_num == game::Trace_GetEntityHitId(&br.trace))
			return get_bullet_damage(weapon, br, bp);

		const auto penetrate_type = game::BG_GetPenetrateType(weapon);

		if (penetrate_type == game::PenetrateType::PENETRATE_TYPE_NONE || game::BG_GetWeaponDef(weapon)->bBulletImpactExplode || !enabled)
			return 0.0f;

		const auto perk_bulletPenetrationMultiplier = game::perk_bullet_penetration_multiplier->current.value;
		const auto has_fmj = game::CG_ClientHasPerk(0, ps->clientNum, 6u);

		for (size_t i = 0; i != game::sv_penetration_count->current.integer; ++i)
		{
			auto max_depth = game::BG_GetSurfacePenetrationDepth(penetrate_type, br.depthSurfaceType);

			if (has_fmj)
				max_depth *= perk_bulletPenetrationMultiplier;

			if (max_depth <= 0.0f)
				return 0.0f;

			if (hit_bad_entity(br, ps))
				return 0.0f;

			const auto lastHitPos = br.hitPos;

			if (!game::BG_AdvanceTrace(&bp, &br, 0.135f))
				return 0.0f;

			const auto traceHitB = CG_BulletTrace(&br, &bp, attacker, br.depthSurfaceType);

			if (hit_bad_entity(br, ps))
				return 0.0f; 
			
			game::BulletFireParams revBp;
			revBp.weaponEntIndex = bp.weaponEntIndex;
			revBp.ignoreEntIndex = bp.ignoreEntIndex;
			revBp.damageMultiplier = bp.damageMultiplier;
			revBp.origStart = bp.origStart;
			revBp.dir = -bp.dir;
			revBp.start = bp.end;
			revBp.end = lastHitPos + revBp.dir * 0.01f;

			auto revBr = br;
			revBr.trace.normal = -revBr.trace.normal;

			if (traceHitB)
				game::BG_AdvanceTrace(&revBp, &revBr, 0.01f);

			const auto revTraceHit = CG_BulletTrace(&revBr, &revBp, attacker, revBr.depthSurfaceType);
			const auto allSolid = revTraceHit && revBr.trace.allsolid || br.trace.startsolid && revBr.trace.startsolid;

			if (revTraceHit || allSolid)
			{
				if (revTraceHit)
				{
					auto new_depth = game::BG_GetSurfacePenetrationDepth(penetrate_type, revBr.depthSurfaceType);

					if (has_fmj)
						new_depth *= perk_bulletPenetrationMultiplier;

					max_depth = std::fmin(max_depth, new_depth);

					if (max_depth <= 0.0f)
						return 0.0f;
				}
				
				const auto depth = std::fmax(1.0f, allSolid ? revBp.end.distance(revBp.start) : lastHitPos.distance(revBr.hitPos));

				bp.damageMultiplier -= depth / max_depth;

				if (bp.damageMultiplier <= 0.0f)
					return 0.0f;

				if (!allSolid)
				{
					if (!hit_bad_entity(br, ps) && game::Trace_GetEntityHitId(&br.trace) == trace_entity_num)
						return get_bullet_damage(weapon, br, bp);
				}
			}
			
			if (!traceHitB)
			{
				if (hit_bad_entity(br, ps))
					return 0.0f;
				
				return get_bullet_damage(weapon, br, bp);
			}
		}

		if (!hit_bad_entity(br, ps) && game::Trace_GetEntityHitId(&br.trace) == trace_entity_num)
			return get_bullet_damage(weapon, br, bp);

		return 0.0f;
	}

	void autowall::initialize()
	{
		utils::hook::detour(&bg_get_surface_penetration_depth_original, &bg_get_surface_penetration_depth);
	}
}