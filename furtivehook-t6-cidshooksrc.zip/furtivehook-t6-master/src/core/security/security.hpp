#pragma once
#include "dependencies/std_include.hpp"

namespace security
{
	void __cdecl party_read_member_field(game::PartyMember* partyMember, game::msg_t* msg, game::PartyField* field);
	bool __cdecl party_is_in_temp_banned_xuid_list(const std::uint64_t xuid);
	void netchan_process();
	void r_get_texture_from_code();
	void r_read_char_from_string();
	bool __cdecl sys_send_packet(game::netsrc_t sock, size_t length, const char * data, game::netadr_t to);
	game::XNADDR* __cdecl xenon_get_xnaddr(bool renew);
	game::WeaponDef * __cdecl bg_get_weapon_def(game::WeaponData weapon);
	char * __cdecl cl_get_config_string(std::uint32_t configStringIndex);
	void cl_console_print_add_line();
	void draw_text_2d();
	void seh_localize_text_message();
	void field_char_event();
	bool __cdecl expression_parse(const char** text, void* statement, void* compileBuffer, int compileBufferSize);
	void initialize();
	
	extern std::uint8_t original_ip_address[4];
	extern std::string ip_address_string;
	extern bool spoof_ip_address, see_spoofed_friend_names;
}
