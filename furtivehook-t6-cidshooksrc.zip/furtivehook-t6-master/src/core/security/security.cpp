#include "dependencies/std_include.hpp"
#include "security.hpp"

namespace security
{
	auto r_read_char_from_string_original = reinterpret_cast<decltype(&r_read_char_from_string)>(0x00687452);
	auto party_read_member_field_original = reinterpret_cast<decltype(&party_read_member_field)>(0x0056E310);
	auto xenon_get_xnaddr_original = reinterpret_cast<decltype(&xenon_get_xnaddr)>(0x00628E30);
	auto cl_get_config_string_original = reinterpret_cast<decltype(&cl_get_config_string)>(0x0063C1D0);
	auto bg_get_weapon_def_original = reinterpret_cast<decltype(&bg_get_weapon_def)>(0x005846F0);
	auto cl_console_print_add_line_original = reinterpret_cast<decltype(&cl_console_print_add_line)>(0x007E94C6);
	auto netchan_process_original = reinterpret_cast<decltype(&netchan_process)>(0x005828C7);
	auto draw_text_2d_original = reinterpret_cast<decltype(&draw_text_2d)>(0x00746A11);
	auto r_get_texture_from_code_original = reinterpret_cast<decltype(&r_get_texture_from_code)>(0x0077D1C4);
	auto party_is_in_temp_banned_xuid_list_original = reinterpret_cast<decltype(&party_is_in_temp_banned_xuid_list)>(0x0044DFC0);
	auto sys_send_packet_original = reinterpret_cast<decltype(&sys_send_packet)>(0x004A7D40);
	auto seh_localize_text_message_original = reinterpret_cast<decltype(&seh_localize_text_message)>(0x0047A353);
	auto field_char_event_original = reinterpret_cast<decltype(&field_char_event)>(0x007EAD69);

	std::uint8_t original_ip_address[4];
	std::string ip_address_string = "8.8.8.8";
	bool spoof_ip_address = false, see_spoofed_friend_names = true;

	bool __cdecl sys_send_packet(game::netsrc_t sock, size_t length, const char *data, game::netadr_t to)
	{
		for (auto client_num = 0u; client_num < 18u; ++client_num)
		{
			if (!game::can_send_out_of_band_packet_to_friend(client_num, to))
			{
				return false;
			}
		}

		return sys_send_packet_original(sock, length, data, to);
	}

	game::XNADDR* __cdecl xenon_get_xnaddr(bool renew)
	{
		if (spoof_ip_address)
		{
			game::set_ip_address(misc::ip_buffer, utils::string::split(ip_address_string, '.'));
		}
		else if (std::memcmp(misc::ip_buffer, original_ip_address, sizeof std::uint32_t))
		{
			std::memcpy(misc::ip_buffer, security::original_ip_address, sizeof std::uint32_t);
		}

		return reinterpret_cast<decltype(&xenon_get_xnaddr)>(0x00628E30)(renew);
	}

	game::WeaponDef* __cdecl bg_get_weapon_def(game::WeaponData weapon)
	{
		if (weapon.__s0.weaponIdx > game::bg_lastParsedWeaponIndex)
		{
			PRINT_LOG("weapon.weaponID > bg_lastParsedWeaponIndex: [%u] [0x%08X]", weapon.__s0.weaponIdx, _ReturnAddress());
			PRINT_BOLD_MESSAGE("weapon.weaponID > bg_lastParsedWeaponIndex");

			return bg_get_weapon_def_original(game::WeaponData{});
		}

		return bg_get_weapon_def_original(weapon);
	}

	char* __cdecl cl_get_config_string(std::uint32_t configStringIndex)
	{
		if (configStringIndex >= 2806)
		{
			PRINT_LOG("(configStringIndex) < (MAX_CONFIGSTRINGS) [%u] [0x%08X]", configStringIndex, _ReturnAddress());
			PRINT_BOLD_MESSAGE("(configStringIndex) < (MAX_CONFIGSTRINGS)");
			return "";
		}

		return cl_get_config_string_original(configStringIndex);
	}

	void __cdecl party_read_member_field(game::PartyMember* partyMember, game::msg_t* msg, game::PartyField* field)
	{
		if ((field->offset + field->size) >= sizeof game::PartyMember)
		{
			DEBUG_LOG("Exploit attempt caught!");
			PRINT_BOLD_MESSAGE("Exploit attempt caught!");

			return;
		}

		for (const auto& friends : friends::friends)
		{
			if (partyMember->player == friends.xuid
				&& partyMember->gamertag != friends.name
				&& see_spoofed_friend_names)
			{
				utils::hook::write_string(partyMember->gamertag, friends.name);
			}
		}

		party_read_member_field_original(partyMember, msg, field);
	}

	bool __cdecl party_is_in_temp_banned_xuid_list(const std::uint64_t xuid)
	{
		if (game::is_party_privacy_closed() || exploits::instant_message::block_join_requests)
			return true;

		return party_is_in_temp_banned_xuid_list_original(xuid);
	}

	void callback_cl_console_print_add_line(char* string)
	{
		PRINT_LOG("Invalid material pointer caught! [%s] [%u]", string, string[3] & 0xFF);
		utils::hook::write_string(string, "Invalid material pointer caught!");
	}

	__declspec(naked) void cl_console_print_add_line()
	{
		__asm
		{
			cmp byte ptr[edi + 3], 127;
			ja fix;

			jmp cl_console_print_add_line_original;

		fix:
			pushad;
			push edi;
			call callback_cl_console_print_add_line;
			pop edi;
			popad;

			push 0x007E9509;
			retn;
		}
	}

	__declspec(naked) void draw_text_2d()
	{
		__asm
		{
			pushad;

			push edi;
			call game::is_invalid_material_pointer;
			add esp, 4;

			test al, al;
			jnz fix;

			popad;

			jmp draw_text_2d_original;

		fix:
			popad;

			push 0x007475DA;
			retn;
		}
	}

	__declspec(naked) void r_read_char_from_string()
	{
		__asm
		{
			pushad;

			push eax;
			call game::is_invalid_material_pointer;
			add esp, 4;

			test al, al;
			jnz fix;

			popad;

			jmp r_read_char_from_string_original;

		fix:
			popad;

			push 0x006874C5;
			retn;
		}
	}

	bool callback_netchan_process(game::netchan_t* chan, game::msg_t* msg)
	{
		const auto msg_backup = *msg;

		const auto fragment_index = game::MSG_ReadByte(msg);
		const auto fragment_max_index = game::MSG_ReadByte(msg);
		const auto fragment_size = game::MSG_ReadShort(msg);
		const auto fragment_length = game::MSG_ReadShort(msg);

		DEBUG_LOG("index: %i size: %i length: %i writing at: 0x%x", 
			fragment_index, 
			static_cast<short>(fragment_size), 
			fragment_length,
			&chan->fragmentBuffer[fragment_index * static_cast<short>(fragment_size)]);

		if (!can_process_fragment(chan, msg, fragment_index, fragment_size, fragment_length))
		{
			if (const auto client_num = find_target_from_addr(chan->remoteAddress); client_num >= 0)
			{
				const auto pm = game::party->party_member(client_num);

				game::open_toast_popup(
					utils::string::va("Exploit attempt caught!\nFrom: '%s' (%llu) (%s)",
						pm->gamertag,
						pm->player,
						utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data()));

				PRINT_LOG("Exploit attempt caught! [netchan] from '%s' (%llu) (%s) caught!",
					pm->gamertag,
					pm->player,
					utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data());
			}
			else
			{
				PRINT_LOG("Exploit attempt caught! [netchan]");
			}

			PRINT_BOLD_MESSAGE("Exploit attempt caught!");

			return true;
		}

		*msg = msg_backup;

		return false;
	}

	__declspec(naked) void netchan_process()
	{
		static game::netchan_t* chan;
		static game::msg_t* msg;

		__asm
		{
			mov chan, esi;
			mov msg, edi;

			pushad;

			push msg;
			push chan;
			call callback_netchan_process;
			add esp, 8;

			test al, al;
			jnz fix;

			popad;

			jmp netchan_process_original;

		fix:
			popad;

			push 0x0058283C;
			retn;
		}
	}

	__declspec(naked) void r_get_texture_from_code()
	{
		__asm
		{
			test edi, edi;
			jz fix;

			jmp r_get_texture_from_code_original;

		fix:
			push 0x0077D286;
			retn;
		}
	}

	bool __cdecl callback_seh_localize_text_message(const char* string, size_t token_length)
	{
		if (token_length >= 0x400)
		{
			PRINT_BOLD_MESSAGE("Exploit attempt caught!");
			DEBUG_LOG("Exploit attempt caught! %s [%u]", string, token_length);
			return true;
		}

		return false;
	}

	__declspec(naked) void seh_localize_text_message()
	{
		__asm
		{
			pushad;
			lea eax, [edi + edx];
			push eax;
			push esi;
			call callback_seh_localize_text_message;
			add esp, 8;
			test al, al;
			popad;

			jz fix;

			pop edi;
			pop esi;
			pop ebp;
			pop ebx;
			add esp, 0x824;
			mov eax, [esp + 4];
			retn;
		fix:
			jmp seh_localize_text_message_original;
		}
	}

	void __declspec(naked) field_char_event()
	{
		__asm
		{
			cmp dword ptr[esp + 0x18], 0x007EA9F8;
			jz fix;
			jmp field_char_event_original;
		fix:
			push 0x007EAD81;
			retn;
		}
	}

	
	auto expression_parse_original = reinterpret_cast<decltype(&expression_parse)>(0x006A84C0);
	bool __cdecl expression_parse(const char** text, void* statement, void* compileBuffer, int compileBufferSize)
	{
		DEBUG_LOG("Text: %s\n", *text);
		return false;
	}
	
	void initialize()
	{
		return;
		security::iat::initialize();
		
		utils::hook::detour(&bg_get_weapon_def_original, &bg_get_weapon_def);
		utils::hook::detour(&cl_get_config_string_original, &cl_get_config_string);
		utils::hook::detour(&netchan_process_original, &netchan_process);
		utils::hook::detour(&party_read_member_field_original, &party_read_member_field);
		utils::hook::detour(&party_is_in_temp_banned_xuid_list_original, &party_is_in_temp_banned_xuid_list);
		utils::hook::detour(&cl_console_print_add_line_original, &cl_console_print_add_line);
		utils::hook::detour(&r_read_char_from_string_original, &r_read_char_from_string);
		utils::hook::detour(&draw_text_2d_original, &draw_text_2d);
		utils::hook::detour(&sys_send_packet_original, &sys_send_packet);
		utils::hook::detour(&seh_localize_text_message_original, &seh_localize_text_message);
		utils::hook::detour(&field_char_event_original, &field_char_event);
		//utils::hook::detour(&expression_parse_original, &expression_parse);
		
		utils::hook::call(0x006291A2, &xenon_get_xnaddr);
		
		utils::hook::retn(0x0043A0E0); // League_FetchLeagueHistoryInternal
		utils::hook::retn(0x006EC5D0); // SVC_RemoteCommand
		
		game::lui_error_report->current.enabled = false;
	
		command::on_sv("callvote", [](const auto client_num, const auto& params)
		{
			if (client_num > game::party->currentHost.hostNum)
			{
				game::send_server_command(-1, utils::string::va("; \"'%s' tried calling a vote!\"", game::cg()->client(client_num)->name()));
				return true;
			}

			return false;
		}); 
		
		command::on_sv("endround", [](const auto client_num, const auto& params)
		{
			if (client_num > game::party->currentHost.hostNum)
			{
				game::send_server_command(-1, utils::string::va("; \"'%s' tried ending the game!\"", game::cg()->client(client_num)->name()));
				return true;
			}

			return false;
		});

		command::on_sv("sl", [](const auto client_num, const auto& params)
		{
			if (client_num > game::party->currentHost.hostNum)
			{
				game::send_server_command(-1, utils::string::va("; \"'%s' tried crashing the server!\"", game::cg()->client(client_num)->name()));
				return true;
			}

			return false;
		});

		command::on_sv("userinfo", [](const auto client_num, const auto& params)
		{
			if (client_num > game::party->currentHost.hostNum)
			{
				game::send_server_command(-1, utils::string::va("; \"'%s' tried changing his userinfo!\"", game::cg()->client(client_num)->name()));
				return true;
			}

			return false;
		});

		for (const auto& handler : game::handlers)
		{
			network::on_command(handler.first.data(), [=](const auto& params, const auto& target, auto& msg)
			{
				if (handler.second && is_packet_from_host(target))
				{
					return false;
				}

				return send_unhandled_message(params.join(0), target);
			});
		} 

		network::on_command("joinParty", [](const auto& params, const auto& target, auto& msg)
		{
			const auto msg_backup = msg;

			const auto net_version = game::MSG_ReadLong(&msg);
			const auto net_field_checksum = game::MSG_ReadLong(&msg);
			const auto playlist_version_number = game::MSG_ReadLong(&msg);
			const auto xuid = game::MSG_ReadInt64(&msg);
			const auto playlist_id = game::MSG_ReadByte(&msg);
			const auto challenge_response_key = game::MSG_ReadShort(&msg);
			const auto change_list = game::MSG_ReadLong(&msg);
			const auto new_sub_party_count = game::MSG_ReadByte(&msg);

			if (!game::can_attempt_to_join_party(params[0], net_version, net_field_checksum, playlist_version_number, change_list, new_sub_party_count))
			{
				return send_exploit_caught_messages(params[0], target);
			}
			else
			{
				for (auto i = 0u; i < new_sub_party_count; ++i)
				{
					game::MSG_ReadByte(&msg);
					game::MSG_ReadLong(&msg);
					game::MSG_ReadFloat(&msg);
				}

				if (game::MSG_ReadBit(&msg))
				{
					while (true)
					{
						const auto xuid = game::MSG_ReadInt64(&msg);

						if (msg.overflowed)
							return send_exploit_caught_messages(params[0], target);
						
						if (game::Party_IsInTempBannedXuidList(xuid))
							return recieved_join_party_request(target, true);

						if (!game::MSG_ReadBit(&msg))
							break;
					}
				}

				recieved_join_party_request(target);
			}

			msg = msg_backup;

			return false;
		});

		network::on_command("ph", [](const auto& params, const auto& target, auto& msg)
		{	
			if (game::party->is_running() && !game::party->party_id() && is_packet_from_host(target))
			{
				game::MSG_ReadLong(&msg);
				game::MSG_ReadBit(&msg);

				while (true)
				{
					if (msg.overflowed)
						return send_exploit_caught_messages(params[0], target);

					game::MSG_ReadInt64(&msg);

					if (!game::MSG_ReadBit(&msg))
						break;
				}
			}
			
			return false;
		});

		network::on_command("pseg", [](const auto& params, const auto& target, auto& msg)
		{
			const auto msg_backup = msg;

			const auto segment = game::MSG_ReadByte(&msg);

			if (segment >= 6)
			{
				return send_exploit_caught_messages(params[0], target);
			}

			auto packet = game::party->party_state_packet(segment);

			packet->sequenceNumber = game::MSG_ReadLong(&msg);
			packet->totalSize = game::MSG_ReadLong(&msg);
			packet->offset = game::MSG_ReadShort(&msg);
			packet->size = game::MSG_ReadShort(&msg);

			if (!game::can_parse_party_state(params[0], segment, packet->totalSize, packet->offset, packet->size))
			{
				return send_exploit_caught_messages(params[0], target);
			}

			msg = msg_backup;
			
			return false;
		});

		network::on_command("relay", [](const auto& params, const auto& target, const auto& msg)
		{
			const auto client_num = utils::atoi(params[1]);

			if (client_num >= 18)
			{
				return send_exploit_caught_messages(params.join(0), target);
			}

			return false;
		});

		server_command::on_deploy_server_command('\\', [](const auto& params)
		{
			const auto weapon_id = utils::atoi(params[1]);

			if (weapon_id > game::bg_lastParsedWeaponIndex)
			{
				PRINT_LOG("Crash attempt caught! [%s]", params[0]);
				PRINT_BOLD_MESSAGE("Crash attempt caught!");

				return true;
			}

			return false;
		});

		server_command::on_deploy_server_command('^', [](const auto& params)
		{
			const auto dvar_index = utils::atoi(params[1]);

			if (dvar_index == 12)
			{
				if (game::I_stricmp(params[2], "class"))
				{
					PRINT_LOG("Anti-leave attempt caught! %s", params[2]);
					return true;
				}
			}

			return false;
		});

		server_command::on_deploy_server_command('2', [](const auto& params)
		{
			const auto index = utils::atoi(params[1]);
			const auto string = params[2];

			if (index == 2689)
			{
				if (std::strlen(string) > 255)
				{
					PRINT_LOG("Exploit attempt caught! [%s %u] [%u]", params[0], index, std::strlen(string));
					PRINT_BOLD_MESSAGE("Exploit attempt caught!");

					return true;
				}
			}

			return false;
		});

		server_command::on_needs_server_command('2', [](const auto& params)
		{
			const auto index = utils::atoi(params[1]);
			const auto string = params[2];
			
			if (index == 3)
			{
				const auto server_id = game::cl()->serverId;

				if (utils::atoi<std::uint8_t>(string) != (static_cast<std::uint8_t>(server_id & 0xF0) + ((static_cast<std::uint8_t>(server_id) + 1) & 0xF)))
				{
					PRINT_LOG("Crash attempt caught! [%s %u] %s", params[0], index, string);
					PRINT_BOLD_MESSAGE("Crash attempt caught!");

					return true;
				}
			}

			return false;
		});
		
		server_command::on_deploy_server_command('7', [](const auto& params)
		{
			const auto dyn_ent_id = utils::atoi<std::uint16_t>(params[1]);
			const auto draw_type = utils::atoi(params[2]);
				
			if (dyn_ent_id >= game::ent_count || draw_type >= game::DYNENT_DRAW_BRUSH)
			{
				PRINT_BOLD_MESSAGE("Crash attempt caught!");
				PRINT_LOG("Crash attempt caught! [%s] [%u] [%u]", params[0], dyn_ent_id, draw_type); 
				
				return true;
			}

			return false;
		});

		server_command::on_deploy_server_command('i', [](const auto& params)
		{
			const auto team = utils::atoi(params[1]);
			const auto score = utils::atoi(params[2]);
				
			if (team >= 10)
			{
				PRINT_BOLD_MESSAGE("Exploit attempt caught!");
				
				PRINT_LOG("Exploit attempt caught! [%s]\nTeam: 0x%08X\nScore: 0x%08X\nDest: 0x%08X", 
					params[0],
					team,
					score,
					game::cg()->team_scores(team));

				return true;
			}

			return false;
		});

		server_command::on_deploy_server_command('D', [](const auto& params)
		{
			const auto value = utils::atoi(params[2]);

			if (value > 7)
			{
				PRINT_LOG("Crash attempt caught! [%s] [%u]", params[0], value);
				PRINT_BOLD_MESSAGE("Crash attempt caught!");

				return true;
			}

			return false;
		});
	}
}