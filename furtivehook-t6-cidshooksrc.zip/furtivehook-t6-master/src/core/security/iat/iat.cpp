#include "iat.hpp"

namespace security::iat
{
	HANDLE __stdcall heap_create(DWORD options, size_t initial_size, size_t maximum_size)
	{
		static uintptr_t* stack{}, *base{};
		__asm mov stack, esp;
		__asm mov base, ebp;

		DEBUG_LOG("Called at (0x%08X) ..", _ReturnAddress());
		utils::print_stack_details(stack, base);
		utils::nt::terminate(true);
	}

	FARPROC __stdcall get_proc_address(HMODULE module, const char* proc_name)
	{
		if (proc_name != "VirtualProtect"s)
		{
			return GetProcAddress(module, proc_name);
		}

		DEBUG_LOG("Called at (0x%08X) ..", _ReturnAddress());
		utils::nt::terminate(true);
	}

	void* __stdcall virtual_alloc(void* address, size_t size, DWORD allocation_type, DWORD protect)
	{
		if (protect != PAGE_EXECUTE_READWRITE)
		{
			return VirtualAlloc(address, size, allocation_type, protect);
		}

		static uintptr_t* stack{}, *base{};
		__asm mov stack, esp;
		__asm mov base, ebp;

		DEBUG_LOG("Called at (0x%08X) ..", _ReturnAddress());
		utils::print_stack_details(stack, base);
		utils::nt::terminate(true);
	}

	void initialize()
	{
		loader::on_import("KERNEL32.dll", [](const auto& function) -> void*
		{
			if (function == "GetProcAddress")
			{
				return get_proc_address;
			}

			if (function == "HeapCreate")
			{
				return heap_create;
			}

			if (function == "VirtualAlloc")
			{
				return virtual_alloc;
			}

			return nullptr;
		});

		loader::load_library();
	}
}