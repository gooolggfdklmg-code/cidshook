#pragma once

namespace server_command
{
	void on_needs_server_command(std::uint8_t command, const std::function<bool(command::params_&)>& callback);
	void on_deploy_server_command(std::uint8_t command, const std::function<bool(command::params_&)>& callback);
	void initialize();

	extern bool log_sv_commands;
}
