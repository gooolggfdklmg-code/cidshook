#include "dependencies/std_include.hpp"
#include "server_command.hpp"
#include<sstream>
#include<unordered_set>

namespace server_command
{
	std::unordered_map<std::uint8_t, std::function<bool(command::params_&)>> deploy_server_command_handler;
	std::unordered_map<std::uint8_t, std::function<bool(command::params_&)>> needs_server_command_handler;
	bool log_sv_commands = false;

	void on_needs_server_command(std::uint8_t command, const std::function<bool(command::params_&)>& callback)
	{
		if (needs_server_command_handler.find(command) == needs_server_command_handler.end())
		{
			needs_server_command_handler[command] = callback;
		}
	}
	
	void on_deploy_server_command(std::uint8_t command, const std::function<bool(command::params_&)>& callback)
	{
		if (deploy_server_command_handler.find(command) == deploy_server_command_handler.end())
		{
			deploy_server_command_handler[command] = callback;
		}
	}
	
	bool can_handle_server_command(std::unordered_map<std::uint8_t, std::function<bool(command::params_&)>> callbacks, std::uint8_t command)
	{
		return callbacks.find(command) != callbacks.end() && callbacks[command];
	}
	
	bool handle_server_command(std::unordered_map<std::uint8_t, std::function<bool(command::params_&)>> handler)
	{
		command::params_ params = {};

		if (params.size() >= 1)
		{
			auto cmd_string = params[0][0];

			if (can_handle_server_command(handler, cmd_string))
			{
				return handler[cmd_string](params);
			}
		}

		return false;
	}

	int cl_cgame_needs_server_command(std::uint32_t index)
	{
		if (log_sv_commands)
		{
			PRINT_LOG("Received SV Command: %s", command::params.join(0).data());
		}
		
		if (handle_server_command(needs_server_command_handler))
		{
			return reinterpret_cast<decltype(&cl_cgame_needs_server_command)>(0x00635EF0)(2);
		}

		return reinterpret_cast<decltype(&cl_cgame_needs_server_command)>(0x00635EF0)(index);
	}
	
	int cg_deploy_server_command(std::uint32_t index)
	{
		if (handle_server_command(deploy_server_command_handler))
		{
			return reinterpret_cast<decltype(&cg_deploy_server_command)>(0x00635EF0)(2);
		}

		return reinterpret_cast<decltype(&cg_deploy_server_command)>(0x00635EF0)(index);
	}
	
	void initialize()
	{
		utils::hook::call(0x0051148F, &cl_cgame_needs_server_command);
		utils::hook::call(0x007D095D, &cg_deploy_server_command);
		
		/*on_deploy_server_command('O', [](const auto& params)
		{
			const static auto reasons =
			{
				"EXE_TRANSMITERROR",
				"EXE_TIMEDOUT",
				"EXE_LEFTGAME",
				"MP_BANNED",
				"EXE_BANNED",
				"PLATFORM_BANNED",
				"EXE_PLAYERKICKED",
				"EXE_DISCONNECTED",
			};

			for (const auto& reason : reasons)
			{
				const auto game_message = game::get_translated_hud_elem_message(params[1], reason);

				if (!game_message.empty())
				{
					PRINT_LOG("%s", game_message.data());
				}
			}

			return false;
		});

		on_deploy_server_command(';', [](const auto& params)
		{
			const auto game_message = game::get_translated_hud_elem_message(params[1], "MP_CONNECTED");

			if (!game_message.empty())
			{
				PRINT_LOG("%s", game_message.data());
			}

			return false;
		});

		on_deploy_server_command('+', [](const auto& params)
		{
			const auto chat_message = game::get_localized_chat_text_message(params[1], "chat message");

			if (!chat_message.empty())
			{
				PRINT_LOG("%s", chat_message.data());
			}

			return false;
		});

		on_deploy_server_command('j', [](const auto& params)
		{
			const auto chat_message = game::get_localized_chat_text_message(params[1], "team chat message");
				
			if (!chat_message.empty())
			{
				PRINT_LOG("%s", chat_message.data());
			}

			return false;
		});*/
	}
}