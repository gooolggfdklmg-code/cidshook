#include "dependencies/std_include.hpp"
#include "logger.hpp"

namespace logger
{
	std::string generate_log_filename()
	{
		const auto timestamp = utils::get_timestamp();

		char filepath[MAX_PATH] = { 0 };
		utils::io::create_directory("stdout");
		const auto filename = utils::string::va("stdout-%s.txt", timestamp.data());

		PathCombineA(filepath, "stdout\\", filename);

		return filepath;
	}

	void print_log(const char* msg, ...)
	{
		char buffer[2048];

		va_list ap;
		va_start(ap, msg);

		vsnprintf(buffer, sizeof buffer, msg, ap);

		va_end(ap);

		const static auto filename = generate_log_filename();
		utils::io::write_file(filename, buffer, true);
	}
}