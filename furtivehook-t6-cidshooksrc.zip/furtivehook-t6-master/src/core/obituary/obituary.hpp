#pragma once
#include "dependencies/std_include.hpp"

namespace obituary
{
	extern bool kill_say, steal_name;
	extern std::string kill_say_input;
	void cg_obituary();

	extern void initialize();
}
