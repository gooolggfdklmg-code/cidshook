﻿#include "dependencies/std_include.hpp"
#include "obituary.hpp"

namespace obituary
{
	auto cg_obituary_original = reinterpret_cast<decltype(&cg_obituary)>(0x007A345C); 
	bool kill_say = false, steal_name = false;
	std::string kill_say_input = "%v got tapped on by furtivehook";

	void callback_cg_obituary(game::cg_t* cg, size_t attacker, size_t target)
	{
		if (const auto client_num = cg->client_num(); attacker == client_num && attacker != target)
		{
			const auto client = cg->client(target);

			if (kill_say)
			{
				char nigga_message[0xff];
				sprintf_s(nigga_message, "say \"%s\"", utils::string::replace_all(kill_say_input, "%v", client->name()).data());

				game::CL_AddReliableCommand(0, nigga_message);
			}

			if (steal_name)
			{
				auto buffer = ""s;
				buffer.append("userinfo \"");
				buffer.append("\\name\\" + (client->name() + "\x14"s) + "\"");

				game::CL_AddReliableCommand(0, buffer.data());
			}
		}
	}

	__declspec(naked) void cg_obituary()
	{
		static game::cg_t* cg;
		static size_t attacker;
		static size_t target;
		
		__asm
		{
			push eax;
			mov eax, [esp + 0x24];
			mov attacker, eax;
			mov eax, [esp + 0x28];
			mov target, eax;
			pop eax;

			mov cg, esi;

			pushad;

			push target; 
			push attacker;
			push cg;
			call callback_cg_obituary;
			add esp, 12;

			popad;

			jmp cg_obituary_original;
		}
	}

	void initialize()
	{
		utils::hook::detour(&cg_obituary_original, &cg_obituary);
	}
}