#pragma once
#include "dependencies/std_include.hpp"

namespace friends
{
	struct friends_t
	{
		std::uint64_t xuid;
		std::string name;
		std::string adr;
		bool auto_crash;
		bool send_oob_packets;
	}; 
	
	void write_to_friends();
	void refresh_friends();
	void friends_list();

	extern std::vector<friends_t> friends;
}