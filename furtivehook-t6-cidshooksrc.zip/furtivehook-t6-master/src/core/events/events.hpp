#pragma once
#include "dependencies/std_include.hpp"

namespace events
{
	void dw_packet();
	void initialize();

	extern bool fake_lag;
	extern std::uint32_t lag_ms;
}
