#include "dependencies/std_include.hpp"
#include "events.hpp"

namespace events
{
	auto dw_packet_original = reinterpret_cast<decltype(&dw_packet)>(0x00A3276E);
	bool fake_lag = false;
	std::uint32_t lag_ms = 150;

	void __cdecl cg_predict_playerstate(LocalClientNum_t localClientNum)
	{
		auto cmd_cur = game::cl()->user_cmd(game::cl()->currentCmdNum);
		auto cmd_old = game::cl()->user_cmd(game::cl()->currentCmdNum - 1);
		auto cmd_new = game::cl()->user_cmd(++game::cl()->currentCmdNum);

		*cmd_new = *cmd_cur;
		cmd_cur->serverTime -= 1;
		cmd_old->serverTime += 1;

		static std::uint32_t angle_backup[3];
		VECTOR_COPY(angle_backup, cmd_old->angles);
		VECTOR_COPY(cmd_cur->angles, angle_backup);

		static std::uint32_t angle_backup_2[3];
		VECTOR_COPY(angle_backup_2, cmd_cur->angles);
		VECTOR_COPY(cmd_new->angles, angle_backup_2);

		const auto is_akimbo_gun = game::BG_IsDualWield(game::cg()->ps()->weapon);
		const auto is_auto_fire = aimbot::aim_target && aimbot::auto_fire;
		auto button_flag = 0u;

		if (is_auto_fire)
		{
			button_flag |= 0x80000000;

			if (is_akimbo_gun)
				button_flag |= 0x100080;

			cmd_cur->buttons[0] |= button_flag;
		}

		if (button_flag || !is_auto_fire)
		{
			const auto old_angle = SHORT2ANGLE(cmd_old->angles[1]);

			if (aimbot::aim_target)
			{
				cmd_old->angles[0] += ANGLE2SHORT(aimbot::aim_angles[0]);
				cmd_old->angles[1] += ANGLE2SHORT(aimbot::aim_angles[1]);
				cmd_old->angles[2] += ANGLE2SHORT(aimbot::aim_angles[2]);
			}

			const auto spread_angles = nospread::get_compensation_angles(cmd_cur->serverTime,
				game::BG_GetViewmodelWeaponIndex(game::cg()->ps()));

			cmd_old->angles[0] += ANGLE2SHORT(spread_angles[0]);
			cmd_old->angles[1] += ANGLE2SHORT(spread_angles[1]);
			cmd_old->angles[2] += ANGLE2SHORT(spread_angles[2]);

			if (aimbot::aim_target && aimbot::silent)
			{
				adjust_user_cmd_movement(cmd_old, SHORT2ANGLE(cmd_old->angles[1]), old_angle);
			}
		}

		reinterpret_cast<decltype(&cg_predict_playerstate)>(0x005B3C40)(localClientNum);
	}

	void __cdecl cl_write_packet(LocalClientNum_t localClientNum)
	{
		auto is_packet_choked = [](const game::usercmd_s* cmd) -> bool
		{
			if (!fake_lag || (fake_lag && aimbot::aim_target) || !game::CL_LocalClientIsInGame())
			{
				return true;
			}

			static auto last_packet_time = 0u;
			if (!last_packet_time || last_packet_time > cmd->serverTime || cmd->serverTime > last_packet_time + lag_ms)
			{
				last_packet_time = cmd->serverTime;

				return true;
			}

			return false;
		}; 
		
		auto cmd_cur = game::cl()->user_cmd(game::cl()->currentCmdNum);

		const auto is_vehicle_gun = game::BG_UsingVehicleWeapon(game::cg()->ps());
		const auto is_auto_fire = aimbot::aim_target && aimbot::auto_fire;

		if (is_auto_fire && is_vehicle_gun)
		{
			cmd_cur->buttons[0] |= 0x80000000;
			cmd_cur->buttons[1] |= 0x20000000;

			if (aimbot::aim_target)
			{
				cmd_cur->angles[0] += ANGLE2SHORT(aimbot::aim_angles[0]);
				cmd_cur->angles[1] += ANGLE2SHORT(aimbot::aim_angles[1]);
				cmd_cur->angles[2] += ANGLE2SHORT(aimbot::aim_angles[2]);
			}
		}

		antiaim::anti_aim(game::cg()->ps(), cmd_cur);

		if (is_packet_choked(cmd_cur))
		{
			reinterpret_cast<decltype(&cl_write_packet)>(0x0048E610)(localClientNum);
		}
	}

	void __cdecl callback_dw_packet(std::uint32_t packet)
	{
		if (packet == 20)
		{
			PRINT_LOG("Received DW packet '%d'", packet);
		}
	}

	__declspec(naked) void dw_packet()
	{
		__asm
		{
			pushad;
			push esi;
			call callback_dw_packet;
			pop esi;
			popad;

			jmp dw_packet_original;
		}
	}
	
	void initialize()
	{
		utils::hook::detour(&dw_packet_original, &dw_packet); 
		
		utils::hook::call(0x0055CF14, &cg_predict_playerstate);
		utils::hook::call(0x00414CA3, &cl_write_packet);
	}
}