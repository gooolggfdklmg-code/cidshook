#include "dependencies/std_include.hpp"
#define PROXY_NAME "d3d11.dll"
#define PROXY_EXPORT(_export)                                                                \
extern "C" __declspec(naked) __declspec(dllexport) void _export()                            \
{                                                                                            \
    proxy::get_export(__FUNCTION__, PROXY_NAME);                                             \
    __asm { jmp eax }                                                                        \
}

class proxy final
{
private:
	static std::unordered_map<std::string, HMODULE> loaded_libraries;
	static void load_library(const char* library);
	static bool is_library_loaded(const char* library);
public:
	static FARPROC get_export(const char* function, const char* library);
};

std::unordered_map<std::string, HMODULE> proxy::loaded_libraries;

void proxy::load_library(const char* library)
{
	char path[MAX_PATH];

	GetSystemDirectoryA(path, MAX_PATH);

	std::strcat(path, "\\");
	std::strcat(path, library);

	loaded_libraries[library] = LoadLibraryA(path);
}

bool proxy::is_library_loaded(const char* library)
{
	return loaded_libraries.find(library) != loaded_libraries.end() && loaded_libraries[library];
}

FARPROC proxy::get_export(const char* function, const char* library)
{
	if (!is_library_loaded(library))
	{
		load_library(library);
	}

	return GetProcAddress(loaded_libraries[library], function);
}

PROXY_EXPORT(D3D11CreateDevice)
PROXY_EXPORT(D3D11CreateDeviceAndSwapChain)