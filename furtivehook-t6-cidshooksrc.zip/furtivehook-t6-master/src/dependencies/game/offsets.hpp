#pragma once

namespace offsets
{
	constexpr auto net_field_checksum = 0x027DC9CC;
	constexpr auto playlist_version_number = 0x029998E8;
	constexpr auto end_address = 0x00B55000;
	
	constexpr auto LiveSteam_FriendPersonaNameFromXuid = 0x004FEA00;
	constexpr auto CL_Live_LeaveAllParties = 0x00916400;
	constexpr auto Live_CloseAllBusyPopups = 0x0040AC00;
	constexpr auto Live_SendInvite = 0x005E4910;
	constexpr auto CL_CanWeConnectToClient = 0x00697EF0;
	constexpr auto MSG_ReadStringLine = 0x00575000;
	constexpr auto in_appactive = 0x02B69958;
	constexpr auto mouse_active = 0x02B69968;
	constexpr auto yaw_speed = 0x00C6E7CC;

	constexpr auto prestige = 0x002FB1754;
	constexpr auto xp = 0x002FB176C;
	constexpr auto invite_id = 0x00304F7CC;

	constexpr auto SEH_LocalizeTextMessage = 0x0047A240;
	constexpr auto CG_TranslateHudElemMessage = 0x004066B0;
	constexpr auto CleanStr = 0x00583E70;
	
	constexpr auto CG_IsShoutcaster = 0x0065CD80;
	constexpr auto Demo_IsPlaying = 0x00510790;
	constexpr auto NET_CompareAdr = 0x00574030;

	constexpr auto BG_CalculateViewMovementAngles = 0x00661480;
	constexpr auto BG_GetAmmoNotInClip = 0x0063ADD0;
	constexpr auto BG_GetClipSize = 0x00699C30;
	constexpr auto BG_GetHeldWeapon = 0x004420E0;
	
	constexpr auto ent_count = 0x002531DFC;
	constexpr auto ent_def_list = 0x002531E08;
	constexpr auto CL_GetConfigString = 0x0063C1D0;
	
	constexpr auto g_partyData = 0x012B2308;
	constexpr auto g_lobbyData = 0x012A7000; 
	constexpr auto Live_GetXuid = 0x0054FBD0;
	constexpr auto Material_RegisterHandle = 0x00734000;

	constexpr auto Cmd_Argv = 0x006BD620;
	constexpr auto Cmd_Argc = 0x006E8000;
	constexpr auto DynEntCl_DestroyEvent = 0x007014D0;
	constexpr auto Party_HandlePacket = 0x004261E0;
	constexpr auto Party_FindMember = 0x00418260;
	constexpr auto SV_GameSendServerCommand = 0x006B2920;
	
	constexpr auto Live_GetOurClientNum = 0x005F8040;
	constexpr auto Party_FindMemberByXUID = 0x00673F60;
	constexpr auto CL_SendPeerData = 0x006642E0;
	constexpr auto cls_state = 0x011C7848;
	constexpr auto mig_state = 0x011C7850;
	constexpr auto clientConnections = 0x011C7D78;
	constexpr auto centity_t = 0x001140878;
	constexpr auto gentity_t = 0x021EF7C0;
	constexpr auto clientActive = 0x0011C7D74;
	constexpr auto cg = 0x00113F18C;
	constexpr auto clientInfo_t = 0x0011A8BEC;
	constexpr auto hwnd = 0x002B6ED88;

	constexpr auto MSG_Init = 0x69D900;
	constexpr auto MSG_WriteLong = 0x41AB90;
	constexpr auto MSG_WriteString = 0x623EC0;
	constexpr auto MSG_WriteByte = 0x4D0500;
	constexpr auto MSG_WriteInt64 = 0x65A2B0;
	constexpr auto MSG_WriteShort = 0x6C2370;
	constexpr auto MSG_WriteFloat = 0x6F3D70;
	constexpr auto MSG_WriteBit0 = 0x520880;
	constexpr auto MSG_WriteBit1 = 0x6F59F0;
	constexpr auto NET_OutOfBandData = 0x00706EC0;
	constexpr auto MSG_ReadByte = 0x006E07B0;
	constexpr auto MSG_ReadLong = 0x00700150;
	constexpr auto MSG_ReadShort = 0x00572BD0;
	constexpr auto MSG_WriteData = 0x006E28D0;
	
	constexpr auto Cbuf_AddText = 0x005BDF70;
	constexpr auto Dvar_FindVar = 0x0042D410; 
	constexpr auto Sys_GetValue = 0x00635EF0;
	constexpr auto CL_GetClantag = 0x005ACDA0;
	constexpr auto CL_ControllerIndex_GetUsername = 0x0065FDE0;
	constexpr auto CL_AddReliableCommand = 0x005E58E0;
	constexpr auto LiveSteam_PopOverlayForSteamID = 0x00589740;
	constexpr auto Live_GetCurrentSession = 0x006E7C70;
	constexpr auto Live_JoinSessionInProgress = 0x006EB1E0;
	constexpr auto Sys_Milliseconds = 0x005BD480;
	constexpr auto Com_Error = 0x004ECFD0;
	constexpr auto Friends_IsFriendByID = 0x0042F0F0;
	constexpr auto CG_CycleWeapon = 0x0069BAE0;

	constexpr auto BG_seedRandWithGameTime = 0x00543CE0;
	constexpr auto BG_random = 0x006A3490;
	constexpr auto BG_GetSpreadForWeapon = 0x00402A80;
	constexpr auto BG_srand = 0x004F38A0;
	constexpr auto CL_SetFovSensitivityScale = 0x0040BB00;
	constexpr auto BG_GetViewmodelWeaponIndex = 0x00625770;
	constexpr auto BG_WeaponHasPerk = 0x00449D90;
	constexpr auto BG_UsingSniperScope = 0x00646700;
	constexpr auto CL_SetUserCmdAimValues = 0x006E7F80;
	constexpr auto CG_GetLastWeaponForAlt = 0x004760B0;
	constexpr auto CL_SetUserCmdWeapons = 0x00552A60;
	constexpr auto CL_SetExtraButtons = 0x004840B0;

	constexpr auto BG_GetDamageRangeScale = 0x006C5CC0;
	constexpr auto CG_EntityIsDeployedRiotshield = 0x0045D4D0;
	constexpr auto BG_AdvanceTrace = 0x005B0F60;
	constexpr auto CG_ClientHasPerk = 0x0042BD20;
	constexpr auto BG_GetPenetrateType = 0x0062E290;
	constexpr auto BG_GetSurfacePenetrationDepth = 0x00572480;
	constexpr auto BG_GetWeaponDamageForRange = 0x006D85B0;
	constexpr auto G_GetWeaponHitLocationMultiplier = 0x00472780;
	constexpr auto Trace_GetEntityHitId = 0x004AC3D0;

	constexpr auto GScr_AllocString = 0x00479B40;
	constexpr auto Com_GetClientDObj = 0x005D2590;
	constexpr auto CG_DObjGetWorldTagPos = 0x00664930;
	
	constexpr auto CL_LocalClientIsInGame = 0x005922F0;
	constexpr auto BG_IsDualWield = 0x006625B0;
	constexpr auto BG_GetWeaponDef = 0x005846F0;
	
	constexpr auto CG_WorldPosToScreenPos = 0x00595690;

	constexpr auto BG_UsingVehicleWeapon = 0x005B8AD0;
	constexpr auto Session_GetXuidEvenIfInactive = 0x0045C710;
	constexpr auto CG_GetPlayerViewOrigin = 0x00580890;
	constexpr auto BG_GetPlayerViewOrigin = 0x004B72F0;
	constexpr auto CG_GameMessage = 0x005BAB70;
	constexpr auto PM_WeaponAmmoAvailable = 0x0557C40;

	constexpr auto AngleVectors = 0x0056BDC0;
	constexpr auto vectoangles = 0x005CD2A0;
	constexpr auto angle_normalize_360 = 0x0062C920;
	constexpr auto ClampChar = 0x007043C0;
	constexpr auto angle_normalize_180 = 0x04DEF60;
	constexpr auto vec3_distancesq = 0x0517840;
	constexpr auto vec3_normalize = 0x04299A0;
}