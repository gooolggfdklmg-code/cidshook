#pragma once
#include "dependencies/std_include.hpp"

#define DOT_PRODUCT(a,b) ((a)[0]*(b)[0]+(a)[1]*(b)[1]+(a)[2]*(b)[2])
#define ANGLE2SHORT(a) ((int)((a)*(65536/360.0f))&65535)
#define SHORT2ANGLE(a) ((float)((a)*(360.0f/65536)))
#define M_PI 3.14159265358979323846
#define M_PI_DOUBLE ((float)M_PI*2.0f)
#define DEG2RAD(a) ((a)*((float)M_PI/180.0f))
#define RAD2DEG(a) ((a)*(180.0f/(float)M_PI))
#define GET_SIGN(a) ((a) ? ((*(int*)&(a) >> 31) | 1) : 0)
#define VECTOR_COPY(a,b) ((b)[0]=(a)[0],(b)[1]=(a)[1],(b)[2]=(a)[2])

constexpr auto riot_shield = 89;

class Vec2 {
public:
	float x, y;

	Vec2() :x(0), y(0) {}
	Vec2(const float x, const float y) : x(x), y(y) {}
	Vec2(const Vec2& v) : x(v.x), y(v.y) {}
	Vec2(const float fl[2]) : x(fl[0]), y(fl[1]) {}
	
	operator float*() { return &x; }
	operator const float*() const { return &x; }

	bool operator==(const Vec2& v) const { return x == v.x && y == v.y; };
	bool operator!=(const Vec2& v) const { return !(*this == v); };
	
	Vec2 operator-() const { return Vec2(-x, -y); }
	Vec2 operator-(const Vec2& v) const { return Vec2(x - v.x, y - v.y); }
	Vec2 operator+(const Vec2& v) const { return Vec2(x + v.x, y + v.y); }
	Vec2 operator*(const float fl) const { return Vec2(x * fl, y * fl); }
	Vec2 operator/(const float fl) const { return Vec2(x / fl, y / fl); }
	
	void operator+=(const Vec2& v) { x += v.x; y += v.y; }
	void operator-=(const Vec2& v) { x -= v.x; y -= v.y; }
	void operator*=(const Vec2& v) { x *= v.x; y *= v.y; }
	void operator*=(const float fl) { x *= fl; y *= fl; }
	void operator/=(const Vec2& v) { x /= v.x; x /= v.y; }

	void set(const float x, const float y) {
		this->x = x;
		this->y = y;
	}

	void rotate(const double deg) {
		const double theta = deg / 180.0 * M_PI;
		double c = cos(theta);
		double s = sin(theta);
		double tx = x * c - y * s;
		double ty = x * s + y * c;
		x = tx;
		y = ty;
	}
	
	void clear() {
		this->x = 0.0f; this->y = 0.0f;
	}
	
	bool empty() const {
		return this->x == 0.0f && this->y == 0.0f;
	}
	
	Vec2& normalize() {
		if (length() == 0) return *this;
		*this *= (1.0f / length());
		return *this;
	}

	float distance(const Vec2& v) const {
		Vec2 d(x - v.x, y - v.y);
		return d.length();
	}

	float length() const {
		return std::sqrtf(x * x + y * y);
	}
};

class Vec3
{
public:
	float x, y, z;

	Vec3() :x(0), y(0) {}
	Vec3(const float x, const float y, const float z) : x(x), y(y), z(z) {}
	Vec3(const Vec3& v) : x(v.x), y(v.y), z(v.z) {}
	Vec3(const float fl[3]) : x(fl[0]), y(fl[1]), z(fl[3]) {}

	operator float* () { return &x; }
	operator const float* () const { return &x; }

	bool operator==(const Vec3& v) const { return x == v.x && y == v.y && z == v.z; }
	bool operator!=(const Vec3& v) const { return !(*this == v); }

	Vec3 operator-(const Vec3& v) const { return Vec3(x - v.x, y - v.y, z - v.z); }
	Vec3 operator-() const { return Vec3(-x, -y, -z); }
	Vec3 operator+(const Vec3& v) const { return Vec3(x + v.x, y + v.y, z + v.z); }
	Vec3 operator*(const float fl) const { return Vec3(x * fl, y * fl, z * fl); }
	Vec3 operator/(const float fl) const { return Vec3(x / fl, y / fl, z / fl); }

	void operator += (const Vec3& add) { x += add.x; y += add.y; z += add.z; }
	void operator -= (const Vec3& sub) { x -= sub.x; y -= sub.y; z -= sub.z; }
	void operator *= (const float mul) { x *= mul; y *= mul; z *= mul; }
	void operator /= (const float mul) { x /= mul; y /= mul; z /= mul; }

	void set(const float value) {
		x = value; y = value; z = value;
	}

	Vec3 clear() {
		return {};
	}

	float length() const {
		return std::sqrtf(x * x + y * y + z * z);
	}

	bool empty() const {
		return x == 0.0f && y == 0.0f;
	}

	float dot() const {
		return (x * x + y * y + z * z);
	}
	
	Vec3 cross_product(const Vec3& other) const {
		return { y * other.z - z * other.y, z * other.x - x * other.z, x * other.y - y * other.x };
	}

	Vec3& normalized() {
		if (length() == 0) return *this;
		*this *= (1.0 / length());
		return *this;
	}

	float distance(Vec3 v) const {
		Vec3 d(x - v.x, y - v.y, z - v.z);
		return d.length();
	}
};

using Weapon = std::uint32_t;
using LocalClientNum_t = std::uint32_t;
using scr_string_t = std::uint16_t;
using ControllerIndex_t = std::uint32_t;
using ClientNum_t = std::uint32_t;

namespace game
{
	enum entityType_t
	{
		ET_GENERAL = 0x0,
		ET_PLAYER = 0x1,
		ET_PLAYER_CORPSE = 0x2,
		ET_ITEM = 0x3,
		ET_MISSILE = 0x4,
		ET_INVISIBLE = 0x5,
		ET_SCRIPTMOVER = 0x6,
		ET_SOUND_BLEND = 0x7,
		ET_FX = 0x8,
		ET_LOOP_FX = 0x9,
		ET_PRIMARY_LIGHT = 0xA,
		ET_TURRET = 0xB,
		ET_HELICOPTER = 0xC,
		ET_PLANE = 0xD,
		ET_VEHICLE = 0xE,
		ET_VEHICLE_CORPSE = 0xF,
		ET_ACTOR = 0x10,
		ET_ACTOR_SPAWNER = 0x11,
		ET_ACTOR_CORPSE = 0x12,
		ET_STREAMER_HINT = 0x13,
		ET_ZBARRIER = 0x14,
		ET_EVENTS = 0x15,
	}; 
	
	enum ddlReturnCodes_e
	{
		DDL_RC_SUCCESS = 0x0,
		DDL_RC_ERROR = 0xFFFFFFFF,
		DDL_RC_BUFFER_IO_ERROR = 0xFFFFFFFE,
		DDL_RC_STATE_INVALID = 0xFFFFFFFD,
		DDL_RC_MEMBER_NULL = 0xFFFFFFFC,
		DDL_RC_MEMBER_INVALID = 0xFFFFFFFB,
		DDL_RC_OFFSET_INVALID = 0xFFFFFFFA,
		DDL_RC_TRUNCATED = 0xFFFFFFF9,
	}; 

	enum DynEntityDrawType : std::uint32_t
	{
		DYNENT_DRAW_MODEL = 0x0,
		DYNENT_DRAW_BRUSH = 0x1,
		DYNENT_DRAW_COUNT = 0x2,
	}; 
	
	enum migrateClientState_t
	{
		MIGRATE_CLIENT_IDLE = 0x0,
		MIGRATE_CLIENT_SENDING_PACKETS = 0x1,
		MIGRATE_WAITING_FOR_RESPONSES = 0x2,
		MIGRATE_ACTIVE = 0x3,
		MIGRATE_BECOMING_HOST = 0x4,
		MIGRATE_CLIENT_NUM_STATES = 0x5,
	}; 

	enum PartyStatus
	{
		PARTYSTATUS_EMPTY = 0x0,
		PARTYSTATUS_ZOMBIE = 0x1,
		PARTYSTATUS_ANONYMOUS = 0x2,
		PARTYSTATUS_PRESENT = 0x3,
		PARTYSTATUS_TESTCLIENT = 0x4,
		PARTYSTATUS_COUNT = 0x5,
	};
	
	struct cmd_function_s
	{
		cmd_function_s *next;
		const char *name;
		const char *autoCompleteDir;
		const char *autoCompleteExt;
		void(__cdecl *function)();
	};
	
	struct peerResults_t
	{
		unsigned int receivedPacketCount;
		unsigned int totalLatencyMS;
		float m;
		float s;
	};
	
	struct migrateHostData_t
	{
		std::uint64_t nominees[18];
		peerResults_t peerResults[18];
		ClientNum_t tokenHolder;
		unsigned int missingPeerLimit;
	}; 

	struct migrateClientData_t
	{
		peerResults_t peerResults[18];
		unsigned __int64 nominees[18];
		migrateClientState_t clientState;
		unsigned int sentPacketCount;
		int lastPacketSendMs;
		int currentNominee;
		int migrateStartMs;
		int lasthostTimeMS;
		int hostStartMS;
		int lastCalcTime;
		int nextTestPacketSendMS;
		unsigned __int64 peerXor;
	};
	
	struct ddlMemberDef_t
	{
		const char *name;
		int size;
		int offset;
		int type;
		int externalIndex;
		unsigned int rangeLimit;
		unsigned int serverDelta;
		unsigned int clientDelta;
		int arraySize;
		int enumIndex;
		int permission;
	};

	struct ddlHash_t
	{
		int hash;
		int index;
	}; 
	
	struct ddlStructDef_t
	{
		const char *name;
		int size;
		int memberCount;
		ddlMemberDef_t *members;
		ddlHash_t *hashTable;
	};

	struct ddlEnumDef_t
	{
		const char *name;
		int memberCount;
		const char **members;
		ddlHash_t *hashTable;
	};

	union ddlValue_t
	{
		float fixedPointValue;
		int intValue;
		unsigned int uintValue;
		unsigned __int64 int64Value;
		float floatValue;
		const char *stringPtr;
	}; 
	
	struct ddlDef_t
	{
		int version;
		int size;
		ddlStructDef_t *structList;
		int structCount;
		ddlEnumDef_t *enumList;
		int enumCount;
		ddlDef_t *next;
	};

	/* 2750 */
	struct ddlState_t
	{
		int absoluteOffset;
		int arrayIndex;
		ddlMemberDef_t *member;
		ddlDef_t *ddl;
		ddlReturnCodes_e returnCode;
	}; 
	
#pragma pack(push, 1)
	struct XNADDR
	{
		char pad[0x1E];
		union
		{
			std::uint8_t ip[4];
			std::uint32_t inaddr;
		};

		std::uint16_t port;
		char pad2[0x1];
	};
#pragma pack(pop)

	struct bdSecurityID
	{
		char ab[8];

		auto id() const
		{
			return *reinterpret_cast<std::uint64_t*>(reinterpret_cast<uintptr_t>(this));
		}

	};

	struct bdSecurityKey
	{
		char ab[16];
	};

	struct XSESSION_INFO
	{
		bdSecurityID sessionID;
		XNADDR hostAddress;
		bdSecurityKey keyExchangeKey;
	}; 
	
	struct __declspec(align(4)) InviteMessage
	{
		XSESSION_INFO sessionInfo;
		int fromMPInvite;
		bool isDedicated;
	};

	/* 3874 */
	enum IMType
	{
		JOIN_REQUEST = 0x0,
		JOIN_REPLY = 0x1,
		INVITE = 0x2,
		UPDATE_INVITE_INFO = 0x3,
		NUM_INSTANT_MESSAGE_TYPES = 0x4,
	}; 
	
	enum e_JoinRejectionReason
	{
		REASON_NONE = 0x0,
		REASON_PARTY_PRIVACY_CLOSED = 0x1,
		REASON_PARTY_PRIVACY_INVITE_ONLY = 0x2,
		REASON_PARTY_PRIVACY_FRIEND_ONLY = 0x3,
		REASON_SYSTEMLINK_LOBBY = 0x4,
	}; 
	
	struct JoinSessionMessage
	{
		IMType mType;
		std::uint32_t inviteID;
		bool isJoinable;
		bool invited;
		std::uint32_t maxLocalPlayersAllowed;
		bool allowGuests;
		e_JoinRejectionReason rejectionReason;
		InviteMessage inviteInfo;

		auto session_addr() const
		{
			std::array<std::uint8_t, 4u> out{};
			std::copy(&inviteInfo.sessionInfo.hostAddress.ip[0], &inviteInfo.sessionInfo.hostAddress.ip[4], out.begin());

			return out;
		}
	}; 
	
	struct PartyStatePacket_s
	{
		std::uint32_t sequenceNumber;
		std::uint32_t totalSize;
		std::uint32_t size;
		std::uint32_t offset;
	}; 

	struct $190F2CF944EC18EE3AF27F473C4F9DBE
	{
		unsigned __int32 weaponIdx : 8;
		unsigned __int32 attachment1 : 6;
		unsigned __int32 attachment2 : 6;
		unsigned __int32 attachment3 : 6;
		unsigned __int32 padding : 6;
	};

	/* 1793 */
	union WeaponData
	{
		$190F2CF944EC18EE3AF27F473C4F9DBE __s0;
		unsigned int weaponData;
	}; 
	
	struct PartyField
	{
		std::uint32_t bits;
		std::uint32_t offset;
		std::uint32_t size;
		const char *name;
	};
	
	enum clientMigState_t
	{
		CMSTATE_INACTIVE = 0x0,
		CMSTATE_OLDHOSTLEAVING = 0x1,
		CMSTATE_LIMBO = 0x2,
		CMSTATE_NEWHOSTCONNECT = 0x3,
		CMSTATE_COUNT = 0x4,
	};
	
	enum connstate_t
	{
		CA_DISCONNECTED = 0x0,
		CA_CINEMATIC = 0x1,
		CA_UICINEMATIC = 0x2,
		CA_LOGO = 0x3,
		CA_CONNECTING = 0x4,
		CA_CHALLENGING = 0x5,
		CA_CONNECTED = 0x6,
		CA_SENDINGSTATS = 0x7,
		CA_LOADING = 0x8,
		CA_PRIMED = 0x9,
		CA_ACTIVE = 0xA,
	};

	enum class box_type : std::uint32_t
	{
		box_cornered,
		box_bordered
	};

	enum errorParm_t
	{
		ERR_FATAL = 0x0,
		ERR_DROP = 0x1,
		ERR_FROM_STARTUP = 0x2,
		ERR_SERVERDISCONNECT = 0x3,
		ERR_DISCONNECT = 0x4,
		ERR_SCRIPT = 0x5,
		ERR_SCRIPT_DROP = 0x6,
		ERR_LOCALIZATION = 0x7,
	};

	enum class box_mode
	{
		BOX_CORNERED,
		BOX_BORDERED
	};

	enum class prediction_mode
	{
		PREDICTION_NONE,
		PREDICTION_BASIC_VELOCITY,
		PREDICTION_ADVANCED_VELOCITY,
		PREDICTION_PING,
	};

	enum weapType_t : int
	{
		WEAPTYPE_BULLET = 0,
		WEAPTYPE_GRENADE = 1,
		WEAPTYPE_PROJECTILE = 2,
		WEAPTYPE_BINOCULARS = 3,
		WEAPTYPE_GAS = 4,
		WEAPTYPE_BOMB = 5,
		WEAPTYPE_MINE = 6,
		WEAPTYPE_MELEE = 7,
		WEAPTYPE_RIOTSHIELD = 8,
		WEAPTYPE_MAX
	};
	enum class PenetrateType : int
	{
		PENETRATE_TYPE_NONE = 0,
		PENETRATE_TYPE_SMALL = 1,
		PENETRATE_TYPE_MEDIUM = 2,
		PENETRATE_TYPE_LARGE = 3,
		PENETRATE_TYPE_MAX
	};
	enum weapClass_t : int
	{
		WEAPCLASS_RIFLE = 0,
		WEAPCLASS_MG = 1,
		WEAPCLASS_SMG = 2,
		WEAPCLASS_SPREAD = 3,
		WEAPCLASS_PISTOL = 4,
		WEAPCLASS_GRENADE = 5,
		WEAPCLASS_ROCKETLAUNCHER = 6,
		WEAPCLASS_TURRET = 7,
		WEAPCLASS_NON_PLAYER = 8,
		WEAPCLASS_GAS = 9,
		WEAPCLASS_ITEM = 10,
		WEAPCLASS_MELEE = 11,
		WEAPCLASS_KILLSTREAK_ALT_STORED_WEAPON = 12,
		WEAPCLASS_PISTOL_SPREAD = 13,
		WEAPCLASS_MAX
	};

	enum team_t
	{
		TEAM_FREE = 0x0,
		TEAM_ALLIES = 0x1,
		TEAM_AXIS = 0x2,
		TEAM_THREE = 0x3,
		TEAM_FOUR = 0x4,
		TEAM_FIVE = 0x5,
		TEAM_SIX = 0x6,
		TEAM_SEVEN = 0x7,
		TEAM_EIGHT = 0x8,
		TEAM_MAX = 0x9
	};

	enum hitLocation_t
	{
		HITLOC_NONE = 0x0,
		HITLOC_HELMET = 0x1,
		HITLOC_HEAD = 0x2,
		HITLOC_NECK = 0x3,
		HITLOC_TORSO_UPR = 0x4,
		HITLOC_TORSO_MID = 0x5,
		HITLOC_TORSO_LWR = 0x6,
		HITLOC_R_ARM_UPR = 0x7,
		HITLOC_L_ARM_UPR = 0x8,
		HITLOC_R_ARM_LWR = 0x9,
		HITLOC_L_ARM_LWR = 0xA,
		HITLOC_R_HAND = 0xB,
		HITLOC_L_HAND = 0xC,
		HITLOC_R_LEG_UPR = 0xD,
		HITLOC_L_LEG_UPR = 0xE,
		HITLOC_R_LEG_LWR = 0xF,
		HITLOC_L_LEG_LWR = 0x10,
		HITLOC_R_FOOT = 0x11,
		HITLOC_L_FOOT = 0x12,
		HITLOC_GUN = 0x13,
		HITLOC_RIOT = 0x14,
		HITLOC_NUM = 0x15,
	};

	enum class dvarType_t : int
	{
		DVAR_TYPE_INVALID = 0x0,
		DVAR_TYPE_BOOL = 0x1,
		DVAR_TYPE_FLOAT = 0x2,
		DVAR_TYPE_FLOAT_2 = 0x3,
		DVAR_TYPE_FLOAT_3 = 0x4,
		DVAR_TYPE_FLOAT_4 = 0x5,
		DVAR_TYPE_INT = 0x6,
		DVAR_TYPE_ENUM = 0x7,
		DVAR_TYPE_STRING = 0x8,
		DVAR_TYPE_COLOR = 0x9,
		DVAR_TYPE_INT64 = 0xA,
		DVAR_TYPE_LINEAR_COLOR_RGB = 0xB,
		DVAR_TYPE_COLOR_XYZ = 0xC,
		DVAR_TYPE_COUNT = 0xD,
	};

	enum TraceHitType : unsigned long { TRACE_HITTYPE_NONE = 0, TRACE_HITTYPE_ENTITY = 1, TRACE_HITTYPE_DYNENT_MODEL = 2, TRACE_HITTYPE_DYNENT_BRUSH = 3, TRACE_HITTYPE_DYNENT_GLASS = 4 };

	enum netadrtype_t
	{
		NA_BOT = 0x0,
		NA_BAD = 0x1,
		NA_LOOPBACK = 0x2,
		NA_BROADCAST = 0x3,
		NA_IP = 0x4,
	};

	enum netsrc_t
	{
		NS_NULL = 0xFFFFFFFF,
		NS_CLIENT1 = 0x0,
		NS_CLIENT2 = 0x1,
		NS_CLIENT3 = 0x2,
		NS_CLIENT4 = 0x3,
		NS_SERVER = 0x4,
		NS_MAXCLIENTS = 0x4,
		NS_PACKET = 0x5,
	};
	
	union $55088C612251863DED87690D669FF6D2
	{
		void *pixelShader;
		void *localPixelShader;
	};

	union $F01209007E6D5437D99F198F0FAAA1A0
	{
		void *localArgs;
		void *args;
	};
	
	struct MaterialPass
	{
		void *vertexDecl;
		void *vertexShader;
		$55088C612251863DED87690D669FF6D2 ___u2;
		char perPrimArgCount;
		char perObjArgCount;
		char stableArgCount;
		char customSamplerFlags;
		char precompiledIndex;
		char materialType;
		$F01209007E6D5437D99F198F0FAAA1A0 ___u9;
	};
	
	struct MaterialTechnique
	{
		const char *name;
		unsigned __int16 flags;
		unsigned __int16 passCount;
		MaterialPass passArray[1];
	};
	
	struct MaterialTechniqueSet
	{
		const char *name;
		char worldVertFormat;
		MaterialTechnique *techniques[36];
	};
	
	union $93500E63A3928317F74DE3F1B0115B10
	{
		MaterialTechniqueSet *localTechniqueSet;
		MaterialTechniqueSet *techniqueSet;
	};

	struct MaterialConstantDef
	{
		unsigned int nameHash;
		char name[12];
		float literal[4];
	};

	union $9B20CC24F769322148675104C79675BA
	{
		MaterialConstantDef *localConstantTable;
		MaterialConstantDef *constantTable;
	};
	
	struct GfxDrawSurfFields
	{
		unsigned __int64 objectId : 16;
		unsigned __int64 customIndex : 9;
		unsigned __int64 reflectionProbeIndex : 5;
		unsigned __int64 dlightMask : 2;
		unsigned __int64 materialSortedIndex : 12;
		unsigned __int64 primaryLightIndex : 8;
		unsigned __int64 surfType : 4;
		unsigned __int64 prepass : 2;
		unsigned __int64 primarySortKey : 6;
	};

	/* 1556 */
	union GfxDrawSurf
	{
		GfxDrawSurfFields fields;
		unsigned __int64 packed;
	};  
	
	struct __declspec(align(8)) MaterialInfo
	{
		const char *name;
		unsigned int gameFlags;
		char pad;
		char sortKey;
		char textureAtlasRowCount;
		char textureAtlasColumnCount;
		GfxDrawSurf drawSurf;
		unsigned int surfaceTypeBits;
		unsigned int layeredSurfaceTypes;
		unsigned __int16 hashIndex;
		int surfaceFlags;
		int contents;
	};

	struct MaterialTextureDef
	{
		unsigned int nameHash;
		char nameStart;
		char nameEnd;
		char samplerState;
		char semantic;
		char isMatureContent;
		char pad[3];
		void *image;
	};
	
	struct Material
	{
		MaterialInfo info;
		char stateBitsEntry[36];
		char textureCount;
		char constantCount;
		char stateBitsCount;
		char stateFlags;
		char cameraRegion;
		char probeMipBits;
		$93500E63A3928317F74DE3F1B0115B10 ___u8;
		MaterialTextureDef *textureTable;
		$9B20CC24F769322148675104C79675BA ___u10;
		void *stateBitsTable;
		Material *thermalMaterial;
	};
	
	struct netadr_t
	{
		union
		{
			unsigned char bytes[4];
			unsigned int inaddr;
		} ip;
		
		std::uint16_t port;
		netadrtype_t type;
		netsrc_t localNetID;
		std::uint16_t serverID;
	};

	struct netProfilePacket_t
	{
		int iTime;
		int iSize;
		int bFragment;
	};

	/* 1899 */
	struct netProfileStream_t
	{
		netProfilePacket_t packets[60];
		int iCurrPacket;
		int iBytesPerSecond;
		int iLastBPSCalcTime;
		int iCountedPackets;
		int iCountedFragments;
		int iFragmentPercentage;
		int iLargestPacket;
		int iSmallestPacket;
	};

	struct netProfileInfo_t
	{
		netProfileStream_t send;
		netProfileStream_t recieve;
	};

	struct netchan_t
	{
		int outgoingSequence;
		netsrc_t sock;
		int dropped;
		int incomingSequence;
		netadr_t remoteAddress;
		int qport;
		int fragmentSequence;
		int fragmentLength;
		char *fragmentBuffer;
		int fragmentBufferSize;
		int unsentFragments;
		int unsentOnLoan;
		int unsentFragmentStart;
		int unsentLength;
		char *unsentBuffer;
		int unsentBufferSize;
		int reliable_fragments;
		char fragment_send_count[128];
		unsigned int fragment_ack[4];
		int lowest_send_count;
		netProfileInfo_t prof;
	};

	struct renderOptions_s
	{
		unsigned int s;
	};

	struct __declspec(align(4)) PlayerHeldWeapon
	{
		Weapon weapon;
		renderOptions_s options;
		float heatPercent;
		int fuelTankTime;
		int adsZoomSelect;
		bool overHeating;
		bool needsRechamber;
		bool heldBefore;
		bool quickReload;
		bool blockWeaponPickup;
		char model;
	};

	struct __declspec(align(8)) ClientInfo
	{
		bool registered;
		bool voiceRegistered;
		unsigned __int64 xuid;
		int natType;
		netadr_t addr;
		int voiceConnectivityBits;
		int lastConnectivityTestTime[1];
		bool friends;
		int flags;
		bool muted;
		int performanceValue;
		bool privateSlot;
	};

	struct RegisteredUser
	{
		bool active;
		unsigned __int64 xuid;
		bool privateSlot;
		int performanceValue;
	};

	struct SessionDynamicData
	{
		bool sessionHandle;
		XSESSION_INFO sessionInfo;
		bool keysGenerated;
		bool sessionStartCalled;
		unsigned __int64 sessionNonce;
		int privateSlots;
		int publicSlots;
		int flags;
		bool qosListenEnabled;
		ClientInfo users[19];
		ControllerIndex_t sessionCreateController;
		int sessionDeleteTime;
		int actualPublicSlots;
		int voiceConnectivityBits;
		RegisteredUser internalRegisteredUsers[19];
	};

	struct __declspec(align(4)) SessionStaticData
	{
		char* sessionName;
		bool registerUsersWithVoice;
		bool isDedicated;
	};

	struct SessionData
	{
		SessionStaticData staticData;
		SessionDynamicData dyn;

		auto server_addr()
		{
			std::array<std::uint8_t, 4u> out{};
			std::copy(&dyn.sessionInfo.hostAddress.ip[0], &dyn.sessionInfo.hostAddress.ip[4], out.begin());

			return out;
		}
	};

	struct msg_t
	{
		int overflowed;
		int readOnly;
		char* data;
		int splitData;
		int maxsize;
		int cursize;
		int splitSize;
		int readcount;
		int bit;
		int lastEntityRef;
		int flush;
		int targetLocalNetID;
	};

	struct PartySceNpId
	{
		char handle[20];
		char opt[8];
		char reserved[8];
	};

	struct liveAddr
	{
		XNADDR xnaddr;
	};

	struct __declspec(align(4)) platformNetAdr
	{
		netadr_t netAddr;
		liveAddr liveaddr;
	};

	union $4CC444478A5CF1CA3E666352329DBEA9
	{
		int rank;
		int rankPosition;
	};

	union $6F592E3A475AB50E77AAA300354707EA
	{
		std::uint32_t prestige;
		int divisionID;
		int daysLastPlayed;
	};

	struct PartyMemberTeam
	{
		int team;
		int switchTeam;
		int switchTeamTime;
		int lastTeam;
	};

	struct trajectory_t
	{
		int trType;
		int iTime;
		int iDuration;
		Vec3 trBase;
		Vec3 trDelta;
	};

	struct LerpEntityState
	{
		int flags;
		int flags1;
		trajectory_t pos;
		trajectory_t apos;
		char _0x50[0xC];
		int primaryweaponID;
		int stowedweaponID;
		int offhandWeaponID;
		int meleeID;
		char _0x6C[0x10];
	};

	struct entityState_s
	{
		int number;
		LerpEntityState lerp;
		char _0x80[0x58];
		entityType_t type;
		short groundEntNum;
		char _0xDA[0x2];
		short otherEntityNum;
		short attackerNum;
		char _0xE2[0x2];
		int weapon;
		char _0xE8[0x10];
	};

	struct usercmd_s
	{
		std::uint32_t serverTime;
		std::uint32_t buttons[2];
		std::uint32_t angles[3];
		Weapon weapon;
		Weapon offHandWeapon;
		Weapon lastWeaponAltModeSwitch;
		char forwardmove;
		char rightmove;
		char pad1[0x16];
	};

	struct PartyMember
	{
		char status;
		char unknown[8];
		int ackedMembers;
		int lastPacketTime;
		int lastHeartbeatTime;
		int lastPartyStateAck;
		int lastDemoHeartBeatTime;
		unsigned int challenge;
		int subpartyIndex;
		connstate_t reportedConnState;
		bool invited;
		bool headsetPresent;
		bool inLivePartyVoice;
		bool inLivePartyTalking;
		bool finishedLoadingDemo;
		bool isReady;
		bool isGuest;
		bool isSplitscreenClient;
		int natType;
		unsigned __int64 player;
		char gamertag[32];
		ControllerIndex_t localControllerIndex;
		int playerEmblem;
		PartySceNpId npid;
		char clanAbbrev[5];
		bool clanAbbrev_IsEliteValidated;
		int codPoints;
		unsigned int affinityBits;
		platformNetAdr platformAddr;
		int availableMapPackFlags;
		bdSecurityID privatePartyId;
		$4CC444478A5CF1CA3E666352329DBEA9 ___u30;
		$6F592E3A475AB50E77AAA300354707EA ___u31;
		int deaths;
		float skillRating;
		float skillVariance;
		PartyMemberTeam teamInfo;
		int score;
		int vetoedMap;
		int downloadPercent;
		bool readyForPlayback;
		int maximumPing;
		int specialFlags;
		int clanTagFeature;
		int voiceConnectivityBits;
		unsigned __int64 leagueTeamID;
		int leagueMemberCount;
		int searchStartUTC;
		int uploadBandwidth;
		char probation;
		char recentPlaylistEntries[3];
		unsigned int serverchallenge;
		int serverChallengeDeadline;

		auto user_port()
		{
			return reinterpret_cast<netadr_t*>(reinterpret_cast<uintptr_t>(this) + 0xCE)->port;
		}
	};

	struct __declspec(align(4)) MigrateMemberData
	{
		ClientNum_t nominee;
		int nomineeUpload;
		int nomineeNAT;
		bool nomineeOnLSP;
		bool heardFrom;
		int lastHeardFrom;
		int lastSentTo;
		bool inSameGeographicalRegion;
	}; 
	
	struct MigrateData
	{
		int indexBits;
		int startTime;
		MigrateMemberData memberData[18];
	}; 
	
	struct PartyMemberProfile
	{
		int updateTime;
		int sendTime;
		int ackTime;
		int acked;
		char DDL[1024];
	}; 
	
	enum PartyLeagueState
	{
		LEAGUE_WAITING_FOR_STATS = 0x0,
		LEAGUE_FORMING_TEAMS = 0x1,
		LEAGUE_CANNOT_FORM_TEAMS = 0x2,
		LEAGUE_SENDING_OUTCOMES = 0x3,
		LEAGUE_READY_TO_GO = 0x4,
	}; 
	
	enum LeagueDataState
	{
		LEAGUE_DATA_REQUESTING_BASE = 0x0,
		LEAGUE_DATA_BASE_RECEIVED = 0x1,
		LEAGUE_DATA_SENDING_OUTCOMES = 0x2,
		LEAGUE_DATA_OUTCOMES_ACKED = 0x3,
	}; 
	
	struct LeagueStats
	{
		int rankPoints;
		int rank;
		float floats[3];
		int ints[8];
	}; 
	
	struct LeagueOutcomes
	{
		LeagueStats base;
		LeagueStats winner;
		LeagueStats loser;
	}; 
	
	struct __declspec(align(8)) PartyMemberLeagueData
	{
		LeagueDataState state;
		int stateChangeTime;
		int stateUpdateTime;
		unsigned __int64 teamID;
		unsigned __int64 subdivisionID;
		int divisionID;
		int memberCount;
		char teamName[32];
		LeagueOutcomes outcomes;
	}; 
	
	struct __declspec(align(8)) PartyLeagueTeamData
	{
		unsigned __int64 teamID;
		bool valid;
		char name[32];
	};
	
	
	struct SubpartyMember
	{
		int memberIndex;
		char *gamertag;
		int lastTeam;
		unsigned int affinityBits;
	};

	/* 2199 */
	struct SubpartyInfo
	{
		SubpartyMember members[18];
		bool links[18];
		int count;
		float skill;
		int skillRanking;
		int searchStartUTC;
		int score;
		int team;
	}; 
	
	struct __declspec(align(8)) lobbyBanSlot_t
	{
		unsigned __int64 bannedXuid;
		int banTime;
	};
	
	struct __declspec(align(4)) PartyHostDetails
	{
		netadr_t addr;
		XSESSION_INFO sessionInfo;
		std::uint64_t xuid;
		int lastPacketTime;
		int lastPacketSentTime;
		int numPrivateSlots;
		int numPublicSlots;
		ClientNum_t hostNum;
		bool accepted;
		unsigned int challenge;
		bool isDedicated;

		auto host_addr()
		{
			std::array<std::uint8_t, 4u> out{};
			std::copy(&sessionInfo.hostAddress.ip[0], &sessionInfo.hostAddress.ip[4], out.begin());

			return out;
		}
	}; 
	
	enum MergeDedicatedState
	{
		MERGE_DEDICATED_COMPLETE = 0x0,
		MERGE_DEDICATED_NOT_REQUESTED = 0x1,
		MERGE_DEDICATED_REQUESTED = 0x2,
		MERGE_DEDICATED_IN_PROGRESS = 0x3,
	}; 
	
	struct partyMergeData_t
	{
		int timeSinceLastJoin;
		int lastSessionSearch;
		MergeDedicatedState dedicatedState;
	}; 
	
	struct __declspec(align(2)) PartyHostData
	{
		int partyGameStateChangeTime;
		int partyStateChangeTime;
		int stateSequenceNumber;
		int expectedPlayers;
		int vetoPassTime;
		int uiState;
		int uiEvent;
		int uiEventTime;
		int sessionSendTime;
		int lastValidLeagueTime;
		char votePossible;
		bool preloadingMap;
		bool firstLobby;
		bool migrateAfterRound;
		bool stopAfterRound;
		bool readyToStart;
		bool initialAckComplete;
	}; 
	
	struct PartyData_s
	{
		SessionData *session;
		SessionData *presenceSession;
		MigrateData migrateData;
		PartyMember partyMembers[19];
		PartyMemberProfile partyProfiles[19];
		PartyLeagueState leagueState;
		PartyMemberLeagueData memberLeagueData[19];
		PartyLeagueTeamData leagueTeamData[9];
		SubpartyInfo subparties[19];
		int subpartyCount;
		lobbyBanSlot_t lobbyBans[16];
		int partyJoinTime;
		__declspec(align(8)) PartyHostDetails currentHost;
		PartyHostDetails potentialHost;
		PartyHostData hostData;
		partyMergeData_t mergeData;
		float qosPercent;
		int qosSuccesses;
		int qosTotal;
		int localPlayerFlags[1];
		int lastMemberUpdateTime[1];
		int memberUpdateInterval[1];
		int areWeHost;
		int joiningAnotherParty;
		int inParty;
		int party_systemActive;
		int veto;
		bool enteringStartReadyState;
		bool ready;
		int wagerTime;
		int allowedTeams;
		bool teamBased;
		unsigned __int64 demoFileId;
		int demoFileSize;
		bool demoIsUserFile;
		bool finishedLoadingDemo;
		bool retryDemoDownload;
		unsigned __int64 demoAuthorXUID;
		int partyId;
		int nextSessionSearchTime;
		int mapPackSearchFlags;
		int mapPackFlags;
		unsigned __int64 leagueTeamID;
		char leagueTeamName[32];
		int lastPartyStateTime;
		int gameStartTime;
		int countDownTimeLeft;
		int interEndTime;
		int partyTimer;
		int restartMatchmakingTimer;
		int goResumeTime;
		int hostTimeouts;
		char lobbyFlags;
		PartyData_s *partyToNotify;
		bool registeredWithArbitration;
		bool rejoining;
		char stateMsgBuf[7200];
		PartyStatePacket_s partyStatePackets[6];
		char lastEntries[8];
		int currentEntry;
		int lastQosEntry;
		bool qosDataReady;
		int lobbyBeginTime;
		bool stateParsed;
		int soundEvents;
		int hostChangelist;
		int partyStartTimeMs;
		int nextChallengeSend;
		unsigned int serverChallenge;

		PartyHostData* host_data() const
		{
			return reinterpret_cast<PartyHostData*>(reinterpret_cast<std::uintptr_t>(this) + 0x254E);
		}

		auto& challenge() const
		{
			return *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(this) + 0x9528);
		}
		
		auto& a() const
		{
			return *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(this) + 0x958C);
		}
		
		auto& b() const
		{
			return *reinterpret_cast<bool*>(reinterpret_cast<uintptr_t>(this) + 0x9629);
		}
		
		bool is_running() const
		{
			return *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(this) + 0x9590) == 1;
		}

		bool in_party() const
		{
			return is_running() && *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(this) + 0x958C);
		}

		bool we_are_host() const
		{
			return *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(this) + 0x9584);
		}
		
		bool are_we_host() const
		{
			return is_running() && in_party() && we_are_host();
		}

		PartyMember* party_member(const std::size_t index) const
		{
			return reinterpret_cast<PartyMember*>(reinterpret_cast<uintptr_t>(this) + 0x208 + index * sizeof(PartyMember));
		}

		PartyStatePacket_s* party_state_packet(const std::uint8_t segment) const
		{
			return reinterpret_cast<PartyStatePacket_s*>(reinterpret_cast<std::uintptr_t>(this) + sizeof PartyStatePacket_s * segment + 0xB24C);
		}

		int party_id() const
		{
			return *reinterpret_cast<int*>(reinterpret_cast<uintptr_t>(this) + 0x95C4);
		}
	};

	struct ReliableCommands
	{
		int sequence;
		int acknowledge;
		char *commands[128];
		int commandBufferNext;
		char commandBuffer[16384];
	};

	struct __declspec(align(8)) clientConnection_t
	{
		int qport;
		ClientNum_t clientNum;
		int lastPacketSentTime;
		int lastPacketTime;
		netadr_t serverAddress;
		int connectTime;
		int connectPacketCount;
		char serverMessage[256];
		int challenge;
		int checksumFeed;
		ReliableCommands reliableCommands;
		int serverMessageSequence;
		int serverCommandSequence;
		int lastExecutedServerCommand;
		char serverCommands[128][1024];
		bool isServerRestarting;
		bool areTexturesLoaded;
		bool waitForMovie;
		bool hostCompromised;
		netchan_t netchan;
		char netchanOutgoingBuffer[2048];
		char netchanIncomingBuffer[65536];
		netProfileInfo_t OOBProf;
		__int64 statPacketsToSend;
		int statPacketSendTime[41];
	};

	struct WeaponDef
	{
		const char *szOverlayName;
		void **gunXModel;
		void *handXModel;
		const char *szModeName;
		unsigned __int16 *notetrackSoundMapKeys;
		unsigned __int16 *notetrackSoundMapValues;
		int playerAnimType;
		weapType_t weapType;
		weapClass_t weapClass;
		PenetrateType penetrateType;
		int impactType;
		int inventoryType;
		int fireType;
		int clipType;
		int barrelType;
		int itemIndex;
		const char *parentWeaponName;
		int iJamFireTime;
		int overheatWeapon;
		float overheatRate;
		float cooldownRate;
		float overheatEndVal;
		bool coolWhileFiring;
		bool fuelTankWeapon;
		int iTankLifeTime;
		int offhandClass;
		int offhandSlot;
		int stance;
		void *viewFlashEffect;
		void *worldFlashEffect;
		void *barrelCooldownEffect;
		int barrelCooldownMinCount;
		Vec3 vViewFlashOffset;
		Vec3 vWorldFlashOffset;
		const char *pickupSound;
		const char *pickupSoundPlayer;
		const char *ammoPickupSound;
		const char *ammoPickupSoundPlayer;
		const char *projectileSound;
		const char *pullbackSound;
		const char *pullbackSoundPlayer;
		const char *fireSound;
		const char *fireSoundPlayer;
		const char *fireLoopSound;
		const char *fireLoopSoundPlayer;
		const char *fireLoopEndSound;
		const char *fireLoopEndSoundPlayer;
		const char *fireStartSound;
		const char *fireStopSound;
		const char *fireKillcamSound;
		const char *fireStartSoundPlayer;
		const char *fireStopSoundPlayer;
		const char *fireKillcamSoundPlayer;
		const char *fireLastSound;
		const char *fireLastSoundPlayer;
		const char *emptyFireSound;
		const char *emptyFireSoundPlayer;
		const char *crackSound;
		const char *whizbySound;
		const char *meleeSwipeSound;
		const char *meleeSwipeSoundPlayer;
		const char *meleeHitSound;
		const char *meleeMissSound;
		const char *rechamberSound;
		const char *rechamberSoundPlayer;
		const char *reloadSound;
		const char *reloadSoundPlayer;
		const char *reloadEmptySound;
		const char *reloadEmptySoundPlayer;
		const char *reloadStartSound;
		const char *reloadStartSoundPlayer;
		const char *reloadEndSound;
		const char *reloadEndSoundPlayer;
		const char *rotateLoopSound;
		const char *rotateLoopSoundPlayer;
		const char *rotateStopSound;
		const char *rotateStopSoundPlayer;
		const char *deploySound;
		const char *deploySoundPlayer;
		const char *finishDeploySound;
		const char *finishDeploySoundPlayer;
		const char *breakdownSound;
		const char *breakdownSoundPlayer;
		const char *finishBreakdownSound;
		const char *finishBreakdownSoundPlayer;
		const char *detonateSound;
		const char *detonateSoundPlayer;
		const char *nightVisionWearSound;
		const char *nightVisionWearSoundPlayer;
		const char *nightVisionRemoveSound;
		const char *nightVisionRemoveSoundPlayer;
		const char *altSwitchSound;
		const char *altSwitchSoundPlayer;
		const char *raiseSound;
		const char *raiseSoundPlayer;
		const char *firstRaiseSound;
		const char *firstRaiseSoundPlayer;
		const char *adsRaiseSoundPlayer;
		const char *adsLowerSoundPlayer;
		const char *putawaySound;
		const char *putawaySoundPlayer;
		const char *overheatSound;
		const char *overheatSoundPlayer;
		const char *adsZoomSound;
		const char *shellCasing;
		const char *shellCasingPlayer;
		const char **bounceSound;
		const char *standMountedWeapdef;
		const char *crouchMountedWeapdef;
		const char *proneMountedWeapdef;
		int standMountedIndex;
		int crouchMountedIndex;
		int proneMountedIndex;
		void *viewShellEjectEffect;
		void *worldShellEjectEffect;
		void *viewLastShotEjectEffect;
		void *worldLastShotEjectEffect;
		Vec3 vViewShellEjectOffset;
		Vec3 vWorldShellEjectOffset;
		Vec3 vViewShellEjectRotation;
		Vec3 vWorldShellEjectRotation;
		Material *reticleCenter;
		Material *reticleSide;
		int iReticleCenterSize;
		int iReticleSideSize;
		int iReticleMinOfs;
		int activeReticleType;
		Vec3 vStandMove;
		Vec3 vStandRot;
		Vec3 vDuckedOfs;
		Vec3 vDuckedMove;
		Vec3 vDuckedSprintOfs;
		Vec3 vDuckedSprintRot;
		Vec2 vDuckedSprintBob;
		float fDuckedSprintCycleScale;
		Vec3 vSprintOfs;
		Vec3 vSprintRot;
		Vec2 vSprintBob;
		float fSprintCycleScale;
		Vec3 vLowReadyOfs;
		Vec3 vLowReadyRot;
		Vec3 vRideOfs;
		Vec3 vRideRot;
		Vec3 vDtpOfs;
		Vec3 vDtpRot;
		Vec2 vDtpBob;
		float fDtpCycleScale;
		Vec3 vMantleOfs;
		Vec3 vMantleRot;
		Vec3 vSlideOfs;
		Vec3 vSlideRot;
		Vec3 vDuckedRot;
		Vec3 vProneOfs;
		Vec3 vProneMove;
		Vec3 vProneRot;
		Vec3 vStrafeMove;
		Vec3 vStrafeRot;
		float fPosMoveRate;
		float fPosProneMoveRate;
		float fStandMoveMinSpeed;
		float fDuckedMoveMinSpeed;
		float fProneMoveMinSpeed;
		float fPosRotRate;
		float fPosProneRotRate;
		float fStandRotMinSpeed;
		float fDuckedRotMinSpeed;
		float fProneRotMinSpeed;
		void **worldModel;
		void *worldClipModel;
		void *rocketModel;
		void *mountedModel;
		void *additionalMeleeModel;
		Material *fireTypeIcon;
		Material *hudIcon;
		int hudIconRatio;
		Material *indicatorIcon;
		int indicatorIconRatio;
		Material *ammoCounterIcon;
		int ammoCounterIconRatio;
		int ammoCounterClip;
		int iStartAmmo;
		int iMaxAmmo;
		int shotCount;
		const char *szSharedAmmoCapName;
		int iSharedAmmoCapIndex;
		int iSharedAmmoCap;
		bool unlimitedAmmo;
		bool ammoCountClipRelative;
		int damage[6];
		float damageRange[6];
		int minPlayerDamage;
		float damageDuration;
		float damageInterval;
		int playerDamage;
		int iMeleeDamage;
		int iDamageType;
		unsigned __int16 explosionTag;
		int iFireDelay;
		int iMeleeDelay;
		int meleeChargeDelay;
		int iDetonateDelay;
		int iSpinUpTime;
		int iSpinDownTime;
		float spinRate;
		const char *spinLoopSound;
		const char *spinLoopSoundPlayer;
		const char *startSpinSound;
		const char *startSpinSoundPlayer;
		const char *stopSpinSound;
		const char *stopSpinSoundPlayer;
		bool applySpinPitch;
		int iFireTime;
		int iLastFireTime;
		int iRechamberTime;
		int iRechamberBoltTime;
		int iHoldFireTime;
		int iDetonateTime;
		int iMeleeTime;
		int iBurstDelayTime;
		int meleeChargeTime;
		int iReloadTimeRight;
		int iReloadTimeLeft;
		int reloadShowRocketTime;
		int iReloadEmptyTimeLeft;
		int iReloadAddTime;
		int iReloadEmptyAddTime;
		int iReloadQuickAddTime;
		int iReloadQuickEmptyAddTime;
		int iReloadStartTime;
		int iReloadStartAddTime;
		int iReloadEndTime;
		int iDropTime;
		int iRaiseTime;
		int iAltDropTime;
		int quickDropTime;
		int quickRaiseTime;
		int iFirstRaiseTime;
		int iEmptyRaiseTime;
		int iEmptyDropTime;
		int sprintInTime;
		int sprintLoopTime;
		int sprintOutTime;
		int lowReadyInTime;
		int lowReadyLoopTime;
		int lowReadyOutTime;
		int contFireInTime;
		int contFireLoopTime;
		int contFireOutTime;
		int dtpInTime;
		int dtpLoopTime;
		int dtpOutTime;
		int crawlInTime;
		int crawlForwardTime;
		int crawlBackTime;
		int crawlRightTime;
		int crawlLeftTime;
		int crawlOutFireTime;
		int crawlOutTime;
		int slideInTime;
		int deployTime;
		int breakdownTime;
		int iFlourishTime;
		int nightVisionWearTime;
		int nightVisionWearTimeFadeOutEnd;
		int nightVisionWearTimePowerUp;
		int nightVisionRemoveTime;
		int nightVisionRemoveTimePowerDown;
		int nightVisionRemoveTimeFadeInStart;
		int fuseTime;
		int aiFuseTime;
		int lockOnRadius;
		int lockOnSpeed;
		bool requireLockonToFire;
		bool noAdsWhenMagEmpty;
		bool avoidDropCleanup;
		unsigned int stackFire;
		float stackFireSpread;
		float stackFireAccuracyDecay;
		const char *stackSound;
		float autoAimRange;
		float aimAssistRange;
		bool mountableWeapon;
		float aimPadding;
		float enemyCrosshairRange;
		bool crosshairColorChange;
		float moveSpeedScale;
		float adsMoveSpeedScale;
		float sprintDurationScale;
		int overlayReticle;
		int overlayInterface;
		float overlayWidth;
		float overlayHeight;
		float fAdsBobFactor;
		float fAdsViewBobMult;
		bool bHoldBreathToSteady;
		float fHipSpreadStandMin;
		float fHipSpreadDuckedMin;
		float fHipSpreadProneMin;
		float hipSpreadStandMax;
		float hipSpreadDuckedMax;
		float hipSpreadProneMax;
		float fHipSpreadDecayRate;
		float fHipSpreadFireAdd;
		float fHipSpreadTurnAdd;
		float fHipSpreadMoveAdd;
		float fHipSpreadDuckedDecay;
		float fHipSpreadProneDecay;
		float fHipReticleSidePos;
		float fAdsIdleAmount;
		float fHipIdleAmount;
		float adsIdleSpeed;
		float hipIdleSpeed;
		float fIdleCrouchFactor;
		float fIdleProneFactor;
		float fGunMaxPitch;
		float fGunMaxYaw;
		float swayMaxAngle;
		float swayLerpSpeed;
		float swayPitchScale;
		float swayYawScale;
		float swayHorizScale;
		float swayVertScale;
		float swayShellShockScale;
		float adsSwayMaxAngle;
		float adsSwayLerpSpeed;
		float adsSwayPitchScale;
		float adsSwayYawScale;
		bool sharedAmmo;
		bool bRifleBullet;
		bool armorPiercing;
		bool bAirburstWeapon;
		bool bBoltAction;
		bool bUseAltTagFlash;
		bool bUseAntiLagRewind;
		bool bIsCarriedKillstreakWeapon;
		bool aimDownSight;
		bool bRechamberWhileAds;
		bool bReloadWhileAds;
		float adsViewErrorMin;
		float adsViewErrorMax;
		bool bCookOffHold;
		bool bClipOnly;
		bool bCanUseInVehicle;
		bool bNoDropsOrRaises;
		bool adsFireOnly;
		bool cancelAutoHolsterWhenEmpty;
		bool suppressAmmoReserveDisplay;
		bool laserSight;
		bool laserSightDuringNightvision;
		bool bHideThirdPerson;
		bool bHasBayonet;
		bool bDualWield;
		bool bExplodeOnGround;
		bool bThrowBack;
		bool bRetrievable;
		bool bDieOnRespawn;
		bool bNoThirdPersonDropsOrRaises;
		bool bContinuousFire;
		bool bNoPing;
		bool bForceBounce;
		bool bUseDroppedModelAsStowed;
		bool bNoQuickDropWhenEmpty;
		bool bKeepCrosshairWhenADS;
		bool bUseOnlyAltWeaoponHideTagsInAltMode;
		bool bAltWeaponAdsOnly;
		bool bAltWeaponDisableSwitching;
		Material *killIcon;
		int killIconRatio;
		bool flipKillIcon;
		bool bNoPartialReload;
		bool bSegmentedReload;
		bool bNoADSAutoReload;
		int iReloadAmmoAdd;
		int iReloadStartAdd;
		const char *szSpawnedGrenadeWeaponName;
		const char *szDualWieldWeaponName;
		unsigned int dualWieldWeaponIndex;
		int iDropAmmoMin;
		int iDropAmmoMax;
		int iDropClipAmmoMin;
		int iDropClipAmmoMax;
		int iShotsBeforeRechamber;
		bool blocksProne;
		bool bShowIndicator;
		int isRollingGrenade;
		int useBallisticPrediction;
		int isValuable;
		int isTacticalInsertion;
		bool isReviveWeapon;
		bool bUseRigidBodyOnVehicle;
		int iExplosionRadius;
		int iExplosionRadiusMin;
		int iIndicatorRadius;
		int iExplosionInnerDamage;
		int iExplosionOuterDamage;
		float damageConeAngle;
		int iProjectileSpeed;
		int iProjectileSpeedUp;
		int iProjectileSpeedRelativeUp;
		int iProjectileSpeedForward;
		float fProjectileTakeParentVelocity;
		int iProjectileActivateDist;
		float projLifetime;
		float timeToAccelerate;
		float projectileCurvature;
		void *projectileModel;
		int projExplosion;
		void *projExplosionEffect;
		bool projExplosionEffectForceNormalUp;
		void *projExplosionEffect2;
		bool projExplosionEffect2ForceNormalUp;
		void *projExplosionEffect3;
		bool projExplosionEffect3ForceNormalUp;
		void *projExplosionEffect4;
		bool projExplosionEffect4ForceNormalUp;
		void *projExplosionEffect5;
		bool projExplosionEffect5ForceNormalUp;
		void *projDudEffect;
		const char *projExplosionSound;
		const char *projDudSound;
		const char *mortarShellSound;
		const char *tankShellSound;
		bool bProjImpactExplode;
		bool bProjSentientImpactExplode;
		bool bProjExplodeWhenStationary;
		bool bBulletImpactExplode;
		int stickiness;
		int rotateType;
		bool plantable;
		bool hasDetonator;
		bool timedDetonation;
		bool bNoCrumpleMissile;
		bool rotate;
		bool bKeepRolling;
		bool holdButtonToThrow;
		bool offhandHoldIsCancelable;
		bool freezeMovementWhenFiring;
		float lowAmmoWarningThreshold;
		bool bDisallowAtMatchStart;
		float meleeChargeRange;
		bool bUseAsMelee;
		bool isCameraSensor;
		bool isAcousticSensor;
		bool isLaserSensor;
		bool isHoldUseGrenade;
		float *parallelBounce;
		float *perpendicularBounce;
		void *projTrailEffect;
		Vec3 vProjectileColor;
		int guidedMissileType;
		float maxSteeringAccel;
		int projIgnitionDelay;
		void *projIgnitionEffect;
		const char *projIgnitionSound;
		float fAdsAimPitch;
		float fAdsCrosshairInFrac;
		float fAdsCrosshairOutFrac;
		int adsGunKickReducedKickBullets;
		float adsGunKickReducedKickPercent;
		float fAdsGunKickPitchMin;
		float fAdsGunKickPitchMax;
		float fAdsGunKickYawMin;
		float fAdsGunKickYawMax;
		float fAdsGunKickAccel;
		float fAdsGunKickSpeedMax;
		float fAdsGunKickSpeedDecay;
		float fAdsGunKickStaticDecay;
		float fAdsViewKickPitchMin;
		float fAdsViewKickPitchMax;
		float fAdsViewKickMinMagnitude;
		float fAdsViewKickYawMin;
		float fAdsViewKickYawMax;
		float fAdsRecoilReductionRate;
		float fAdsRecoilReductionLimit;
		float fAdsRecoilReturnRate;
		float fAdsViewScatterMin;
		float fAdsViewScatterMax;
		float fAdsSpread;
		int hipGunKickReducedKickBullets;
		float hipGunKickReducedKickPercent;
		float fHipGunKickPitchMin;
		float fHipGunKickPitchMax;
		float fHipGunKickYawMin;
		float fHipGunKickYawMax;
		float fHipGunKickAccel;
		float fHipGunKickSpeedMax;
		float fHipGunKickSpeedDecay;
		float fHipGunKickStaticDecay;
		float fHipViewKickPitchMin;
		float fHipViewKickPitchMax;
		float fHipViewKickMinMagnitude;
		float fHipViewKickYawMin;
		float fHipViewKickYawMax;
		float fHipViewScatterMin;
		float fHipViewScatterMax;
		float fAdsViewKickCenterDuckedScale;
		float fAdsViewKickCenterProneScale;
		float fAntiQuickScopeTime;
		float fAntiQuickScopeScale;
		float fAntiQuickScopeSpreadMultiplier;
		float fAntiQuickScopeSpreadMax;
		float fAntiQuickScopeSwayFactor;
		float fightDist;
		float maxDist;
		const char *accuracyGraphName[2];
		Vec2 *accuracyGraphKnots[2];
		Vec2 *originalAccuracyGraphKnots[2];
		int accuracyGraphKnotCount[2];
		int originalAccuracyGraphKnotCount[2];
		int iPositionReloadTransTime;
		float leftArc;
		float rightArc;
		float topArc;
		float bottomArc;
		float accuracy;
		float aiSpread;
		float playerSpread;
		float minTurnSpeed[2];
		float maxTurnSpeed[2];
		float pitchConvergenceTime;
		float yawConvergenceTime;
		float suppressTime;
		float maxRange;
		float fAnimHorRotateInc;
		float fPlayerPositionDist;
		const char *szUseHintString;
		const char *dropHintString;
		int iUseHintStringIndex;
		int dropHintStringIndex;
		float horizViewJitter;
		float vertViewJitter;
		float cameraShakeScale;
		int cameraShakeDuration;
		int cameraShakeRadius;
		float explosionCameraShakeScale;
		int explosionCameraShakeDuration;
		int explosionCameraShakeRadius;
		const char *szScript;
		float destabilizationRateTime;
		float destabilizationCurvatureMax;
		int destabilizeDistance;
		float *locationDamageMultipliers;
		const char *fireRumble;
		const char *meleeImpactRumble;
		const char *reloadRumble;
		const char *explosionRumble;
		void *tracerType;
		void *enemyTracerType;
		float adsDofStart;
		float adsDofEnd;
		float hipDofStart;
		float hipDofEnd;
		float scanSpeed;
		float scanAccel;
		int scanPauseTime;
		const char *flameTableFirstPerson;
		const char *flameTableThirdPerson;
		void *flameTableFirstPersonPtr;
		void *flameTableThirdPersonPtr;
		void *tagFx_preparationEffect;
		void *tagFlash_preparationEffect;
		bool doGibbing;
		float maxGibDistance;
		float altScopeADSTransInTime;
		float altScopeADSTransOutTime;
		int iIntroFireTime;
		int iIntroFireLength;
		void *meleeSwipeEffect;
		void *meleeImpactEffect;
		void *meleeImpactNoBloodEffect;
		const char *throwBackType;
		void *weaponCamo;
		float customFloat0;
		float customFloat1;
		float customFloat2;
		int customBool0;
		int customBool1;
		int customBool2;
	};

	struct orientation_t
	{
		Vec3 origin;
		Vec3 axis[3];
	};

	struct refdef_t
	{
	private:
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) const {
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		auto width() const {
			return get<std::uint32_t>(0x8);
		}

		auto height() const {
			return get<std::uint32_t>(0xC);
		}

		auto tan_half_fov_x() const {
			return get<float>(0x20);
		}

		auto tan_half_fov_y() const {
			return get<float>(0x24);
		}

		auto& fov_x() const {
			return get<float>(0x30);
		}

		auto view_origin() const {
			return get<Vec3>(0x34);
		}

		auto& splitscreen_blur_edges() const {
			return get<int>(0x16D80);
		}

		auto& player_teleported() const {
			return get<int>(0x16D84);
		}
	};

	struct clientInfo_t
	{
	private:
		char pad[0x808];
		
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) const 
		{
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		auto valid() const {
			return get<std::uint32_t>(0);
		}

		auto next_valid() const {
			return get<std::uint32_t>(0x4);
		}

		auto client_number() const {
			return get<std::uint32_t>(0x8);
		}

		auto name() const {
			return get<std::string>(0xC).data();
		}

		auto xuid() const {
			return get<std::uint64_t>(0x78);
		}

		auto ping() const {
			return get<std::uint32_t>(0x88);
		}

		auto clan() const {
			return get<std::string>(0x80).data();
		}

		auto team() const {
			return get<std::uint32_t>(0x2C);
		}

		auto old_team() const {
			return get<std::uint32_t>(0x30);
		}

		auto& player_angles() const {
			return get<Vec3>(0x4C4);
		}

		auto& ui_visibility_flags() const {
			return get<std::uint32_t>(0x65C);
		}
	};

	struct centity_t
	{
	private:
		char pad[0x380];
		
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) const 
		{
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		bool is_alive() const {
			return get<std::uint8_t>(0x378) & 2;
		}

		auto& origin() const {
			return get<Vec3>(0x2C);
		}

		auto& angles() const {
			return get<Vec3>(0x38);
		}

		auto& prev_state() const {
			return get<LerpEntityState>(0x160);
		}

		auto& next_state() const {
			return get<entityState_s>(0x1DC);
		}
	};

	enum objectiveState_t
	{
		OBJST_EMPTY = 0x0,
		OBJST_ACTIVE = 0x1,
		OBJST_INVISIBLE = 0x2,
		OBJST_NUMSTATES = 0x3,
	};

	struct __declspec(align(2)) objective_t
	{
		objectiveState_t state;
		Vec3 origin;
		__int16 entNum;
		Vec2 size;
		int icon;
		__int16 ownerNum;
		unsigned __int16 name;
		__int16 teamMask;
		char progress;
		int clientUseMask[1];
		char gamemodeFlags;
		char flags;
		char teamNum;
	};

	enum OffhandSecondaryClass
	{
		PLAYER_OFFHAND_SECONDARY_SMOKE = 0x0,
		PLAYER_OFFHAND_SECONDARY_FLASH = 0x1,
		PLAYER_OFFHAND_SECONDARIES_TOTAL = 0x2,
	};

	enum OffhandPrimaryClass
	{
		PLAYER_OFFHAND_PRIMARY_FRAG = 0x0,
		PLAYER_OFFHAND_PRIMARY_GEAR = 0x1,
		PLAYER_OFFHAND_PRIMARIES_TOTAL = 0x2,
	};

	struct AmmoPool
	{
		int count;
	};

	struct AmmoClip
	{
		int count;
	};

	enum ViewLockTypes
	{
		PLAYERVIEWLOCK_NONE = 0x0,
		PLAYERVIEWLOCK_FULL = 0x1,
		PLAYERVIEWLOCK_WEAPONJITTER = 0x2,
		PLAYERVIEWLOCKCOUNT = 0x3,
	};

	enum locSel_t
	{
		LOC_SEL_NONE = 0x0,
		LOC_SEL_ARTILLERY = 0x1,
		LOC_SEL_AIRSTRIKE = 0x2,
		LOC_SEL_MORTAR = 0x3,
		LOC_SEL_NAPALM = 0x4,
		LOC_SEL_COMLINK = 0x5,
	};

	struct SprintState
	{
		int sprintButtonUpRequired;
		int sprintDelay;
		int lastSprintStart;
		int lastSprintEnd;
		int sprintStartMaxLength;
		int sprintDuration;
		int sprintCooldown;
	};

	struct MantleState
	{
		float yaw;
		int timer;
		int transIndex;
		int flags;
	};

	enum ActionSlotType
	{
		ACTIONSLOTTYPE_DONOTHING = 0x0,
		ACTIONSLOTTYPE_SPECIFYWEAPON = 0x1,
		ACTIONSLOTTYPE_ALTWEAPONTOGGLE = 0x2,
		ACTIONSLOTTYPE_NIGHTVISION = 0x3,
		ACTIONSLOTTYPECOUNT = 0x4,
	};

	struct ActionSlotParam_SpecifyWeapon
	{
		Weapon weapon;
	};

	struct ActionSlotParam
	{
		ActionSlotParam_SpecifyWeapon specifyWeapon;
	};

	struct $C96EA5EC2ACBB9C0BF22693F316ACC67
	{
		char r;
		char g;
		char b;
		char a;
	};

	union hudelem_color_t
	{
		$C96EA5EC2ACBB9C0BF22693F316ACC67 __s0;
		int rgba;
	};

	struct __declspec(align(4)) hudelem_s
	{
		float x;
		float y;
		float z;
		float fontScale;
		float fromFontScale;
		int fontScaleStartTime;
		hudelem_color_t color;
		hudelem_color_t fromColor;
		int fadeStartTime;
		int scaleStartTime;
		float fromX;
		float fromY;
		int moveStartTime;
		int time;
		int duration;
		float value;
		float sort;
		hudelem_color_t glowColor;
		int fxBirthTime;
		unsigned int flags;
		__int16 targetEntNum;
		__int16 fontScaleTime;
		__int16 fadeTime;
		__int16 label;
		__int16 width;
		__int16 height;
		__int16 fromWidth;
		__int16 fromHeight;
		__int16 scaleTime;
		__int16 moveTime;
		__int16 text;
		unsigned __int16 fxLetterTime;
		unsigned __int16 fxDecayStartTime;
		unsigned __int16 fxDecayDuration;
		unsigned __int16 fxRedactDecayStartTime;
		unsigned __int16 fxRedactDecayDuration;
		char type;
		char font;
		char alignOrg;
		char alignScreen;
		char materialIndex;
		char offscreenMaterialIdx;
		char fromAlignOrg;
		char fromAlignScreen;
		char soundID;
		char ui3dWindow;
	};

	struct $F5C28173AB9F55FBE8E1E7FFC8C7C9B1
	{
		hudelem_s current[31];
		hudelem_s archival[31];
	};

	struct __declspec(align(4)) PlayerVehicleState
	{
		Vec3 origin;
		Vec3 angles;
		Vec3 velocity;
		Vec3 angVelocity;
		Vec2 tilt;
		Vec2 tiltVelocity;
		float targetHeightDelta;
		float lastGroundHeight;
		int entity;
		int flags;
		bool fullPhysics;
	}; 
	
	struct __declspec(align(8)) playerState_s
	{
		int commandTime;
		int pm_type;
		int bobCycle;
		int pm_flags;
		__int64 weapFlags;
		int otherFlags;
		int pm_time;
		unsigned int loopSoundId;
		int loopSoundFade;
		Vec3 origin;
		Vec3 velocity;
		int remoteEyesEnt;
		int remoteEyesTagname;
		int remoteControlEnt;
		int weaponTime;
		int weaponDelay;
		int weaponTimeLeft;
		int weaponDelayLeft;
		int weaponIdleTime;
		int grenadeTimeLeft;
		int throwBackGrenadeOwner;
		int throwBackGrenadeTimeLeft;
		int weaponRestrictKickTime;
		bool mountAvailable;
		bool bRunLeftGun;
		bool bCarryingTurret;
		Vec3 mountPos;
		float mountDir;
		bool third_person;
		int foliageSoundTime;
		int gravity;
		float leanf;
		int speed;
		Vec3 delta_angles;
		int groundEntityNum;
		int moverEntityNum;
		int moverTimestamp;
		int groundType;
		Vec3 vLadderVec;
		int jumpTime;
		float jumpOriginZ;
		int slideTime;
		int moveType;
		int legsTimer;
		int torsoTimer;
		__int16 legsAnim;
		__int16 torsoAnim;
		int legsAnimDuration;
		int torsoAnimDuration;
		int damageTimer;
		int damageDuration;
		int dmgDirection;
		int dmgType;
		int corpseIndex;
		int movementDir;
		int eFlags;
		int eFlags2;
		PlayerVehicleState vehicleState;
		__int16 predictableEventSequence;
		__int16 predictableEventSequenceOld;
		int predictableEvents[4];
		unsigned int predictableEventParms[4];
		__int16 unpredictableEventSequence;
		__int16 unpredictableEventSequenceOld;
		int unpredictableEvents[4];
		unsigned int unpredictableEventParms[4];
		ClientNum_t clientNum;
		Weapon offHandWeapon;
		OffhandSecondaryClass offhandSecondary;
		OffhandPrimaryClass offhandPrimary;
		renderOptions_s renderOptions;
		int momentum;
		Weapon weapon;
		Weapon lastStandPrevWeapon;
		Weapon lastWeaponAltModeSwitch;
		Weapon stowedWeapon;
		char unusedCompatibilityPadding;
		Weapon meleeWeapon;
		int weaponstate;
		int weaponstateLeft;
		unsigned int weaponShotCount;
		unsigned int weaponShotCountLeft;
		float fWeaponPosFrac;
		int adsDelayTime;
		int spreadOverride;
		int spreadOverrideState;
		float weaponSpinLerp;
		int viewmodelIndex;
		Vec3 viewangles;
		int viewHeightTarget;
		float viewHeightCurrent;
		int viewHeightLerpTime;
		int viewHeightLerpTarget;
		int viewHeightLerpDown;
		Vec2 viewAngleClampBase;
		Vec2 viewAngleClampRange;
		int damageEvent;
		int damageYaw;
		int damagePitch;
		int damageCount;
		int stats[4];
		PlayerHeldWeapon heldWeapons[15];
		AmmoPool ammoNotInClip[15];
		AmmoClip ammoInClip[15];
		float proneDirection;
		float proneDirectionPitch;
		float proneTorsoPitch;
		ViewLockTypes viewlocked;
		__int16 viewlocked_entNum;
		int vehiclePos;
		int vehicleType;
		int vehicleAnimBoneIndex;
		int linkFlags;
		Vec3 linkAngles;
		int cursorHint;
		int cursorHintString;
		int cursorHintEntIndex;
		int cursorHintWeapon;
		int iCompassPlayerInfo;
		unsigned int spyplaneTypeEnabled;
		unsigned int satelliteTypeEnabled;
		int locationSelectionInfo;
		locSel_t locationSelectionType;
		SprintState sprintState;
		int lastDtpEnd;
		float fTorsoPitch;
		float fWaistPitch;
		float holdBreathScale;
		int holdBreathTimer;
		int chargeShotTimer;
		unsigned int chargeShotLevel;
		unsigned int shotsFiredFromChamber;
		float quickScopeScale;
		int quickScopeTimer;
		unsigned int clientFields;
		unsigned int clientFields2;
		unsigned int clientFields3;
		unsigned int entityStateClientFields;
		float moveSpeedScaleMultiplier;
		MantleState mantleState;
		int vehicleAnimStage;
		int vehicleEntryPoint;
		unsigned int scriptedAnim;
		int scriptedAnimTime;
		int meleeChargeEnt;
		int meleeChargeDist;
		int meleeChargeTime;
		int weapLockFlags;
		int weapLockedEntnum;
		unsigned int airburstMarkDistance;
		unsigned int perks[2];
		ActionSlotType actionSlotType[4];
		ActionSlotParam actionSlotParam[4];
		Weapon inventoryWeapon;
		__int16 wiiumoteAimX;
		__int16 wiiumoteAimY;
		char wiiuControllerType;
		char vehicleDefIndex;
		int entityEventSequence;
		int weapAnim;
		int weapAnimLeft;
		float aimSpreadScale;
		int shellshockIndex;
		int shellshockTime;
		int shellshockDuration;
		float dofNearStart;
		float dofNearEnd;
		float dofFarStart;
		float dofFarEnd;
		float dofNearBlur;
		float dofFarBlur;
		float dofViewmodelStart;
		float dofViewmodelEnd;
		int waterlevel;
		int smokeColorIndex;
		int hudElemLastAssignedSoundID;
		int adsZoomSelect;
		int adsZoomLatchTime;
		bool adsZoomLatchState;
		int adsPrevZoomSelect;
		int adsPrevZoomSelectTime;
		int artilleryInboundIconLocation;
		float visionSetLerpRatio;
		int poisoned;
		int binoculars;
		int scriptCursorHintString;
		objective_t objective[32];
		int deltaTime;
		int killCamEntity;
		int killCamTargetEntity;
		int introShotsFired;
		$F5C28173AB9F55FBE8E1E7FFC8C7C9B1 hud;
	};

	struct viewState_t
	{
		playerState_s *ps;
		int damageTime;
		int time;
		float v_dmg_pitch;
		float v_dmg_roll;
		float xyspeed;
		float frametime;
		float fLastIdleFactor;
	};

	struct outPacket_t
	{
		int p_cmdNumber;
		int p_serverTime;
		int p_realtime;
	};

	struct clSnapshot_t
	{
		int valid;
		int snapFlags;
		int serverTime;
		int physicsTime;
		int messageNum;
		int deltaNum;
		int ping;
		int cmdNum;
		playerState_s ps;
		int numEntities;
		int numClients;
		int numActors;
		int parseMatchStateIndex;
		int parseEntitiesIndex;
		int parseClientsIndex;
		int parseActorsIndex;
		int serverCommandNum;
	};

	enum StanceState
	{
		CL_STANCE_STAND = 0x0,
		CL_STANCE_CROUCH = 0x1,
		CL_STANCE_PRONE = 0x2,
		CL_STANCE_DIVE_TO_PRONE = 0x3,
	};

	struct ClientArchiveData
	{
		int serverTime;
		Vec3 origin;
		Vec3 velocity;
		int bobCycle;
		int movementDir;
		PlayerVehicleState playerVehStateClientArchive;
	};

	struct ArchivedMatchState
	{
		int matchUIVisibilityFlags;
		int bombTimer[2];
		int roundsPlayed;
		int worldFields[8];
	};

	struct UnarchivedMatchState
	{
		int teamScores[9];
		int matchUIVisibilityFlags;
		int scoreboardColumnTypes[5];
		char sideHasMeat;
		bool initialPlayersConnected;
		unsigned int talkFlags;
	};

	struct __declspec(align(8)) MatchState
	{
		int index;
		ArchivedMatchState archivedState;
		UnarchivedMatchState unarchivedState;
		unsigned int pad[1];
	};

	struct ScreenPlacement
	{
		Vec2 scaleVirtualToReal;
		Vec2 scaleVirtualToFull;
		Vec2 scaleRealToVirtual;
		Vec2 virtualViewableMin;
		Vec2 virtualViewableMax;
		Vec2 virtualTweakableMin;
		Vec2 virtualTweakableMax;
		Vec2 realViewportBase;
		Vec2 realViewportSize;
		Vec2 realViewportMid;
		Vec2 realViewableMin;
		Vec2 realViewableMax;
		Vec2 realTweakableMin;
		Vec2 realTweakableMax;
		Vec2 subScreen;
		float hudSplitscreenScale;
	};


	struct clientActive_t
	{
		MatchState *parseMatchStatesBuf;
		int numParseMatchStates;
		int maxParseMatchStates;
		void *parseEntitiesBuf;
		int numParseEntities;
		int maxParseEntities;
		void *parseClientsBuf;
		int numParseClients;
		int maxParseClients;
		void *parseActorsBuf;
		int numParseActors;
		int maxParseActors;
		outPacket_t *outPackets;
		clSnapshot_t *snapshots;
		int packetBackupCount;
		int packetBackupMask;
		int gameStateMarker;
		bool usingAds;
		int timeoutcount;
		clSnapshot_t snap;
		int snapServerTime;
		int oldSnapServerTime;
		bool alwaysFalse;
		int serverTime;
		int oldServerTime;
		int oldFrameServerTime;
		int serverTimeDelta;
		int extrapolatedSnapshot;
		int newSnapshots;
		int serverId;
		int forceNewSnapshots;
		int unpausedTimeBehind;
		int serverTimeErrorIndex;
		int serverTimeErrorCount;
		int serverTimeErrorCumul;
		int serverTimeErrorAvg;
		int serverTimeErrorPrev;
		int serverTimeError[20];
		int serverTimeError2[20];
		char mapname[64];
		int parseMatchStateIndex;
		int parseEntitiesIndex;
		int parseClientsIndex;
		int parseActorsIndex;
		bool stanceHeld;
		StanceState stance;
		StanceState stancePosition;
		int stanceTime;
		bool weapNextHeld;
		int weapNextTime;
		bool switchingToInventory;
		Weapon cgameUserCmdWeapon;
		Weapon cgameUserCmdOffHandWeapon;
		Weapon cgameUserCmdLastWeaponForAlt;
		float cgameFOVSensitivityScale;
		float cgameMaxPitchSpeed;
		float cgameMaxYawSpeed;
		Vec3 cgameKickAngles;
		Vec3 cgameOrigin;
		Vec3 cgameVelocity;
		PlayerVehicleState cgamePlayerVehState;
		int cgameBobCycle;
		int cgameMovementDir;
		int cgameExtraButton_bits[2];
		int cgamePredictedDataServerTime;
		Vec3 viewangles;
		int skelTimeStamp;
		volatile int skelMemPos;
		char skelMemory[262144];
		char *skelMemoryStart;
		bool allowedAllocSkel;
		usercmd_s cmds[128];
		int currentCmdNum;
		ClientArchiveData clientArchive[256];
		int clientArchiveIndex;
		void* entityBaselines[1024];
		int corruptedTranslationFile;
		char translationVersion[256];
		int lastFireTime;
		bool useHeld;
		int useTime;
		int useCount;
		int wasInVehicle;
		int serverFrameMS;
		int serverKbps;
		int serverKbpsAvg[2];
		int serverKbpsCount[2];

		auto user_cmd(std::uint32_t i)
		{
			return &cmds[i & 0x7F];
		}
	};

	struct __declspec(align(128)) snapshot_s
	{
		int snapFlags;
		int ping;
		int serverTime;
		int physicsTime;
		playerState_s ps;
		int numEntities;
		int numClients;
		int numActors;
		void* entities[512];
		void* clients[18];
		void* actors[32];
		__declspec(align(32)) MatchState matchState;
		unsigned __int16 entIndices[512];
		int serverCommandSequence;
	};

	struct __declspec(align(8)) cgs_t
	{
		int viewX;
		int viewY;
		int viewWidth;
		int viewHeight;
		float viewAspect;
		float sceneViewportX;
		float sceneViewportY;
		float sceneViewportWidth;
		float sceneViewportHeight;
		int serverCommandSequence;
		int processedSnapshotNum;
		int localServer;
		char gametype[32];
		char szHostName[256];
		int maxclients;
		int privateClients;
		char mappath[64];
		char mapname[32];
		int gameEndTime;
		int voteTime;
		int voteYes;
		int voteNo;
		char voteString[256];
		int redCrosshair;
		void *gameModels[512];
		void* *fxs[196];
		void* *grenadeFx[40];
		int grenadeFxCount;
		void* *playerFireFx[3];
		void* holdBreathParams;
		char teamChatMsgs[8][90];
		int teamChatMsgTimes[8];
		int teamChatPos;
		int teamLastChatPos;
		float compassWidth;
		float compassHeight;
		float compassY;
		clientInfo_t corpseinfo[4];
		void* actorCorpseInfo[8];
		bool entUpdateToggleContextKey;
		void* actorGravity[32];
	};

	struct cg_t
	{
	private:
		std::uintptr_t get_base() const {
			return std::uintptr_t(this);
		}

		template<typename T> T& get(std::uintptr_t offset) const
		{
			return *reinterpret_cast<T*>(get_base() + offset);
		}

	public:
		char pad[0x80B3C];
		int extraButton_bits[2];
		
		auto client_num() const
		{
			return get<std::uint32_t>(0);
		}
		
		auto team_scores(std::uint32_t team) const {
			return (0x2E448C80 + team * sizeof std::uint32_t + 0x6885C);
		}

		auto& equipped_offhand()
		{
			return get<std::uint32_t>(0x696CC);
		}

		auto frame_interpolation() const {
			return get<float>(0x48084);
		}

		auto frame_time() const {
			return get<std::uint32_t>(0x48088);
		}

		auto idle_factor() const {
			return get<float>(0x4AE48);
		}

		auto time() const {
			return get<std::uint32_t>(0x4808C);
		}

		auto& v_dmg_pitch() const {
			return get<float>(0x697A8);
		}

		auto& v_dmg_roll() const {
			return get<float>(0x697AC);
		}

		auto xyspeed() const {
			return get<float>(0x697B8);
		}

		auto rendering_third_person() const {
			return get<std::uint32_t>(0x480A0);
		}

		auto aim_spread_scale() const {
			return get<float>(0x80B5C);
		}

		auto refdef_view_angles() const {
			return get<Vec3>(0x648F0);
		}

		auto base_gun_angles() const {
			return get<Vec3>(0x64A2C);
		}

		auto script_main_menu() const {
			return get<std::string>(0x68754).data();
		}

		auto& view_angles() const {
			return get<Vec3>(0x19BC6C4);
		}

		auto& weapon_select() const {
			return get<Weapon>(0x69674);
		}

		auto equipped_offhand() const {
			return get<Weapon>(0x696CC);
		}

		auto shock_sensitivity() const {
			return get<float>(0x6989C);
		}

		auto& zoom_sensitivity() const {
			return get<float>(0x682C8);
		}

		auto& kick_angles() const {
			return get<Vec3>(0x697C8);
		}

		auto offset_angles() const {
			return get<Vec3>(0x697D4);
		}

		auto player_teleported() const {
			return get<std::uint32_t>(0x8134C);
		}

		auto& match_ui_flags() const {
			return get<std::uint32_t>(0x68958);
		}

		auto damage_time() const {
			return get<std::uint32_t>(0x69770);
		}

		auto damage_kick_angles() const {
			return get<Vec3>(0x64A74);
		}

		auto health() const {
			return get<std::uint32_t>(0x02C8);
		}

		auto in_killcam() const {
			return get<bool>(0x69928);
		}
		
		auto& weapon_select_time() const
		{
			return get<int>(0x69678);
		}

		auto ps() const {
			return reinterpret_cast<playerState_s*>(get_base() + 0x480A8);
		}

		auto snap() const {
			return reinterpret_cast<snapshot_s*>(*reinterpret_cast<std::uintptr_t*>(get_base() + 0x24)); 
		}

		auto new_snap() const {
			return reinterpret_cast<snapshot_s*>(*reinterpret_cast<std::uintptr_t*>(get_base() + 0x28));
		}

		auto active_snapshots() const {
			return reinterpret_cast<snapshot_s*>(get_base() + 0x80);
		}

		auto next_snapshot() const
		{
			const auto snap = this->snap() == this->active_snapshots();
			{
				return reinterpret_cast<snapshot_s*>(get_base() + 0x80 + snap * sizeof(snapshot_s));
			};
		}

		auto refdef() const {
			return reinterpret_cast<refdef_t*>(get_base() + 0x4D890);
		}

		auto client(std::size_t index) const {
			return reinterpret_cast<clientInfo_t*>(get_base() + (0x69A60 + (sizeof clientInfo_t * index)));
		}
	};

	struct trace_t
	{
		Vec3 normal;
		char pad1[0x4];
		float fraction;
		int sflags;
		char pad2[0x8];
		short hit_id;
		char pad3[0x6];
		short partgroup;
		bool allsolid;
		bool startsolid;
		char pad4[0x14];
	};

	struct BulletTraceResults
	{
		trace_t trace;
		char pad1[0x4];
		Vec3 hitPos;
		bool ignoreHitEnt;
		char pad2[0x3];
		int depthSurfaceType;
		char pad4[0x8];
	};

	struct BulletFireParams
	{
		int weaponEntIndex;
		int ignoreEntIndex;
		float damageMultiplier;
		int methodOfDeath;
		Vec3 origStart;
		Vec3 start;
		Vec3 end;
		Vec3 dir;
	};

	union DvarValue
	{
		bool enabled;
		int integer;
		unsigned int unsignedInt;
		__int64 integer64;
		unsigned __int64 unsignedInt64;
		float value;
		ImVec4 vector;
		const char *string;
		char color[4];
	};

	/* 1544 */
	struct $BFBB53559BEAC4289F32B924847E59CB
	{
		int stringCount;
		const char **strings;
	};

	/* 1545 */
	struct $9CA192F9DB66A3CB7E01DE78A0DEA53D
	{
		int min;
		int max;
	};

	/* 1546 */
	struct $5FF817DA2B223410B016B4653DEC4160
	{
		__int64 min;
		__int64 max;
	};

	/* 1547 */
	struct $251C2428A496074035CACA7AAF3D55BD
	{
		float min;
		float max;
	};

	/* 1548 */
	union DvarLimits
	{
		$BFBB53559BEAC4289F32B924847E59CB enumeration;
		$9CA192F9DB66A3CB7E01DE78A0DEA53D integer;
		$5FF817DA2B223410B016B4653DEC4160 integer64;
		$251C2428A496074035CACA7AAF3D55BD value;
		$251C2428A496074035CACA7AAF3D55BD vector;
	};

	/* 1549 */
	struct __declspec(align(8)) dvar_t
	{
		const char *name;
		const char *description;
		int hash;
		unsigned int flags;
		dvarType_t type;
		bool modified;
		DvarValue current;
		DvarValue latched;
		DvarValue reset;
		DvarLimits domain;
		dvar_t *hashNext;
	};

	enum class bdNATType : int
	{
		BD_NAT_UNKNOWN = 0,
		BD_NAT_OPEN = 1,
		BD_NAT_MODERATE = 2,
		BD_NAT_STRICT = 3
	};

	struct SpawnVar
	{
		bool spawnVarsValid;
		int numSpawnVars;
		char *spawnVars[64][2];
		int numSpawnVarChars;
		char spawnVarChars[2048];
	};

	struct EntHandle
	{
		unsigned __int16 number;
		unsigned __int16 infoIndex;
	};

	struct cached_tag_mat_t
	{
		int time;
		int entnum;
		unsigned __int16 name;
		Vec3 tagMat[4];
	};

	struct trigger_info_t
	{
		unsigned __int16 entnum;
		unsigned __int16 otherEntnum;
		int useCount;
		int otherUseCount;
	};

	struct com_parse_mark_t
	{
		int lines;
		const char *text;
		int ungetToken;
		int backup_lines;
		const char *backup_text;
	};

	struct sv_FxVisBlock_t
	{
		void *fxEnt;
		float radius;
	};

	struct actorAntilagFrame_t
	{
		Vec3 position[32];
		Vec3 angles[32];
		char useCount[32];
		char inUse[32];
		int time;
	};

	struct vehicleAntilagFrame_t
	{
		Vec3 position[16];
		Vec3 angles[16];
		char useCount[16];
		char inUse[16];
		int time;
	};

	struct level_locals_t
	{
		void *clients;
		void *gentities;
		int gentitySize;
		int num_entities;
		void *firstFreeEnt;
		void *lastFreeEnt;
		void *vehicles;
		void *firstFreeActor;
		void *lastFreeActor;
		int num_actors;
		void *sentients;
		void *actors;
		int actorCorpseCount;
		void *bots;
		void *turrets;
		int logFile;
		int initializing;
		int clientIsSpawning;
		int maxclients;
		int teamSortedClients[18];
		objective_t objectives[32];
		int objectivesClientMask[32][2];
		int framenum;
		int time;
		int previousTime;
		int frametime;
		int startTime;
		SpawnVar spawnVar;
		EntHandle droppedWeaponCue[32];
		int savepersist;
		float fFogOpaqueDist;
		float fFogOpaqueDistSqrd;
		int bPlayerIgnoreRadiusDamage;
		int bPlayerIgnoreRadiusDamageLatched;
		int currentEntityThink;
		int registerWeapons;
		int bRegisterItems;
		int bRegisterLeaderboards;
		cached_tag_mat_t cachedTagMat;
		cached_tag_mat_t cachedEntTargetTagMat;
		trigger_info_t pendingTriggerList[256];
		trigger_info_t currentTriggerList[256];
		int pendingTriggerListSize;
		int currentTriggerListSize;
		int openScriptIOFileHandles[1];
		char *openScriptIOFileBuffers[1];
		com_parse_mark_t currentScriptIOLineMark[1];
		int scriptPrintChannel;
		Vec2 compassMapUpperLeft;
		Vec2 compassMapWorldSize;
		Vec2 compassNorth;
		int finished;
		int manualNameChange;
		unsigned __int16 modelMap[512];
		int disable_grenade_suicide;
		int numConnectedClients;
		ClientNum_t sortedClients[18];
		int bUpdateScoresForIntermission;
		int numVotingClients;
		__declspec(align(32)) MatchState matchState;
		int teamScores[10];
		int lastTeammateHealthTime;
		unsigned int teamHasSpyplane[10];
		unsigned int teamHasSatellite[10];
		unsigned int teamHasMeat[10];
		char voteString[1024];
		char voteDisplayString[1024];
		int voteTime;
		int voteExecuteTime;
		int voteYes;
		int voteNo;
		int currentActorClone;
		int iSearchFrame;
		sv_FxVisBlock_t fxVisibilityEnts[32];
		int currentPlayerClone;
		bool hostMigrationActive;
		int hostMigrationStart;
		actorAntilagFrame_t actorAntilagFrames[20];
		int nextActorAntilagFrame;
		vehicleAntilagFrame_t vehicleAntilagFrames[20];
		int nextVehicleAntilagFrame;
		void *zbarrierTypes[255];
	};

	struct viewClamp
	{
		Vec2 start;
		Vec2 current;
		Vec2 goal;
	}; 
	
	struct viewClampState
	{
		viewClamp min;
		viewClamp max;
		float accelTime;
		float decelTime;
		float totalTime;
		float startTime;
	}; 
	
	enum sessionState_t
	{
		SESS_STATE_PLAYING = 0x0,
		SESS_STATE_DEAD = 0x1,
		SESS_STATE_SPECTATOR = 0x2,
		SESS_STATE_INTERMISSION = 0x3,
	}; 
	
	enum clientConnected_t
	{
		CON_DISCONNECTED = 0x0,
		CON_CONNECTING = 0x1,
		CON_CONNECTED = 0x2,
	}; 

	enum ffa_team_t
	{
		TEAM_FFA_NONE = 0x0,
		TEAM_FFA_AXIS = 0x1,
		TEAM_FFA_ALLIES = 0x2,
		TEAM_FFA_THREE = 0x3,
	};
	
	struct playerTeamState_t
	{
		int location;
	}; 
	
	struct netUInt64
	{
		unsigned int low;
		unsigned int high;
	}; 
	
	union $137F9095F7597C63EB19E8F61F5887B0
	{
		int prestige;
		int lastDaysPlayed;
	}; 
	
	union $A5847F3733B25A05995DACEFEA4A5EF0
	{
		unsigned __int64 xuid;
		netUInt64 xuid64;
	}; 
	
	union $42558DA933B613EBF7110FAC0B092AA9
	{
		unsigned __int64 leagueTeamID;
		netUInt64 leagueTeamID64;
	}; 
	
	union $507BA11C2F866A98DA37F669C2EF3B8A
	{
		unsigned __int64 leagueSubdivisionID;
		netUInt64 leagueSubdivisionID64;
	}; 
	
	enum VehicleAnimState
	{
		VEHICLEANIMSTATE_IDLE = 0x0,
		VEHICLEANIMSTATE_ENTRY = 0x1,
		VEHICLEANIMSTATE_CHANGEPOS = 0x2,
		VEHICLEANIMSTATE_EXIT = 0x3,
		VEHICLEANIMSTATECOUNT = 0x4,
	}; 
	
	struct score_s
	{
		int ping;
		int status_icon;
		int place;
		int score;
		int kills;
		int assists;
		int deaths;
		int wagerWinnings;
		int scoreboardColumns[5];
		int downs;
		int revives;
		int headshots;
		int scoreMultiplier;
		int currentStreak;
	}; 
	
	struct __declspec(align(8)) clientState_s
	{
		ClientNum_t clientIndex;
		team_t team;
		ffa_team_t ffaTeam;
		int modelindex;
		int riotShieldNext;
		int attachModelIndex[6];
		int attachTagIndex[6];
		char name[32];
		float maxSprintTimeMultiplier;
		int rank;
		$137F9095F7597C63EB19E8F61F5887B0 ___u10;
		int lastDamageTime;
		int lastStandStartTime;
		int turnedHumanTime;
		int beingRevived;
		$A5847F3733B25A05995DACEFEA4A5EF0 ___u15;
		$42558DA933B613EBF7110FAC0B092AA9 ___u16;
		int leagueDivisionID;
		$507BA11C2F866A98DA37F669C2EF3B8A ___u18;
		int leagueSubdivisionRank;
		unsigned int perks[2];
		int voiceConnectivityBits;
		char clanAbbrev[8];
		int attachedVehEntNum;
		int attachedVehSeat;
		int needsRevive;
		int clanAbbrevEV;
		VehicleAnimState vehAnimState;
		score_s score;
		int clientUIVisibilityFlags;
		int offhandWeaponVisible;
	}; 
	
	struct __declspec(align(8)) clientSession_t
	{
		sessionState_t sessionState;
		ClientNum_t forceSpectatorClient;
		int killCamEntity;
		int killCamTargetEntity;
		int archiveTime;
		unsigned __int16 scriptPersId;
		clientConnected_t connected;
		usercmd_s cmd;
		usercmd_s oldcmd;
		int localClient;
		int predictItemPickup;
		char newnetname[32];
		int maxHealth;
		int enterTime;
		playerTeamState_t teamState;
		int voteCount;
		int teamVoteCount;
		float moveSpeedScaleMultiplier;
		int viewmodelIndex;
		int noSpectate;
		int teamInfo;
		clientState_s cs;
		int psOffsetTime;
		int scoreboardColumnCache[26];
	}; 
	
	struct gclient_t
	{
		playerState_s ps;
		playerState_s lastPlayerPS;
		clientSession_t sess;
		ClientNum_t spectatorClient;
		int flags;
		int lastCmdTime;
		std::uint32_t button_bits[2];
		std::uint32_t oldbutton_bits[2];
		std::uint32_t latched_button_bits[2];
		std::uint32_t button_bitsSinceLastFrame[2];
		float fGunPitch;
		float fGunYaw;
		int damage_blood;
		Vec3 damage_from;
		int damage_fromWorld;
		int inactivityTime;
		int inactivityWarning;
		int lastVoiceTime;
		int outWaterTime;
		int switchSeatTime;
		float currentAimSpreadScale;
		int dropWeaponTime;
		EntHandle pLookatEnt;
		ImVec4 prevLinkedInvQuat;
		bool prevLinkAnglesSet;
		bool link_doCollision;
		bool link_useTagAnglesForViewAngles;
		bool link_useBaseAnglesForViewClamp;
		float linkAnglesFrac;
		viewClampState link_viewClamp;
		EntHandle useHoldEntity;
		int useHoldTime;
		int useButtonDone;
		int iLastCompassPlayerInfoEnt;
		int compassPingTime;
		int damageTime;
		float v_dmg_roll;
		float v_dmg_pitch;
		Vec3 swayViewAngles;
		Vec3 swayOffset;
		Vec3 swayAngles;
		Vec3 baseAngles;
		Vec3 baseOrigin;
		Vec3 recoilAngles;
		float fLastIdleFactor;
		int weaponIdleTime;
		Vec3 recoilSpeed;
		int previousRecoilTime;
		float previousRecoilRatio;
		int lastServerTime;
		int lastSpawnTime;
		Weapon lastWeapon;
		bool previouslyFiring;
		bool previouslyUsingNightVision;
		bool previouslyDTP;
		bool previouslyBeganWeaponRaise;
		bool previouslySprinting;
		unsigned int hasSpyplane;
		unsigned int hasSatellite;
		int revive;
		int reviveTime;
		int disallowVehicleUsage;
		unsigned __int16 attachShieldTagName;
		int lastStand;
		int lastStandTime;
	}; 

	struct entityShared_t
	{
		char linked;
		char bmodel;
		char svFlags;
		char inuse;
		int broadcastTime;
		Vec3 mins;
		Vec3 maxs;
		int contents;
		Vec3 absmin;
		Vec3 absmax;
		Vec3 currentOrigin;
		Vec3 currentAngles;
		EntHandle ownerNum;
		int eventTime;
	};

	struct gentity_t;
	
	struct flame_timed_damage_t
	{
		gentity_t *attacker;
		int damage;
		float damageDuration;
		float damageInterval;
		int start_timestamp;
		int end_timestamp;
		int lastupdate_timestamp;
	};
	
	union $D054511B64C7859A2972E5005FF506FD
	{
		int a;
	};
	
	struct $8B2B5A2D6EB549120AB558355B552286
	{
		unsigned __int16 notifyString;
		unsigned int index;
		char stoppable;
		int basetime;
		int duration;
	};
	
	struct gentity_t
	{
		char pad[0x31C];
	};

	enum svscmd_type
	{
		SV_CMD_CAN_IGNORE = 0x0,
		SV_CMD_RELIABLE = 0x1,
	};

	struct __declspec(align(4)) PartyMessages
	{
		const char *string;
		void(__cdecl *func)(PartyData_s *, ControllerIndex_t, netadr_t, msg_t *);
		bool verbose;
	};

	struct MigrationMessage
	{
		const char *string;
		void(__cdecl *func)(LocalClientNum_t, netadr_t, msg_t *);
	};

	struct svscmd_info_t
	{
		char *cmd;
		int time;
		int type;
	};

	/* 3667 */
	struct clientSnapshot_t
	{
		playerState_s ps;
		int entityCount;
		int clientCount;
		int actorCount;
		int matchStateIndex;
		int firstEntityIndex;
		int firstClientIndex;
		int firstActorIndex;
		int messageSent;
		int messageAcked;
		int messageSize;
		int serverTime;
		int physicsTime;
		int timeDelta;
		int baselineSnap;
	}; 
	
	struct PredictedVehicleDef
	{
		bool fullPhysics;
		Vec3 origin;
		Vec3 angles;
		Vec3 tVel;
		Vec3 aVel;
		int serverTime;
	}; 
	
	struct clientHeader_t
	{
		int state;
		int sendAsActive;
		int deltaMessage;
		int rateDelayed;
		int hasAckedBaselineData;
		int hugeSnapshotSent;
		netchan_t netchan;
		Vec3 predictedOrigin;
		int predictedOriginServerTime;
		int migrationState;
		PredictedVehicleDef predictedVehicle;
	}; 
	
	struct client_t
	{
		clientHeader_t header;
		const char *dropReason;
		char userinfo[1024];
		char reliableCommandBuffer[16384];
		int reliableCommandBufferNext;
		svscmd_info_t reliableCommandInfo[128];
		int reliableSequence;
		int reliableAcknowledge;
		int reliableSent;
		int messageAcknowledge;
		int gamestateMessageNum;
		int challenge;
		usercmd_s lastUsercmd;
		int lastClientCommand;
		char lastClientCommandString[1024];
		gentity_t *gentity;
		char name[32];
		char clanAbbrev[5];
		int clanAbbrev_IsEliteValidated;
		unsigned __int64 xuid;
		unsigned __int64 teamid;
		unsigned int doubleXPGroupMask;
		int nextReliableTime;
		int nextReliableCount;
		char reservedSlot;
		int lastPacketTime;
		int lastConnectTime;
		int nextSnapshotTime;
		int lastSnapshotTime;
		int timeoutCount;
		clientSnapshot_t frames[16];
		int ping;
		int pingMin;
		int pingMax;
		int unackCount;
		int rate;
		int pureAuthentic;
		int packetUploadCount;
		__declspec(align(128)) char netchanOutgoingBuffer[65536];
		char netchanIncomingBuffer[2048];
		int guid;
		unsigned __int16 scriptId;
		bool bIsSplitscreenClient;
		bool bIsSecondScreenClient;
		int bIsTestClient;
		int serverId;
		int natType;
		char stats[50176];
		char purchasedItems[32];
		int unlockedAttachments[64];
		char bonusCardsActive[10];
		char modifiedStatBytes[6272];
		int statsSentIndex;
		int statsModified;
		__int64 statPacketsReceived;
		int statsValidated;
		bool liveAuthorized;
		int liveAuthFlags;
		char liveAuthFailCount;
		int liveAuthTimestamp;
		unsigned __int64 liveUserID;
		bool tempPacketDebugging;
		int snapshotHistoryTime;
		int snapshotHistoryFrames;
		int messageHistorySize;
		int demoPacketCount;
		int demoPacketSizes[8];
		int demoPacketIsFragment[8];
		int demoReliableCmdSize;
		unsigned int lastHashedXP;
		int lastSmallDeltaTime;
		int lastSnapSentTime;
	};

	struct ucmd_t
	{
		char *name;
		void(__cdecl *func)(client_t *);
		int allowFromOldServer;
	};

	struct des_key
	{
		unsigned int ek[32];
		unsigned int dk[32];
	};
	
	struct blowfish_key
	{
		unsigned int S[4][256];
		unsigned int K[18];
	};
	
	struct des3_key
	{
		unsigned int ek[3][32];
		unsigned int dk[3][32];
	};
	
	struct rijndael_key
	{
		unsigned int eK[60];
		unsigned int dK[60];
		int Nr;
	};
	
	union Symmetric_key
	{
		des_key des;
		des3_key des3;
		blowfish_key blowfish;
		rijndael_key rijndael;
		void *data;
	};
	
	struct symmetric_CTR
	{
		int cipher;
		int blocklen;
		int padlen;
		int mode;
		int ctrlen;
		char ctr[128];
		char pad[128];
		Symmetric_key key;
	};
	
	struct yarrow_prng
	{
		int cipher;
		int hash;
		char pool[128];
		symmetric_CTR ctr;
	}; 
	
	union prng_state
	{
		char dummy[1];
		yarrow_prng yarrow;
	};
	
	struct ltc_prng_descriptor
	{
		char *name;
		int export_size;
		int(__cdecl *start)(prng_state *);
		int(__cdecl *add_entropy)(const char *, unsigned int, prng_state *);
		int(__cdecl *ready)(prng_state *);
		unsigned int(__cdecl *read)(char *, unsigned int, prng_state *);
		int(__cdecl *done)(prng_state *);
		int(__cdecl *pexport)(char *, unsigned int *, prng_state *);
		int(__cdecl *pimport)(const char *, unsigned int, prng_state *);
		int(__cdecl *test)();
	};

	struct ecc_point
	{
		void *x;
		void *y;
		void *z;
	};
	
	struct ltc_ecc_set_type
	{
		int size;
		char *name;
		char *prime;
		char *B;
		char *order;
		char *Gx;
		char *Gy;
	};
	
	struct ecc_key
	{
		int type;
		int idx;
		ltc_ecc_set_type *dp;
		ecc_point pubkey;
		void *k;
	};

	enum statsLocation
	{
		STATS_LOCATION_NORMAL = 0x0,
		STATS_LOCATION_FORCE_NORMAL = 0x1,
		STATS_LOCATION_BACKUP = 0x2,
		STATS_LOCATION_STABLE = 0x3,
		STATS_LOCATION_OTHERPLAYER = 0x4,
		STATS_LOCATION_COUNT = 0x5,
	};
	
	struct persistentStats
	{
		char statsBuffer[50176];
		bool isChecksumValid;
		bool statsWriteNeeded;
		bool statsValidatedWithDDL;
		bool statsFetched;
		bool disableUpload;
	};

	struct MapnameRichPresenceInfo
	{
		const char *mapname;
		int context;
		int mapPack;
		const char *locString;
	};

	enum ProberMode
	{
		PROBER_UNDEFINED = 0x0,
		PROBER_SEARCH = 0x1,
		PROBER_MERGE = 0x2,
		PROBER_INVITE = 0x3,
		PROBER_NEWLOBBY = 0x4,
		PROBER_CLIENT = 0x5,
	};

	enum ProberState
	{
		STATE_IDLE = 0x0,
		STATE_WAITING_FOR_HOSTS = 0x1,
		STATE_QOS_IN_PROGRESS = 0x2,
		STATE_QOS_COMPLETE = 0x3,
		STATE_ASSOCIATING = 0x4,
		STATE_HANDSHAKING = 0x5,
		STATE_HOST_FAILED = 0x6,
		STATE_NO_HOSTS = 0x7,
		STATE_SEARCH_EXHAUSTED = 0x8,
		STATE_CLIENT_ASSOCIATING = 0x9,
		STATE_CLIENT_HANDSHAKING = 0xA,
		STATE_CLIENT_CONNECTED = 0xB,
		STATE_CLIENT_FAILED = 0xC,
		STATE_HOST_ACCEPT = 0xD,
		STATE_CLIENTS_AGREE = 0xE,
		STATE_ALL_IN = 0xF,
		STATE_ERROR = 0x10,
	};

	enum searchSessionMode_t
	{
		SEARCH_SESSION_MODE_INVALID = 0x0,
		SEARCH_SESSION_MODE_PUBLIC = 0x1,
		SEARCH_SESSION_MODE_LEAGUE = 0x2,
		SEARCH_SESSION_MODE_LOBBY_MERGE = 0x3,
		SEARCH_SESSION_MODE_DEDICATED_SERVER = 0x4,
		SEARCH_SESSION_MODE_COUNT = 0x5,
	};

	struct __declspec(align(8)) PartyInfo
	{
		int flags;
		XSESSION_INFO info;
		netadr_t serverAddr;
		int occupiedPublicSlots;
		int occupiedPrivateSlots;
		int numPublicSlots;
		int numPrivateSlots;
		float skill;
		int geo1;
		int geo2;
		int geo3;
		int geo4;
		int ping;
		int avgPing;
		unsigned __int64 xuid;
		int upload;
	};

	struct PartyProber
	{
		PartyInfo hosts[50];
		int hostCount;
		ProberMode mode;
		ProberState state;
		ControllerIndex_t controllerIndex;
		int partyId;
		PartyData_s *partyToNotify;
		searchSessionMode_t searchMode;
		int minPlayers;
		int requiredFlags;
		int searchStartUTC;
		netadr_t masterAddr;
		int echoChallenge;
		PartyInfo echoHost;
		int echoHostNum;
		int clientDisagreeTime[18];
		int clientAgreeTime[18];
		int clientPacketTime;
		int clientWaitStart;
		int hostIndex;
		netadr_t hostAddr;
		unsigned int hostChallenge;
		int hostNum;
		int nextSearchTime;
		int packetStartTime;
		int packetRecvTime;
		int packetSendTime;
		int retryCount;
		char errorMessage[256];
	};

	struct qosPayload_t
	{
		int protocol;
		int isMP;
		int isMigrating;
		int numAvailableSlots;
		int maxLocalPlayersAllowed;
		int allowGuests;
		int isMatchEnding;
		int isLoading;
		int isDedicated;
		unsigned __int64 xuid;
	};

	struct serverStatusInfoResponse_t
	{
		char string[20480];
		netadr_t address;
		int time;
		int startTime;
		int pending;
		int print;
		int retrieved;
		bdSecurityID secId;
	};

	enum XAssetType
	{
		ASSET_TYPE_XMODELPIECES = 0x0,
		ASSET_TYPE_PHYSPRESET = 0x1,
		ASSET_TYPE_PHYSCONSTRAINTS = 0x2,
		ASSET_TYPE_DESTRUCTIBLEDEF = 0x3,
		ASSET_TYPE_XANIMPARTS = 0x4,
		ASSET_TYPE_XMODEL = 0x5,
		ASSET_TYPE_MATERIAL = 0x6,
		ASSET_TYPE_TECHNIQUE_SET = 0x7,
		ASSET_TYPE_IMAGE = 0x8,
		ASSET_TYPE_SOUND = 0x9,
		ASSET_TYPE_SOUND_PATCH = 0xA,
		ASSET_TYPE_CLIPMAP = 0xB,
		ASSET_TYPE_CLIPMAP_PVS = 0xC,
		ASSET_TYPE_COMWORLD = 0xD,
		ASSET_TYPE_GAMEWORLD_SP = 0xE,
		ASSET_TYPE_GAMEWORLD_MP = 0xF,
		ASSET_TYPE_MAP_ENTS = 0x10,
		ASSET_TYPE_GFXWORLD = 0x11,
		ASSET_TYPE_LIGHT_DEF = 0x12,
		ASSET_TYPE_UI_MAP = 0x13,
		ASSET_TYPE_FONT = 0x14,
		ASSET_TYPE_FONTICON = 0x15,
		ASSET_TYPE_MENULIST = 0x16,
		ASSET_TYPE_MENU = 0x17,
		ASSET_TYPE_LOCALIZE_ENTRY = 0x18,
		ASSET_TYPE_WEAPON = 0x19,
		ASSET_TYPE_WEAPONDEF = 0x1A,
		ASSET_TYPE_WEAPON_VARIANT = 0x1B,
		ASSET_TYPE_WEAPON_FULL = 0x1C,
		ASSET_TYPE_ATTACHMENT = 0x1D,
		ASSET_TYPE_ATTACHMENT_UNIQUE = 0x1E,
		ASSET_TYPE_WEAPON_CAMO = 0x1F,
		ASSET_TYPE_SNDDRIVER_GLOBALS = 0x20,
		ASSET_TYPE_FX = 0x21,
		ASSET_TYPE_IMPACT_FX = 0x22,
		ASSET_TYPE_AITYPE = 0x23,
		ASSET_TYPE_MPTYPE = 0x24,
		ASSET_TYPE_MPBODY = 0x25,
		ASSET_TYPE_MPHEAD = 0x26,
		ASSET_TYPE_CHARACTER = 0x27,
		ASSET_TYPE_XMODELALIAS = 0x28,
		ASSET_TYPE_RAWFILE = 0x29,
		ASSET_TYPE_STRINGTABLE = 0x2A,
		ASSET_TYPE_LEADERBOARD = 0x2B,
		ASSET_TYPE_XGLOBALS = 0x2C,
		ASSET_TYPE_DDL = 0x2D,
		ASSET_TYPE_GLASSES = 0x2E,
		ASSET_TYPE_EMBLEMSET = 0x2F,
		ASSET_TYPE_SCRIPTPARSETREE = 0x30,
		ASSET_TYPE_KEYVALUEPAIRS = 0x31,
		ASSET_TYPE_VEHICLEDEF = 0x32,
		ASSET_TYPE_MEMORYBLOCK = 0x33,
		ASSET_TYPE_ADDON_MAP_ENTS = 0x34,
		ASSET_TYPE_TRACER = 0x35,
		ASSET_TYPE_SKINNEDVERTS = 0x36,
		ASSET_TYPE_QDB = 0x37,
		ASSET_TYPE_SLUG = 0x38,
		ASSET_TYPE_FOOTSTEP_TABLE = 0x39,
		ASSET_TYPE_FOOTSTEPFX_TABLE = 0x3A,
		ASSET_TYPE_ZBARRIER = 0x3B,
		ASSET_TYPE_COUNT = 0x3C,
		ASSET_TYPE_STRING = 0x3C,
		ASSET_TYPE_ASSETLIST = 0x3D,
		ASSET_TYPE_REPORT = 0x3E,
		ASSET_TYPE_DEPEND = 0x3F,
		ASSET_TYPE_FULL_COUNT = 0x40,
	};

	union XAssetHeader
	{
		void *xmodelPieces;
		void *physPreset;
		void *physConstraints;
		void *destructibleDef;
		void *parts;
		void *model;
		Material *material;
		void *pixelShader;
		void *vertexShader;
		void *techniqueSet;
		void *image;
		void *sound;
		void *soundPatch;
		void *clipMap;
		void *comWorld;
		void *gameWorldSp;
		void *gameWorldMp;
		void *mapEnts;
		void *gfxWorld;
		void *lightDef;
		void *font;
		void *fontIcon;
		void *menuList;
		void *menu;
		void *localize;
		void *weapon;
		void *attachment;
		void *attachmentUnique;
		void *weaponCamo;
		void *sndDriverGlobals;
		void *fx;
		void *impactFx;
		void *rawfile;
		void *stringTable;
		void *leaderboardDef;
		void *xGlobals;
		void *ddlRoot;
		void *glasses;
		void *textureList;
		void *emblemSet;
		void *scriptParseTree;
		void *keyValuePairs;
		void *vehicleDef;
		void *memoryBlock;
		void *addonMapEnts;
		void *tracerDef;
		void *skinnedVertsDef;
		void *qdb;
		void *slug;
		void *footstepTableDef;
		void *footstepFXTableDef;
		void *zbarrierDef;
		void *data;
	};

	struct XAsset
	{
		XAssetType type;
		XAssetHeader header;
	};

	struct XAssetEntry
	{
		XAsset asset;
		char zoneIndex;
		bool inuse;
		unsigned __int16 nextHash;
		unsigned __int16 nextOverride;
		unsigned __int16 usageFrame;
	}; 
	
	union XAssetEntryPoolEntry
	{
		XAssetEntry entry;
		XAssetEntryPoolEntry *next;
	};

	typedef XAssetEntryPoolEntry XAssetEntryPool[37900];
}
