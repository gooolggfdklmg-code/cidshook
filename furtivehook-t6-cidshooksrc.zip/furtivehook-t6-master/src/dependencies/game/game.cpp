﻿#include "dependencies/std_include.hpp"
#include "game.hpp"

namespace game
{
	std::unordered_map<std::string, bool> handlers;
	std::array<scr_string_t, static_cast<std::size_t>(bone_tag::num_tags)> bone_tags;
	std::vector<std::string> map_names;
	PartyData_s* party = nullptr;

	namespace oob
	{
		bool send_data(const game::netadr_t& target, const std::string& data)
		{
			return NET_SendPacket(NS_SERVER, data.size(), data.data(), target);
		}

		bool send(const game::netadr_t& target, const std::string& data)
		{
			const auto packet{ "\xFF\xFF\xFF\xFF" + data };
			return send_data(target, packet);
		}
	}
	
	void initialize()
	{
		for (size_t i = 2; i < 0x20; ++i)
			map_names.emplace_back(map_handler[i].mapname);

		for (size_t i = 0; i < 6; ++i)
			handlers[migrate_handler[i].string];

		for (size_t i = 0; i < 4; ++i)
		{
			handlers[party_migrate_handler[i].string];
			handlers[sv_migrate_handler[i].string];
		}

		handlers["connectResponseMigration"] = true;
		handlers["fastrestart"] = true;
		handlers["loadingnewmap"] = true;
		handlers["go"] = true;
		handlers["rejoin"] = true;

		handlers["echo"];
		handlers["newClientState"];
		handlers["playdemo"];
		handlers["print"];
		//handlers["rcon"];
		handlers["requeststats"];
		handlers["RA"];
		handlers["b"];

		bone_tags[static_cast<std::size_t>(bone_tag::helmet)] = GScr_AllocString("j_helmet");
		bone_tags[static_cast<std::size_t>(bone_tag::head_end)] = GScr_AllocString("j_head_end");
		bone_tags[static_cast<std::size_t>(bone_tag::head)] = GScr_AllocString("j_head");
		bone_tags[static_cast<std::size_t>(bone_tag::neck)] = GScr_AllocString("j_neck");
		bone_tags[static_cast<std::size_t>(bone_tag::shoulder_left)] = GScr_AllocString("j_shoulder_le");
		bone_tags[static_cast<std::size_t>(bone_tag::shoulder_right)] = GScr_AllocString("j_shoulder_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::clavicle_left)] = GScr_AllocString("j_clavicle_le");
		bone_tags[static_cast<std::size_t>(bone_tag::clavicle_right)] = GScr_AllocString("j_clavicle_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::spineupper)] = GScr_AllocString("j_spineupper");
		bone_tags[static_cast<std::size_t>(bone_tag::spine)] = GScr_AllocString("j_spine4");
		bone_tags[static_cast<std::size_t>(bone_tag::spinelower)] = GScr_AllocString("j_spinelower");
		bone_tags[static_cast<std::size_t>(bone_tag::hip_left)] = GScr_AllocString("j_hip_le");
		bone_tags[static_cast<std::size_t>(bone_tag::hip_right)] = GScr_AllocString("j_hip_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::knee_left)] = GScr_AllocString("j_knee_le");
		bone_tags[static_cast<std::size_t>(bone_tag::knee_right)] = GScr_AllocString("j_knee_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_left)] = GScr_AllocString("j_wrist_le");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_right)] = GScr_AllocString("j_wrist_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_twist_left)] = GScr_AllocString("j_wristtwist_le");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_twist_right)] = GScr_AllocString("j_wristtwist_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_left)] = GScr_AllocString("j_elbow_le");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_right)] = GScr_AllocString("j_elbow_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_buldge_left)] = GScr_AllocString("j_elbow_bulge_le");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_buldge_right)] = GScr_AllocString("j_elbow_bulge_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::ankle_left)] = GScr_AllocString("j_ankle_le");
		bone_tags[static_cast<std::size_t>(bone_tag::ankle_right)] = GScr_AllocString("j_ankle_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::ball_left)] = GScr_AllocString("j_ball_le");
		bone_tags[static_cast<std::size_t>(bone_tag::ball_right)] = GScr_AllocString("j_ball_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::mainroot)] = GScr_AllocString("j_mainroot");

		exception::initialize();
		security::initialize();
		rendering::initialize();
		steam::initialize();
		events::initialize();
		network::initialize();
		nospread::initialize();
		obituary::initialize();
		exploits::initialize();
		server_command::initialize();
		localized_strings::initialize();
		scheduler::start_thread();
		command::initialize();
		stats::initialize();
		autowall::initialize();
		session::initialize();

		PRINT_LOG("Initialized!");
	}

	bool send_unhandled_message(const std::string& command, const netadr_t& target)
	{
		if (const auto client_num = find_target_from_addr(target); client_num >= 0)
		{
			const auto pm = party->party_member(client_num);

			PRINT_LOG("Received unhandled [%s] OOB from '%s' (%llu) (%s) ..",
				command.data(),
				pm->gamertag,
				pm->player,
				utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data());
		}
		else
		{
			platformNetAdr adr = {};
			if (Party_NetAdrToPlatformNetAdr(target, &adr))
			{
				PRINT_LOG("Received unhandled [%s] OOB from (%s) ..",
					command.data(),
					utils::string::adr_to_string(adr).data());
			}
		}

		return true;
	}

	int find_target_from_addr(const netadr_t& from)
	{
		if (const auto client_num = Party_FindMember(party, from); client_num >= 0 && party->party_member(client_num)->status >= PARTYSTATUS_PRESENT)
		{
			return client_num;
		}

		for (size_t i = 0; i < 18; i++)
		{
			platformNetAdr adr = {};
			if (Party_NetAdrToPlatformNetAdr(from, &adr))
			{
				auto xnaddr = party->party_member(i)->platformAddr.liveaddr.xnaddr;

				if (NET_CompareXNAddr(&adr.liveaddr.xnaddr, &xnaddr))
				{
					return i;
				}
			}
		}

		return -1;
	}

	int Party_FindMemberByXUID(const std::uint64_t player)
	{
		return reinterpret_cast<int(*)(PartyData_s*, const std::uint64_t)>(0x00673F60)(party, player);
	}

	connstate_t& CL_GetLocalClientConnectionState(/*LocalClientNum_t localClientNum*/) {
		return *reinterpret_cast<connstate_t*>(offsets::cls_state);
	}

	clientMigState_t& CL_GetLocalClientMigrationState(/*LocalClientNum_t localClientNum*/) {
		return *reinterpret_cast<clientMigState_t*>(offsets::mig_state);
	}

	float get_weapon_damage_range(const Weapon& weapon)
	{
		if (const auto weap_def = BG_GetWeaponDef(weapon); weap_def->weapClass == WEAPCLASS_SPREAD || weap_def->weapClass == WEAPCLASS_PISTOL_SPREAD)
		{
			return BG_GetDamageRangeScale(weapon) * weap_def->damageRange[5];
		}

		return sv_bullet_range->current.value;
	}

	void fast_reload(playerState_s* ps)
	{
		const auto weapon = BG_GetViewmodelWeaponIndex(ps);
		static auto reloaded_weapon = 0u;
		
		if (reloaded_weapon)
		{
			for (const auto& slot : ps->heldWeapons)
			{
				if (slot.weapon != reloaded_weapon)
				{
					CG_CycleWeapon(0, 0);
					break;
				}
			}

			reloaded_weapon = 0;
		}

		if (aimbot::is_reloading(ps) && current_ammo_equal_to_clip_size(ps, weapon))
		{
			reloaded_weapon = weapon;

			for (const auto& slot : ps->heldWeapons)
			{
				if (slot.weapon != reloaded_weapon)
				{
					CG_CycleWeapon(0, 0);
					break;
				}
			}
		}
	}

	bool BG_CheckIfDualWieldEmpty(const playerState_s* ps, Weapon weapon)
	{
		return BG_GetAmmoInClip(ps, weapon) == BG_GetClipSize(weapon) || !BG_GetAmmoNotInClip(ps, weapon);
	}

	bool current_ammo_equal_to_clip_size(const playerState_s* ps, Weapon weapon)
	{
		return BG_CheckIfDualWieldEmpty(ps, BG_GetDualWieldWeapon(weapon)) 
			&& BG_GetAmmoInClip(ps, weapon) == BG_GetClipSize(weapon) 
			|| !BG_GetAmmoNotInClip(ps, weapon);
	}

	bool is_valid_target(const size_t client_num)
	{
		if(party)
			return CL_LocalClientIsInGame() ? cg()->client(client_num)->valid() : party->session->dyn.users[client_num].registered;

		return false;
	}

	bool is_enemy(size_t client_num)
	{
		if (cg()->client(client_num)->team() == TEAM_FREE)
		{
			return true;
		}

		return cg()->client(client_num)->team() != cg()->client(cg()->client_num())->team();
	}

	bool is_friend(std::size_t client_num)
	{
		if (const auto our_client_num = Party_FindMemberByXUID(Live_GetXuid(0)); our_client_num == client_num)
		{
			return false;
		}

		const auto xuid = CL_LocalClientIsInGame() ? party->session->dyn.users[client_num].xuid :
			party->party_member(client_num)->player;

		for (const auto& friends : friends::friends)
		{
			if (friends.xuid == xuid || Friends_IsFriendByID(0, xuid))
			{
				return true;
			}
		}

		return false;
	}

	void set_fov(const float fov)
	{
		Dvar_FindVar("cg_fov_default_thirdperson")->current.value = fov;
		Dvar_FindVar("cg_fov")->current.value = fov;
	}

	void cycling_prestige()
	{
		if (CL_GetLocalClientConnectionState() == CA_DISCONNECTED)
		{
			if (misc::cycling_prestige)
			{
				static auto prestige = 0u;
				if (++prestige > 0x10)
				{
					prestige = 0;
				}

				stats::set_prestige(prestige);
			}
		}
	}

	void spectator_client_handler()
	{
		if (!SV_Loaded())
		{
			return;
		}

		for (auto i = 0u; i < 18u; ++i)
		{
			const auto client = gclient(i);

			if (client && client->sess.sessionState == SESS_STATE_SPECTATOR && !client->spectatorClient && !client->ps.killCamEntity)
			{
				CG_GameMessage(0, utils::string::va("%s is spectating you!", client->sess.cs.name));
			}
		}
	}

	void anti_leave()
	{
		static auto allow_leave = false;

		if (misc::anti_leave)
		{
			allow_leave = true; 
			
			game::send_server_command(-1, "^ 12 aaaa");
		}
		else if (allow_leave)
		{
			allow_leave = false; 
			
			game::send_server_command(-1, "^ 12 class");
		}
	}

	void on_every_frame()
	{
		aimbot::run(cg()->ps());
		esp::visuals();
		fast_reload(cg()->ps());
	}

	bool is_packet_from_host(const netadr_t& from)
	{
		return NET_CompareAdr(party->currentHost.addr, from) 
			|| NET_CompareAdr(party->potentialHost.addr, from) 
			|| from.type == NA_LOOPBACK && party->are_we_host();
	}

	void send_host_crashes(const int index)
	{
		scheduler::once([=]()
		{
			game::send_server_command(index, "; \"^H\xef\xbf\xbd\xef\xbf\xbd\x0a\"");
			game::send_server_command(index, "D 0 1234567");

			std::this_thread::sleep_for(500ms);

			game::send_server_command(index, "7 -1234567 -1234567");
			game::send_server_command(index, "\\ -1");
			game::send_server_command(index, "0 -1234567 aaaaaaaaaa");
			game::send_server_command(index, "i -1234567890 6872128");
			game::send_server_command(index, "D -1234567");
			game::send_server_command(index, "2 3 -1234567");
		}, scheduler::pipeline::async);
	}

	float BG_EvaluateTrajectoryInternal(const trajectory_t* tr, std::uint32_t time, Vec3& result, float scale)
	{
		static constexpr auto address = 0x0047F7A0;
		auto actual_result = 0.0f;

		__asm
		{
			fld scale;

			push result;
			push time;
			push tr;
			call address;
			add esp, 12;

			fstp actual_result;
		}

		return actual_result;
	}

	void adjust_user_cmd_movement(usercmd_s* cmd_old, const float angle, const float old_angle)
	{
		const auto delta_view = DEG2RAD(angle - old_angle);

		cmd_old->forwardmove = ClampChar(static_cast<int>(std::cosf(delta_view) * cmd_old->forwardmove - std::sinf(delta_view) * cmd_old->rightmove));
		cmd_old->rightmove = ClampChar(static_cast<int>(std::sinf(delta_view) * cmd_old->forwardmove + std::cosf(delta_view) * cmd_old->rightmove));
	}

	bool can_parse_party_state(const char* command, const std::uint8_t segment, const std::uint32_t total_size, const std::uint16_t offset, const std::uint16_t size)
	{
		if (size > 1200 || offset + size > total_size || offset + size > 7200 || total_size > 7200)
		{
			const std::unordered_map<std::string, std::pair<std::uint32_t, std::uint32_t>> msgs =
			{
				{"segment", std::pair<std::uint32_t, std::uint32_t>(segment, 5)},
				{"size", std::pair<std::uint32_t, std::uint32_t>(size, 1200)},
				{"offset + size", std::pair<std::uint32_t, std::uint32_t>(offset + size, total_size)},
				{"total_size", std::pair<std::uint32_t, std::uint32_t>(total_size, 7200)},
			};

			for (const auto& msg : msgs)
			{
				PRINT_LOG("[%s] [%s]: [%u] [%u]", command, msg.first.data(), msg.second.first, msg.second.second);
			}

			return false;
		}

		return true;
	}

	bool can_attempt_to_join_party(const char* command, const std::uint32_t net_version, const std::uint32_t net_field_checksum, const std::uint32_t playlist_version_number, const std::uint32_t change_list, const std::uint32_t new_sub_party_count)
	{
		if (net_version != 2091 || net_field_checksum != net_field_checksum
			|| playlist_version_number != playlist_version_number
			|| change_list != 0x1CF6F4 || new_sub_party_count >= 18)
		{
			const std::unordered_map<std::string, std::pair<std::uint32_t, std::uint32_t>> msgs =
			{
				{"net_version", std::pair<std::uint32_t, std::uint32_t>(net_version, 2091)},
				{"net_field_checksum", std::pair<std::uint32_t, std::uint32_t>(net_field_checksum, net_field_checksum)},
				{"playlist_version", std::pair<std::uint32_t, std::uint32_t>(playlist_version_number, playlist_version_number)},
				{"change_list", std::pair<std::uint32_t, std::uint32_t>(change_list, 0x1CF6F4)},
				{"new_sub_party_count", std::pair<std::uint32_t, std::uint32_t>(new_sub_party_count, 17)},
			};

			for (const auto& msg : msgs)
			{
				PRINT_LOG("[%s] [%s]: [%u] [%u]", command, msg.first.data(), msg.second.first, msg.second.second);
			}

			return false;
		}

		return true;
	}

	bool can_process_fragment(const netchan_t* chan, const msg_t* msg, const std::uint8_t fragment_index, const std::uint16_t fragment_size, const std::uint16_t fragment_length)
	{
		if (msg->readcount + fragment_length > msg->cursize)
		{
			return false;
		}

		if (chan->fragmentLength + fragment_length > chan->fragmentBufferSize)
		{
			return false;
		}
		
		if ((fragment_index * fragment_size + fragment_length) > chan->fragmentBufferSize)
		{
			return false;
		}

		return true;
	}

	bool send_exploit_caught_messages(const std::string& command, const netadr_t& target)
	{
		if (const auto client_num = find_target_from_addr(target); client_num >= 0)
		{
			const auto pm = party->party_member(client_num);

			open_toast_popup(
				utils::string::va("Exploit attempt caught!\nFrom: '%s' (%llu) (%s)",
					pm->gamertag,
					pm->player,
					utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data()));

			PRINT_LOG("Exploit attempt caught! [%s] from '%s' (%llu) (%s)",
				command.data(),
				pm->gamertag,
				pm->player,
				utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data());
		}
		else
		{
			platformNetAdr adr = {};
			if (Party_NetAdrToPlatformNetAdr(target, &adr))
			{
				open_toast_popup(
					utils::string::va("Exploit attempt caught!\nFrom: (%s)",
						utils::string::adr_to_string(adr).data()));

				PRINT_LOG("Exploit attempt caught! [%s] from (%s)",
					command.data(),
					utils::string::adr_to_string(adr).data());
			}
		}

		PRINT_BOLD_MESSAGE("Exploit attempt caught!");

		return true;
	}

	void change_name(const std::string& name, const std::string& clan_tag)
	{
		auto buffer = ""s;
		buffer.append("userinfo \"");
		buffer.append("\\name\\"s + (name.empty() ? CL_ControllerIndex_GetUsername(0) : name));
		buffer.append("\x14");

		if (!clan_tag.empty())
		{
			buffer.append("\\clanabbrev\\" + clan_tag + "\"");
		}
		else
		{
			buffer.append("\"");
		}

		CL_AddReliableCommand(0, buffer.data());
	}

	bool is_bot(size_t index)
	{
		return party->party_member(index)->platformAddr.netAddr.type == NA_BOT;
	}

	bool is_party_privacy_closed()
	{
		const auto party_privacy = GamerProfile_GetInt(34u, 0);
		return party_privacy == 3;
	}

	bool recieved_blocked_join_request(const std::string& sender_name, const std::uint64_t& sender_id, const JoinSessionMessage& message)
	{
		open_toast_popup(
			utils::string::va("Received blocked join request!\nFrom: '%s' (%llu) (%s)",
				sender_name.data(),
				sender_id,
				utils::string::adr_to_string(&message.inviteInfo.sessionInfo).data()),
			2700,
			"menu_mp_lobby_locked_big");

		PRINT_LOG("'%s' (%llu) (%s) tried joining you when your party was closed or non-joinable!",
			sender_name.data(),
			sender_id,
			utils::string::adr_to_string(&message.inviteInfo.sessionInfo).data());

		return true;
	}

	bool recieved_join_party_request(const netadr_t& target, const bool blocked)
	{
		const auto icon = blocked ? "menu_mp_lobby_locked_big" : "";
		auto message = "Received join party request!"s;
		if (blocked)
			message = "Received blocked join party request!";

		if (const auto client_num = find_target_from_addr(target); client_num >= 0)
		{
			const auto pm = party->party_member(client_num);

			open_toast_popup(
				utils::string::va("%s\nFrom: '%s' (%llu) (%s)",
					message.data(),
					pm->gamertag,
					pm->player,
					utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data()),
				2700,
				icon);

			PRINT_LOG("%s From: '%s' (%llu) (%s)",
				message.data(),
				pm->gamertag,
				pm->player,
				utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data());
		}
		else
		{
			platformNetAdr adr = {};
			if (Party_NetAdrToPlatformNetAdr(target, &adr))
			{
				open_toast_popup(
					utils::string::va("%s\nFrom: (%s)",
						message.data(),
						utils::string::adr_to_string(adr).data()),
					2700,
					icon);

				PRINT_LOG("%s From: (%s)",
					message.data(),
					utils::string::adr_to_string(adr).data());
			}
		}

		return blocked;
	}

	void open_toast_popup(const std::string& message, const std::uint32_t ms, const std::string& icon)
	{
		UI_OpenToastPopup(0,
			icon.empty() ? "menu_mp_killstreak_select" : icon.data(),
			message.data(),
			nullptr,
			ms);
	}

	bool is_user_signed_into_demonware()
	{
		return Live_IsUserSignedInToDemonware(0) && Sys_IsDatabaseReady2();
	}

	void make_dvar_server_info(const char* dvar_name, const char* value)
	{
		const auto dvar = Dvar_SetFromStringByNameFromSource(dvar_name, value, 0, 0);
		Dvar_AddFlags(dvar, 0x400);
	}

	void* LiveStats_GetPrivateKey()
	{
		return *reinterpret_cast<LPVOID*>(0x0301EB88);
	}

	bool BG_UnlockablesSetItemPurchased(int itemIndex, bool isPurchased)
	{
		static constexpr auto address = 0x009494B0;
		auto result = false;

		__asm
		{
			push isPurchased;
			push 0;
			mov eax, itemIndex;

			call address;
			add esp, 8;

			mov result, al;
		}

		return result;
	}

	void CG_RemoveChatEscapeChar(char* text)
	{
		static constexpr auto address = 0x007CFDE0;
		
		__asm
		{
			lea esi, text;
			call address;
		}
	}

	std::string get_localized_chat_text_message(const char* message, const char* message_type)
	{
		const auto text_message = SEH_LocalizeTextMessage(message, message_type, 0);

		char chat_message[128] = { 0 };
		strncpy_s(chat_message, text_message, sizeof chat_message);

		CG_RemoveChatEscapeChar(chat_message);
		return I_CleanStr(chat_message);
	}

	std::string get_translated_hud_elem_message(const std::string& game_message, const std::string& message)
	{
		if (utils::string::contains(game_message, message))
		{
			char hud_elem_string[256];
			CG_TranslateHudElemMessage(0, game_message.data(), "game message", hud_elem_string);

			return I_CleanStr(hud_elem_string);
		}

		return {};
	}

	std::string get_oob_command(const netadr_t& target)
	{
		if (const auto client_num = find_target_from_addr(target); client_num >= 0)
		{
			const auto pm = party->party_member(client_num);

			return utils::string::va("Received OOB '%s' from '%s' (%llu) (%s)",
				command::params.join(0).data(),
				pm->gamertag,
				pm->player,
				utils::string::adr_to_string(pm->platformAddr, pm->user_port()).data());
		}
		else
		{
			platformNetAdr adr = {};
			if (Party_NetAdrToPlatformNetAdr(target, &adr))
			{
				return utils::string::va("Received OOB '%s' from (%s)",
					command::params.join(0).data(),
					utils::string::adr_to_string(adr).data());
			}
		}

		return {};
	}

	bool can_draw_overhead_names(const centity_t* cent)
	{
		const auto our_team = cg()->client(cg()->client_num())->team();
		const auto victim_team = cg()->client(cent->next_state().number)->team();

		return victim_team == our_team && esp::enabled && esp::player_name_tag && !esp::enemies_only
			|| victim_team != our_team && esp::enabled && esp::player_name_tag && esp::enemies_only
			|| our_team == TEAM_FREE && esp::enabled && esp::player_name_tag;
	}

	game::Material* get_material(const char* material_ptr, const int length)
	{
		if (length < 0 || length > 255)
			return nullptr;

		if (std::strlen(material_ptr) >= length)
			return game::Material_RegisterHandle(material_ptr, 7, true, -1);

		return nullptr;
	}

	bool is_invalid_material_pointer(const char* string)
	{
		const auto material = get_material(string + 4, string[3]);
		if (material && material->___u8.techniqueSet && material->___u8.techniqueSet->name != "trivial_9z33feqw"s)
		{
			return false;
		}

		return true;
	}

	std::vector<std::uint32_t> get_party_ids()
	{
		std::vector<std::uint32_t> party_ids;

		for (size_t i = 0; i <= 2; ++i)
		{
			party_ids.emplace_back(i);
		}

		return party_ids;
	}

	bool is_hosting()
	{
		return !party->currentHost.hostNum && !party->is_running() && party->we_are_host();
	}

	bool can_send_out_of_band_packet_to_friend(const std::size_t client_num, const netadr_t& target)
	{
		if (is_valid_target(client_num))
		{
			for (const auto& friends : friends::friends)
			{
				if(const auto client_num = Party_FindMemberByXUID(friends.xuid); client_num >= 0)
				{
					const auto pm = party->party_member(client_num);

					if (NET_CompareAdr(pm->platformAddr.netAddr, target) 
						&& !friends.send_oob_packets)
					{
						return false;
					}
				}
			}
		}

		return true;
	}

	bool set_ip_address(void* ip_bytes, std::vector<std::string> ip_string)
	{
		if (!ip_string.empty())
		{
			std::vector<std::uint8_t> ip_address;

			for (const auto& ip : ip_string)
			{
				if (ip_string.size() <= 4)
					ip_address.emplace_back(std::stoi(ip));
			}

			if (!ip_address.empty())
			{
				std::memcpy(ip_bytes, ip_address.data(), sizeof std::uint32_t);

				return true;
			}
		}

		return false;
	}

	Vec2 get_scale(const centity_t* cent, const float pos)
	{
		Vec2 scale{};

		if (cent->next_state().lerp.flags & 0x08)
		{
			scale.set(pos / 1.5f, pos / 2.0f);
		}

		else if (cent->next_state().lerp.flags & 0x04)
		{
			scale.set(pos / 2.0f, pos / 2.0f);
		}

		else
		{
			scale.set(pos / 2.0f, pos / 1.5f);
		}

		scale *= 2.0f;
		return scale;
	}

	Vec3 get_top_position(const centity_t* cent)
	{
		auto origin = cent->origin();
		origin.z += 55.0f;

		return origin;
	}

	Vec2 get_screen_pos(const Vec3& world_pos)
	{
		Vec2 out{};
		
		if (const auto screen_pos = CG_WorldPosToScreenPos(0, &world_pos, &out); screen_pos)
		{
			return out;
		}

		return {};
	}

	void PartyProber_ClearHosts(game::PartyProber* prober)
	{
		if (prober->controllerIndex != -1)
			Live_CleanUpQoSProbes();

		if (Live_QoSInProgress())
		{
			std::memset(prober, 0, 0x1DB0);
			prober->hostCount = 0;
		}
	}

	void PartyProber_SetState(game::PartyProber* prober, const ProberState state)
	{
		if (prober->state != state)
		{
			prober->state = state;
		}
	}

	bool Party_AreWeHost(const PartyData_s* party)
	{
		if (party->is_running() != 1 || !party->are_we_host() || !party->in_party())
			return false;
		
		return true;
	}

	void PartyProber_StartInvite()
	{
		party->a() = false;
		party->b() = true;
		reinterpret_cast<void(*)(PartyData_s*, int)>(0x00636D80)(party, 0);
		
		party->potentialHost = {};
		party->potentialHost.numPublicSlots = 18;
		party->potentialHost.addr = party->currentHost.addr;
		party->potentialHost.sessionInfo = {};
		
		auto prober = reinterpret_cast<PartyProber*>(0x00D4A5F8);
		
		//PartyProber_ClearHosts(prober);
		prober->hostCount = 0; 
		PartyProber_SetState(prober, STATE_IDLE);
		std::memset(&prober->echoHost, 0, sizeof PartyInfo);
		prober->packetRecvTime = 0;

		prober->mode = PROBER_INVITE;
		prober->controllerIndex = 0;
		prober->minPlayers = 0;
		prober->requiredFlags = reinterpret_cast<int(*)()>(0x00548990)();
		prober->searchStartUTC = 0;
		prober->masterAddr = {};
		prober->hostCount = 1;

		prober->hosts->info = {};
		prober->hosts->occupiedPublicSlots = 1;
		prober->hosts->occupiedPrivateSlots = 0;
		prober->hosts->numPrivateSlots = 0;
		prober->hosts->numPublicSlots = 18;
		prober->hostIndex = -1;

		prober->hosts->flags |= 3;
		prober->partyId = 2;

		if (Party_AreWeHost(g_partyData))
		{
			prober->partyToNotify = g_partyData;
		}
		else
		{
			prober->partyToNotify = 0;
		}

		PartyProber_SetState(prober, STATE_QOS_COMPLETE);
	}

	void send_server_command(const int client_num, const std::string& command)
	{
		if (client_num < -1 || client_num >= 18)
			return;
		if (!game::CL_LocalClientIsInGame())
			return;
		if (!game::IsServerRunning())
			return;

		game::SV_GameSendServerCommand(client_num, SV_CMD_RELIABLE, command.data());
	}

	int I_stricmp(const std::string& a, const std::string& b)
	{
		return _strnicmp(a.data(), b.data(), std::numeric_limits<int>::max());
	}

	char* I_strncpyz(char* place, const std::string& string, const size_t length)
	{
		const auto result = std::strncpy(place, string.data(), length);
		place[length - 1] = 0;
		return result;
	}

	bool transmit_fragment(const netchan_t& chan, const std::uint8_t index, const std::uint16_t size, const std::string& data)
	{
		auto buffer{ ""s };
		buffer.reserve(1264);

		const auto sequence{ chan.outgoingSequence | (chan.reliable_fragments ? 0xC0000000 : 0x80000000) };
		const auto qport{ static_cast<std::uint16_t>(chan.qport) };
		const auto max_index{ std::numeric_limits<std::uint8_t>::max() };
		const auto buf_size{ static_cast<std::uint16_t>(data.size()) };

		buffer.append(reinterpret_cast<const char*>(&sequence), sizeof sequence);

		if (chan.sock < NS_SERVER)
			buffer.append(reinterpret_cast<const char*>(&qport), sizeof qport);

		buffer.append(reinterpret_cast<const char*>(&index), sizeof index);
		buffer.append(reinterpret_cast<const char*>(&max_index), sizeof max_index);
		buffer.append(reinterpret_cast<const char*>(&size), sizeof size);
		buffer.append(reinterpret_cast<const char*>(&buf_size), sizeof buf_size);
		buffer.append(data);

		const auto result = game::NET_SendPacket(chan.sock, buffer.size(), buffer.data(), chan.remoteAddress);

		if (result)
		{
			PRINT_LOG("Sent fragment packet [index: %i size: %i data length: %u]", index, size, data.size());
		}
		else
		{
			PRINT_LOG("Couldn't send packet.");
		}

		return result;
	}

	bool transmit_fragment(const std::uint8_t index, const std::uint16_t size, const std::string& data)
	{
		return transmit_fragment(clc()->netchan, index, size, data);
	}
}