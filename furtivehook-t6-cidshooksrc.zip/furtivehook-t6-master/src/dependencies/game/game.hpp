#pragma once
#include "structs.hpp"
#include "offsets.hpp"

namespace game
{
	enum class bone_tag
	{
		helmet,
		head_end,
		head,
		neck,
		shoulder_left,
		shoulder_right,
		clavicle_left,
		clavicle_right,
		spineupper,
		spine,
		spinelower,
		hip_left,
		hip_right,
		knee_left,
		knee_right,
		wrist_left,
		wrist_right,
		wrist_twist_left,
		wrist_twist_right,
		elbow_left,
		elbow_right,
		elbow_buldge_left,
		elbow_buldge_right,
		ankle_left,
		ankle_right,
		ball_left,
		ball_right,
		mainroot,
		num_tags,
	};

	const static auto IsServerRunning = reinterpret_cast<bool(*)()>(0x004AE8F0);
	const static auto SV_Loaded = reinterpret_cast<bool(*)()>(0x006DC090);
	const static auto ClientCommand = reinterpret_cast<void(*)(ClientNum_t clientNum)>(0x0065EEB0);
	const static auto SV_Cmd_TokenizeString = reinterpret_cast<void(*)(const char *text_in)>(0x006B0790);
	const static auto SV_Cmd_EndTokenizedString = reinterpret_cast<void(*)()>(0x004DDE20);
	const static auto Cmd_TokenizeStringNoEval = reinterpret_cast<void(*)(const char *text_in)>(0x00495B50);
	const static auto Cmd_EndTokenizedString = reinterpret_cast<void(*)()>(0x00694A50);
	const static auto CL_Netchan_Transmit = reinterpret_cast<void(*)(netchan_t *chan, char *data, int length)>(0x004F8430);

	const static auto MSG_ReadBigString = reinterpret_cast<char*(*)(msg_t *msg)>(0x0061BBE0);
	const static auto MSG_ReadString = reinterpret_cast<char*(*)(msg_t *msg, char *string, unsigned int maxChars)>(0x0053C1A0);
	const static auto Info_ValueForKey = reinterpret_cast<const char*(*)(const char *s, const char *key)>(0x00508710);

	const static auto DB_EnumXAssets_Internal = reinterpret_cast<void(__cdecl*)(XAssetType type, void(*)(XAssetHeader, void*), const void* inData, bool includeOverride)>(0x006CAF30);
	const static auto DB_GetXAssetName = reinterpret_cast<const char*(*)(const game::XAsset*)>(0x004DCFE0);

	const static auto Party_IsInTempBannedXuidList = reinterpret_cast<bool(*)(std::uint64_t)>(0x0044DFC0); 
	const static auto UI_GetGameTypeDisplayName = reinterpret_cast<char*(*)(const char *pszGameType, const char *pszMap)>(0x0044C300);
	const static auto GetPlayerStatus = reinterpret_cast<char*(*)(std::uint64_t)>(0x00595D60);
	const static auto dwNetadrToCommonAddr = reinterpret_cast<bool(*)(netadr_t netadr, void *commonAddrBuf, const unsigned int commonAddrBufSize, bdSecurityID * id)>(0x005AE090);
	const static auto SV_DropClient = reinterpret_cast<void(*)(client_t *drop, const char *reason, bool tellThem)>(0x005420D0);
	const static auto dwCommonAddrToNetadr = reinterpret_cast<bool(*)(netadr_t *const netadr, const char *const commonAddrBuf, const bdSecurityID *secID)>(0x004F7F20);
	const static auto accept_game_invite = reinterpret_cast<bool(*)(ControllerIndex_t controllerIndex, std::uint64_t xuid, bool a1)>(0x00514020);
	const static auto Dvar_FindVar = reinterpret_cast<dvar_t*(*)(const char* dvar)>(offsets::Dvar_FindVar);
	const static auto Material_IsDefault = reinterpret_cast<bool(*)(Material*)>(0x00733ED0);
	const static auto Material_RegisterHandle = reinterpret_cast<Material*(*)(const char *name, int imageTrack, bool errorIfMissing, int waitTime)>(offsets::Material_RegisterHandle);
	const static auto Cmd_AddCommandInternal = reinterpret_cast<std::uint32_t(*)(const char *cmdName, void(__cdecl *function)(), cmd_function_s *allocedCmd)>(0x006B4B20);
	const static auto PartyClient_DisconnectFromHost = reinterpret_cast<void(*)(PartyData_s *party, ControllerIndex_t localControllerIndex, const char *reason, bool keepPartyTogether, bool createParty)>(0x00487EE0);
	const static auto DynEnt_GetEntityCount = reinterpret_cast<std::uint32_t(*)(std::uint32_t type)>(0x00403DC0);
	const static auto& ent_count = *reinterpret_cast<std::uint16_t*>(offsets::ent_count);
	const static auto& com_error_message = reinterpret_cast<const char*>(0x0025E2CE8);
	const static auto& cmd_argc_sv = reinterpret_cast<std::uint32_t*>(0x00255DDCC);
	const static auto& cmd_id_sv = reinterpret_cast<std::uint32_t*>(0x00255DD48);
	const static auto& bg_lastParsedWeaponIndex = *reinterpret_cast<std::uint32_t*>(0x0326E990);
	const static auto& ucmds = reinterpret_cast<ucmd_t*>(0x00D5F5D4);
	const static auto& map_handler = reinterpret_cast<MapnameRichPresenceInfo*>(0x00C8A6A0);
	const static auto& party_migrate_handler = reinterpret_cast<PartyMessages*>(0x00C6F1A8);
	const static auto& migrate_handler = reinterpret_cast<MigrationMessage*>(0x00C6ED70);
	const static auto& sv_migrate_handler = reinterpret_cast<MigrationMessage*>(0x00C819F4);
	const static auto& party_host_handler = reinterpret_cast<PartyMessages*>(0x00C6F050);
	const static auto& party_client_handler = reinterpret_cast<PartyMessages*>(0x00C6EEF8);
	const static auto& ui_demoname = *reinterpret_cast<dvar_t**>(0x00294E20C);
	const static auto& sv_bullet_range = *reinterpret_cast<dvar_t**>(0x00290B8B8);
	const static auto& sv_penetration_count = *reinterpret_cast<dvar_t**>(0x0028FB870);
	const static auto& lui_error_report = *reinterpret_cast<dvar_t**>(0x0025E2BE0);
	const static auto& perk_bullet_penetration_multiplier = *reinterpret_cast<dvar_t**>(0x00325FC04);
	const static auto& joinInProgressInviteID = *reinterpret_cast<std::uint32_t*>(offsets::invite_id);
	const static auto& ignore_party_warning = *reinterpret_cast<bool*>(0x00304F7E7);
	const static auto Party_ShouldShowInviteWarning = reinterpret_cast<bool(*)(PartyData_s* party)>(0x00562EF0);
	const static auto Sys_EnterCriticalSection = reinterpret_cast<void(*)(int critSect)>(0x00453100);
	const static auto Sys_LeaveCriticalSection = reinterpret_cast<void(*)(int critSect)>(0x00524A70);
	const static auto Live_IsUserSignedInToDemonware = reinterpret_cast<bool(*)(ControllerIndex_t controllerIndex)>(0x00672F20);
	const static auto Sys_IsDatabaseReady2 = reinterpret_cast<bool(*)()>(0x004C6B90);
	const static auto Live_CleanUpQoSProbes = reinterpret_cast<void(*)()>(0x006D3FC0);
	const static auto Live_QoSInProgress = reinterpret_cast<bool(*)()>(0x005B8420);
	const static auto Dvar_AddFlags = reinterpret_cast<void(*)(dvar_t *dvar, int flags)>(0x004AABE0);
	const static auto Dvar_SetFromStringByNameFromSource = reinterpret_cast<dvar_t*(*)(const char *dvarName, const char *string, int source, unsigned int flags)>(0x00546A10);
	const static auto& sprng_desc = reinterpret_cast<ltc_prng_descriptor*>(0x00CC8030);
	const static auto& prestige = *reinterpret_cast<std::uint32_t*>(offsets::prestige);
	const static auto& experience = *reinterpret_cast<std::uint32_t*>(offsets::xp);

	const static auto& g_assetNames = reinterpret_cast<const char**>(0x00D4A8A0);

	const static auto& net_field_checksum = *reinterpret_cast<std::uint32_t*>(offsets::net_field_checksum);
	const static auto& playlist_version_number = *reinterpret_cast<std::uint32_t*>(offsets::playlist_version_number);

	const static auto& g_partyData = reinterpret_cast<PartyData_s*>(offsets::g_partyData); 
	const static auto& g_partyProber = reinterpret_cast<PartyProber*>(0x00D4A5F8);
	const static auto& g_lobbyData = reinterpret_cast<PartyData_s*>(offsets::g_lobbyData);
	const static auto& migrateHostData = reinterpret_cast<migrateHostData_t*>(0x0012BDA10);
	const static auto& migrateClientData = reinterpret_cast<migrateClientData_t*>(0x0012BD810);
	const static auto& g_serverSession = reinterpret_cast<SessionData*>(0x002F5D830);
	const static auto SV_Cmd_Argv = reinterpret_cast<char*(*)(int argIndex)>(0x0043D270);
	const static auto Party_PacketIsFromHost = reinterpret_cast<bool(*)(PartyData_s *party, netadr_t from)>(0x00581DD0);
	const static auto NET_StringToAdr = reinterpret_cast<int(*)(const char *s, netadr_t *a)>(0x00402000);
	const static auto CL_ConnectFromParty = reinterpret_cast<void(*)(ControllerIndex_t controllerIndex, XSESSION_INFO *hostInfo, netadr_t addr, int numPublicSlots, int numPrivateSlots, const char *mapname)>(0x0056A2E0);
	const static auto BG_FactionData_GetTeamColor = reinterpret_cast<void(*)(std::uint32_t team, ImColor *out)>(0x0040AA70);

	const static auto strncpyz = reinterpret_cast<void(*)(char *dest, const char *src, int destsize)>(0x0049B6A0);
	const static auto bdSecurity_ID = reinterpret_cast<void(__fastcall*)(bdSecurityID*)>(0x00A2D780);
	const static auto bdSecurity_Key = reinterpret_cast<void(__fastcall*)(bdSecurityKey*)>(0x00A2CC40);
	const static auto PartyHost_KickPlayer = reinterpret_cast<void(*)(PartyData_s *party, ClientNum_t memberIndex, const char *reason)>(0x006824B0);
	const static auto Session_RegisterRemotePlayer = reinterpret_cast<void(*)(ControllerIndex_t localControllerIndex, SessionData *session, const unsigned __int64 player, bool privateSlot, ClientNum_t clientNum, const int natType, netadr_t addr)>(0x006593C0);
	const static auto PartyHost_AddLocalPlayer = reinterpret_cast<int(*)(PartyData_s *party, ControllerIndex_t localControllerIndex, ClientNum_t slot)>(0x00629020);
	const static auto Live_GetPlayerNetAddr = reinterpret_cast<netadr_t*(*)(netadr_t *result, SessionData *session, ClientNum_t clientNum)>(0x00701320);
	const static auto PartyProber_FindByXNAddr = reinterpret_cast<int(*)(XNADDR* key)>(0x007FA750);

	const static auto find_hash = reinterpret_cast<std::uint32_t(*)(const char* name)>(0x00A5E1C0);
	const static auto hash_memory = reinterpret_cast<std::uint32_t(*)(std::uint32_t hash, char* in, std::size_t inLen, char* out, size_t* outlen)>(0x00A61B00);
	const static auto register_prng = reinterpret_cast<std::uint32_t(*)(void* prng)>(0x00A61F10);
	const static auto find_prng = reinterpret_cast<std::uint32_t(*)(const char* name)>(0x00A61EA0);
	const static auto sign_hash = reinterpret_cast<std::uint32_t(*)(const char* in, size_t inlen, char* out, size_t* outlen, void* prng, int wprng, void* key)>(0x00A61C00);
	const static auto Xenon_RegisterRemoteXenon = reinterpret_cast<bool(*)(XSESSION_INFO const *info, netadr_t *addr)>(0x006D0460);
	const static auto Xenon_GetXNAddr = reinterpret_cast<XNADDR*(*)(bool renew)>(0x00628E30);
	const static auto Live_UpdatePlayerNetAddr = reinterpret_cast<void(*)(SessionData *session, ClientNum_t clientNum, netadr_t *addr)>(0x005A99A0);

	const static auto RMsg_AddMessage = reinterpret_cast<bool(*)(netsrc_t from, const netadr_t *to, msg_t *msg)>(0x0041F530);
	const static auto RMsg_AddPrint = reinterpret_cast<bool(*)(netsrc_t from, netadr_t *to, const char *line)>(0x004D5950);
	const static auto RMsg_FindSlotForAddr = reinterpret_cast<int(*)(const netadr_t *to)>(0x008CB520);
	const static auto NET_SendPacket = reinterpret_cast<bool(*)(netsrc_t sock, int length, const void *data, netadr_t to)>(0x00651870);
	const static auto LiveStats_GetIntPlayerStatFromBuffer = reinterpret_cast<int(*)(const char *statName, void *buffer)>(0x0067A430);
	const static auto SV_FindClientByAddress = reinterpret_cast<client_t*(*)(netadr_t from, std::uint16_t qport)>(0x006FAD70);
	const static auto Com_UseRawUDP = reinterpret_cast<bool(*)()>(0x00581FE0);
	const static auto IN_Activate = reinterpret_cast<void(*)(bool open)>(0x00615E30);
	const static auto Party_NetAdrToPlatformNetAdr = reinterpret_cast<bool(*)(netadr_t netAddr, platformNetAdr *platNetAddr)>(0x006FE690);
	const static auto dwCommonAddrToInAddr = reinterpret_cast<std::uint32_t(*)(const char *commonAddrBuf, const unsigned int commonAddrBufSize)>(0x004561D0);
	const static auto GamerProfile_GetInt = reinterpret_cast<std::uint32_t(*)(int setting, ControllerIndex_t controllerIndex)>(0x00521080);
	const static auto CL_GetClientName = reinterpret_cast<bool(*)(LocalClientNum_t localClientNum, int index, char *buf, size_t size, bool addClanName)>(0x0055D8E0);
	const static auto UI_OpenToastPopup = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, const char *toastPopupIconName, const char *toastPopupTitle, const char *toastPopupDesc, int toastPopupDuration)>(0x006A8310);
	const static auto UI_CloseAll = reinterpret_cast<int(*)(LocalClientNum_t localClientNum)>(0x005C4C80);
	const static auto UI_ClearErrors = reinterpret_cast<int(*)()>(0x00544B40);
	const static auto UI_SetActiveMenu = reinterpret_cast<int(*)(LocalClientNum_t localClientNum, int menu)>(0x005C2CB0);
	const static auto send_popup_on_screen = reinterpret_cast<void(*)(ControllerIndex_t controllerIndex, char* msg, std::uint64_t xuid, size_t key)>(0x0069F330);
	const static auto LiveSteam_FriendPersonaNameFromXuid = reinterpret_cast<char*(*)(char* buff, int size, bool asciionly)>(offsets::LiveSteam_FriendPersonaNameFromXuid);
	const static auto CL_Live_LeaveAllParties = reinterpret_cast<void(*)()>(offsets::CL_Live_LeaveAllParties);
	const static auto Live_CloseAllBusyPopups = reinterpret_cast<void(*)()>(offsets::Live_CloseAllBusyPopups);
	const static auto Live_SendInvite = reinterpret_cast<void(*)(ControllerIndex_t controllerIndex, std::uint64_t xuid, bool unk)>(offsets::Live_SendInvite);
	const static auto Invite_Message = reinterpret_cast<char*(__thiscall*)(InviteMessage *thisptr, InviteMessage * thatptr)>(0x004D9970);
	const static auto CL_CanWeConnectToClient = reinterpret_cast<int(*)(SessionData *sessionData, ClientNum_t ourClientNum, ClientNum_t theirClientNum)>(offsets::CL_CanWeConnectToClient);
	const static auto Live_GetXuid = reinterpret_cast<std::uint64_t(*)(ControllerIndex_t controllerIndex)>(offsets::Live_GetXuid);
	const static auto big_short = reinterpret_cast<std::uint16_t(*)(std::uint16_t l)>(0x004CE920);

	const static auto Session_CreateInProgress = reinterpret_cast<bool(*)()>(0x0054B040);
	const static auto SEH_LocalizeTextMessage = reinterpret_cast<char*(*)(const char *pszInputBuffer, const char *pszMessageType, std::uint32_t errType)>(offsets::SEH_LocalizeTextMessage);
	const static auto SEH_SafeTranslateString = reinterpret_cast<char*(*)(const char *)>(0x005E8830);
	const static auto SEH_StringEd_GetString = reinterpret_cast<const char*(*)(const char *)>(0x00677BD0);
	const static auto CG_TranslateHudElemMessage = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, const char *message, const char *messageType, char *hudElemString)>(offsets::CG_TranslateHudElemMessage);
	const static auto I_CleanStr = reinterpret_cast<char*(*)(char *text)>(offsets::CleanStr);

	const static auto CG_IsShoutcaster = reinterpret_cast<bool(*)()>(offsets::CG_IsShoutcaster);
	const static auto Demo_IsPlaying = reinterpret_cast<bool(*)()>(offsets::Demo_IsPlaying);
	const static auto NET_CompareAdr = reinterpret_cast<bool(*)(netadr_t a, netadr_t b)>(offsets::NET_CompareAdr);
	const static auto PartyClient_RequestLocalJoin = reinterpret_cast<void(*)(PartyData_s *party, int partyId, ControllerIndex_t localControllerIndex)>(0x0041B200);

	const static auto MSG_WriteData = reinterpret_cast<void(*)(msg_t *buf, const void *data, int length)>(offsets::MSG_WriteData);
	const static auto MSG_WriteBitsCompress = reinterpret_cast<int(*)(bool trainHuffman, const char *from, int fromSizeBytes, char *to, int toSizeBytes)>(0x006DC4F0);
	const static auto MSG_ReadBit = reinterpret_cast<std::uint32_t(*)(msg_t *buf)>(0x005E4C10);
	const static auto MSG_ReadData = reinterpret_cast<void(*)(msg_t *buf, const void *data, int length)>(0x00499540);
	const static auto MSG_ReadByte = reinterpret_cast<std::uint8_t(*)(msg_t *msg)>(offsets::MSG_ReadByte);
	const static auto MSG_ReadLong = reinterpret_cast<std::uint32_t(*)(msg_t *msg)>(offsets::MSG_ReadLong);
	const static auto MSG_ReadFloat = reinterpret_cast<float(*)(msg_t *msg)>(0x00568ED0);
	const static auto MSG_ReadInt64 = reinterpret_cast<std::uint64_t(*)(msg_t *msg)>(0x005CE600);
	const static auto MSG_ReadShort = reinterpret_cast<std::uint16_t(*)(msg_t *msg)>(offsets::MSG_ReadShort);
	const static auto MSG_ReadStringLine = reinterpret_cast<char*(*)(msg_t * msg, char* string, unsigned int maxChars)>(offsets::MSG_ReadStringLine);
	const static auto MSG_Init = reinterpret_cast<void(*)(msg_t * buf, char* data, int length)>(offsets::MSG_Init);
	const static auto MSG_WriteLong = reinterpret_cast<void(*)(msg_t * msg, int c)>(offsets::MSG_WriteLong);
	const static auto MSG_WriteString = reinterpret_cast<void(*)(msg_t * sb, const char* s)>(offsets::MSG_WriteString);
	const static auto MSG_WriteInt64 = reinterpret_cast<void(*)(msg_t * msg, std::uint64_t c)>(offsets::MSG_WriteInt64);
	const static auto MSG_WriteShort = reinterpret_cast<void(*)(msg_t * msg, int c)>(offsets::MSG_WriteShort);
	const static auto MSG_WriteByte = reinterpret_cast<void(*)(msg_t * msg, int c)>(offsets::MSG_WriteByte);
	const static auto MSG_WriteFloat = reinterpret_cast<void(*)(msg_t * msg, float f)>(offsets::MSG_WriteFloat);
	const static auto MSG_WriteBit0 = reinterpret_cast<void(*)(msg_t * msg)>(offsets::MSG_WriteBit0);
	const static auto MSG_WriteBit1 = reinterpret_cast<void(*)(msg_t * msg)>(offsets::MSG_WriteBit1);
	const static auto MSG_InitReadOnly = reinterpret_cast<void(*)(msg_t *buf, char *data, int length)>(0x006608D0);
	const static auto MSG_BeginReading = reinterpret_cast<void(*)(msg_t *msg)>(0x00598A60);
	const static auto NET_OutOfBandData = reinterpret_cast<bool(*)(netsrc_t sock, netadr_t adr, const char* format, int len)>(offsets::NET_OutOfBandData);
	const static auto NET_SendLoopPacket = reinterpret_cast<void(*)(netsrc_t sock, int length, const void *data, netadr_t to)>(0x0069D540);
	const static auto Sys_SendPacket = reinterpret_cast<void(*)(netsrc_t sock, int length, const void *data, netadr_t to)>(0x004A7D40);
	const static auto dwCloseConnection = reinterpret_cast<bool(*)(netadr_t *const netadr)>(0x0049D8C0);
	const static auto Party_WriteMember = reinterpret_cast<bool(*)(PartyMember *partyMember, msg_t *msg)>(0x0051D490);
	const static auto Party_WriteMemberField = reinterpret_cast<void(*)(msg_t *msg, PartyField *field, PartyMember *partyMember)>(0x0051D490);

	const static auto SV_WaitServer = reinterpret_cast<void(*)()>(0x005159C0);
	const static auto BG_CalculateViewMovementAngles = reinterpret_cast<void(*)(viewState_t *vs, Vec3 *angles, bool bIgnoreIdleSway)>(offsets::BG_CalculateViewMovementAngles);
	const static auto BG_GetAmmoNotInClip = reinterpret_cast<std::uint32_t(*)(const playerState_s *ps, Weapon weapon)>(offsets::BG_GetAmmoNotInClip);
	const static auto BG_GetAmmoInClip = reinterpret_cast<std::uint32_t(*)(const playerState_s *ps, Weapon weapon)>(0x004346F0);
	const static auto BG_GetDualWieldWeapon = reinterpret_cast<std::uint32_t(*)(Weapon weapon)>(0x0047ED10);
	const static auto BG_GetClipSize = reinterpret_cast<std::uint32_t(*)(Weapon weapon)>(offsets::BG_GetClipSize);
	const static auto BG_GetHeldWeapon = reinterpret_cast<PlayerHeldWeapon*(*)(playerState_s *ps, Weapon weapon)>(offsets::BG_GetHeldWeapon);
	const static auto Party_MsgPrint = reinterpret_cast<void(*)(netsrc_t sock, netadr_t adr, const char *data, bool doubleSend)>(0x006E7970);
	const static auto PartyClient_RemovePlayer = reinterpret_cast<void(*)(PartyData_s *party, ClientNum_t memberIndex)>(0x0064DA80);
	const static auto PartyHost_RemovePlayer = reinterpret_cast<void(*)(PartyData_s *party, ClientNum_t memberIndex, bool tellThem, const char* reason)>(0x00625820);
	const static auto UI_GetMapName = reinterpret_cast<char*(*)(const char*, bool returnStringRef)>(0x00480EF0);
	const static auto UI_GetGameTypeName = reinterpret_cast<char*(*)(const char*, bool, const char*)>(0x006D53F0);

	const static auto CL_GetConfigString = reinterpret_cast<char*(*)(std::uint32_t configStringIndex)>(offsets::CL_GetConfigString); 
	const static auto SV_SetConfigValueForKey = reinterpret_cast<char*(*)(int start, int max, const char *key, const char *value)>(0x005091B0);
	const static auto SV_Cmd_ArgvBuffer = reinterpret_cast<void(*)(size_t arg, char *buffer, size_t bufferLength)>(0x005D6990);
	const static auto Cmd_Argc = reinterpret_cast<std::uint32_t(*)()>(offsets::Cmd_Argc);
	const static auto Cmd_Argv = reinterpret_cast<char*(*)(int argIndex)>(offsets::Cmd_Argv);
	const static auto DynEntCl_DestroyEvent = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, std::uint16_t dynEntId, DynEntityDrawType drawType, Vec3* hitPos, Vec3* hitDir)>(offsets::DynEntCl_DestroyEvent);
	const static auto Party_HandlePacket = reinterpret_cast<bool(*)(PartyData_s *party, const char *c, ControllerIndex_t localControllerIndex, netadr_t from, msg_t *msg)>(offsets::Party_HandlePacket);
	const static auto CL_SendPeerData = reinterpret_cast<bool(*)(SessionData * session, LocalClientNum_t localClientNum, netsrc_t sock, size_t clientNum, msg_t * msg, int dataType)>(offsets::CL_SendPeerData);

	const static auto SV_GameSendServerCommand = reinterpret_cast<void(*)(ClientNum_t clientNum, std::uint32_t type, const char *text)>(offsets::SV_GameSendServerCommand);
	const static auto CL_Disconnect = reinterpret_cast<void(*)(LocalClientNum_t, bool)>(0x004A2EE0);
	const static auto Cbuf_AddText = reinterpret_cast<std::uint32_t(*)(LocalClientNum_t localClientNumber, const char* text)>(offsets::Cbuf_AddText);
	const static auto CL_AddReliableCommand = reinterpret_cast<std::uint32_t(*)(LocalClientNum_t localClientNumber, const char* text)>(offsets::CL_AddReliableCommand);
	const static auto Sys_GetValue = reinterpret_cast<int(*)(int valueIndex)>(offsets::Sys_GetValue);
	const static auto CL_GetClantag = reinterpret_cast<const char*(*)(ControllerIndex_t controllerIndex)>(offsets::CL_GetClantag);
	const static auto CL_ControllerIndex_GetUsername = reinterpret_cast<const char*(*)(ControllerIndex_t controllerIndex)>(offsets::CL_ControllerIndex_GetUsername);
	const static auto Live_GetCurrentSession = reinterpret_cast<void*(*)()>(offsets::Live_GetCurrentSession);
	const static auto Live_JoinSessionInProgress = reinterpret_cast<bool(*)(ControllerIndex_t localControllerIndex, std::uint64_t xuid)>(offsets::Live_JoinSessionInProgress);
	const static auto dwInstantSendMessage = reinterpret_cast<bool(*)(ControllerIndex_t controllerIndex, const std::uint64_t* recipientUIDs, unsigned int numRecipients, char msgType, const void *message, unsigned int msgSize)>(0x004322D0);
	const static auto Live_SendJoinInfo = reinterpret_cast<void(*)(ControllerIndex_t localControllerIndex, std::uint64_t xuid, JoinSessionMessage msg)>(0x006978A0);
	const static auto Sys_Milliseconds = reinterpret_cast<std::uint32_t(*)()>(offsets::Sys_Milliseconds);
	const static auto Com_Error = reinterpret_cast<void(*)(errorParm_t errorType, const char* text)>(offsets::Com_Error);
	const static auto Friends_IsFriendByID = reinterpret_cast<bool(*)(ControllerIndex_t controllerIndex, std::uint64_t xuid)>(offsets::Friends_IsFriendByID);
	const static auto CG_CycleWeapon = reinterpret_cast<bool(*)(LocalClientNum_t localClientNum, int cycleForward)>(offsets::CG_CycleWeapon);
	const static auto CG_SelectWeaponIndex = reinterpret_cast<bool(*)(LocalClientNum_t localClientNum, Weapon weapon)>(0x005E77C0);
	const static auto Live_AreWeJoinable = reinterpret_cast<bool(*)(bool fromInvite, e_JoinRejectionReason *reason)>(0x004EA370);
	const static auto Party_FindMember = reinterpret_cast<int(*)(const PartyData_s * party, netadr_t playerAddr)>(offsets::Party_FindMember);
	const static auto dwInstantHandlePartyMessage = reinterpret_cast<bool(*)(unsigned __int64 senderID, ControllerIndex_t destIndex, msg_t *msg)>(0x005DAD40);

	const static auto BG_seedRandWithGameTime = reinterpret_cast<std::uint32_t*(*)(std::uint32_t* serverTime)>(offsets::BG_seedRandWithGameTime);
	const static auto BG_random = reinterpret_cast<float(*)(std::uint32_t* serverTime)>(offsets::BG_random);
	const static auto BG_GetSpreadForWeapon = reinterpret_cast<void(*)(playerState_s * ps, Weapon weapon, float* minSpread, float* maxSpread)>(offsets::BG_GetSpreadForWeapon);
	const static auto BG_srand = reinterpret_cast<std::uint32_t*(*)(std::uint32_t* serverTime)>(offsets::BG_srand);
	const static auto CL_SetFovSensitivityScale = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, float scale)>(offsets::CL_SetFovSensitivityScale);
	const static auto BG_GetViewmodelWeaponIndex = reinterpret_cast<Weapon(*)(const playerState_s* ps)>(offsets::BG_GetViewmodelWeaponIndex);
	const static auto BG_WeaponHasPerk = reinterpret_cast<bool(*)(Weapon weapon, std::uint32_t perk)>(offsets::BG_WeaponHasPerk);
	const static auto BG_UsingSniperScope = reinterpret_cast<bool(*)(const playerState_s* ps)>(offsets::BG_UsingSniperScope);
	const static auto CL_SetUserCmdAimValues = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, Vec3* angles)>(offsets::CL_SetUserCmdAimValues);
	const static auto CG_GetLastWeaponForAlt = reinterpret_cast<Weapon(*)(const cg_t * cg, const playerState_s * ps, Weapon weapon)>(offsets::CG_GetLastWeaponForAlt);
	const static auto CL_SetUserCmdWeapons = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, Weapon weapon, Weapon offHandWeapon, Weapon lastWeaponForAlt)>(offsets::CL_SetUserCmdWeapons);
	const static auto CL_SetExtraButtons = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, int* button_bits)>(offsets::CL_SetExtraButtons);

	const static auto BG_GetDamageRangeScale = reinterpret_cast<float(*)(Weapon weapon)>(offsets::BG_GetDamageRangeScale);
	const static auto CG_EntityIsDeployedRiotshield = reinterpret_cast<bool(*)(centity_t * ent)>(offsets::CG_EntityIsDeployedRiotshield);
	const static auto BG_AdvanceTrace = reinterpret_cast<bool(*)(BulletFireParams * bp, BulletTraceResults * br, float dist)>(offsets::BG_AdvanceTrace);
	const static auto CG_ClientHasPerk = reinterpret_cast<bool(*)(LocalClientNum_t localClientNum, ClientNum_t clientNum, std::uint32_t perkIndex)>(offsets::CG_ClientHasPerk);
	const static auto BG_GetPenetrateType = reinterpret_cast<PenetrateType(*)(Weapon weapon)>(offsets::BG_GetPenetrateType);
	const static auto BG_GetSurfacePenetrationDepth = reinterpret_cast<float(*)(PenetrateType penetrateType, int surfaceType)>(offsets::BG_GetSurfacePenetrationDepth);
	const static auto BG_GetWeaponDamageForRange = reinterpret_cast<int(*)(Weapon weapon, const Vec3 * start, const Vec3 * hitPos)>(offsets::BG_GetWeaponDamageForRange);
	const static auto G_GetWeaponHitLocationMultiplier = reinterpret_cast<float(*)(short hitLoc, Weapon weapon)>(offsets::G_GetWeaponHitLocationMultiplier);
	const static auto Trace_GetEntityHitId = reinterpret_cast<std::uint16_t(*)(const trace_t* results)>(offsets::Trace_GetEntityHitId);

	const static auto GScr_AllocString = reinterpret_cast<std::uint32_t(*)(const char* s)>(offsets::GScr_AllocString);
	const static auto Com_GetClientDObj = reinterpret_cast<char*(*)(int handle, LocalClientNum_t localClientNum)>(offsets::Com_GetClientDObj);
	const static auto CG_DObjGetWorldTagPos = reinterpret_cast<std::uint32_t(*)(const centity_t * entity, void* obj, scr_string_t tagName, Vec3* pos)>(offsets::CG_DObjGetWorldTagPos);
	const static auto Com_GameMode_IsMode = reinterpret_cast<bool(*)(int a1)>(0x005B44C0);
	const static auto SL_ConvertToString = reinterpret_cast<char*(*)(unsigned int stringValue)>(0x004BE5B0);

	const static auto CL_LocalClientIsInGame = reinterpret_cast<bool(*)()>(offsets::CL_LocalClientIsInGame);
	const static auto BG_IsDualWield = reinterpret_cast<bool(*)(Weapon weapon)>(offsets::BG_IsDualWield);
	const static auto BG_GetWeaponDef = reinterpret_cast<WeaponDef*(*)(Weapon weapon)>(offsets::BG_GetWeaponDef);

	const static auto CG_WorldPosToScreenPos = reinterpret_cast<bool(*)(LocalClientNum_t localClientNum, const Vec3* worldPos, Vec2* outScreenPos)>(offsets::CG_WorldPosToScreenPos);
	//const static auto ScrPlace_GetView = reinterpret_cast<ScreenPlacement*(*)(LocalClientNum_t localClientNum)>(0x004C7EF0);

	const static auto BG_UsingVehicleWeapon = reinterpret_cast<bool(*)(const playerState_s* ps)>(offsets::BG_UsingVehicleWeapon);
	const static auto CG_GetPlayerViewOrigin = reinterpret_cast<bool(*)(LocalClientNum_t localClientNum, const playerState_s * ps, Vec3 * outvec)>(offsets::CG_GetPlayerViewOrigin);
	const static auto CG_GameMessage = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, const char* msg)>(offsets::CG_GameMessage);
	const static auto CG_BoldGameMessage = reinterpret_cast<void(*)(LocalClientNum_t localClientNum, const char* msg, int)>(0x0054A6C0);
	const static auto LiveSteam_PopOverlayForSteamID = reinterpret_cast<void(*)(std::uint64_t steam_id)>(offsets::LiveSteam_PopOverlayForSteamID);
	const static auto PM_WeaponAmmoAvailable = reinterpret_cast<std::uint32_t(*)(const playerState_s* ps)>(offsets::PM_WeaponAmmoAvailable);

	const static auto AngleVectors = reinterpret_cast<void(*)(const Vec3 * angles, Vec3 * forward, Vec3 * right, Vec3 * up)>(offsets::AngleVectors);
	const static auto vectoangles = reinterpret_cast<void(*)(const Vec3* vec, Vec3* angles)>(offsets::vectoangles);
	const static auto ClampChar = reinterpret_cast<char(*)(const int i)>(offsets::ClampChar);
	const static auto angle_normalize_360 = reinterpret_cast<float(*)(const float angle)>(offsets::angle_normalize_360);
	const static auto angle_normalize_180 = reinterpret_cast<float(*)(const float angle)>(offsets::angle_normalize_180);
	const static auto vec3_distancesq = reinterpret_cast<float(*)(Vec3* angle, Vec3* angle2)>(offsets::vec3_distancesq);
	const static auto vec3_normalize = reinterpret_cast<float(*)(Vec3 * angle)>(offsets::vec3_normalize);
	const static auto Friends_SetInviteInfo = reinterpret_cast<int(*)(ControllerIndex_t controllerIndex, XSESSION_INFO sessionInfo, unsigned __int64 fromXuid, bool byInvite)>(0x005E6660);
	const static auto NET_CompareXNAddr = reinterpret_cast<int(*)(const XNADDR *a, const XNADDR *b)>(0x004FE2B0);
	const static auto NET_CompareIPAdr = reinterpret_cast<bool(*)(netadr_t a, netadr_t b)>(0x006D4010);
	const static auto NET_CompareBaseAdr = reinterpret_cast<bool(*)(netadr_t a, netadr_t b)>(0x004C15D0);
	const static auto PartyClient_JoinLocalClientsToParty_Internal = reinterpret_cast<bool(*)(PartyData_s *party, netadr_t partyHost, unsigned int challenge)>(0x00589BC0);
	const static auto BG_UnlockablesIsItemValidNotNull = reinterpret_cast<bool(*)(std::uint32_t)>(0x00530D30);
	const static auto BG_SetAmmoInClip = reinterpret_cast<void(*)(playerState_s *ps, Weapon weapon, int amount)>(0x006B0660);
	const static auto PartyMigrate_MigrateActive = reinterpret_cast<bool(*)(PartyData_s* party)>(0x00548D90);
	const static auto Com_LocalClient_GetUIContextIndex = reinterpret_cast<int(*)(LocalClientNum_t)>(0x006678C0);

	extern std::unordered_map<std::string, bool> handlers;
	extern std::array<scr_string_t, static_cast<std::size_t>(bone_tag::num_tags)> bone_tags;
	extern PartyData_s* party;
	extern std::vector<std::string> map_names;

	namespace oob
	{
		bool send_data(const game::netadr_t& target, const std::string& data);
		bool send(const game::netadr_t& target, const std::string& data);
	}

	void initialize();
	bool send_unhandled_message(const std::string& command, const netadr_t& target);
	int find_target_from_addr(const netadr_t & adr);
	clientConnection_t* clc();
	clientActive_t* cl();
	float get_weapon_damage_range(const Weapon& weapon);
	void fast_reload(const playerState_s* ps);
	bool current_ammo_equal_to_clip_size(const playerState_s* ps, Weapon cur_weapon);
	bool is_valid_target(const size_t client_num);
	int Party_FindMemberByXUID(const std::uint64_t player);
	connstate_t& CL_GetLocalClientConnectionState(/*LocalClientNum_t localClientNum*/);
	clientMigState_t& CL_GetLocalClientMigrationState();
	bool is_enemy(size_t client_num);
	bool is_friend(std::size_t client_num);
	void set_fov(const float fov);
	void cycling_prestige();
	void spectator_client_handler();
	void anti_leave();
	void on_every_frame();
	bool is_packet_from_host(const netadr_t & from);
	void send_host_crashes(const int index = -1);
	float BG_EvaluateTrajectoryInternal(const trajectory_t* tr, std::uint32_t time, Vec3& result, float scale);
	void adjust_user_cmd_movement(usercmd_s * cmd_old, const float angle, const float old_angle);
	bool can_parse_party_state(const char * command, const std::uint8_t segment, const std::uint32_t total_size, const std::uint16_t offset, const std::uint16_t size);
	bool can_attempt_to_join_party(const char * command, const std::uint32_t net_version, const std::uint32_t net_field_checksum, const std::uint32_t playlist_version_number, const std::uint32_t change_list, const std::uint32_t new_sub_party_count);
	bool can_process_fragment(const netchan_t * chan, const msg_t* msg, const std::uint8_t fragment_index, const std::uint16_t fragment_size, const std::uint16_t fragment_length);
	bool send_exploit_caught_messages(const std::string& command, const netadr_t& target);
	void change_name(const std::string & name = {}, const std::string & clan_tag = {});
	bool is_bot(size_t index);
	bool is_party_privacy_closed();
	bool recieved_blocked_join_request(const std::string & sender_name, const std::uint64_t & sender_id, const JoinSessionMessage & message);
	bool recieved_join_party_request(const netadr_t& adr, const bool blocked = false);
	void open_toast_popup(const std::string & message, const std::uint32_t ms = 2700, const std::string & icon = {});
	bool is_user_signed_into_demonware();
	void make_dvar_server_info(const char * dvar_name, const char * value);
	void * LiveStats_GetPrivateKey();
	bool BG_UnlockablesSetItemPurchased(int itemIndex, bool isPurchased);
	void CG_RemoveChatEscapeChar(char * text);
	std::string get_localized_chat_text_message(const char * message, const char * message_type);
	std::string get_translated_hud_elem_message(const std::string & game_message, const std::string & message);
	std::string get_oob_command(const netadr_t & target);
	bool can_draw_overhead_names(const centity_t * cent);
	bool is_invalid_material_pointer(const char * string);
	std::vector<std::uint32_t> get_party_ids();
	bool is_hosting();
	bool can_send_out_of_band_packet_to_friend(const std::size_t client_num, const netadr_t & target);
	bool set_ip_address(void * ip_bytes, std::vector<std::string> ip_string);
	Vec2 get_scale(const centity_t * cent, const float pos);
	Vec3 get_top_position(const centity_t * cent);
	Vec2 get_screen_pos(const Vec3 & world_pos);
	void PartyProber_StartInvite();
	void send_server_command(const int client_num, const std::string & command);
	int I_stricmp(const std::string& a, const std::string& b);
	char* I_strncpyz(char* place, const std::string& string, const size_t length);
	bool transmit_fragment(const game::netchan_t & chan, const std::uint8_t index, const std::uint16_t size, const std::string & data);
	bool transmit_fragment(const std::uint8_t index, const std::uint16_t size, const std::string & data);
	
	inline centity_t* centity(const std::size_t index)
	{
		return reinterpret_cast<centity_t*>(*reinterpret_cast<std::uintptr_t*>(offsets::centity_t) + sizeof centity_t * index);
	}

	inline clientConnection_t* clc() {
		return reinterpret_cast<clientConnection_t*>(*reinterpret_cast<std::uintptr_t*>(offsets::clientConnections));
	}

	inline clientActive_t* cl() {
		return reinterpret_cast<clientActive_t*>(*reinterpret_cast<std::uintptr_t*>(offsets::clientActive));
	}

	inline cg_t* cg()
	{
		return reinterpret_cast<cg_t*>(*reinterpret_cast<std::uintptr_t*>(offsets::cg));
	}

	inline gclient_t* gclient(const std::size_t index)
	{
		return *reinterpret_cast<gclient_t**>(offsets::gentity_t + index * 0x31C + 0x154);
	}

	inline level_locals_t* level()
	{
		return reinterpret_cast<level_locals_t*>(0x02366B80);
	}

	inline ScreenPlacement* screen_placement()
	{
		return reinterpret_cast<ScreenPlacement*>(0x012C2300 + sizeof ScreenPlacement * Com_LocalClient_GetUIContextIndex(0));
	}

	inline client_t* svs_client(const std::size_t index)
	{
		return reinterpret_cast<client_t*>(*reinterpret_cast<std::uintptr_t*>(0x0291C0C0) + 0x4E180 * index);
	}

	inline auto get_tag(const bone_tag t)
	{
		if (t >= bone_tag::num_tags)
			return static_cast<scr_string_t>(0u);

		return bone_tags[static_cast<std::size_t>(t)];
	}

	inline auto SV_Cmd_Argc()
	{
		return cmd_argc_sv[*cmd_id_sv];
	}
}