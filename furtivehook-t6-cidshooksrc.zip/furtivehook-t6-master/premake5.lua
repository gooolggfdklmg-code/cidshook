workspace "furtivehook-t6"
    location "build/"
    startproject "furtivehook-t6"

    targetdir "%{wks.location}/bin/%{cfg.buildcfg}/"
    objdir "%{wks.location}/obj/%{cfg.buildcfg}/%{prj.name}/"
    buildlog "%{wks.location}/obj/%{cfg.buildcfg}/%{prj.name}.log"

    systemversion "latest"
    architecture "x86"
    characterset "mbcs"
    warnings "off"
    editandcontinue "off"
    staticruntime "on"

    disablewarnings {
        "4005",
        "4099",
        "5054",
        "26812"
    }

    includedirs {
        "src/",
        "$(DXSDK_DIR)include/",
    }

    buildoptions {
        "/Zm200",
        "/utf-8",
        "/std:c++latest",
    }

    flags {
        "shadowedvariables",
        "noincrementallink",
        "undefinedidentifiers",
        "multiprocessorcompile",
    }

    defines {
        "NOMINMAX",
        "WIN32_LEAN_AND_MEAN",
        "_CRT_SECURE_NO_WARNINGS"
    }

    platforms {
        "x86",
    }

    configurations {
        "debug",
        "release",
    }

    configuration "debug"
        defines {
            "DEBUG",
            "STEAM"
        }

        optimize "debug"
        runtime "debug"
        symbols "on"

        targetname "furtivehook-t6-debug"

        postbuildcommands { "copy /Y \"%{wks.location}\\bin\\%{cfg.buildcfg}\\furtivehook-t6-debug.dll\" \"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Call of Duty Black Ops II\\d3d11.dll\"" }

    configuration "release"
        defines {
             "NDEBUG",
             "STEAM"
        }
        
        optimize "off"
        runtime "release"
        symbols "on"

        targetname "furtivehook-t6-release"

        postbuildcommands { "copy /Y \"%{wks.location}\\bin\\%{cfg.buildcfg}\\furtivehook-t6-release.dll\" \"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Call of Duty Black Ops II\\d3d11.dll\"" }

project "furtivehook-t6"
    kind "sharedlib"
    language "c++"
    
	dependson {
        "imgui",
        "steam_api",
    }
    
    files {
		"src/**.h",
		"src/**.hpp",
		"src/**.cpp",
    }
    
	links {
        "imgui",
        "steam_api",
        "detours.lib",
        "ws2_32.lib",
        "steam_api.lib"
    }
    
	includedirs {
        "src/"
    }

    libdirs {
        "thirdparty/detours/lib/",
        "thirdparty/steam_api/lib/"
    }

project "imgui"
    targetname "imgui"
    warnings "off"

    language "c++"
    kind "staticlib"

    files {
        "thirdparty/imgui/*.h",
        "thirdparty/imgui/*.hpp",
        "thirdparty/imgui/*.cpp"
    }

    includedirs {
        "thirdparty/imgui",
    }

 project "steam_api"
    targetname "steam_api"
    warnings "off"

    language "c++"
    kind "staticlib"

    files {
        "thirdparty/steam_api/*.hpp",
    }

    includedirs {
        "thirdparty/steam_api",
        "thirdparty/steam_api/lib",
    }