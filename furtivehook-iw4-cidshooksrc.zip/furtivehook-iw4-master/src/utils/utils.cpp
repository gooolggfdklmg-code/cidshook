#include "dependencies/stdafx.hpp"
#include "utils.hpp"

namespace utils
{
	FILE* file_out;
	
	std::string get_sender_string(const game::netadr_t& from)
	{
		const auto ip_str{ from.to_string(true) };
		const auto party{ game::party_data() };
		const auto client_num{ game::Party_FindMember(party, from) };

		if (client_num < 0)
		{
			return utils::string::va("%s", ip_str.data());
		}

		const auto member = party->partyMembers[client_num];
		return utils::string::va("'%s' (%llu) %s", member.gamertag, member.player, ip_str.data());
	}
	
	void open_console()
	{
		AllocConsole();
		AttachConsole(GetCurrentProcessId());
		freopen_s(&file_out, "CONOUT$", "w", stdout);

		SetConsoleTitleA("furtivehook");
	}

	void close_console()
	{
		fclose(file_out);
		FreeConsole();
	}
	
	void print_stack_details(const std::uintptr_t* esp, const std::uintptr_t* ebp)
	{
		if (esp)
		{
			PRINT_LOG("ESP: [0x%p]", esp);
			for (size_t i = 0; i < 256; ++i)
			{
				const auto ptr = esp + i;
				PRINT_LOG("[%i]: 0x%p 0x%08X", i, ptr, *ptr);
			}
		}

		if (ebp)
		{
			PRINT_LOG("EBP: [0x%p]", ebp);
			for (size_t i = 0; i < 256; ++i)
			{
				const auto ptr = ebp + i;
				PRINT_LOG("[%i]: 0x%p 0x%08X", i, ptr, *ptr);
			}
		}
	}
}