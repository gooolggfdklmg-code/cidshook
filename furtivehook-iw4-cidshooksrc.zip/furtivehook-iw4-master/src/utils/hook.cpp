#include "dependencies/stdafx.hpp"
#include "hook.hpp"

namespace utils::hook
{
	void detour(void** original, void* func)
	{
		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());
		DetourAttach(original, func);
		DetourTransactionCommit();
	}

	void detour(void* original, void* func) 
	{ 
		detour(reinterpret_cast<void**>(original), func); 
	}

	void retn(const uintptr_t address)
	{
		set(address, instr::ret);
	}
	
	void nop(const uintptr_t address, const size_t size)
	{
		DWORD old_protect{ 0 };
		VirtualProtect(reinterpret_cast<void*>(address), size, PAGE_EXECUTE_READWRITE, &old_protect);

		std::memset(reinterpret_cast<void*>(address), std::uint8_t(instr::nop), size);

		VirtualProtect(reinterpret_cast<void*>(address), size, old_protect, &old_protect);
		
		FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void*>(address), size);
	}
}