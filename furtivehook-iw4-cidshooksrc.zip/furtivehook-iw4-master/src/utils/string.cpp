#include "dependencies/stdafx.hpp"
#include "string.hpp"

namespace utils::string
{
	std::string get_log_file(const std::string& dir, const std::string& ext)
	{
		return "furtivehook/" + dir + "/furtivehook-" + utils::string::data_time() + "." + ext;
	}

	std::string data_time(time_t seconds, const bool date_only)
	{
		const auto time = seconds == 0 ? std::time(nullptr) : seconds;
		const auto local_time = std::localtime(&time);

		char timestamp[MAX_PATH] = { 0 };

		if (date_only)
		{
			std::strftime(timestamp, sizeof(timestamp), "%F", local_time);
		}
		else
		{
			std::strftime(timestamp, sizeof(timestamp), "%F %r", local_time);
		}

		return timestamp;
	}
	
	std::uint32_t string_to_ip(const std::string& target)
	{
		addrinfo* result = nullptr;
		addrinfo hints = {};
		hints.ai_family = AF_INET;

		getaddrinfo(target.data(), nullptr, &hints, &result);

		if (result)
		{
			return reinterpret_cast<sockaddr_in*>(result->ai_addr)->sin_addr.S_un.S_addr;
		}

		return 0;
	}
	
	std::string join(const std::vector<std::string>& args, const std::size_t index)
	{
		auto result = ""s;

		for (auto i = index; i < args.size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(args[i]);
		}

		return result;
	}
	
	std::string dump_hex(const std::string& data, const std::string& separator)
	{
		auto result = ""s;

		for (size_t i = 0; i < data.size(); ++i)
		{
			if (i > 0)
			{
				result.append(separator);
			}

			result.append(va("%02X", data[i] & 0xFF));
		}

		return result;
	}
	
	std::string format(const va_list ap, const char* message)
	{
		static thread_local char buffer[0x1000];

		const auto count = vsnprintf_s(buffer, sizeof(buffer), _TRUNCATE, message, ap);

		if (count < 0) return {};
		return { buffer, static_cast<size_t>(count) };
	}
	
	std::string va(const char* fmt, ...)
	{
		static thread_local va_provider<8, 256> provider;

		va_list ap;
		va_start(ap, fmt);

		const auto* result = provider.get(fmt, ap);

		va_end(ap);
		return result;
	}

	std::vector<std::string> split(const std::string& text, const char delimiter)
	{
		std::stringstream ss(text);
		std::string item;
		std::vector<std::string> elems;

		while (std::getline(ss, item, delimiter))
		{
			if (!item.empty())
			{
				elems.emplace_back(item);
			}
		}

		return elems;
	}

	std::string replace_all(std::string str, const std::string& from, const std::string& to)
	{
		if (from.empty())
		{
			return str;
		}
		
		std::string::size_type start_pos = 0;

		while ((start_pos = str.find(from, start_pos)) != std::string::npos)
		{
			str.replace(start_pos, from.length(), to);
			start_pos += to.length();
		}

		return str;
	}

	bool begins_with(const std::string& text, const std::string& substring)
	{
		return text.find(substring) == 0;
	}

	bool contains(const std::string &text, const std::string &substring)
	{
		return text.find(substring) != std::string::npos;
	}

	bool ends_with(const std::string& text, const std::string& substring)
	{
		if (substring.size() > text.size()) return false;
		return std::equal(substring.rbegin(), substring.rend(), text.rbegin());
	}

	std::string to_lower(std::string text)
	{
		std::transform(text.begin(), text.end(), text.begin(), [](const auto& input) { return static_cast<char>(std::tolower(input)); });
		return text;
	}

	std::string to_upper(std::string text)
	{
		std::transform(text.begin(), text.end(), text.begin(), [](const auto& input) { return static_cast<char>(std::toupper(input)); });
		return text;
	}

	std::string reverse_words(std::string_view s)
	{
		std::string result;
		result.reserve(s.size());

		while (!s.empty())
		{
			const auto i = s.rfind(' ');
			result.append(s.begin() + i + 1, s.end());

			if (i == std::string_view::npos) break;

			s = s.substr(0, i);
		}

		return result;
	}

	std::string random(const size_t length)
	{
		const auto random_characters = "0123456789" "ABCDEFGHIJKLMNOPQRSTUVWXYZ" "abcdefghijklmnopqrstuvwxyz"s;

		std::mt19937 engine{ std::random_device{}() };
		std::uniform_int_distribution<std::string::size_type> dist(0, random_characters.size() - 1);

		std::string result(length, 0);
		std::generate_n(result.begin(), length, [&]()
		{ 
			const auto index = dist(engine); 
			return random_characters[index];
		});

		return result;
	};

	bool is_numeric(const std::string& text)
	{
		return std::to_string(utils::atoi(text)) == text;
	}

	std::string strip(const std::string& string)
	{
		const auto result = game::I_CleanStr(string.data());
		return result;
	}
}