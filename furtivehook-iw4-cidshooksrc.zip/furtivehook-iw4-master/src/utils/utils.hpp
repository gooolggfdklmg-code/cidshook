#pragma once
#include "dependencies/stdafx.hpp"

namespace utils
{
	void close_console();
	void print_stack_details(const std::uintptr_t * esp, const std::uintptr_t * ebp);
	std::string get_sender_string(const game::netadr_t& from);
	void open_console();

	template <typename T> auto atoi(const std::string& str)
	{
		return static_cast<T>(std::atoi(str.data()));
	}

	static auto atoi(const std::string& str)
	{
		return atoi<int>(str);
	}

	static auto atoll(const std::string& str)
	{
		return static_cast<std::uint64_t>(std::atoll(str.data()));
	}
}
