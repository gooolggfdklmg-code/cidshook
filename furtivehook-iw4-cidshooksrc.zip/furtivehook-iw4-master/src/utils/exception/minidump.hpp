#pragma once
#include "dependencies/stdafx.hpp"

namespace utils::exception::minidump
{
	bool write(const LPEXCEPTION_POINTERS ex);
}