#pragma once
#include "dependencies/stdafx.hpp"

namespace utils::concurrency
{
	template <typename T, typename MutexType = std::mutex>
	class container
	{
	public:
		template <typename R = void, typename T>
		R access(T&& accessor) const
		{
			std::lock_guard<MutexType> _{ mutex_ };
			return accessor(object_);
		}

		template <typename R = void, typename T>
		R access(T&& accessor)
		{
			std::lock_guard<MutexType> _{ mutex_ };
			return accessor(object_);
		}

		template <typename R = void, typename T>
		R access_with_lock(T&& accessor) const
		{
			std::unique_lock<MutexType> lock{ mutex_ };
			return accessor(object_, lock);
		}

		template <typename R = void, typename T>
		R access_with_lock(T&& accessor)
		{
			std::unique_lock<MutexType> lock{ mutex_ };
			return accessor(object_, lock);
		}

		T& get_raw() { return object_; }
		const T& get_raw() const { return object_; }

	private:
		mutable MutexType mutex_{};
		T object_{};
	};
}