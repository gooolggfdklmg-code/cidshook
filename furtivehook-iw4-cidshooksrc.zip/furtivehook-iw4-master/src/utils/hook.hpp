#pragma once
#include "dependencies/stdafx.hpp"

namespace utils::hook
{
	enum class instr : uint8_t
	{ 
		call = 0xE8, 
		jmp = 0xE9,
		ret = 0xC3,
		mov = 0xB8,
		nop = 0x90,
	};
	
	void detour(void** original, void* func);
	void detour(void* original, void* func);
	void retn(const uintptr_t address);
	void nop(const uintptr_t address, const size_t size);

	template <typename T> void set(const uintptr_t address, const T value)
	{
		DWORD old_protect{ 0 };
		VirtualProtect(reinterpret_cast<void*>(address), sizeof value, PAGE_EXECUTE_READWRITE, &old_protect);

		*reinterpret_cast<T*>(address) = value;

		VirtualProtect(reinterpret_cast<void*>(address), sizeof value, old_protect, &old_protect);
		
		FlushInstructionCache(GetCurrentProcess(), reinterpret_cast<void*>(address), sizeof value);
	}

	template <typename T> auto iat(const std::string& mod_name, const std::string& proc_name, T function)
	{
		const nt::library main;
		if (!main.is_valid()) return T();

		auto ptr = main.get_iat_entry(mod_name, proc_name);
		if (!ptr) return T();

		auto original = *ptr;
		set(ptr, reinterpret_cast<uintptr_t*>(function));
		return reinterpret_cast<T>(original);
	}
	
	template <typename T> void set(const void* place, const T value)
	{
		set<T>(reinterpret_cast<uintptr_t>(place), value);
	}
	
	template <typename T> void jump(const uintptr_t address, const T function)
	{
		set(address, instr::jmp);
		set(address + 1, uintptr_t(function) - address - 5);
	}

	template <typename T> void jump(const void* place, const T function)
	{
		jump<T>(uintptr_t(place), function);
	}

	template <typename T> void call(const uintptr_t address, const T function)
	{
		set(address, instr::call);
		set(address + 1, uintptr_t(function) - address - 5);
	}

	template <typename T> void return_value(const uintptr_t address, const T value)
	{
		set(address, instr::mov);
		set(address + 1, uintptr_t(value));
		set(address + 5, instr::ret);
	}

	template<typename T> T vtable(uintptr_t instance, const size_t index, T function)
	{
		auto table = *reinterpret_cast<uintptr_t**>(instance);
		
		MEMORY_BASIC_INFORMATION mbi{};
		VirtualQuery(reinterpret_cast<void*>(table), &mbi, sizeof(mbi));
		VirtualProtect(mbi.BaseAddress, mbi.RegionSize, PAGE_READWRITE, &mbi.Protect);

		const auto original = table[index];
		table[index] = uintptr_t(function);

		VirtualProtect(mbi.BaseAddress, mbi.RegionSize, mbi.Protect, &mbi.Protect);
		
		return reinterpret_cast<T>(original);
	}

	template <typename T> T vtable(const void* place, const size_t index, T function)
	{
		return vtable<T>(uintptr_t(place), index, function);
	}
}