#pragma once
#include "dependencies/stdafx.hpp"

namespace math
{
	float angle_normalize_360(const float angle);
	float angle_normalize_180(const float angle);
	float angle_delta(const float angle, const float angle2);
	Vec3 angle_normalize_360(const Vec3 & v);
	Vec3 angle_normalize_180(const Vec3 & v);
	Vec3 angle_delta(const Vec3 & angles1, const Vec3 & angles2);
}
