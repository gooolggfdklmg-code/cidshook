#pragma once

namespace offsets
{
	constexpr auto window = 0x00642E218;
	constexpr auto end_address = 0x0067D000;

	constexpr auto g_inLobby = 0x066547A9;
	constexpr auto g_IWLobbyJoinInProgress = 0x066547AB;
	constexpr auto g_localSteamClient = 0x066547BC;
	constexpr auto inviteState = 0x0642C520;
	constexpr auto clientMatchData = 0x02031684;
	constexpr auto g_serverSession = 0x06641358;
	constexpr auto g_partyData = 0x010F5A98;
	constexpr auto g_lobbyData = 0x010F9268;
	constexpr auto g_entities = 0x0194B9D0;
	constexpr auto g_client = 0x01B0E1C0;
	constexpr auto device = 0x06664C60;
}