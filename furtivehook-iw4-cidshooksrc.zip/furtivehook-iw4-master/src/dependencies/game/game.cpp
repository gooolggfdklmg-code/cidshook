#include "dependencies/stdafx.hpp"
#include "game.hpp"

namespace game
{
	gentity_s* g_entities = reinterpret_cast<gentity_s*>(0x0194B9D0);
	sv_clients_t* svs_client = reinterpret_cast<sv_clients_t*>(0x03172088);
	std::array<scr_string_t, static_cast<std::size_t>(bone_tag::num_tags)> bone_tags;

	namespace net
	{
		SOCKET ip_socket{};
		
		sockaddr_in convert_to_sockaddr(const game::netadr_t& target)
		{
			sockaddr_in to{};
			to.sin_family = AF_INET;
			to.sin_addr.S_un.S_addr = target.addr.inaddr;
			to.sin_port = target.addr.port;
			return to;
		}
		
		void create_ip_socket()
		{
			ip_socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
			
			if (ip_socket == INVALID_SOCKET)
			{
				throw std::runtime_error("Unable to create socket");
			}
			
			unsigned long mode = 1;
			ioctlsocket(ip_socket, FIONBIO, &mode);

			constexpr char broadcast = 1;
			setsockopt(ip_socket, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast));

			sockaddr_in server_addr{};
			server_addr.sin_family = AF_INET;
			server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
			server_addr.sin_port = htons(3300); // 1500, 3300, 3101
			
			int retries = 0;
			while (bind(ip_socket, reinterpret_cast<const sockaddr*>(&server_addr), sizeof(server_addr)) ==
				SOCKET_ERROR)
			{
				if (++retries > 10) return;
				server_addr.sin_port = htons(ntohs(server_addr.sin_port) + 1);
			}
		}
			
		bool send_packet(const netadr_t& target, const std::string& data)
		{
			const auto to = convert_to_sockaddr(target);
			return ::sendto(ip_socket, data.data(), static_cast<int>(data.size()), 0,
				reinterpret_cast<const sockaddr*>(&to), sizeof(to));
		}

		bool send_data(const game::netadr_t& target, const std::string& data)
		{
			const auto sock{ target.type == game::NA_LOOPBACK ? NS_CLIENT1 : NS_SERVER };
			return NET_SendPacket(sock, data.size(), data.data(), target);
		}

		bool send_oob(const game::netadr_t& target, const std::string& data, const bool packet)
		{
			auto to{ target };
			if (game::is_real_address(*game::g_ourXnaddr, to))
			{
				to.addr.inaddr = 0x0100007F;
				to.addr.port = ntohs(28960);
				to.type = NA_IP;
			}

			const auto final_data{ "\xff\xff\xff\xff" + data };
			return packet ? send_packet(to, final_data) : send_data(to, final_data);
		}

		bool send_oob(const game::netadr_t& target, const msg_t& msg, const bool packet)
		{
			return send_oob(target, { msg.data, static_cast<std::string::size_type>(msg.cursize) }, packet);
		}

		bool send_relay_packet(const game::netadr_t& to, const size_t client_num, const std::string& data)
		{
			if (const auto party = game::party_data(); party->inParty && party->session->dyn.sessionStartCalled)
			{
				if (party->areWeHost)
				{
					return net::send_oob(party->session->dyn.users[client_num].addr, data);
				}

				return net::send_oob(to, "relay " + std::to_string(client_num) + "\n" + data);
			}

			return false;
		}

		bool send_relay_packet(const size_t client_num, const std::string& data)
		{
			return send_relay_packet(game::CL_IsLocalClientInGame() ? game::clc()->serverAddress : game::party_data()->currentHost.adr, client_num, data);
		}

		bool send_connectivity_test(const game::netadr_t& to, const size_t client_num)
		{
			if (const auto our_client_num = game::Party_FindMemberByXUID(game::Live_GetXuid(0)); our_client_num >= 0)
			{
				auto data{ "vt\n"s };
				data.push_back(our_client_num);
				const auto xuid = game::Live_GetXuid(0);
				data.append(reinterpret_cast<const char*>(&xuid), sizeof xuid);
				return net::send_oob(to, data);
			}

			return false;
		}

		bool send_peer_to_peer_oob(const size_t client_num, const std::string& data)
		{
			const auto session{ game::party_data()->session };

			if (session == nullptr)
				return false;

			if (const auto relay_route = find_route_to_player(session, client_num); relay_route >= 0)
			{
				return net::send_relay_packet(session->dyn.users[relay_route].addr, client_num, data);
			}

			return net::send_oob(session->dyn.users[client_num].addr, data);
		}

		bool transmit_data(const netchan_t& chan, const std::string& data)
		{
			auto buffer{ ""s };
			buffer.reserve(1400);

			const auto sequence{ chan.outgoingSequence };
			const auto qport{ static_cast<std::uint16_t>(chan.qport) };

			buffer.append(reinterpret_cast<const char*>(&sequence), sizeof sequence);

			if (chan.sock < NS_SERVER)
				buffer.append(reinterpret_cast<const char*>(&qport), sizeof qport);

			buffer.append(data);

			return net::send_data(chan.remoteAddress, buffer);
		}

		bool transmit_data(const netchan_t& chan, const msg_t& msg)
		{
			return transmit_data(chan, { msg.data, static_cast<std::string::size_type>(msg.cursize) });
		}
	}

	void initialize()
	{
		bone_tags[static_cast<std::size_t>(bone_tag::helmet)] = GScr_AllocString("j_helmet");
		bone_tags[static_cast<std::size_t>(bone_tag::head_end)] = GScr_AllocString("j_head_end");
		bone_tags[static_cast<std::size_t>(bone_tag::head)] = GScr_AllocString("j_head");
		bone_tags[static_cast<std::size_t>(bone_tag::neck)] = GScr_AllocString("j_neck");
		bone_tags[static_cast<std::size_t>(bone_tag::shoulder_left)] = GScr_AllocString("j_shoulder_le");
		bone_tags[static_cast<std::size_t>(bone_tag::shoulder_right)] = GScr_AllocString("j_shoulder_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::clavicle_left)] = GScr_AllocString("j_clavicle_le");
		bone_tags[static_cast<std::size_t>(bone_tag::clavicle_right)] = GScr_AllocString("j_clavicle_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::spineupper)] = GScr_AllocString("j_spineupper");
		bone_tags[static_cast<std::size_t>(bone_tag::spine)] = GScr_AllocString("j_spine4");
		bone_tags[static_cast<std::size_t>(bone_tag::spinelower)] = GScr_AllocString("j_spinelower");
		bone_tags[static_cast<std::size_t>(bone_tag::hip_left)] = GScr_AllocString("j_hip_le");
		bone_tags[static_cast<std::size_t>(bone_tag::hip_right)] = GScr_AllocString("j_hip_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::knee_left)] = GScr_AllocString("j_knee_le");
		bone_tags[static_cast<std::size_t>(bone_tag::knee_right)] = GScr_AllocString("j_knee_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_left)] = GScr_AllocString("j_wrist_le");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_right)] = GScr_AllocString("j_wrist_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_twist_left)] = GScr_AllocString("j_wristtwist_le");
		bone_tags[static_cast<std::size_t>(bone_tag::wrist_twist_right)] = GScr_AllocString("j_wristtwist_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_left)] = GScr_AllocString("j_elbow_le");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_right)] = GScr_AllocString("j_elbow_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_buldge_left)] = GScr_AllocString("j_elbow_bulge_le");
		bone_tags[static_cast<std::size_t>(bone_tag::elbow_buldge_right)] = GScr_AllocString("j_elbow_bulge_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::ankle_left)] = GScr_AllocString("j_ankle_le");
		bone_tags[static_cast<std::size_t>(bone_tag::ankle_right)] = GScr_AllocString("j_ankle_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::ball_left)] = GScr_AllocString("j_ball_le");
		bone_tags[static_cast<std::size_t>(bone_tag::ball_right)] = GScr_AllocString("j_ball_ri");
		bone_tags[static_cast<std::size_t>(bone_tag::mainroot)] = GScr_AllocString("j_mainroot");

		rendering::initialize();
		security::initialize();
		exception::initialize();
		exploit::initialize();
		network::initialize();
		friends::initialize();
		session::initialize();
		server_command::initialize();
		steam::initialize();
		events::initialize();
		prediction::initialize();
		autowall::initialize();
		host::initialize();
		command::initialize();
		dvar::initialize();
		stats::initialize();
		bots::initialize();

		net::create_ip_socket();

		PRINT_LOG("Initialized!");
	}

	size_t get_client_num(const PartyMember* member)
	{
		return member - party_data()->partyMembers;
	}

	size_t get_client_num(const client_t* client)
	{
		return client - svs_client->clients;
	}

	float get_weapon_damage_range(const game::playerState_s* ps, const Weapon weapon)
	{
		const auto perks = cg()->clients[ps->clientNum].perks;
		const auto weapon_def = game::bg_weaponDefs(weapon);

		if (BG_WeaponBulletFire_ShouldSpread(perks, weapon_def))
		{
			return weapon_def->fMinDamageRange;
		}

		return 8192.0f;
	}

	int Bullet_GetDamage(const BulletTraceResults& br, const BulletFireParams& bp, const WeaponDef& weapon)
	{
		const auto damage = weapon.damage;
		const auto min_damage = weapon.minDamage;
		auto final_damage = damage;

		if (damage != min_damage)
		{
			const auto min_damage_range = weapon.fMinDamageRange;
			const auto max_damage_range = weapon.fMaxDamageRange;
			const auto dist = br.hitPos.distance(bp.origStart);

			if (max_damage_range > dist)
				return static_cast<int>(bp.damageMultiplier * damage);

			if (min_damage_range > dist)
			{
				const auto bpd = (dist - max_damage_range) / (min_damage_range - max_damage_range);
				const auto bpe = bpd * min_damage + (1.0f - bpd) * damage;

				return static_cast<int>(bp.damageMultiplier * static_cast<float>(static_cast<int>(bpe)));
			}

			final_damage = min_damage;
		}

		return static_cast<int>(bp.damageMultiplier * final_damage);
	}

	bool is_enemy(size_t client_num)
	{
		if (cg()->clients[client_num].team == TEAM_FREE)
		{
			return true;
		}

		return cg()->clients[client_num].team != cg()->clients[cg()->predictedPlayerState.clientNum].team;
	}

	bool AimTarget_GetTagPos(const game::centity_t* cent, const scr_string_t& tag_name, Vec3* end)
	{
		if (const auto dobj = game::Com_GetClientDObj(cent->number); dobj)
		{
			return CG_DObjGetWorldTagPos(cent, dobj, tag_name, end);
		}

		return false;
	}

	int get_held_weapon_slot(const game::playerState_s* ps, const Weapon& weapon)
	{
		for (size_t i = 0; i < 15; ++i)
		{
			if (weapon && weapon == ps->weaponsEquipped[i])
			{
				return i;
			}
		}

		return -1;
	}

	int Party_FindMemberByXUID(const std::uint64_t player)
	{
		for (size_t i = 0; i < 18; ++i)
		{
			const auto member = party_data()->partyMembers[i];
			if (member.status >= 3 && member.player == player)
				return i;
		}

		return -1;
	}

	bool is_valid_target(const size_t client_num)
	{
		return CL_IsLocalClientInGame() ? cg()->clients[client_num].infoValid : party_data()->is_user_registered(client_num);
	}

	void send_server_command(const int client_num, const std::string& command)
	{
		if (client_num < -1 || client_num >= 18)
			return;
		if (!game::CL_IsLocalClientInGame())
			return;

		if (game::IsServerRunning())
			game::SV_GameSendServerCommand(client_num, SV_CMD_RELIABLE, command.data());
		else
			exploit::join_party::send_payload("svcmd", { std::to_string(client_num), command });
	}

	void join_lobby_ip(std::string address)
	{
		auto port{ "28960"s };
		if (const auto pos{ address.find_first_of(':') }; pos != std::string::npos)
		{
			port = address.substr(pos + 1);
			address = address.substr(0, pos);
		}

		if (g_inLobby && !g_IWLobbyJoinInProgress)
		{
			g_inLobby = false;
		}

		std::memset(reinterpret_cast<uint32_t*>(*reinterpret_cast<uintptr_t*>(offsets::g_localSteamClient) + 160), 0, sizeof XNADDR);
		*reinterpret_cast<uint32_t*>(*reinterpret_cast<uintptr_t*>(offsets::g_localSteamClient) + 168) = utils::string::string_to_ip(address);
		*reinterpret_cast<uint16_t*>(*reinterpret_cast<uintptr_t*>(offsets::g_localSteamClient) + 174) = utils::atoi<uint16_t>(port);

		inviteState = 2;

		PRINT_LOG("Joining session %s:%s", address.data(), port.data());
	}

	std::string get_client_name(const game::PartyMember* pm, const size_t index)
	{
		char player_name[38] = {};
		CL_GetClientName(0, index, player_name, sizeof player_name);

		if (party_data() == g_partyData)
		{
			game::I_strncpyz(player_name, pm->gamertag, sizeof player_name);
			return player_name;
		}

		return player_name;
	}

	connstate_t& CL_GetLocalClientConnectionState(/*LocalClientNum_t localClientNum*/)
	{
		return *reinterpret_cast<connstate_t*>(0x00BC43C0);
	}

	clientMigState_t& CL_GetLocalClientMigrationState(/*LocalClientNum_t localClientNum*/)
	{
		return *reinterpret_cast<clientMigState_t*>(0x00BC3880);
	}

	bool is_same_address(const std::string& adr, const netadr_t& target)
	{
		game::netadr_t netadr{};
		if (!game::NET_StringToAdr(adr.data(), &netadr))
			return false;

		if (!game::NET_CompareAdr(netadr, target))
			return false;

		return true;
	}

	netadr_t net_string_to_adr(const std::string& adr)
	{
		netadr_t netadr{};
		if (!game::NET_StringToAdr(adr.data(), &netadr))
		{
			return {};
		}

		return netadr;
	}

	bool CG_WorldPosToScreenPos(const Vec3* world_pos, Vec2* out_pos)
	{
		const static auto CG_WorldPosToScreenPos = reinterpret_cast<bool(*)(LocalClientNum_t, void*, const Vec3 * worldPos, Vec2 * outScreenPos)>(0x0048BF30);
		return CG_WorldPosToScreenPos(0, ScrPlace_GetActivePlacement(0), world_pos, out_pos);
	}

	Vec2 get_screen_pos(const Vec3& world_pos)
	{
		Vec2 out{};

		if (const auto screen_pos = CG_WorldPosToScreenPos(&world_pos, &out); screen_pos)
		{
			return out;
		}

		return {};
	}

	Vec2 get_scale(const centity_t* cent, const float pos)
	{
		Vec2 scale{};

		if (cent->flags & 0x08)
		{
			scale.set(pos / 1.5f, pos / 2.0f);
		}

		else if (cent->flags & 0x04)
		{
			scale.set(pos / 2.0f, pos / 2.0f);
		}

		else
		{
			scale.set(pos / 2.0f, pos / 1.5f);
		}

		scale *= 2.0f;
		return scale;
	}

	Vec3 get_top_position(const centity_t* cent)
	{
		auto origin = cent->origin;
		origin.z += 55.0f;

		return origin;
	}

	void on_every_frame()
	{
		aimbot::run(&game::cg()->predictedPlayerState);
		esp::visuals();
	}

	void adjust_user_cmd_movement(usercmd_s* cmd_old, const float angle, const float old_angle)
	{
		const auto delta_view = DEG2RAD(angle - old_angle);

		cmd_old->forwardmove = ClampChar(static_cast<int>(std::cosf(delta_view) * cmd_old->forwardmove - std::sinf(delta_view) * cmd_old->rightmove));
		cmd_old->rightmove = ClampChar(static_cast<int>(std::sinf(delta_view) * cmd_old->forwardmove + std::cosf(delta_view) * cmd_old->rightmove));
	}

	void adjust_user_cmd_movement(const usercmd_s* cmd, usercmd_s* cmd_old, const float yaw)
	{
		if (cmd->forwardmove || cmd->rightmove)
		{
			const auto move_angle = math::angle_normalize_360(RAD2DEG(std::atan2(-cmd->rightmove / 127.0f, cmd->forwardmove / 127.0f)));
			const auto delta_angle = math::angle_normalize_360(yaw - SHORT2ANGLE(cmd->angles[1]));
			const auto dest_angle = DEG2RAD(math::angle_normalize_360(move_angle - delta_angle));
			auto forwardmove_ratio = std::cosf(dest_angle);
			auto rightmove_ratio = -std::sinf(dest_angle);

			const auto abs_forwardmove_ratio = std::abs(forwardmove_ratio);
			const auto abs_rightmove_ratio = std::abs(rightmove_ratio);

			if (abs_forwardmove_ratio < abs_rightmove_ratio)
			{
				forwardmove_ratio *= 1.0f / abs_rightmove_ratio;
				rightmove_ratio = rightmove_ratio > 0.0f ? 1.0f : -1.0f;
			}
			else if (abs_forwardmove_ratio > abs_rightmove_ratio)
			{
				rightmove_ratio *= 1.0f / abs_forwardmove_ratio;
				forwardmove_ratio = forwardmove_ratio > 0.0f ? 1.0f : -1.0f;
			}
			else
			{
				forwardmove_ratio = 1.0f;
				rightmove_ratio = 1.0f;
			}

			cmd_old->forwardmove = ClampChar(static_cast<int>(forwardmove_ratio * std::numeric_limits<char>::max()));
			cmd_old->rightmove = ClampChar(static_cast<int>(rightmove_ratio * std::numeric_limits<char>::max()));
		}
	}

	void CG_BulletEndpos(int* randSeed, const float spread, const Vec3* start, Vec3* end, Vec3* dir, const Vec3* forwardDir, const Vec3* rightDir, const Vec3* upDir, const float maxRange)
	{
		constexpr auto address = 0x004B4B40;

		__asm
		{
			push maxRange;
			push upDir;
			push rightDir;
			push forwardDir;
			push dir;
			push spread;
			mov esi, randSeed;
			mov edi, end;
			mov ebx, start;

			call address;

			add esp, 4 * 6;
		}
	}

	std::string get_translated_hud_elem_message(const std::string& game_message, const std::string& message)
	{
		if (utils::string::contains(game_message, message))
		{
			char hud_elem_string[256];
			CG_TranslateHudElemMessage(0, game_message.data(), "game message", hud_elem_string, sizeof hud_elem_string);

			return utils::string::strip(hud_elem_string);
		}

		return {};
	}

	void set_map(const std::string& map)
	{
		Dvar_SetStringByName("ui_mapname", map.data());
		Cbuf_AddCall(0, UI_Map);
	}

	int I_stricmp(const std::string& a, const std::string& b)
	{
		return _strnicmp(a.data(), b.data(), std::numeric_limits<int>::max());
	}

	char* I_strncpyz(char* place, const std::string& string, const size_t length)
	{
		const auto result = std::strncpy(place, string.data(), length);
		place[length - 1] = 0;
		return result;
	}

	bool is_hosting()
	{
		return party_data() && party_data()->are_we_host();
	}

	bool is_weapon_in_held_slot(const std::uint32_t index)
	{
		if (index > game::bg_lastParsedWeaponIndex)
			return false;

		const auto held_weapon = get_held_weapon_slot(&game::cg()->predictedPlayerState, index);
		return held_weapon >= 0;
	}

	char CL_DeathMessageIconDimension(const float icon_width)
	{
		float v1; // ST00_4
		signed int v2; // eax

		v2 = (icon_width * 32.0f) + 9.313225746154785e-10;

		if (v2 >= 127)
			return 143;

		if (v2 <= 16)
			v2 = 16;

		return v2 + 16;
	}

	std::string CL_AddMessageIcon(const std::string& name, const Vec2& dimensions, const bool flip_icon)
	{
		auto string{ "^"s };
		string.push_back(flip_icon ? 2 : 1);
		string.push_back(CL_DeathMessageIconDimension(dimensions.x));
		string.push_back(CL_DeathMessageIconDimension(dimensions.y));
		const auto material = Material_RegisterHandle(name.data());
		string.append(reinterpret_cast<const char*>(&material));
		return string;
	}

	void enum_assets(const XAssetType type, const std::function<void(game::XAssetHeader)>& callback, const bool includeOverride)
	{
		DB_EnumXAssets_Internal(type, static_cast<void(*)(XAssetHeader, void*)>([](XAssetHeader header, void* data)
		{
			const auto& cb = *static_cast<const std::function<void(XAssetHeader)>*>(data);
			cb(header);
		}), &callback, includeOverride);
	}

	void SV_ExecuteClientCommand(client_t* client, const char* command, int clientOk, int fromOldServer)
	{
		constexpr auto address = 0x00586B80;

		__asm
		{
			mov eax, fromOldServer;
			push eax;
			mov eax, clientOk;
			push eax;
			mov eax, command;
			mov ecx, client;
			call address;
			add esp, 8;
		}
	}

	int get_client_count()
	{
		auto count = 0u;

		for (size_t i = 0; i < 18; ++i)
		{
			if (game::svs_client->clients[i].header.state >= CS_ZOMBIE)
			{
				++count;
			}
		}

		return count;
	}

	void set_config_string_value_for_key(const size_t client_num, const std::string& dvar, const std::string& value)
	{
		size_t index{ 24 };

		for (; index < 200; ++index)
		{
			const auto key = game::CL_GetConfigString(index);

			if (!*key)
			{
				game::send_server_command(client_num, "d " + std::to_string(index) + " " + dvar);
				break;
			}

			if (!game::I_stricmp(key, dvar))
			{
				break;
			}
		}

		game::send_server_command(client_num, "d " + std::to_string(index + 200) + " " + value);
	}

	bool can_connect_to_player(const size_t client_num)
	{
		const auto party{ game::party_data() };
		const auto session{ party->session };
		const auto our_client_num{ game::Party_FindMemberByXUID(game::Live_GetXuid(0)) };

		if (session == nullptr)
			return false;
		if (our_client_num < 0)
			return false;
		if (our_client_num == client_num)
			return true;

		if (client_num < std::size(party->session->dyn.users))
		{
			return CL_CanWeConnectToClient(party->session, our_client_num, client_num);
		}

		return false;
	}

	int find_route_to_player(const game::SessionData* session, const size_t client_num)
	{
		const auto our_client_num{ game::Party_FindMemberByXUID(game::Live_GetXuid(0)) };

		if (our_client_num < 0)
			return -1;
		if (our_client_num == client_num)
			return -1;

		if (const auto relay_route = game::find_route_to_player(session, our_client_num, client_num);
			relay_route >= 0
			&& our_client_num != relay_route
			&& client_num != relay_route)
		{
			return relay_route;
		}

		return -1;
	}

	int find_route_to_player(const game::SessionData* session, const size_t our_client_num, const size_t client_num)
	{
		const auto target_bits = session->dyn.users[client_num].voiceConnectivityBits;

		if ((1 << our_client_num) & target_bits)
			return our_client_num;

		for (size_t i = 0; i < 18; ++i)
		{
			if (const auto result = (i + our_client_num + 1) % 18; party_data()->is_user_registered(result) && ((1 << result) & target_bits) != 0)
			{
				return result;
			}
		}

		return -1;
	}

	bool LiveStorage_DataSetInternalString(const int index, char const* const* args, const std::string& value, uint8_t* persistent_data, uint8_t* modified_flags)
	{
		int last_index{ 0 };
		StructuredDataLookup lookup{};

		const auto asset = StructuredDataDef_GetAsset("mp/playerdata.def", 0x1FFC);
		StructuredData_InitializeLookup(asset, &lookup);

		if (StructuredData_NavigateByStrings(&lookup, args, index, &last_index))
		{
			if (last_index != index)
			{
				PRINT_LOG("Error setting persistent data: incorrect number of arguments.");
				return false;
			}

			const auto result = LiveStorage_SetLookedUpDataFromString(&lookup, reinterpret_cast<uint8_t*>(&persistent_data), modified_flags, value.data());

			if (result && result != 1)
			{
				PRINT_LOG("Error setting persistent data");
				return false;
			}

			return true;
		}
		else
		{
			PRINT_LOG("Error setting persistent data.");
		}

		return false;
	}

	bool is_real_address(const game::XNADDR& xnaddr, const game::netadr_t& netadr)
	{
		if (netadr.type == game::NA_LOOPBACK)
			return true;

		if (xnaddr.addr.inaddr == netadr.addr.inaddr)
			return true;

		return false;
	}

	int RMsg_FindSlotForAddr(const game::netadr_t* netadr)
	{
		constexpr auto address = 0x005C2CF0;
		auto result = -1;

		__asm
		{
			mov edi, netadr;
			call address;
			mov result, eax;
		}

		return result;
	}
}