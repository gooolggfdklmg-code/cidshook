#pragma once

#include <ws2tcpip.h>
#include <windows.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <vector>
#include <memory>
#include <intrin.h>
#include <algorithm>
#include <WinInet.h>
#include <time.h>
#include <dxgi.h>
#include <random>
#include <numeric>
#include <future>
#include <mutex>
#include <regex>
#include <cmath>
#include <fstream>
#include <iterator>
#include <algorithm>
#include <array>
#include <codecvt>
#include <psapi.h>
#include <Shlwapi.h>
#include <dbghelp.h>
#include <filesystem>
#include <shellapi.h>
#include <cctype>
#include <d3d9.h>
#include <csetjmp>
#include <set>
#include <winternl.h>
#include <TlHelp32.h>
#include <sstream>

#pragma comment(lib, "Dbghelp.lib")

#include "../thirdparty/nlohmann/json.hpp"
#include "../thirdparty/steam_api/isteamfriends.hpp"
#include "../thirdparty/steam_api/isteamnetworking.hpp"
#include "../thirdparty/imgui/imgui.h"
#include "../thirdparty/imgui/imgui_internal.h"
#include "../thirdparty/imgui/imgui_impl_dx9.h"
#include "../thirdparty/imgui/imgui_impl_win32.h"
#include "../thirdparty/detours/detours.hpp"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

using namespace std::literals;
using namespace std::chrono_literals;
using json = nlohmann::json;

#define LOG_PREFIX "[furtivehook]"

#define PRINT_LOG_DETAILED(__FMT__, ...) std::printf(LOG_PREFIX "[" __FUNCTION__ "] " __FMT__ "\n", __VA_ARGS__); logger::print_log(LOG_PREFIX "[" __FUNCTION__ "] " __FMT__, __VA_ARGS__)

#define PRINT_LOG(__FMT__, ...)	std::printf(__FMT__ "\n", __VA_ARGS__);	logger::print_log(__FMT__, __VA_ARGS__)

#define PRINT_MESSAGE(title, __FMT__, ...) PRINT_LOG(__FMT__, __VA_ARGS__); utils::toast::add_toast(title, utils::string::va(__FMT__, __VA_ARGS__))

#include "game/game.hpp"
#include "math/math.hpp"

#include "utils/utils.hpp"
#include "utils/io.hpp"
#include "utils/hook.hpp"
#include "utils/memory.hpp"
#include "utils/string.hpp"
#include "utils/concurrency.hpp"
#include "utils/nt.hpp"
#include "utils/toast.hpp"
#include "utils/exception/minidump.hpp"

#include "core/misc/misc.hpp"
#include "core/dvar/dvar.hpp"
#include "core/input/input.hpp"
#include "core/rendering/dx.hpp"
#include "core/rendering/rendering.hpp"
#include "core/menu/menu.hpp"
#include "core/command/command.hpp"
#include "core/security/security.hpp"
#include "core/security/iat/iat.hpp"
#include "core/exception/exception.hpp"
#include "core/exploit/rop/rop.hpp"
#include "core/exploit/host/rce.hpp"
#include "core/exploit/rce/rce.hpp"
#include "core/exploit/exploit.hpp"
#include "core/network/network.hpp"
#include "core/scheduler/scheduler.hpp"
#include "core/session/session.hpp"
#include "core/server_command/server_command.hpp"
#include "core/logger/logger.hpp"
#include "core/friends/friends.hpp"
#include "core/stats/stats.hpp"
#include "core/aimbot/aimbot.hpp"
#include "core/aimbot/autowall.hpp"
#include "core/esp/esp.hpp"
#include "core/event/event.hpp"
#include "core/nospread/nospread.hpp"
#include "core/bots/bots.hpp"
#include "core/host/host.hpp"
#include "core/prediction/prediction.hpp"
#include "steam/steam.hpp"