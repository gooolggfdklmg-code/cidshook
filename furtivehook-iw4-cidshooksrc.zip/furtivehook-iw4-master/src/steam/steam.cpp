#include "dependencies/stdafx.hpp"
#include "steam.hpp"

namespace steam
{
	auto get_persona_name_original = reinterpret_cast<decltype(&get_persona_name)>(0);
	auto get_steam_id_original = reinterpret_cast<decltype(&get_steam_id)>(0);
	ISteamFriends* friends = nullptr; ISteamNetworking* networking = nullptr;
	std::uint64_t steam_id = 11111111111111111;
	std::string persona_name = "";
	
	bool send_p2p_packet(const std::uint64_t steam_id)
	{
		if (!game::g_foundOurExternalIP || !game::g_steamInitialized)
			return false;
		
		auto data{ ""s };
		data.reserve(1024);

		data.push_back(0);
		data.push_back(0);
		const auto inaddr = htonl(game::g_ourXnaddr->addr.inaddr);
		data.append(reinterpret_cast<const char*>(&inaddr), sizeof inaddr);
		const auto port = htons(game::g_ourXnaddr->addr.port);
		data.append(reinterpret_cast<const char*>(&port), sizeof port);

		return networking->SendP2PPacket(steam_id, data.data(), data.size(), k_EP2PSendReliable);
	}

	std::string get_friend_persona_name(const std::uint64_t steam_id, const std::string& name)
	{
		const auto steam_name = friends->GetFriendPersonaName(steam_id);

		if (steam_name != nullptr
			&& *steam_name
			&& steam_name != "[unknown]"s
			&& steam_name != name)
		{
			return steam_name;
		}

		return "";
	}

	CSteamID* __fastcall get_steam_id(void* ecx, void* edx, int a3)
	{
		const auto result = get_steam_id_original(ecx, edx, a3);
		return result;
	}

	const char* __fastcall get_persona_name(void* ecx, void* edx)
	{
		if (!persona_name.empty())
		{
			return persona_name.data();
		}

		return get_persona_name_original(ecx, edx);
	}

	void initialize()
	{
		utils::nt::library steam{ "steam_api.dll" };

		if (const auto user = steam.invoke<ISteamUser*>("SteamUser"))
		{
			get_steam_id_original = utils::hook::vtable(user, 2, &get_steam_id);
		}

		if (friends = steam.invoke<ISteamFriends*>("SteamFriends"))
		{
			get_persona_name_original = utils::hook::vtable(friends, 0, &get_persona_name);
		}

		networking = steam.invoke<ISteamNetworking*>("SteamNetworking");
	}
}
