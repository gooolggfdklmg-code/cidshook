#pragma once
#include "dependencies/stdafx.hpp"

namespace steam
{
	bool send_p2p_packet(const std::uint64_t steam_id);
	std::string get_friend_persona_name(const std::uint64_t steam_id, const std::string & name);
	CSteamID* __fastcall get_steam_id(void* ecx, void* edx, int a3);
	const char* __fastcall get_persona_name(void* ecx, void* edx);
	void initialize();
	
	extern ISteamFriends* friends; extern ISteamNetworking* networking;
	extern std::uint64_t steam_id;
	extern std::string persona_name;
}