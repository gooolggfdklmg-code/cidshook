#include "dependencies/stdafx.hpp"
#include "bots.hpp"

namespace bots
{
	auto sv_map_restart_original = reinterpret_cast<decltype(&sv_map_restart)>(0x00585295); 
	
	bool can_add_bot()
	{
		if (game::get_client_count() < game::svs_client->maxClients)
		{
			return true;
		}
		
		return false;
	}
	
	void bot_team_join(const size_t ent_num)
	{
		scheduler::once([=]()
		{
			game::SV_ExecuteClientCommand(
				&game::svs_client->clients[ent_num],
				("mr " + std::to_string(game::cl()->serverId) + " 2 autoassign").data(),
				true, false);

			scheduler::once([=]()
			{
				game::SV_ExecuteClientCommand(
					&game::svs_client->clients[ent_num],
					("mr " + std::to_string(game::cl()->serverId) + " 9 class1").data(),
					true, false);
				
			}, scheduler::pipeline::server, 1s);
			
		}, scheduler::pipeline::server, 1s);
	}
	
	void add_bot()
	{
		if (!can_add_bot())
		{
			PRINT_MESSAGE("Bots", "Can't add bot, server is full.");
			return;
		}
		
		if (const auto bot_ent = game::SV_AddTestClient(); bot_ent)
		{
			bot_team_join(bot_ent->s.number);
		}
	}

	bool __cdecl callback_sv_map_restart(game::client_t* client)
	{
		if (!client->bIsTestClient)
		{
			return false;
		}

		game::SV_DropClient(client, "EXE_PLAYERKICKED", true);
		return true;
	}

	__declspec(naked) void sv_map_restart()
	{
		__asm
		{
			pushad;
			push esi;
			call callback_sv_map_restart;
			test al, al;
			pop esi;
			popad;

			jz fix;

			push 0x005852C6;
			retn;

		fix:
			jmp sv_map_restart_original;
		}
	}

	void initialize()
	{
		utils::hook::detour(&sv_map_restart_original, &sv_map_restart);
	}
}