#pragma once
#include "dependencies/stdafx.hpp"

namespace bots
{
	void add_bot();
	void sv_map_restart();
	void initialize();
}