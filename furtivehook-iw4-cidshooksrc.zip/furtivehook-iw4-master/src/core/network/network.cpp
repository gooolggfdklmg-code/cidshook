#include "dependencies/stdafx.hpp"
#include "network.hpp"

namespace network
{
	auto cl_dispatch_connectionless_packet_original = reinterpret_cast<decltype(&cl_dispatch_connectionless_packet)>(0x004C6B52);
	bool log_commands = false;

	namespace
	{
		std::unordered_map<std::string, callback>& get_callbacks()
		{
			static std::unordered_map<std::string, callback> callbacks{};
			return callbacks;
		}
		
		bool handle_command(const command::args& args, const game::netadr_t& from, game::msg_t& msg)
		{
			auto oob_string = utils::string::to_lower(args[0]);
			if (oob_string.length() > 1 && (oob_string[0] == '0' || oob_string[0] == '1' || oob_string[0] == '2'))
			{
				oob_string = oob_string.substr(1);
			}
			
			const auto& callbacks = get_callbacks();
			const auto handler = callbacks.find(oob_string);

			if (handler == callbacks.end())
				return false;

			const auto msg_backup = msg;
			const auto callback = handler->second(args, from, msg);

			if (msg.readcount != msg_backup.readcount)
				msg = msg_backup;

			return callback;
		}

		bool __cdecl callback_cl_dispatch_connectionless_packet(game::netadr_t* from, game::msg_t* msg)
		{
			const command::args args{}; 
			
			if (log_commands)
			{
				PRINT_LOG("Received OOB '%s' from %s", args.join(0).data(), utils::get_sender_string(*from).data());
			}
			else
			{
				logger::print_log("Received OOB '%s' from %s", args.join(0).data(), utils::get_sender_string(*from).data());
			}

			return handle_command(args, *from, *msg);
		}
	}

	void on_command(const std::string& command, const callback& callback)
	{
		get_callbacks()[utils::string::to_lower(command)] = callback;
	}

	__declspec(naked) void cl_dispatch_connectionless_packet()
	{
		static game::netadr_t* from;
		static game::msg_t* msg;

		__asm
		{
			lea eax, [esp + 0xC54];
			mov from, eax; 
			mov msg, ebp;

			pushad;
			push msg;
			push from;
			call callback_cl_dispatch_connectionless_packet;
			add esp, 8;
			test al, al;
			popad;

			jz fix;

			push 0x004C7715;
			retn;
		fix:
			jmp cl_dispatch_connectionless_packet_original;
		}
	}
	
	void initialize()
	{
		utils::hook::detour(&cl_dispatch_connectionless_packet_original, &cl_dispatch_connectionless_packet);

		const auto ignore_oob = [](const auto& args, const auto& target, const auto&)
		{
			PRINT_LOG("Ignoring OOB '%s' from %s", args.join(0).data(), utils::get_sender_string(target).data());
			return true;
		};

		network::on_command("echo", ignore_oob);
		network::on_command("ident", ignore_oob);
		network::on_command("OpenNAT", ignore_oob);
		network::on_command("SP", ignore_oob);
		network::on_command("print", ignore_oob);
		network::on_command("hostquit", ignore_oob);
		network::on_command("roundsdone", ignore_oob);
		
		network::on_command("RA", [](const auto& args, const auto& target, const auto&)
		{
			if (const auto client_slot = game::RMsg_FindSlotForAddr(&target); client_slot >= 0)
			{
				const auto sequence = utils::atoi<uint8_t>(args[1]); 
				const auto reliable_client = game::reliable_client(client_slot);
				const auto message{ reliable_client->reliableBuf };
				const auto sender_str{ utils::get_sender_string(reliable_client->addr) };

				if (log_commands)
				{
					PRINT_LOG("Received reliable message '%s' with sequence [%u] from %s", message, sequence, sender_str.data());
				}
				else
				{
					logger::print_log("Received reliable message '%s' with sequence [%u] from %s", message, sequence, sender_str.data());
				}
			}

			return false;
		});
	}
}