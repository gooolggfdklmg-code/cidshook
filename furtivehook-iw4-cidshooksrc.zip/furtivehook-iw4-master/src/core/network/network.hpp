#pragma once
#include "dependencies/stdafx.hpp"

namespace network
{
	using callback = std::function<bool(const command::args&, const game::netadr_t&, game::msg_t&)>;
	
	void on_command(const std::string& command, const callback& callback);
	void cl_dispatch_connectionless_packet();
	void initialize();

	extern bool log_commands;
}

namespace std
{
	template <>
	struct equal_to<game::netadr_t>
	{
		using result_type = bool;

		bool operator()(const game::netadr_t& lhs, const game::netadr_t& rhs) const
		{
			return game::NET_CompareAdr(lhs, rhs);
		}
	}; 
	
	template <>
	struct hash<game::netadr_t>
	{
		size_t operator()(const game::netadr_t& x) const
		{
			return hash<uint32_t>()(*reinterpret_cast<const uint32_t*>(&x.addr.ip[0])) ^ hash<uint16_t>()(x.addr.port);
		}
	};
}