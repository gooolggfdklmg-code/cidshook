#include "dependencies/stdafx.hpp"
#include "command.hpp"

namespace command
{
	std::unordered_map<std::string, callback> callbacks;
	std::unordered_map<std::string, callback_sv> callbacks_sv;

	bool handle_command(const game::client_t& client)
	{
		const command::args_sv args{};

		if (args.size() <= 0)
			return false;

		const auto command = utils::string::to_lower(args[0]);
		const auto handler = callbacks_sv.find(command);

		if (handler == callbacks_sv.end())
		{
			return false;
		}

		return handler->second(args, client);
	}

	void __cdecl client_command(ClientNum_t clientNum)
	{
		if (!handle_command(game::svs_client->clients[clientNum]))
		{
			return reinterpret_cast<decltype(&client_command)>(0x00526280)(clientNum);
		}
	}
	
	const char* args::get(const size_t index) const
	{
		return game::Cmd_Argv(index);
	}

	size_t args::size() const
	{
		return game::cmd_argc[*game::cmd_id];
	}

	std::string args::join(const size_t index) const
	{
		auto result = ""s;

		for (auto i = index; i != this->size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(this->get(i));
		}

		return result;
	}

	const char* args_sv::get(const size_t index) const
	{
		return game::SV_Cmd_Argv(index);
	}

	size_t args_sv::size() const
	{
		return game::sv_cmd_argc[*game::sv_cmd_id];
	}

	std::string args_sv::join(const size_t index) const
	{
		auto result = ""s;

		for (auto i = index; i != this->size(); ++i)
		{
			if (i > index)
			{
				result.append(" ");
			}

			result.append(this->get(i));
		}

		return result;
	}

	void on_command(const std::string& command, const callback_sv& callback)
	{
		callbacks_sv[utils::string::to_lower(command)] = callback;
	}

	void add_raw(const char* name, void(*callback)())
	{
		game::Cmd_AddCommandInternal(name, callback, utils::memory::get_allocator()->allocate<game::cmd_function_s>());
	}

	void main_handler()
	{
		const args args{};
		const auto command_lwr = utils::string::to_lower(args[0]);
		
		if (callbacks.find(command_lwr) != callbacks.end())
		{
			callbacks[command_lwr](args);
		}
	}
	
	void add(const char* name, const callback& callback)
	{
		const auto command_lwr = utils::string::to_lower(name);

		if (callbacks.find(command_lwr) == callbacks.end())
			add_raw(name, main_handler);

		callbacks[command_lwr] = callback;
	}

	void add(const char* name, const std::function<void()>& callback)
	{
		add(name, [callback](const auto&) { callback(); });
	}

	void execute(std::string command, const bool sync)
	{
		command += "\n";

		if (sync)
		{
			game::Cmd_ExecuteSingleCommand(0, 0, command.data());
		}
		else
		{
			game::Cbuf_AddText(0, command.data());
		}
	}

	void initialize()
	{
		utils::hook::call(0x00586C2A, &client_command);
		
		add("quit", game::Com_Quit_f);
		add("crash", []() { *reinterpret_cast<int*>(1) = 0; });
		
		add("cmd_dump", []()
		{
			for (auto cmd = game::cmd_functions; cmd; cmd = cmd->next)
			{
				if (const auto cmd_name = cmd->name; cmd_name)
				{
					PRINT_LOG("%s", cmd_name);
				}
			}
		}); 
		
		add("dvar_dump", []()
		{
			for (size_t i = 0; i < game::g_dvarCount; ++i)
			{
				if (const auto dvar = game::s_sortedDvars[i]; dvar)
				{
					PRINT_LOG("%s: %s", dvar->name, game::Dvar_ValueToString(dvar, dvar->current));
				}
			}
		});

		add("list_asset", [](const auto& args)
		{
			if (args.size() > 0)
			{
				const auto type = utils::atoi<game::XAssetType>(args[1]);

				if (type >= game::ASSET_TYPE_PHYSPRESET && type < game::ASSET_TYPE_COUNT)
				{
					PRINT_LOG("Listing assets in [%s] pool", game::g_assetNames[type]); 
					
					std::vector<std::pair<std::string, int>> assets{}; 
					
					game::enum_assets(type, [&](const auto& header)
					{
						const auto asset = game::XAsset{ type, header };
						const auto asset_name = game::DB_GetXAssetName(&asset);

						if (args.size() > 2 && !utils::string::contains(asset_name, args[2]))
							return;

						if (type == game::ASSET_TYPE_LOCALIZE_ENTRY)
						{
							const auto string = reinterpret_cast<const char*(*)(const char*)>(0x0059DB60)(asset_name);
							assets.emplace_back(std::make_pair(asset_name, std::strlen(string)));
						}
						else
						{
							PRINT_LOG("%s", asset_name);
						}
					}, true);

					std::sort(assets.begin(), assets.end(), [](const auto& a, const auto& b) { return a.second < b.second; });

					for (const auto& asset : assets)
					{
						const auto string = reinterpret_cast<const char*(*)(const char*)>(0x0059DB60)(asset.first.data());
						PRINT_LOG("%s: %s [%i]", asset.first.data(), string, asset.second);
					}
				}
			}
		});
	}
}