#pragma once
#include "dependencies/stdafx.hpp"

namespace events
{
	void initialize();
}