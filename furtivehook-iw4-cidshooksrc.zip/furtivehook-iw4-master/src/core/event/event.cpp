#include "dependencies/stdafx.hpp"
#include "event.hpp"

namespace events
{
	void __cdecl cg_predict_playerstate(LocalClientNum_t localClientNum)
	{
		auto cmd_cur = game::cl()->get_user_cmd(game::cl()->cmdNumber);
		auto cmd_old = game::cl()->get_user_cmd(game::cl()->cmdNumber - 1);
		auto cmd_new = game::cl()->get_user_cmd(++game::cl()->cmdNumber);

		*cmd_new = *cmd_cur;
		cmd_cur->serverTime -= 1;
		cmd_old->serverTime += 1;

		static std::uint32_t angle_backup[3];
		VECTOR_COPY(angle_backup, cmd_old->angles);
		VECTOR_COPY(cmd_cur->angles, angle_backup);

		static std::uint32_t angle_backup_2[3];
		VECTOR_COPY(angle_backup_2, cmd_cur->angles);
		VECTOR_COPY(cmd_new->angles, angle_backup_2);

		static bool gun_switch = false; gun_switch = !gun_switch;
		const auto is_akimbo_gun = !game::bg_weaponDefs(cmd_cur->weapon)->noDualWield;
		const auto is_auto_fire = aimbot::aim_target && aimbot::auto_fire;
		auto button_flag = 0u;

		if ((is_auto_fire && (gun_switch || !is_akimbo_gun)) || (cmd_cur->buttons & 1))
			button_flag |= 1;
		if (is_akimbo_gun && ((is_auto_fire && !gun_switch) || (cmd_cur->buttons & 0x80800)))
			button_flag |= 0x80800;

		cmd_old->buttons |= button_flag;
		
		if (button_flag)
		{
			auto cmd_angles = cmd_old->get_angles();
			
			if (aimbot::aim_target)
			{
				cmd_angles += aimbot::aim_angles;
				cmd_angles = math::angle_normalize_360(cmd_angles);
			}

			if (nospread::enabled)
			{
				const auto spread_angles = nospread::get_spread_angles(
					&game::cg()->predictedPlayerState, 
					cmd_old, 
					(button_flag & 1) && is_akimbo_gun);

				cmd_angles += spread_angles;
				cmd_angles = math::angle_normalize_360(cmd_angles);
			}

			cmd_old->set_angles(cmd_angles);

			if (aimbot::aim_target && aimbot::silent)
			{
				game::adjust_user_cmd_movement(cmd_cur, cmd_old, SHORT2ANGLE(cmd_old->angles[1]));
			}
		}

		return reinterpret_cast<decltype(&cg_predict_playerstate)>(0x004A2A70)(localClientNum);
	}

	void __fastcall cg_add_to_team_chat(const char* message)
	{
		const auto cleaned_message = utils::string::strip(message); 
		PRINT_LOG("%s", cleaned_message.data());
		return reinterpret_cast<decltype(&cg_add_to_team_chat)>(0x004A6680)(message);
	}

	void initialize()
	{
		utils::hook::call(0x004A79D8, &cg_add_to_team_chat);
		utils::hook::call(0x004B0E44, &cg_predict_playerstate);
	}
}