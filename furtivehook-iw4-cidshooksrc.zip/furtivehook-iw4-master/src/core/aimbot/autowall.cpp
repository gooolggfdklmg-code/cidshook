#include "dependencies/stdafx.hpp"
#include "autowall.hpp"

namespace autowall
{
	auto bg_get_surface_penetration_depth_original = reinterpret_cast<decltype(&bg_get_surface_penetration_depth)>(0x00479430);
	bool enabled = true;

	float __cdecl bg_get_surface_penetration_depth(game::WeaponDef* weapon, int surfaceType)
	{
		return dvar::bg_surfacePenetration->current.value > 0.0f ? dvar::bg_surfacePenetration->current.value : bg_get_surface_penetration_depth_original(weapon, surfaceType);
	}
	
	bool CG_BulletTrace(game::BulletTraceResults* br_, game::BulletFireParams* bp_, game::centity_t* cent, int lastSurfaceType)
	{
		constexpr auto address = 0x004B4520;
		auto result = false;

		__asm
		{
			push lastSurfaceType;
			push cent;
			mov esi, br_;
			mov eax, bp_;
			call address;
			add esp, 8;
			mov result, al;
		}

		return result;
	}

	bool can_hit_entity(const game::playerState_s* ps, const game::WeaponDef& weap_def)
	{
		return !game::CG_IsPlayerReloading() 
			&& !(ps->pm_type & 2 || ps->pm_type & 3)
			&& weap_def.weapType == game::WEAPTYPE_BULLET;
	}

	float get_bullet_damage(const game::BulletTraceResults& br, const game::BulletFireParams& bp, const game::WeaponDef& weap_def)
	{
		const auto bullet_damage = game::Bullet_GetDamage(br, bp, weap_def);
		return static_cast<float>(bullet_damage);
	}
	
	float get_penetration_damage(const Vec3& start, const Vec3& target, game::playerState_s* ps, const size_t trace_entity_num)
	{
		const auto weapon = game::BG_GetViewmodelWeaponIndex(ps);
		const auto weapon_def = game::bg_weaponDefs(weapon);

		if (!can_hit_entity(ps, *weapon_def))
			return 0.0f;
		
		if (target.distance(start) >= game::get_weapon_damage_range(ps, weapon))
			return 0.0f;
		
		game::BulletFireParams bp;
		bp.weaponEntIndex = 2046;
		bp.ignoreEntIndex = ps->clientNum;
		bp.damageMultiplier = 1.0f;
		bp.origStart = start;
		bp.start = start;
		bp.end = target;
		bp.dir = (target - start).normalized();

		game::BulletTraceResults br{};

		const auto attacker = game::centity(ps->clientNum);
		const auto perks = game::cg()->clients[attacker->number].perks;

		if (!CG_BulletTrace(&br, &bp, attacker, 0))
			return 0.0f;

		if (br.trace.startsolid)
			return 0.0f;

		if (trace_entity_num == game::Trace_GetEntityHitId(&br.trace))
			return get_bullet_damage(br, bp, *weapon_def);

		if (!game::BG_WeaponBulletFire_ShouldPenetrate(perks, weapon_def) || !enabled)
			return 0.0f;
		
		constexpr auto perk_bulletPenetrationMultiplier = 2.0f;
		const auto has_fmj = perks[0] & 0x20;
		
		for (size_t i = 0; i < dvar::bg_penetrationCount->current.integer; ++i)
		{
			auto max_depth = game::BG_GetSurfacePenetrationDepth(weapon_def, br.depthSurfaceType) * game::bg_weaponVariantDef(weapon)->bulletPenetrationMultiplier;

			if (has_fmj)
				max_depth *= perk_bulletPenetrationMultiplier;

			if (max_depth <= 0.0f)
				return 0.0f;

			const auto last_hit_pos = br.hitPos;

			if (!game::BG_AdvanceTrace(&bp, &br, 0.135f))
				return 0.0f;

			const auto traceHitB = CG_BulletTrace(&br, &bp, attacker, br.depthSurfaceType);

			game::BulletFireParams rev_bp;
			rev_bp.weaponEntIndex = bp.weaponEntIndex;
			rev_bp.ignoreEntIndex = bp.ignoreEntIndex;
			rev_bp.damageMultiplier = bp.damageMultiplier;
			rev_bp.origStart = bp.origStart;
			rev_bp.dir = -bp.dir;
			rev_bp.start = bp.end;
			rev_bp.end = rev_bp.dir * 0.01f + last_hit_pos;

			auto rev_br = br;
			rev_br.trace.normal = -rev_br.trace.normal;

			if (traceHitB)
				game::BG_AdvanceTrace(&rev_bp, &rev_br, 0.01f);

			const auto rev_trace_hit = CG_BulletTrace(&rev_br, &rev_bp, attacker, rev_br.depthSurfaceType);
			const auto all_solid = rev_trace_hit && rev_br.trace.allsolid || br.trace.startsolid && rev_br.trace.startsolid;

			if (rev_trace_hit || all_solid)
			{
				if (rev_trace_hit)
				{
					auto new_depth = game::BG_GetSurfacePenetrationDepth(weapon_def, rev_br.depthSurfaceType);
					
					if (game::CG_ClientHasPerk(perks, 5))
						new_depth *= perk_bulletPenetrationMultiplier;

					max_depth = std::fmin(max_depth, new_depth) * game::bg_weaponVariantDef(weapon)->bulletPenetrationMultiplier;

					if (max_depth <= 0.0f)
						return 0.0f;
				}

				const auto depth = std::fmax(1.0f, all_solid ? rev_bp.end.distance(rev_bp.start) : last_hit_pos.distance(rev_br.hitPos));

				bp.damageMultiplier -= depth / max_depth;

				if (bp.damageMultiplier <= 0.0f)
					return 0.0f;

				if (!all_solid)
				{
					if (game::Trace_GetEntityHitId(&br.trace) == trace_entity_num)
						return get_bullet_damage(br, bp, *weapon_def);
				}
			}

			if (!traceHitB)
				return get_bullet_damage(br, bp, *weapon_def);
		}

		if(game::Trace_GetEntityHitId(&br.trace) == trace_entity_num)
			return get_bullet_damage(br, bp, *weapon_def);
		
		return 0.0f;
	}

	void initialize()
	{
		utils::hook::detour(&bg_get_surface_penetration_depth_original, &bg_get_surface_penetration_depth);
	}
}