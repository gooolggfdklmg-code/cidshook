#pragma once
#include "dependencies/stdafx.hpp"

namespace autowall
{
	void test();
	float __cdecl bg_get_surface_penetration_depth(game::WeaponDef * weapon, int surfaceType);
	float get_penetration_damage(const Vec3& start, const Vec3& target, game::playerState_s* ps, const size_t trace_entity_num);
	void initialize();

	extern bool enabled;
}