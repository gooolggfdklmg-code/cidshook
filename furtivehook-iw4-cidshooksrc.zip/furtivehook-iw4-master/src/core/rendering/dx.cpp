#include "dependencies/stdafx.hpp"
#include "dx.hpp"

namespace rendering::dx
{
	void on_every_frame()
	{
		if (menu::initialized)
		{
			ImGui::GetIO().MouseDrawCursor = menu::is_open();
			
			ImGui_ImplDX9_NewFrame();
			ImGui_ImplWin32_NewFrame();
			ImGui::NewFrame();

			ImGui::PushStyleColor(ImGuiCol_WindowBg, ImColor(0, 100, 200, 255).Value);
			utils::toast::draw_toast();
			ImGui::PopStyleColor(); 
			
			esp::draw(); 
			menu::draw();

			ImGui::Render();
			ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
		}
	}
	
	void on_frame(IDirect3DDevice9* device)
	{
		const auto game_window = game::hwnd;

		if (!game_window)
			return;
		
		input::initialize(game_window);

		ImGui::CreateContext();
		
		menu::set_style();
		
		ImGui_ImplWin32_Init(game_window);
		ImGui_ImplDX9_Init(device);
	}
}