#pragma once
#include "dependencies/stdafx.hpp"

namespace rendering::dx
{
	void on_every_frame(); 
	void on_frame(IDirect3DDevice9* device);
}
