#include "dependencies/stdafx.hpp"
#include "rendering.hpp"

namespace rendering
{
	auto end_scene_original = reinterpret_cast<decltype(&end_scene)>(0);
	auto reset_original = reinterpret_cast<decltype(&reset)>(0);

	HRESULT __stdcall reset(IDirect3DDevice9* thisptr, D3DPRESENT_PARAMETERS *pPresentationParameters)
	{
		if (!menu::initialized)
			return reset_original(thisptr, pPresentationParameters);
		
		ImGui_ImplDX9_InvalidateDeviceObjects();
		const auto original = reset_original(thisptr, pPresentationParameters);
		ImGui_ImplDX9_CreateDeviceObjects();

		return original;
	}
	
	HRESULT __stdcall end_scene(IDirect3DDevice9* thisptr)
	{
		menu::initialize(thisptr);
		dx::on_every_frame();
		
		return end_scene_original(thisptr);
	}
	
	void initialize()
	{
		if (const auto device = *reinterpret_cast<IDirect3DDevice9**>(offsets::device))
		{
			reset_original = utils::hook::vtable(device, 16, &reset);
			end_scene_original = utils::hook::vtable(device, 42, &end_scene);
		}
	}
}