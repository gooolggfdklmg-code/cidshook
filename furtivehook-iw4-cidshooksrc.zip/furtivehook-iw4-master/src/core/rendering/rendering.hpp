#pragma once
#include "dependencies/stdafx.hpp"

namespace rendering
{
	HRESULT __stdcall reset(IDirect3DDevice9 * thisptr, D3DPRESENT_PARAMETERS * pPresentationParameters);
	HRESULT __stdcall end_scene(IDirect3DDevice9 * thisptr);
	void initialize();
}
