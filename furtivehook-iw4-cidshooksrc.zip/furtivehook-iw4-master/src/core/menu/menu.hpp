#pragma once
#include "dependencies/stdafx.hpp"

namespace menu
{
	constexpr static auto window_title = "furtivehook";
	constexpr static auto color_flags = ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip;
	constexpr static auto window_flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize;
	const Vec2 color_position = { 440.5f, 458.0f };
	extern bool initialized;
	extern std::unordered_map<std::string, std::string> map_names;
	extern ImFont* glacial_indifference_bold;
	extern ImFont* glacial_indifference;

	void initialize(IDirect3DDevice9 * device);
	void draw();
	bool begin_section(const std::string& text);
	std::pair<std::string, std::string> get_rce_commands(const float width);
	bool is_open();
	void set_style();
}
