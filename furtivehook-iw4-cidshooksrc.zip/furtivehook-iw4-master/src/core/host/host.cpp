#include "dependencies/stdafx.hpp"
#include "host.hpp"

namespace host
{
	bool force_host, infinite_ammo, anti_leave;
	
	void __cdecl pm_weapon_use_ammo(game::playerState_s* ps, const size_t weapon, const int amount, const int player_hand_index)
	{
		if (!infinite_ammo)
		{
			return reinterpret_cast<decltype(&pm_weapon_use_ammo)>(0x00478B00)(ps, weapon, amount, player_hand_index);
		}
		
		for (size_t i = 0; i < 15; ++i)
		{
			ps->weapCommon.ammoInClip[i].ammoCount[0] = 1024;
			ps->weapCommon.ammoNotInClip[i].ammoCount = 1024;
		}
	}

	void on_anti_leave()
	{
		static auto allow_leave = false;

		if (anti_leave)
		{
			allow_leave = true;

			game::send_server_command(-1, "s g_scriptMainMenu aaaa");
		}
		else if (allow_leave)
		{
			allow_leave = false;

			game::send_server_command(-1, "s g_scriptMainMenu class");
		}
	}
	
	void on_frame()
	{
		const auto our_client_num = game::Party_FindMemberByXUID(game::Live_GetXuid(0));

		if (our_client_num < 0)
			return;
		
		if (!game::centity(our_client_num)->is_alive()) 
			return;

		on_anti_leave();
	}

	void initialize()
	{
		utils::hook::call(0x00476145, &pm_weapon_use_ammo);
		
		utils::hook::retn(0x0053C0A0); // ScrCmd_SetMoveSpeedScale
		
		scheduler::loop(host::on_frame, scheduler::pipeline::renderer, 1s);

		game::Dvar_FindVar("sv_floodProtect")->current.enabled = false;
	}
}