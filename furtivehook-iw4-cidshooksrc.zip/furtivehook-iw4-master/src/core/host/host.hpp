#pragma once
#include "dependencies/stdafx.hpp"

namespace host
{
	void initialize();

	extern bool infinite_ammo, anti_leave;
}