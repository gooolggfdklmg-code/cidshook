#include "dvar.hpp"

namespace dvar
{
	game::dvar_t* bg_surfacePenetration, * bg_penetrationCount; 
	std::unordered_map<std::string, callback> callbacks;

	bool is_valid_cod_info_dvar(const std::string& dvar_name)
	{
		if (utils::string::contains(dvar_name, "cg_score")
			|| utils::string::contains(dvar_name, "cg_fov")
			|| utils::string::contains(dvar_name, "crosshair")
			|| utils::string::contains(dvar_name, "thirdperson")
			|| utils::string::contains(dvar_name, "timescale")
			|| utils::string::contains(dvar_name, "radius")
			|| utils::string::begins_with(dvar_name, "com_")
			|| utils::string::begins_with(dvar_name, "fs_")
			|| utils::string::begins_with(dvar_name, "r_")
			|| utils::string::begins_with(dvar_name, "snd_")
			|| utils::string::begins_with(dvar_name, "player_"))
		{
			return false;
		}

		return true;
	}

	bool is_valid_client_dvar(const std::string& dvar_name)
	{
		const auto dvars =
		{
			"cg_deadChatWithDead",
			"cg_deadChatWithTeam",
			"cg_deadHearAllLiving",
			"cg_deadHearTeamLiving",
			"cg_everyoneHearsEveryone",
			"cg_hudGrenadeIconHeight",
			"cg_hudGrenadeIconOffset",
			"cg_hudGrenadeIconWidth",
			"cg_hudGrenadePointerHeight",
			"cg_hudGrenadePointerPivot",
			"cg_hudGrenadePointerWidth",
		};

		const auto result = std::any_of(dvars.begin(), dvars.end(), [=](const auto& string) { return !game::I_stricmp(dvar_name, string); });

		if (result)
		{
			return true;
		}

		return false;
	}
	
	void on_dvar(const std::string& dvar, const callback& callback)
	{
		callbacks[utils::string::to_lower(dvar)] = callback;
	}

	bool handle_dvars(const std::string& dvar_name, const std::string& dvar_value)
	{
		const auto dvar_name_lwr = utils::string::to_lower(dvar_name);
		const auto dvar_value_lwr = utils::string::to_lower(dvar_value);

		if (const auto dvar_func = callbacks.find(dvar_name_lwr); dvar_func != callbacks.end())
		{
			return dvar_func->second(dvar_value_lwr);
		}

		if (!dvar::is_valid_client_dvar(dvar_name))
		{
			logger::print_sv_log("Not setting dvar '%s' to: '%s' from server.", dvar_name.data(), dvar_value.data());
			return true;
		}
		
		return false;
	}

	void __cdecl dvar_set_from_string_by_name(const char* dvar, const char* value)
	{
		const auto dvar_lwr = utils::string::to_lower(dvar);

		if (!dvar::is_valid_cod_info_dvar(dvar_lwr))
		{
			logger::print_sv_log("Not setting dvar '%s' to: '%s' from info.", dvar, value);
			return;
		}

		bg_penetrationCount->current.integer = bg_penetrationCount->reset.integer;
		bg_surfacePenetration->current.value = bg_surfacePenetration->reset.value;
		
		logger::print_sv_log("Setting dvar '%s' to: '%s' from info.", dvar, value);
		
		return reinterpret_cast<decltype(&dvar_set_from_string_by_name)>(0x005BE940)(dvar, value);
	}
	
	void initialize()
	{
		utils::hook::call(0x004A567E, &dvar_set_from_string_by_name);
		utils::hook::call(0x004CA496, &dvar_set_from_string_by_name);

		bg_surfacePenetration = game::Dvar_RegisterFloat("bg_surfacePenetration", 0.0f,
			0.0f, std::numeric_limits<float>::max(), game::DVAR_FLAG_NONE);

		bg_penetrationCount = game::Dvar_RegisterInt("bg_penetrationCount", 5,
			0, std::numeric_limits<char>::max(), game::DVAR_FLAG_NONE);

		dvar::on_dvar("g_scriptMainMenu", [](const auto& value)
		{
			if (value != "team_marinesopfor"
				&& value != "class_marines"
				&& value != "class_opfor"
				&& value != "class")
			{
				PRINT_LOG("Anti-leave attempt caught!");
				return true;
			}

			return false;
		}); 
		
		server_command::on_server_command("s", [](const auto& args)
		{
			if (args.size() > 1)
			{
				for (size_t i = 1; i < args.size(); i += 2)
				{
					const auto dvar_name = args[i];
					const auto dvar_value = args[i + 1];

					if (dvar::handle_dvars(dvar_name, dvar_value) 
						&& game::I_stricmp(dvar_name, "cg_objectiveText")
						&& game::I_stricmp(dvar_name, "hud_drawHud"))
					{
						return true;
					}

					logger::print_sv_log("Setting dvar '%s' to: '%s' from server.", dvar_name, dvar_value);
				}
			}

			return false;
		});
	}
}