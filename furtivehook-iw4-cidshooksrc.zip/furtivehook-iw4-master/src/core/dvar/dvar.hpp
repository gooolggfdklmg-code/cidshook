#pragma once
#include "dependencies/stdafx.hpp"

namespace dvar
{
	using callback = std::function<bool(const std::string&)>; 
	void on_dvar(const std::string & dvar, const callback& callback);
	void initialize();

	extern game::dvar_t* bg_surfacePenetration, * bg_penetrationCount;
}
