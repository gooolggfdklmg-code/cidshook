#include "dependencies/stdafx.hpp"
#include "prediction.hpp"

namespace prediction
{
	bool enabled = true;
	
	float BG_EvaluateTrajectory(const game::trajectory_t* tr, std::uint32_t time, Vec3& result, float scale)
	{
		constexpr auto address = 0x004690C0;
		auto actual_result = 0.0f;

		__asm
		{
			fld scale;

			push result;
			push time;
			push tr;
			call address;
			add esp, 12;

			fstp actual_result;
		}

		return actual_result;
	}

	Vec3 get_entity_velocity(const game::centity_t* cent)
	{
		Vec3 old_position, new_position; 
		
		auto result = BG_EvaluateTrajectory(&cent->prev_state().pos, game::cg()->snap->serverTime, old_position, game::cg()->frameInterpolation);
		BG_EvaluateTrajectory(&cent->next_state().pos, game::cg()->nextSnap->serverTime, new_position, result);

		auto velocity = (new_position - old_position);
		velocity[0] = static_cast<float>(GET_SIGN(velocity[0]));
		velocity[1] = static_cast<float>(GET_SIGN(velocity[1]));
		velocity[2] = static_cast<float>(GET_SIGN(velocity[2]));

		return velocity;
	}

	Vec3 get_entity_interpolated_angles(const game::centity_t* cent)
	{
		Vec3 old_angles, new_angles, angles; 
		
		auto result = BG_EvaluateTrajectory(&cent->prev_state().apos, game::cg()->snap->serverTime, old_angles, game::cg()->frameInterpolation);
		BG_EvaluateTrajectory(&cent->next_state().pos, game::cg()->nextSnap->serverTime, new_angles, result);

		angles[0] = math::angle_delta(new_angles[0], old_angles[0]);
		angles[1] = math::angle_delta(new_angles[1], old_angles[1]);
		angles[2] = math::angle_delta(new_angles[2], old_angles[2]);

		angles[0] = static_cast<float>(GET_SIGN(angles[0]));
		angles[1] = static_cast<float>(GET_SIGN(angles[1]));
		angles[2] = static_cast<float>(GET_SIGN(angles[2]));

		return angles;
	}

	void callback_cg_interpolate_entity_position(game::centity_t* cent)
	{
		if (!enabled)
			return;

		if (!aimbot::is_valid_target(cent))
			return;

		const auto velocity = get_entity_velocity(cent);
		cent->origin += velocity * (game::cg()->frameTime * 0.001f);
		cent->origin += velocity * (game::cg()->snap->ping * 0.001f);

		const auto angles = get_entity_interpolated_angles(cent);
		cent->angles += angles * (game::cg()->frameTime * 0.001f);
		cent->angles += angles * (game::cg()->snap->ping * 0.001f);
	}

	__declspec(naked) void cg_interpolate_entity_position()
	{
		__asm
		{
			mov ecx, 0x0048D410;
			call ecx;

			pushad;
			push esi;
			call callback_cg_interpolate_entity_position;
			pop esi;
			popad;
			retn;
		}
	}

	void initialize()
	{
		utils::hook::call(0x0048E89F, &cg_interpolate_entity_position);
		utils::hook::retn(0x0046935F);
	}
}