#pragma once
#include "dependencies/stdafx.hpp"

namespace prediction
{
	extern bool enabled;
	void initialize();
}