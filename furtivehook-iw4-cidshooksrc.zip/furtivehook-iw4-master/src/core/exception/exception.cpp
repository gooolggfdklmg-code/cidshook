#include "dependencies/stdafx.hpp"
#include "exception.hpp"

namespace exception
{
	using callback = std::function<void(CONTEXT&)>;
	std::unordered_map<std::uintptr_t, callback>& get_callbacks()
	{
		static std::unordered_map<std::uintptr_t, callback> callbacks{};
		return callbacks;
	}

	bool handle_exception(const LPEXCEPTION_POINTERS ex)
	{
		const auto& callbacks = get_callbacks();
		const auto handler = callbacks.find(ex->ContextRecord->Eip);

		if (handler == callbacks.end())
		{
			return false;
		}

		handler->second(*ex->ContextRecord);
		return true;
	}

	void register_hook(const std::uintptr_t address, const callback& callback)
	{
		get_callbacks()[address] = callback;
	}
	
	LONG __stdcall exception_filter(const LPEXCEPTION_POINTERS ex)
	{
		const auto addr = ex->ExceptionRecord->ExceptionAddress;
		const auto code = ex->ExceptionRecord->ExceptionCode;

		if (code != STATUS_INTEGER_OVERFLOW
			&& code != STATUS_FLOAT_OVERFLOW
			&& code != STATUS_SINGLE_STEP
			&& !handle_exception(ex))
		{
			auto error = "Termination due to a stack overflow."s;
			if (code != EXCEPTION_STACK_OVERFLOW)
			{
				error = utils::string::va("Exception: 0x%08X at 0x%08X", code, addr);
			}

			utils::exception::minidump::write(ex);

			PRINT_LOG("%s", error.data());
			game::Com_Error(game::ERR_DROP, error.data());
		}

		return EXCEPTION_CONTINUE_SEARCH;
	}

	LPTOP_LEVEL_EXCEPTION_FILTER __stdcall set_unhandled_exception_filter(LPTOP_LEVEL_EXCEPTION_FILTER)
	{
		return &exception_filter;
	}
	
	void initialize()
	{
		SetUnhandledExceptionFilter(exception_filter);
		utils::hook::jump(&SetUnhandledExceptionFilter, &set_unhandled_exception_filter);
	}
}