#pragma once
#include "dependencies/stdafx.hpp"

struct hotkey_t
{
	UINT key;
	void(*func)();
	bool block;
};

namespace input
{
	void initialize(HWND hwnd);
	void on_key(UINT key, void(*cbb)(), bool block = false);
}