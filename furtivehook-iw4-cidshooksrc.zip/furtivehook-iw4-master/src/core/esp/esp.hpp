#pragma once
#include "dependencies/stdafx.hpp"

namespace esp
{
	struct player_bone_tags
	{
		Vec2 pos[static_cast<std::uint32_t>(game::bone_tag::num_tags)];
		ImVec4 color;
	};

	struct player_box
	{
		bool w2s;
		Vec2 bottom, top, screen;
		Vec2 pos;
		Vec2 scale;
	};

	struct player_name
	{
		char name[38]{};
		Vec2 pos;
		Vec3 center;
	};

	constexpr static auto window_title = "visuals";
	constexpr static auto window_flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoInputs;

	extern float bone_thickness;
	extern bool enabled, name_tag, box, bone_tags, enemies_only;
	extern ImVec4 enemy_visible_color, enemy_color, friendly_color;

	void visuals();
	void draw();
}