#pragma once
#include "dependencies/stdafx.hpp"

namespace security::iat
{
	void initialize();
}
