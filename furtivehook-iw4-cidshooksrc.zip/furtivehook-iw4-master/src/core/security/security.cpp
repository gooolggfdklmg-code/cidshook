#include "dependencies/stdafx.hpp"
#include "security.hpp"

namespace security
{
	auto lsp_handle_packet_original = reinterpret_cast<decltype(&lsp_handle_packet)>(0x006267B0); 
	auto sv_set_stats_original = reinterpret_cast<decltype(&sv_set_stats)>(0x004A749F);
	auto rb_draw_stretch_pic_rotate_original = reinterpret_cast<decltype(&rb_draw_stretch_pic_rotate)>(0x00438CF0);
	auto bg_get_weapon_def_original = reinterpret_cast<decltype(&bg_get_weapon_def)>(0x00479510);
	auto bg_get_weapon_complete_def_original = reinterpret_cast<decltype(&bg_get_weapon_complete_def)>(0x00479520);
	auto cl_get_config_string_original = reinterpret_cast<decltype(&cl_get_config_string)>(0x004BBFC0);
	auto msg_read_bits_original = reinterpret_cast<decltype(&msg_read_bits)>(0x00491DE0);
	auto msg_read_bit_original = reinterpret_cast<decltype(&msg_read_bit)>(0x00491D50);
	auto cg_map_restart_original = reinterpret_cast<decltype(&cg_map_restart)>(0x004A7690);
	auto ui_replace_directive_original = reinterpret_cast<decltype(&ui_replace_directive)>(0x005AA3E0);
	auto seh_localize_text_message_original = reinterpret_cast<decltype(&seh_localize_text_message)>(0x00591CF0);
	auto seh_localize_text_message_token_original = reinterpret_cast<decltype(&seh_localize_text_message_token)>(0x00591DE2);
	auto field_char_event_original = reinterpret_cast<decltype(&field_char_event)>(0x004C2502);

	int __cdecl msg_read_bit(game::msg_t* msg)
	{
		if (msg->overflowed)
		{
			PRINT_LOG("[0x%08X] Overflow in MSG_ReadBit", _ReturnAddress());
			return 0;
		}

		return msg_read_bit_original(msg); 
	}
	
	int __cdecl msg_read_bits(game::msg_t* msg, int bits)
	{
		if (msg->overflowed)
		{
			PRINT_LOG("[0x%08X] Overflow in MSG_ReadBits", _ReturnAddress());
			return 0;
		}

		return msg_read_bits_original(msg, bits);
	}

	const char* __cdecl cl_get_config_string(int config_string_index)
	{
		if (constexpr auto max_index = 4339u; static_cast<std::uint32_t>(config_string_index) < max_index)
		{
			return cl_get_config_string_original(config_string_index);
		}

		PRINT_LOG("(configStringIndex) > (MAX_CONFIGSTRINGS) [%u] [0x%08X]", config_string_index, _ReturnAddress());
		return "";
	}

	game::WeaponDef* __cdecl bg_get_weapon_def(int weapon_index)
	{
		if (const auto max_index = game::BG_GetNumWeapons(); static_cast<std::uint32_t>(weapon_index) < max_index)
		{
			return bg_get_weapon_def_original(weapon_index);
		}

		PRINT_LOG("weapon_index > bg_lastParsedWeaponIndex: [%u] [0x%08X]", weapon_index, _ReturnAddress());
		return bg_get_weapon_def_original(game::cl()->snap.ps.weapCommon.weapon);
	}

	game::WeaponCompleteDef* __cdecl bg_get_weapon_complete_def(int weapon_index)
	{
		if (const auto max_index = game::BG_GetNumWeapons(); static_cast<std::uint32_t>(weapon_index) < max_index)
		{
			return bg_get_weapon_complete_def_original(weapon_index);
		}

		PRINT_LOG("weapon_index > bg_lastParsedWeaponIndex: [%u] [0x%08X]", weapon_index, _ReturnAddress());
		return bg_get_weapon_complete_def_original(game::cl()->snap.ps.weapCommon.weapon);
	}

	bool __cdecl callback_rb_draw_stretch_pic_rotate(game::Material* material)
	{
		const auto material_index = game::DB_GetMaterialIndex(material);
		if (material_index < 4096 && !material->info.hashIndex && material->techniqueSet && material->techniqueSet->name == "2d"s)
		{
			return false;
		}

		return true;
	}

	__declspec(naked) void rb_draw_stretch_pic_rotate()
	{
		__asm
		{
			pushad;
			mov ecx, dword ptr[ecx + 3];
			push ecx;
			call callback_rb_draw_stretch_pic_rotate;
			test al, al;
			pop ecx;
			popad;

			jz fix;

			retn;

		fix:
			jmp rb_draw_stretch_pic_rotate_original;
		}
	}
	
	void __cdecl sv_update_server_commands_to_client(game::client_t* client, game::msg_t* msg)
	{
		if (client->reliableAcknowledge < 0)
		{
			PRINT_LOG("Invalid reliableAcknowledge message from '%s' (%llu) %s",
				client->name,
				client->steamID,
				client->header.netchan.remoteAddress.to_string().data());
		}
		
		return reinterpret_cast<void(*)(game::client_t*, game::msg_t*, size_t)>(0x0058F400)(client, msg, msg->maxsize); // SV_UpdateServerCommandsToClient_PreventOverflow
	}

	void __cdecl callback_sv_set_stats()
	{
		if (game::IsServerRunning())
		{
			PRINT_MESSAGE("Server", "Your stats were modified");
			return;
		}

		std::memcpy(game::LiveStorage_GetPersistentDataBuffer(0), game::g_statsBackup, 0x1FFC);
		PRINT_MESSAGE("Server", "Stat change attempt caught from host");
	}

	__declspec(naked) void sv_set_stats()
	{
		__asm
		{
			pushad;
			call callback_sv_set_stats;
			popad;

			push 0x004A75CB;
			retn;
		}
	}

	void __cdecl cg_map_restart(LocalClientNum_t localClientNum, int savepersist)
	{
		if (game::clc()->isServerRestarting)
		{
			return cg_map_restart_original(localClientNum, savepersist);
		}

		PRINT_LOG_DETAILED("Exploit attempt caught!");
	}

	bool __cdecl load_script_menu(LocalClientNum_t localClientNum, const char *pszMenu, int imageTrack)
	{
		const auto menu_lwr = utils::string::to_lower(pszMenu); 
		if (!utils::string::begins_with(menu_lwr, "uiscript"))
		{
			logger::print_sv_log("Loading script menu file %s", pszMenu);
			return reinterpret_cast<decltype(&load_script_menu)>(0x0059B350)(localClientNum, pszMenu, imageTrack);
		}

		PRINT_LOG("Not loading script menu file %s", pszMenu);
		return true;
	}
	
	void __cdecl net_defer_packet_to_client(game::netadr_t *net_from, game::msg_t *net_message)
	{
		if (static_cast<size_t>(net_message->cursize) >= sizeof(game::DeferredMsg::data))
		{
			PRINT_LOG_DETAILED("Exploit attempt caught! [%u] from %s", net_message->cursize, net_from->to_string(true).data());
			return;
		}

		return reinterpret_cast<decltype(&net_defer_packet_to_client)>(0x00573290)(net_from, net_message);
	}

	bool ui_replace_directive(LocalClientNum_t localClientNum, char* message, char* hudElemString, int length)
	{
		if (const auto str_len = std::strlen(message); str_len >= static_cast<size_t>(length))
		{
			PRINT_LOG_DETAILED("[0x%08X] Exploit attempt caught! [%u] [%u] [%s]", _ReturnAddress(), str_len, length, utils::string::dump_hex(message, " ").data());
			*message = 0;
		}

		return ui_replace_directive_original(localClientNum, message, hudElemString, length);
	}

	char *__cdecl seh_localize_text_message(char *buffer, const char* msg_type, int errType)
	{
		if (const auto str_len = std::strlen(buffer); str_len >= 1024)
		{
			PRINT_LOG_DETAILED("[0x%08X] Exploit attempt caught! [%u] [%s]", _ReturnAddress(), str_len, buffer);
			*buffer = 0;
		}
		
		return seh_localize_text_message_original(buffer, msg_type, errType);
	}
	
	bool __cdecl callback_seh_localize_text_message_token(size_t token_length)
	{
		if (token_length >= 0x400)
		{
			PRINT_LOG_DETAILED("Exploit attempt caught! [%u]", token_length);
			return true;
		}

		return false;
	}
	
	__declspec(naked) void seh_localize_text_message_token()
	{
		__asm
		{
			pushad;
			lea eax, [ebx + ebp];
			push eax;
			call callback_seh_localize_text_message_token;
			test al, al;
			pop eax;
			popad;

			jz fix;

			pop edi;
			pop esi;
			pop ebp;
			pop ebx;
			add esp, 0x824;
			mov eax, [esp + 4];
			retn; 
		fix:
			jmp seh_localize_text_message_token_original;
		}
	}

	void __declspec(naked) field_char_event()
	{
		__asm
		{
			cmp dword ptr[esp + 12], 0x004C26E3;
			jz fix;
			
			jmp field_char_event_original;
		fix:
			push 0x004C2527;
			retn;
		}
	}

	bool __cdecl lsp_handle_packet(game::msg_t *msg, game::netadr_t* netadr)
	{
		if (game::NET_CompareBaseAdr(*reinterpret_cast<game::netadr_t*>(0x06651D2C), *netadr))
		{
			return lsp_handle_packet_original(msg, netadr);
		}

		PRINT_LOG("Received LSP packet from an invalid address (%s:%u)", netadr->to_string().data(), netadr->addr.port);
		return false;
	}
	
	void initialize()
	{
		security::iat::initialize(); 
		
		utils::hook::detour(&cl_get_config_string_original, &cl_get_config_string);
		utils::hook::detour(&bg_get_weapon_def_original, &bg_get_weapon_def);
		utils::hook::detour(&bg_get_weapon_complete_def_original, &bg_get_weapon_complete_def);
		utils::hook::detour(&rb_draw_stretch_pic_rotate_original, &rb_draw_stretch_pic_rotate);
		utils::hook::detour(&ui_replace_directive_original, &ui_replace_directive);
		utils::hook::detour(&sv_set_stats_original, &sv_set_stats);
		utils::hook::detour(&msg_read_bits_original, &msg_read_bits);
		utils::hook::detour(&msg_read_bit_original, &msg_read_bit);
		utils::hook::detour(&cg_map_restart_original, &cg_map_restart);
		utils::hook::detour(&seh_localize_text_message_original, &seh_localize_text_message);
		utils::hook::detour(&seh_localize_text_message_token_original, &seh_localize_text_message_token);
		utils::hook::detour(&field_char_event_original, &field_char_event);
		utils::hook::detour(&lsp_handle_packet_original, &lsp_handle_packet);
		
		utils::hook::jump(0x0058F380, &sv_update_server_commands_to_client);
		utils::hook::call(0x004A6144, &load_script_menu);
		utils::hook::call(0x0058AC3A, &net_defer_packet_to_client);
		
		command::on_command("mr", [](const auto& args, const auto& client)
		{
			if (utils::atoi(args[1]) != game::sv_serverId_value)
				return true;

			const auto menu_index = utils::atoi(args[2]);
			const auto response = utils::string::to_lower(args[3]);

			if (menu_index == 2)
			{
				if (game::Dvar_FindVar("xblive_privatematch")->current.enabled)
				{
					return false;
				}

				game::send_server_command(-1, utils::string::va("f \"^5'%s'^7 attempted to change their team.\"", client.name));
				return true;
			}
			else if (response == "endround")
			{
				if (client.header.netchan.remoteAddress.type == game::NA_LOOPBACK)
				{
					return false;
				}

				game::send_server_command(-1, utils::string::va("f \"^5'%s'^7 attempted to end the game.\"", client.name));
				return true;
			}

			return false;
		});
		
		network::on_command("error", [](const auto& args, const auto& target, auto& msg)
		{
			if (game::CL_GetLocalClientConnectionState() == game::CA_CHALLENGING)
			{
				return false;
			}

			PRINT_MESSAGE("Security", "Kick attempt caught from %s", utils::get_sender_string(target).data());
			return true;
		});

		network::on_command("go", [](const auto& args, const auto& target, const auto&)
		{
			const auto playlist_num = utils::atoi<int>(args[1]);
			const auto entry_num = utils::atoi<int>(args[2]);
			const auto map_name = args[4];

			if (!game::SV_MapExists(map_name) || map_name != utils::string::to_lower(map_name))
			{
				PRINT_LOG("Map '%s' doesn't exist.", map_name);
				return true;
			}

			if (static_cast<size_t>(playlist_num) >= game::Playlist_GetPlaylistCount() || static_cast<size_t>(entry_num) > 255)
			{
				PRINT_MESSAGE("Security", "Crash attempt caught from %s", utils::get_sender_string(target).data());
				return true;
			}

			return false;
		});

		network::on_command("joinParty", [](const auto& args, const auto& target, const auto&)
		{
			const auto count = utils::atoi<int>(args[7]);
			const auto overflown = count > 18;

			if (overflown)
			{
#if 0
				return target.addr.inaddr && target.addr.inaddr != 0x0100007F;
#endif
				PRINT_MESSAGE("Security", "Exploit attempt caught from %s", utils::get_sender_string(target).data());
				return true;
			}
				
			return false;
		});
		
		network::on_command("loadingnewmap", [](const auto& args, const auto& target, auto& msg)
		{
			if (!game::NET_CompareBaseAdr(target, game::clc()->serverAddress) || target.type == game::NA_LOOPBACK)
				return true;

			char mapname[64] = { 0 };
			game::MSG_ReadStringLine(&msg, mapname, sizeof mapname);

			if (!game::SV_MapExists(mapname) || mapname != utils::string::to_lower(mapname))
			{
				PRINT_LOG("Map '%s' doesn't exist.", mapname);
				return true;
			}

			return false;
		});
		
		network::on_command("mstart", [](const auto& args, const auto& target, const auto&)
		{
			if (game::NET_CompareBaseAdr(target, game::clc()->serverAddress))
			{
				return false;
			}

			PRINT_MESSAGE("Security", "Migration screen attempt caught from %s", utils::get_sender_string(target).data());
			return true;
		});
		
		network::on_command("relay", [](const auto& args, const auto& target, auto& msg)
		{
			if (const auto client_num = utils::atoi<uint32_t>(args[1]); client_num >= 18)
			{
				PRINT_MESSAGE("Security", "Crash attempt caught from %s", utils::get_sender_string(target).data());
				return true;
			}
				
			char data[1024] = { 0 };
			game::MSG_ReadString(&msg, data, sizeof data);

			const auto data_args = utils::string::split(utils::string::to_lower(data), ' ');
			
			const auto accept =
			{
				"nominee"s,
				"migrateto"s,
				"bandtest"s,
				"bandres"s,
			};

			const auto result = std::any_of(accept.begin(), accept.end(), [=](const auto& oob_string) 
			{ 
				return !data_args.empty() && (data_args[0][0] == '0' || data_args[0][0] == '1' || data_args[0][0] == '2') && data_args[0].substr(1) == oob_string;
			});

			if (!result)
			{
				PRINT_LOG("Ignoring relay OOB '%s' from %s", data, utils::get_sender_string(target).data());
				return true;
			}

			return false;
		});

		network::on_command("requeststats", [](const auto& args, const auto& target, const auto&)
		{
			if (game::NET_CompareBaseAdr(target, game::clc()->serverAddress) 
				&& game::CL_GetLocalClientConnectionState() == game::CA_CONNECTED)
			{
				return false;
			}

			PRINT_MESSAGE("Security", "Exploit attempt caught from %s", utils::get_sender_string(target).data()); 
			return true;
		});

		server_command::on_server_command("A", [](const auto& args)
		{
			const auto channel_count = utils::atoi<uint32_t>(args[1]);
			const auto param_index = utils::atoi<uint32_t>(args[2]);

			if (channel_count < 4 && param_index < 16)
			{
				return false;
			}

			PRINT_LOG("Crash attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("B", [](const auto& args)
		{
			if (const auto channel_count = utils::atoi<uint32_t>(args[1]); channel_count < 4)
			{
				return false;
			}

			PRINT_LOG("Crash attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("J", [](const auto& args)
		{	
			if (args.size() % 2 != 1)
			{
				PRINT_LOG("Kick attempt caught! [%s]", args[0]);
				return true;
			}

			for (size_t i = 1; i < args.size(); i += 2)
			{
				if (const auto index = utils::atoi<uint32_t>(args[i]); index >= 0x1FFC)
				{
					PRINT_LOG("Kick attempt caught! [%s]", args[0]);
					return true;
				}
			}
			
			return false;
		}); 
		
		server_command::on_server_command("K", [](const auto& args)
		{
			const auto client_info_index = utils::atoi<uint32_t>(args[1]); 
			const auto player_card_cache_index = utils::atoi<uint32_t>(args[2]);

			if (client_info_index < 18 && player_card_cache_index < 18)
			{
				return false;
			}
				
			PRINT_LOG("Exploit attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("a", [](const auto& args)
		{
			if (const auto weapon_index = utils::atoi<uint32_t>(args[1]); game::is_weapon_in_held_slot(weapon_index))
			{
				return false;
			}
			
			PRINT_LOG("Crash attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("b", [](const auto& args)
		{
			if (const auto client_num = utils::atoi<uint32_t>(args[5]); client_num < 18)
			{
				return false;
			}

			PRINT_LOG("Exploit attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("d", [](const auto& args)
		{
			const auto config_string_index = utils::atoi<uint32_t>(args[1]);
			const auto config_string = args[2];

			if (config_string_index >= 4339)
			{
				PRINT_LOG("(configStringIndex) > (MAX_CONFIGSTRINGS) [%u]", config_string_index);
				return true;
			}

			if (config_string_index == 3)
			{
				const auto server_id = game::cl()->serverId;
				const auto valid = game::clc()->isServerRestarting || utils::atoi<std::uint8_t>(config_string) == (static_cast<std::uint8_t>(server_id & 0xF0) + ((static_cast<std::uint8_t>(server_id) + 1) & 0xF));

				if (valid)
				{
					return false;
				}

				PRINT_LOG("Exploit attempt caught! '%s' [%u]", args[0], config_string_index);
				return true;
			}
			else if (config_string_index == 4138)
			{
				if (const auto weapon_index = utils::atoi<uint32_t>(config_string); weapon_index < game::bg_lastParsedWeaponIndex)
				{
					return false;
				}

				PRINT_LOG("Crash attempt caught! '%s' [%u]", args[0], config_string_index);
				return true;
			}

			return false;
		}); 
		
		server_command::on_server_command("n", [](const auto& args)
		{
			const auto volume = std::atof(args[1]);
			const auto fade = utils::atoi<uint32_t>(args[2]);

			if (std::abs(volume) <= 1.0f && fade <= 1000)
			{
				return false;
			}

			PRINT_LOG("Exploit attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("o", [](const auto& args)
		{
			if (const auto env_effect_priority = utils::atoi<uint32_t>(args[1]); env_effect_priority < 5)
			{
				return false;
			}

			PRINT_LOG("Crash attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("t", [](const auto& args)
		{
			const auto time{ std::chrono::high_resolution_clock::now() }; 
			static std::chrono::high_resolution_clock::time_point last_time{};
				
			if (last_time + 2s < time)
			{
				last_time = time;
				PRINT_LOG("Server told us to disconnect you with reason %s", args.join(1).data());
			}
				
			if (game::cg()->nextSnap && game::cg()->nextSnap->serverTime && game::cg()->nextSnap->ps.commandTime)
			{
				return true;
			}
				
			return false;
		});

		server_command::on_server_command("y", [](const auto& args)
		{
			if (const auto weapon_index = utils::atoi<uint32_t>(args[1]); weapon_index < game::bg_lastParsedWeaponIndex)
			{
				return false;
			}

			PRINT_LOG("Crash attempt caught! [%s]", args[0]);
			return true;
		});

		server_command::on_server_command("z", [](const auto& args)
		{
			if (const auto env_effect_priority = utils::atoi<uint32_t>(args[1]); env_effect_priority < 5)
			{
				return false;
			}

			PRINT_LOG("Crash attempt caught! [%s]", args[0]);
			return true;
		});
	}
}