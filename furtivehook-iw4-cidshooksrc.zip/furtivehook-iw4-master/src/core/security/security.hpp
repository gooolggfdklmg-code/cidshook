#pragma once
#include "dependencies/stdafx.hpp"

namespace security
{
	const char * __cdecl cl_get_config_string(int configStringIndex);
	game::WeaponCompleteDef * __cdecl bg_get_weapon_complete_def(int weapon_index);
	game::WeaponDef * __cdecl bg_get_weapon_def(int weapon_index);
	int __cdecl msg_read_bit(game::msg_t * msg);
	int __cdecl msg_read_bits(game::msg_t * msg, int c);
	void rb_draw_stretch_pic_rotate();
	void sv_set_stats();
	void __cdecl cg_map_restart(LocalClientNum_t localClientNum, int savepersist);
	bool ui_replace_directive(LocalClientNum_t localClientNum, char * message, char * buffer, int length);
	char * __cdecl seh_localize_text_message(char * buffer, const char * msg_type, int errType);
	void seh_localize_text_message_token();
	void field_char_event();
	bool __cdecl lsp_handle_packet(game::msg_t * msg, game::netadr_t * netadr);
	void initialize();
}