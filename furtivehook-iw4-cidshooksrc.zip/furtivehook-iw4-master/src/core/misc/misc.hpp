#pragma once
#include "dependencies/stdafx.hpp"

namespace misc
{
	void __cdecl com_error(game::errorParm_t errorType, const char * error);
	void __cdecl cl_bandwidth_test_frame(int bandwidth_data, int bandwidth_input);
	void party_write_member();
	void client_user_info_changed();
	void cl_exec_binding();
	void initialize();

	extern float fov_value;
	extern bool cycling_prestige, third_person, no_flinch, no_recoil, always_host, spoof_ip;
}
