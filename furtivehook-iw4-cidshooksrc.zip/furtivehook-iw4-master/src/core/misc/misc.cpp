#include "dependencies/stdafx.hpp"
#include "misc.hpp"

namespace misc
{
	auto com_error_original = reinterpret_cast<decltype(&com_error)>(0x0056A0C0);
	auto cl_bandwidth_test_frame_original = reinterpret_cast<decltype(&cl_bandwidth_test_frame)>(0x0062C830);
	auto party_write_member_original = reinterpret_cast<decltype(&party_write_member)>(0x004D76D0);
	auto client_user_info_changed_original = reinterpret_cast<decltype(&client_user_info_changed)>(0x0051F16F);
	auto cl_exec_binding_original = reinterpret_cast<decltype(&cl_exec_binding)>(0x004C0E45);
	bool cycling_prestige = false, third_person = false, no_flinch = true, no_recoil = true, always_host = false, spoof_ip = false;
	int brush_model_trace_finish = 0;
	float fov_value = 65.0f;
	
	void __cdecl cg_damage_feedback(LocalClientNum_t localClientNum, int yawByte, int pitchByte, int damage, bool flag)
	{
		if (!misc::no_flinch)
		{
			return reinterpret_cast<decltype(&cg_damage_feedback)>(0x004A0850)(localClientNum, yawByte, pitchByte, damage, flag);
		}
	}

	void __cdecl bg_weapon_fire_recoil(const game::playerState_s* ps, Vec2 recoilSpeed, std::uint32_t* holdrand, int unk1)
	{
		if (!misc::no_recoil)
		{
			return reinterpret_cast<decltype(&bg_weapon_fire_recoil)>(0x00479F60)(ps, recoilSpeed, holdrand, unk1);
		}
	}

	int __cdecl brush_model_trace_info(int index)
	{
		return brush_model_trace_finish ? brush_model_trace_finish : reinterpret_cast<decltype(&brush_model_trace_info)>(0x00576760)(index);
	}

	int get_host_rating()
	{
		if (!misc::always_host)
		{
			return reinterpret_cast<decltype(&get_host_rating)>(0x004C8C10)();
		}

		return std::numeric_limits<int>::max();
	}

	__declspec(naked) void r_create_window()
	{
		__asm
		{
			mov ebp, WS_VISIBLE | WS_POPUP;
			retn;
		}
	}

	char* __cdecl dvar_info_string(LocalClientNum_t localClientNum, int bit)
	{
		const auto result = reinterpret_cast<decltype(&dvar_info_string)>(0x0056C530)(localClientNum, bit);
		game::Info_SetValueForKey(result, "amogus", "a");

		return result;
	}

	void __cdecl com_error(game::errorParm_t errorType, const char* error)
	{
		if (game::com_errorEnteredCount >= 1)
		{
			PRINT_LOG("[double com_error] First Error: %s Second Error: %s", game::com_errorMessage, error);
		}

		logger::print_log("[%i] %s @ 0x%08X", errorType, error, _ReturnAddress());

		if (errorType == game::ERR_FATAL)
			errorType = game::ERR_DROP;

		return com_error_original(errorType, error);
	}

	game::XNADDR* __cdecl xenon_get_xnaddr_for_live()
	{
		if (!misc::spoof_ip)
		{
			return reinterpret_cast<decltype(&xenon_get_xnaddr_for_live)>(0x005C72F0)();
		}

		auto xn{ game::g_ourXnaddr };
		xn->localaddr = htonl(0x01010101);
		xn->addr.inaddr = xn->localaddr;
		xn->addr.port = 1111;

		return xn;
	}

	void __cdecl cl_bandwidth_test_frame(int bandwidth_data, int bandwidth_input)
	{
		if (misc::always_host)
		{
			*reinterpret_cast<int*>(bandwidth_data + 148) = std::numeric_limits<int>::max();
		}

		return cl_bandwidth_test_frame_original(bandwidth_data, bandwidth_input);
	}

	void __cdecl callback_party_write_member(game::PartyMember* member)
	{
		const auto client_num = game::get_client_num(member);
		const auto netadr = game::party_data()->session->dyn.users[client_num].addr;

		if (const auto f = friends::get_by_ip(netadr))
		{
			const auto nickname = f->nickname;

			if (!nickname.empty())
			{
				game::I_strncpyz(member->gamertag, nickname, 32);
			}
		}
	}

	__declspec(naked) void party_write_member()
	{
		__asm
		{
			pushad;
			push esi;
			call callback_party_write_member;
			pop esi;
			popad;

			jmp party_write_member_original;
		}
	}

	void __cdecl callback_client_user_info_changed(size_t client_num)
	{
		const auto client = &game::svs_client->clients[client_num];

		if (!client)
			return;

		if (const auto f = friends::get_by_ip(client->header.netchan.remoteAddress))
		{
			const auto nickname = f->nickname;

			if (!nickname.empty())
			{
				game::Info_SetValueForKey(client->userinfo, "name", nickname.data());
			}
		}
	}

	__declspec(naked) void client_user_info_changed()
	{
		__asm
		{
			pushad;
			push edi;
			call callback_client_user_info_changed;
			pop edi;
			popad;

			jmp client_user_info_changed_original;
		}
	}

	__declspec(naked) void cl_exec_binding()
	{
		__asm
		{
			push ebx;

			mov ebx, dword ptr[esp + 0x10];

			cmp ebx, 0x40;
			jz fix;
			cmp ebx, 0x3F;
			jz fix;

			pop ebx;

			jmp cl_exec_binding_original;
		fix:
			push 0x004C0E68;
			retn;
		}
	}
	
	void initialize()
	{
		utils::hook::detour(&com_error_original, &com_error);
		utils::hook::detour(&cl_bandwidth_test_frame_original, &cl_bandwidth_test_frame);
		utils::hook::detour(&party_write_member_original, &party_write_member);
		utils::hook::detour(&client_user_info_changed_original, &client_user_info_changed);
		utils::hook::detour(&cl_exec_binding_original, &cl_exec_binding); 
		
		utils::hook::call(0x0055F435, &brush_model_trace_info);
		utils::hook::call(0x004C93A3, &get_host_rating);
		utils::hook::call(0x004B9FE7, &bg_weapon_fire_recoil);
		utils::hook::call(0x004A0DD2, &cg_damage_feedback);
		utils::hook::call(0x004C44EE, &dvar_info_string);
		utils::hook::call(0x004CF569, &xenon_get_xnaddr_for_live);
		
		utils::hook::nop(0x004DE2AE, 2); // PartyUI_ShowTruePlayerInfo
		utils::hook::retn(0x005C9150); // Sys_CheckCrashOrRerun
		utils::hook::return_value(0x005C7C20, 1); // Sys_AllowVidRestart

		utils::hook::set<std::uint8_t>(0x0056B012, 0xEB); // Com_StartHunkUsers
		utils::hook::set<std::uint8_t>(0x004DB41A, 0xEB); // PartyHost_HandleJoinPartyRequest
		utils::hook::set<std::uint8_t>(0x0085CCC0, 1); // g_natType
		utils::hook::set<std::uint8_t>(0x004A4CCD + 1, 1);
		
		constexpr static auto font_height{ 12.0f };
		utils::hook::set(0x004869DC + 0x2, &font_height);
		constexpr static auto font_scale{ 10.0f };
		utils::hook::set(0x004869F6 + 0x2, &font_scale);
		
		input::on_key(VK_F2, [] { command::execute("disconnect"); });
		input::on_key(VK_F3, [] { game::Com_Quit_f(); });
		input::on_key(VK_F4, [] { third_person = !third_person; });

		scheduler::once(game::initialize, scheduler::pipeline::main);
		
		scheduler::loop([]()
		{
			for (size_t i = 0; i < 18; ++i)
			{
				if (!game::is_valid_target(i))
				{
					aimbot::priority_target[i] = false;
					aimbot::ignore_target[i] = false;
				}
			}
			
			stats::set_skills(0);
			game::Dvar_FindVar("ping_default_min")->current.integer = 250;
		}, scheduler::pipeline::main);

		scheduler::loop(game::on_every_frame, scheduler::pipeline::renderer); 
		
		scheduler::loop([]()
		{
			brush_model_trace_finish = game::Sys_GetValue(3); 
				
			const static auto cg_thirdperson = game::Dvar_FindVar("cg_thirdPerson");
			const static auto fov = game::Dvar_FindVar("cg_fov");
			cg_thirdperson->current.enabled = misc::third_person && !game::cg()->in_killcam();
			fov->current.value = misc::fov_value;
		}, scheduler::pipeline::renderer);
	}
}