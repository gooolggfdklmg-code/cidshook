#pragma once

namespace server_command
{
	void on_server_command(const std::string& command, const std::function<bool(const command::args&)>& callback);
	void cl_cgame_needs_server_command();
	void initialize();
	
	extern bool log_sv_commands;
}
