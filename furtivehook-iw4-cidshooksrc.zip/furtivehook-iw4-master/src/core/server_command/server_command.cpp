#include "dependencies/stdafx.hpp"
#include "server_command.hpp"

namespace server_command
{
	auto cl_cgame_needs_server_command_original = reinterpret_cast<decltype(&cl_cgame_needs_server_command)>(0x004BD203);
	std::unordered_map<std::string, std::function<bool(const command::args&)>> callbacks;
	bool log_sv_commands = false;

	void on_server_command(const std::string& command, const std::function<bool(const command::args&)>& callback)
	{
		if (callbacks.find(command) == callbacks.end())
		{
			callbacks[command] = callback;
		}
	}

	bool can_handle_server_command(const std::string& command)
	{
		return callbacks.find(command) != callbacks.end() && callbacks[command];
	}

	void log_server_commands(const std::string& command)
	{
		if (log_sv_commands)
		{
			PRINT_LOG("Received SV Command %s", command.data()); 
			return;
		}

		logger::print_sv_log("Received SV Command %s", command.data());
	}

	bool handle_server_command(const std::string& command)
	{
		if (const command::args args{}; args.size() > 0)
		{
			log_server_commands(args.join());

			if (can_handle_server_command(command))
			{
				return callbacks[command](args);
			}
		}

		return false;
	}

	bool __cdecl callback_cl_cgame_needs_server_command(const char* command)
	{
		if (handle_server_command(command))
		{
			game::Cmd_EndTokenizedString();
			return true;
		}

		return false;
	}

	__declspec(naked) void cl_cgame_needs_server_command()
	{
		__asm
		{
			pushad;
			push ecx;
			call callback_cl_cgame_needs_server_command;
			test al, al;
			pop ecx;
			popad;

			jz fix;

			pop esi;
			push 0x004BD19A;
			retn;

		fix:
			jmp cl_cgame_needs_server_command_original; 
		}
	}
	
	void initialize()
	{
		utils::hook::detour(&cl_cgame_needs_server_command_original, &cl_cgame_needs_server_command);
		utils::hook::nop(0x004BD198, 2);

		on_server_command("e", [](const auto& args)
		{
			const auto reasons =
			{
				"EXE_TRANSMITERROR",
				"EXE_TIMEDOUT",
				"EXE_LEFTGAME",
				"EXE_PLAYERKICKED",
				"EXE_DISCONNECTED",
				"EXE_LOSTRELIABLECOMMANDS",
			};

			for (const auto& reason : reasons)
			{
				const auto game_message = game::get_translated_hud_elem_message(args[1], reason);

				if (!game_message.empty())
				{
					PRINT_LOG("%s", game_message.data());
				}
			}

				return false;
		}); 
		
		on_server_command("f", [](const auto& args)
		{
			const auto game_message = game::get_translated_hud_elem_message(args[1], "MP_CONNECTED");

			if (!game_message.empty())
			{
				PRINT_LOG("%s", game_message.data());
			}

			return false;
		}); 
	}
}