#pragma once
#include "dependencies/stdafx.hpp"

namespace session
{
	struct player_info
	{
		size_t client_num;
		uint64_t steam_id;
		std::string name;
		game::netadr_t adr;
	};

	struct pong_response
	{
		game::netadr_t netadr;
		bool ingame;
		std::pair<uint32_t, uint32_t> clients;
	};

	struct session_info
	{
		std::chrono::system_clock::time_point last_online{};
		pong_response response{};

		bool operator<(const session_info& other) const
		{
			return response.clients.first > other.response.clients.first;
		}
	}; 
	
	std::string build_hping(const pong_response& response);
	void draw_session_list(const float width, const float spacing);
	void initialize();
}