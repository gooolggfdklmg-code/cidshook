#include "dependencies/stdafx.hpp"
#include "stats.hpp"
#include <any>

namespace stats
{
	bool is_ready()
	{
		if (game::LiveStorage_MaySetPersistentData() && game::LiveStorage_DoWeHaveStats(0))
			return true;

		return false;
	}

	std::vector<const char*> parse_args_to_lookup_strings(const std::vector<std::string>& args, const bool set_data)
	{
		std::vector<const char*> lookup_strings_vector{};
		size_t amount_lookup_strings{ args.size() };

		if (set_data)
		{
			--amount_lookup_strings;
		}

		for (size_t i = 0; i < amount_lookup_strings; ++i)
		{
			lookup_strings_vector.push_back(args[i].data());
		}

		return lookup_strings_vector;
	}

	void set_player_data(const std::vector<std::string>& args)
	{
		if (args.size() < 2)
			return;

		const auto persistent_data_buffer{ game::LiveStorage_GetPersistentDataBuffer(0) };
		const auto lookup_strings_vector{ stats::parse_args_to_lookup_strings(args, true) };
		const auto index{ args.size() - 1 };
		const auto value{ args[index] };

		if (!game::LiveStorage_DataSetInternalString(index, &lookup_strings_vector[0], value, persistent_data_buffer, nullptr))
			return;

		game::LiveStorage_StatsWriteNeeded(0);
	}
	
	int get_player_data(const std::vector<std::string>& args)
	{
		if (args.size() < 1)
			return 0;

		const auto* persistent_data_buffer{ game::LiveStorage_GetPersistentDataBuffer(0) };
		const auto lookup_strings_vector{ stats::parse_args_to_lookup_strings(args, false) };
		const auto index{ args.size() };

		return game::LiveStorage_DataGetInternalInt(&lookup_strings_vector[0], index, reinterpret_cast<uint8_t*>(&persistent_data_buffer));
	}
	
	void set_skills(const int skill)
	{
		if (!stats::is_ready())
			return;

		const auto skills = stats::get_player_data("skills", "tdm");
		
		if (skills == skill)
			return;

		stats::set_player_data("skills", "tdm", skill);
	}
	
	void set_prestige(const int prestige)
	{
		if (!stats::is_ready())
			return;

		if (prestige < 0 || prestige > 11)
			return;

		stats::set_player_data("prestige", prestige);
	}

	void cycling_prestige()
	{
		if (!misc::cycling_prestige)
			return;
		
		static uint32_t prestige{ 0 };
		
		if (++prestige > 11)
			prestige = 0;

		stats::set_prestige(prestige);
	}

	void unlock_all()
	{
		if (!stats::is_ready())
			return;

		const game::StringTable* challenges_table{ nullptr };
		game::StringTable_GetAsset("mp/allchallengestable.csv", &challenges_table);

		if (challenges_table)
		{
			for (size_t i = 0; i < challenges_table->rowCount; ++i)
			{
				auto max_state{ 0 };
				auto max_progress{ 0 };

				for (size_t j = 0; j < 10; ++j)
				{
					const auto progress{ utils::atoi(game::StringTable_GetColumnValueForRow(challenges_table, i, 6 + j * 2)) };
					if (!progress) break;

					max_state = j + 2;
					max_progress = progress;
				}

				const auto challenge{ game::StringTable_GetColumnValueForRow(challenges_table, i, 0) };
				stats::set_player_data("challengeState", challenge, max_state);
				stats::set_player_data("challengeProgress", challenge, max_progress);
			}
		}

		stats::set_player_data("experience", 2516000);
		stats::set_player_data("iconUnlocked", "cardicon_prestige10_02", true);
		stats::set_player_data("skills", "tdm", 0);

		for (size_t i = 0; i < 10; ++i)
		{
			stats::set_player_data("customClasses", i, "name", "^2furtivehook");
		}

		command::execute("uploadStats", true);
		command::execute("updateGamerProfile", true);
	}

	void initialize()
	{
		utils::hook::return_value(0x005CABC0, 0); // Live_GetIWSkill
		utils::hook::return_value(0x005681C0, 0); // LiveStorage_UploadStats_IsRegression
		
		scheduler::loop(stats::cycling_prestige, scheduler::pipeline::main, 500ms);
	}
}