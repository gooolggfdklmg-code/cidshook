#pragma once
#include "dependencies/stdafx.hpp"

namespace stats
{
	void set_player_data(const std::vector<std::string>& args);
	int get_player_data(const std::vector<std::string>& args);
	void set_skills(const int skill);
	void set_prestige(const int prestige);
	void unlock_all();
	void initialize();
	
	template<class T> std::string to_string(T&& t) 
	{
		if constexpr (std::is_arithmetic_v<std::decay_t<T>>)
		{
			return std::to_string(std::forward<T>(t));
		}
		else
		{
			return std::forward<T>(t);
		}
	}
	
	template<typename... Args> void set_player_data(Args... args)
	{
		std::string text;
		(text.append(to_string(args) + " "), ...);

		set_player_data(utils::string::split(text, ' '));
	}

	template<typename... Args> int get_player_data(const Args... args)
	{
		std::string text;
		(text.append(to_string(args) + " "), ...);

		return get_player_data(utils::string::split(text, ' '));
	}
}