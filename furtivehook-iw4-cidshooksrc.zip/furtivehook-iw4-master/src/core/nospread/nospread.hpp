#pragma once
#include "dependencies/stdafx.hpp"

namespace nospread
{
	Vec3 get_spread_angles(const game::playerState_s * ps, const game::usercmd_s * cmd, const bool akimbo);

	extern bool enabled;
}