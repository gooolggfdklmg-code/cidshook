#include "dependencies/stdafx.hpp"
#include "nospread.hpp"

namespace nospread
{
	bool enabled = true;

	Vec3 get_bullet_end_pos(int* seed, const Vec3 view_axis[3], const float aim_spread_amount, const float range)
	{
		Vec3 start{}, end{}, direction{};
		game::CG_BulletEndpos(seed, aim_spread_amount, &start, &end, &direction, &view_axis[0], &view_axis[1], &view_axis[2], range);
		game::vectoangles(&direction, &direction);
		
		return direction;
	}
	
	float get_aim_spread_amount(const game::playerState_s* ps, const Weapon weapon)
	{
		const auto weapon_def = game::bg_weaponDefs(weapon);
		if (!weapon_def)
			return 0.0f;
		
		float min_spread, max_spread;
		game::BG_GetSpreadForWeapon(ps, weapon_def, &min_spread, &max_spread);

		const auto weapon_pos_frac = ps->weapCommon.fWeaponPosFrac;
		const auto aim_spread_scale = game::cg()->aimSpreadScale / 255.0f;
		const auto aim_spread_amount = (max_spread - min_spread) * aim_spread_scale + min_spread;
		
		if (weapon_pos_frac == 0.0f)
		{
			return aim_spread_amount;
		}

		const auto ads_spread = weapon_def->fAdsSpread;
		auto spread = aim_spread_amount * (1.0f - weapon_pos_frac);
		spread += ((max_spread - ads_spread) * aim_spread_scale + ads_spread) * weapon_pos_frac;

		return spread;
	}
	
	Vec3 get_spread_angles(const game::playerState_s* ps, const game::usercmd_s* cmd, const bool akimbo)
	{
		auto rand_seed{ cmd->serverTime };
		
		if (akimbo)
			rand_seed += 10;

		Vec3 view_axis[3];
		game::AngleVectors(&game::cg()->refdefViewAngles, &view_axis[0], &view_axis[1], &view_axis[2]);

		auto& spread_angles = get_bullet_end_pos(
			game::BG_srand(&rand_seed),
			view_axis,
			get_aim_spread_amount(ps, cmd->weapon),
			game::get_weapon_damage_range(ps, cmd->weapon));

		spread_angles = math::angle_delta(game::cg()->gunAngles, spread_angles);

		return spread_angles;
	}
}