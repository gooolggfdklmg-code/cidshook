#pragma once
#include "dependencies/stdafx.hpp"
#include "../session/session.hpp"

namespace friends
{
	struct friend_info
	{
		std::uint64_t id;
		std::string name;
		std::string ip_data;
		std::string nickname;
		std::set<std::string> ip_aliases;
		std::time_t last_online;
		session::pong_response response;

		bool is_online() const
		{
			return response.netadr.addr.inaddr;
		}
		
		bool operator<(const friend_info& other) const
		{
			if (is_online())
			{
				return is_online() > other.is_online();
			}
			
			return last_online > other.last_online;
		}
	}; 

	NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(friend_info, id, name, ip_data, nickname, ip_aliases, last_online)

	friend_info* get(const std::uint64_t id);
	friend_info* get_by_ip(const game::netadr_t& target);
	void write();
	void draw_friends_list(const float width, const float spacing);
	void initialize();
	
	extern std::vector<friend_info> friends;
	constexpr auto FETCHSESSION_NONCE{ 0x696969 };
}