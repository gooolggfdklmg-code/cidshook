#include "dependencies/stdafx.hpp"
#include "logger.hpp"

namespace logger
{
	std::string get_log_message(const std::string& message)
	{
		auto log_message{ "[" + utils::string::data_time(0, false) + "]" };
		log_message.push_back(' ');
		log_message.append(message);
		log_message.push_back('\n');
		return log_message;
	}
	
	void print_log(const char* msg, ...)
	{
		va_list ap;
		va_start(ap, msg);
		const auto result = utils::string::format(ap, msg);
		va_end(ap);

		const static auto file = utils::string::get_log_file("logs");
		utils::io::write_file(file, get_log_message(result), true);
	}

	void print_sv_log(const char* msg, ...)
	{
		va_list ap;
		va_start(ap, msg);
		const auto result = utils::string::format(ap, msg);
		va_end(ap);

		const static auto file = utils::string::get_log_file("logs/server");
		utils::io::write_file(file, get_log_message(result), true);
	}
}