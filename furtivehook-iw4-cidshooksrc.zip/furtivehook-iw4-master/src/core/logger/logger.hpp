#pragma once
#include "dependencies/stdafx.hpp"

namespace logger
{
	void print_log(const char* msg, ...);
	void print_sv_log(const char * msg, ...);
}